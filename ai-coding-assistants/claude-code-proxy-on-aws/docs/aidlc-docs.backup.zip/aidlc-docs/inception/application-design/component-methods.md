# Component Methods — Claude Code Proxy on AWS

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Components](./components.md), [Requirements v1.1](../requirements/requirements.md), [API Spec v0.4](../../../docs/API_SPEC.md)

> **Note**: 상세 비즈니스 규칙은 Functional Design (CONSTRUCTION phase)에서 정의합니다. 본 문서는 메서드 시그니처와 고수준 목적만 다룹니다.

---

## C2. Lambda Token Service

### VirtualKeyService

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `get_or_create_key(principal_info)` | IAM Principal 정보 | VirtualKeyResponse | 활성 키 조회 또는 신규 생성 |

### UserLookupService

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `resolve_user(principal_info)` | IAM Principal 정보 | User | identity_store_user_id 기반 사용자 조회 |
| `validate_user_active(user)` | User | bool | ACTIVE 상태 확인 |

### KmsHelper (shared/utils)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `encrypt_key(plaintext_key)` | str | bytes | KMS Encrypt로 키 암호화 |
| `decrypt_key(ciphertext)` | bytes | str | KMS Decrypt로 키 복호화 |
| `generate_fingerprint(plaintext_key)` | str | str | SHA-256 fingerprint 생성 |

---

## C3. FastAPI LLM Gateway

### GatewayService (runtime/services.py)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `process_message(request, api_key)` | AnthropicRequest, str | AnthropicResponse | 비스트리밍 요청 전체 처리 오케스트레이션 |
| `process_message_stream(request, api_key)` | AnthropicRequest, str | AsyncGenerator[SSEEvent] | 스트리밍 요청 전체 처리 오케스트레이션 |
| `list_models(api_key)` | str | ModelListResponse | caller 허용 모델 목록 반환 |

### PolicyChain (policy/engine.py) — Chain of Responsibility (Q2)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `evaluate(context)` | PolicyContext | PolicyResult | 10단계 정책 체인 순차 평가 (hard block / soft warn 포함) |

### 개별 정책 핸들러 (policy/handlers/)

| 핸들러 | 목적 |
|--------|------|
| `VirtualKeyHandler` | key_fingerprint 기반 키 유효성 + 사용자 identity 복원. 미존재/잘못된 키 → InvalidKeyError, REVOKED 상태 키 → KeyRevokedError. 외부 응답은 둘 다 401이지만 감사 로그에서 구분 |
| `UserStatusHandler` | 사용자 ACTIVE 상태 확인 |
| `TeamStatusHandler` | 팀 ACTIVE 상태 확인 (team-less 허용) |
| `ModelResolverHandler` | selected model → resolved model 해석 + fallback 적용 + 모델 메타데이터(supports_prompt_cache 등)를 PolicyContext에 enrichment |
| `UserModelPolicyHandler` | 사용자 override 기반 모델 허용/차단 평가 |
| `TeamModelPolicyHandler` | 팀 기본값 + 시스템 기본값 기반 모델 허용/차단 평가 |
| `UserBudgetPreCheckHandler` | 사용자 scope budget 사전 검사. hard limit 초과 → BudgetExceededError, soft limit 초과 → PolicyContext.warnings에 BudgetWarning 누적 |
| `TeamBudgetPreCheckHandler` | 팀 scope budget 사전 검사 (team-less면 no-op). hard/soft limit 처리는 UserBudgetPreCheckHandler와 동일 |
| `ModelBudgetPreCheckHandler` | model-specific budget 사전 검사. hard/soft limit 처리는 UserBudgetPreCheckHandler와 동일 |
| `CachePolicyHandler` | block-level cache_control 보존 + 최종 cache policy 해석 (none/5m/1h). PolicyContext에 enrichment된 모델 메타데이터(supports_prompt_cache)를 사용하여 미지원 모델은 자동 none downgrade |

### UsageService (usage/services.py)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `record_success(context, usage_info)` | RequestContext, UsageInfo | UsageEvent | 성공 요청 사용량 기록 + 예산 사후 정산 |
| `record_blocked_request(context, error)` | RequestContext, AppError | UsageEvent | Bedrock 호출 전 차단된 요청을 zero-token row로 기록 |
| `record_error(context, error, usage_info=None)` | RequestContext, AppError, UsageInfo \| None | UsageEvent | terminal error 요청 기록 (usage 미확정 시 zero-token) |

### AnthropicToBedrockConverter (runtime/converter/) — Q3: Request/Response 분리

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `convert_request(anthropic_req, resolved_model, cache_policy)` | AnthropicRequest, str, str | BedrockConverseRequest | Anthropic → Bedrock Converse 요청 변환 (thinking/outputConfig/cache 포함) |
| `convert_system(system)` | str \| list | list[SystemMessage] | system 필드 정규화 |
| `convert_messages(messages)` | list[Message] | list[BedrockMessage] | messages/content block 배열 변환 (text/tool_use/tool_result/image/document/thinking/redacted_thinking) |
| `convert_tools(tools, tool_choice)` | list[Tool], ToolChoice | ToolConfig | tools/tool_choice 변환 |
| `convert_thinking(thinking, prior_reasoning)` | dict \| None, dict \| None | dict \| None | additionalModelRequestFields.thinking 및 reasoning signature 재전달 변환 |
| `convert_output_config(output_format, output_config)` | dict \| None, dict \| None | dict \| None | Bedrock outputConfig 변환 |
| `apply_cache_points(request, cache_policy)` | BedrockConverseRequest, str | BedrockConverseRequest | block-level cache_control 보존 + top-level automatic caching 시 tools → system → messages 순서로 마지막 cacheable block에 cachePoint 삽입 |

### BedrockToAnthropicConverter (runtime/converter/)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `convert_response(bedrock_resp, selected_model)` | BedrockConverseResponse, str | AnthropicResponse | Bedrock → Anthropic 응답 변환 (usage/stop_reason/thinking 복원 포함) |
| `convert_stream_event(event, state)` | StreamEvent, StreamState | list[SSEEvent] | streaming event → Anthropic SSE 변환 (message delta/stop/final metadata 포함) |
| `extract_usage(response_or_metadata)` | dict | UsageInfo | usage 정보 추출 |

### StreamProcessor (runtime/streaming.py) — Q6: AsyncGenerator 기반

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `stream_response(bedrock_stream, context)` | AsyncIterator, RequestContext | AsyncGenerator[SSEEvent] | Bedrock 스트림 → Anthropic SSE 변환 |

### BedrockClient (runtime/services.py)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `converse(request)` | BedrockConverseRequest | BedrockConverseResponse | Bedrock Converse 동기 호출 |
| `converse_stream(request)` | BedrockConverseRequest | AsyncIterator[StreamEvent] | Bedrock ConverseStream 호출 |

> **호출 정책**: boto3/botocore client는 `max_attempts=1`로 구성하여 upstream 오류를 retry 없이 즉시 전파한다.

---

## C3/C4 공유 — Repository 레이어 (Q4)

| Repository | 주요 메서드 | 목적 |
|------------|------------|------|
| `UserRepository` | `get_by_id`, `get_by_identity_store_id`, `update_status`, `list_users` | 사용자 CRUD |
| `TeamRepository` | `get_by_id`, `create`, `update`, `list_teams` | 팀 CRUD |
| `TeamMembershipRepository` | `add_member`, `remove_member`, `get_memberships`, `get_default_team` | 멤버십 관리 |
| `VirtualKeyRepository` | `get_active_by_user`, `get_by_fingerprint`, `create`, `update_status` | 키 관리 |
| `ModelCatalogRepository` | `get_by_id`, `get_active`, `create`, `update_status` | 모델 카탈로그 |
| `ModelAliasMappingRepository` | `resolve_model`, `get_fallback`, `create`, `update` | 모델 매핑 |
| `ModelPricingRepository` | `get_active_pricing`, `create` | 가격 정책 |
| `UserModelPolicyRepository` | `get_policy`, `set_policy` | 사용자 모델 정책 |
| `TeamModelPolicyRepository` | `get_policy`, `set_policy` | 팀 모델 정책 |
| `BudgetPolicyRepository` | `get_applicable_policies`, `create`, `update`, `check_policies`, `apply_costs` | 예산 관리 (user/team/model scope, hard/soft limit). exact scope + period + model 당 active policy는 최대 1개이며, `budget_policies.current_used_usd` + `window_started_at`을 사용해 현재 기간 누적 비용을 원자적으로 갱신한다. |
| `UsageEventRepository` | `create_event`, `list_events` | 사용량 이벤트 |
| `UsageAggRepository` | `get_daily`, `get_monthly`, `upsert_daily`, `upsert_monthly` | 집계 (배치 전용) |
| `AuditEventRepository` | `create_event`, `list_events` | 감사 이벤트 |
| `IdentitySyncRunRepository` | `create_run`, `update_run`, `get_latest` | sync 이력 |

---

## C4. Admin API Services

| 서비스 | 주요 메서드 | 목적 |
|--------|------------|------|
| `AdminUserService` | `list_users`, `get_user`, `update_user`, `set_runtime_policy` | 사용자 관리 |
| `AdminTeamService` | `list_teams`, `create_team`, `update_team`, `set_runtime_policy`, `add_member`, `remove_member` | 팀/멤버십 관리 |
| `AdminModelService` | `list_models`, `create_model`, `update_model`, `create_mapping`, `update_mapping`, `set_pricing` | 모델 관리 |
| `AdminBudgetService` | `list_budgets`, `create_budget`, `update_budget`, `get_budget_status` | 예산 관리 |
| `AdminVirtualKeyService` | `list_keys`, `get_key`, `rotate_key`, `revoke_key` | Virtual Key metadata 조회 및 admin lifecycle 관리 |
| `AdminUsageService` | `list_events`, `get_aggregates`, `trigger_rollup` | 사용량 조회 + 집계 배치 트리거 |
| `IdentitySyncService` | `run_sync`, `get_sync_status` | Identity Center sync |

---

## C6. Observability — MetricsService (Q9)

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `emit_token_usage(context, usage)` | RequestContext, UsageInfo | None | `bedrock.token.usage` Counter emit |
| `emit_cost_usage(context, cost)` | RequestContext, Decimal | None | `bedrock.cost.usage` Counter emit |
| `emit_request_duration(context, latency_ms)` | RequestContext, int | None | `bedrock.request.duration` Histogram emit |

---

## 예산 트랜잭션 패턴 (Q7: 분리 트랜잭션)

```
1. [읽기 트랜잭션] PolicyChain.evaluate()
   - user/team/model budget handlers가 applicable policy를 계산하고 SELECT 기반 pre-check 수행
   - hard limit 초과 → 즉시 block, soft limit 초과 → warning만 context에 기록
2. [Bedrock 호출] BedrockClient.converse() / converse_stream() (max_attempts=1)
3. [쓰기 트랜잭션] BudgetPolicyRepository.apply_costs() → applicable hard-limit counter들을 원자적으로 UPDATE ... RETURNING
4. [쓰기 트랜잭션] UsageEventRepository.create_event() → terminal request row INSERT
5. [배치] UsageAggRepository.upsert_daily/monthly() → reporting rollup만 담당 (runtime hot path 제외)
6. [트랜잭션 외부] MetricsService.emit_*() → upstream usage/latency가 있는 경우만 emit
```

## 차단/오류 요청 기록 패턴

```
1. Policy/App error 발생
2. UsageService.record_blocked_request() 또는 record_error() 호출
3. zero-token 또는 partial-usage usage_events row 기록
4. Bedrock 호출이 없거나 upstream usage/latency가 없으면 bedrock.* metric은 emit하지 않음
```
