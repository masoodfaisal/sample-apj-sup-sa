# Unit of Work — Claude Code Proxy on AWS

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Application Design](./application-design.md), [Requirements v1.1](../requirements/requirements.md), [User Stories v1.1](../user-stories/stories.md)

---

## 1. 유닛 구성 결정

| 항목 | 결정 |
|------|------|
| 유닛 수 | 4개 |
| 구현 순서 | 의존성 순서 (Unit 1 → 2 → 3 → 4) |
| 구현 방식 | 순차 구현 |
| CDK 인프라 할당 | Unit 1에 CDK 전체 집중, 다른 유닛은 애플리케이션 코드만 |

---

## 2. 유닛 정의

### Unit 1: Foundation Infrastructure

**범위**: AWS 리소스 프로비저닝 및 구성 관리 (CDK Python 5개 스택 전체)

**책임**:
- VPC, 서브넷(public/private app/private data), VPC Endpoints, 보안 그룹 (NetworkStack)
- Aurora PostgreSQL Serverless v2, RDS Proxy, Secrets Manager (DataStack)
- ECS Cluster, Fargate Service(skeleton), Lambda Function(skeleton) (ComputeStack)
- API Gateway, ALB, Target Groups (ApiStack)
- AMP Workspace, ADOT 설정 (ObservabilityStack)
- IAM 역할/정책, KMS Key
- VPC Endpoint policy 설정

**컴포넌트**: C1 (CDK Infrastructure)

**산출물**:
- `infra/app.py` — CDK App 진입점
- `infra/stacks/network_stack.py`
- `infra/stacks/data_stack.py`
- `infra/stacks/compute_stack.py`
- `infra/stacks/api_stack.py`
- `infra/stacks/observability_stack.py`

**참고**: ComputeStack의 ECS task definition과 Lambda function definition은 skeleton으로 정의. 컨테이너 이미지, 환경변수, health check 경로 등 애플리케이션 의존 설정은 Unit 3/4 구현 후 보완.

---

### Unit 2: Shared Models & DB Migration

**범위**: SQLAlchemy ORM 모델, Alembic 마이그레이션, 공통 유틸리티

**책임**:
- 14개 테이블에 대한 SQLAlchemy ORM 모델 정의
- Alembic 마이그레이션 환경 설정 및 초기 마이그레이션 스크립트
- KMS 헬퍼 (encrypt_key, decrypt_key, generate_fingerprint)
- 해시 유틸리티, 상수 정의
- 공통 Pydantic 스키마/DTO 정의
- Docker Compose 로컬 개발 환경 (PostgreSQL)
- pyproject.toml, uv 프로젝트 설정

**컴포넌트**: C5 (Shared Models & Migration)

**산출물**:
- `shared/models/` — user.py, team.py, virtual_key.py, model_catalog.py, budget.py, usage.py, audit.py
- `shared/schemas/` — 공통 Pydantic 스키마
- `shared/utils/` — KMS 헬퍼, 해시, 상수
- `migrations/` — Alembic 환경 + 초기 마이그레이션
- `docker-compose.yml` — 로컬 PostgreSQL
- `pyproject.toml`, `uv.lock`
- `tests/` — 모델/유틸리티 단위 테스트

---

### Unit 3: Token Service

**범위**: Lambda 기반 Virtual Key 발급/조회 서비스

**책임**:
- Lambda 핸들러 (API Gateway event 처리)
- IAM Principal에서 사용자 식별자 추출
- UserLookupService (resolve_user, validate_user_active)
- VirtualKeyService (get_or_create_key)
- KMS 기반 키 암호화/복호화
- SHA-256 fingerprint 생성
- audit_events 기록
- shared/ 패키지 import

**컴포넌트**: C2 (Lambda Token Service)

**산출물**:
- `lambda/handler.py` — Lambda 진입점
- `lambda/services/virtual_key_service.py`
- `lambda/services/user_lookup_service.py`
- `tests/` — Lambda 서비스 단위 테스트
- `infra/` 보완 — ComputeStack Lambda 설정 확정 (함수 코드 경로, 환경변수, IAM 역할)

---

### Unit 4: Gateway (Runtime + Admin + Observability)

**범위**: FastAPI 기반 LLM Gateway, Admin API, Identity Sync, Observability

**책임**:

*Runtime Gateway (C3)*:
- FastAPI 앱 골격 (`main.py`, `core/`)
- Virtual Key 기반 인증 (x-api-key)
- 10단계 정책 평가 체인 (PolicyChain + 10개 핸들러)
- Anthropic → Bedrock Converse 요청 변환 (AnthropicToBedrockConverter)
- Bedrock → Anthropic 응답 변환 (BedrockToAnthropicConverter)
- BedrockClient (Converse/ConverseStream, max_attempts=1)
- SSE 스트리밍 처리 (StreamProcessor)
- GatewayService 오케스트레이션
- `POST /v1/messages`, `GET /v1/models`, `GET /healthz`
- 커스텀 예외 계층 + Anthropic-compatible 에러 응답

*Usage & Budget (C3 일부)*:
- UsageService (record_success, record_blocked_request, record_error)
- 예산 사후 정산 (BudgetPolicyRepository.apply_costs)
- UsageRollupService (배치, Admin API 트리거)

*Admin API (C4)*:
- AdminUserService — 사용자 관리
- AdminTeamService — 팀/멤버십 관리
- AdminModelService — 모델/매핑/가격 관리
- AdminBudgetService — 예산 정책 관리
- AdminVirtualKeyService — Virtual Key admin lifecycle
- AdminUsageService — 사용량 조회 + 집계 배치 트리거
- IdentitySyncService — Identity Center 사용자 sync
- `/v1/admin/*` 라우트

*Observability (C6)*:
- MetricsService — OTel SDK 래퍼, 3개 primary metric emit
- OTLP gRPC push (localhost:4317)

*공유 레이어*:
- Repository 레이어 (14개 Repository 클래스)
- FastAPI Depends 기반 DI
- DB 세션 관리 (단일 세션 + 명시적 commit)

**컴포넌트**: C3, C4, C6

**산출물**:
- `gateway/main.py`
- `gateway/core/` — config.py, database.py, dependencies.py, exceptions.py
- `gateway/domains/runtime/` — router.py, services.py, converter/, streaming.py
- `gateway/domains/policy/` — engine.py, handlers/
- `gateway/domains/admin/` — router.py, users.py, teams.py, models.py, budgets.py, virtual_keys.py, usage.py
- `gateway/domains/sync/` — router.py, services.py
- `gateway/domains/usage/` — services.py, metrics.py, rollup.py
- `gateway/repositories/` — 14개 Repository
- `Dockerfile`
- `tests/` — Gateway/Admin/Policy 단위 테스트
- `infra/` 보완 — ComputeStack ECS 설정 확정 (컨테이너 이미지, 환경변수, health check, ADOT sidecar)

---

## 3. 유닛 크기 비교

| 유닛 | 예상 파일 수 | 복잡도 | 비고 |
|------|-------------|--------|------|
| Unit 1 | ~10 | Medium | CDK 스택 5개 + constructs |
| Unit 2 | ~15 | Low-Medium | ORM 모델 7개 + 마이그레이션 + 유틸 |
| Unit 3 | ~5 | Low | Lambda 핸들러 + 서비스 2개 |
| Unit 4 | ~35 | High | Runtime + Admin + Observability + Repository 14개 |

Unit 4가 가장 크지만, Unit 1~3이 완료된 상태에서 시작하므로 인프라, DB 모델, 공통 유틸이 모두 갖춰진 환경에서 애플리케이션 로직에 집중할 수 있다.

---

## 4. 구현 순서 및 의존성

```
Unit 1: Foundation Infrastructure
  │ CDK 전체 (VPC, Aurora, ECS skeleton, Lambda skeleton, API GW, ALB, AMP)
  ▼
Unit 2: Shared Models & DB Migration
  │ SQLAlchemy 모델, Alembic, 공통 유틸 (Unit 1의 Aurora/RDS Proxy 필요)
  ▼
Unit 3: Token Service
  │ Lambda + Virtual Key (Unit 2의 모델/유틸 필요, Unit 1의 Lambda skeleton 보완)
  ▼
Unit 4: Gateway (Runtime + Admin + Observability)
  │ FastAPI 전체 (Unit 2의 모델/유틸 필요, Unit 1의 ECS skeleton 보완)
  ▼
[완료]
```
