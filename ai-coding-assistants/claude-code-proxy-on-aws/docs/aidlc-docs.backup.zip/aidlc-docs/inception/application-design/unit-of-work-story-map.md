# Unit of Work — Story Map

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Unit of Work](./unit-of-work.md), [User Stories v1.1](../user-stories/stories.md)

---

## 1. 유닛별 스토리 매핑

### Unit 1: Foundation Infrastructure

| Story ID | 제목 | 매핑 근거 |
|----------|------|-----------|
| 4.1 | TLS 통신 보장 | ALB/API Gateway TLS 설정, VPC Endpoint HTTPS |
| 4.3 | 보안 정책 준수 확인 | VPC Endpoint policy, 보안 그룹, IAM 최소 권한 |

---

### Unit 2: Shared Models & DB Migration

| Story ID | 제목 | 매핑 근거 |
|----------|------|-----------|
| — | (직접 매핑 스토리 없음) | 인프라성 유닛. Unit 3/4의 모든 스토리가 간접 의존 |

> Unit 2는 DB 모델과 유틸리티를 제공하는 기반 유닛으로, 모든 기능 스토리의 전제 조건이지만 특정 스토리에 직접 매핑되지 않는다.

---

### Unit 3: Token Service

| Story ID | 제목 | 매핑 근거 |
|----------|------|-----------|
| 1.1 | SSO 인증 후 Virtual Key 발급 | Lambda Virtual Key 발급/조회 |
| 1.2 | Virtual Key로 Gateway 접근 | Virtual Key 생성 (Gateway 검증은 Unit 4) |
| 1.5 | Virtual Key 관리 | Virtual Key rotate/revoke (Admin API 경로는 Unit 4) |

---

### Unit 4: Gateway (Runtime + Admin + Observability)

| Story ID | 제목 | 매핑 근거 |
|----------|------|-----------|
| 1.2 | Virtual Key로 Gateway 접근 | Gateway Virtual Key 검증 (VirtualKeyHandler) |
| 1.3 | Claude Code 호환 Gateway 호출 | Anthropic↔Bedrock 변환, 스트리밍 |
| 1.4 | 모델 매핑 및 Fallback | ModelResolverHandler, model_alias_mappings |
| 1.5 | Virtual Key 관리 | Admin API: Virtual Key metadata 조회/rotate/revoke 엔드포인트 |
| 1.6 | 기본 모델 카탈로그 등록 | Admin API: 모델 등록 |
| 2.1 | Identity Center 사용자 동기화 | IdentitySyncService, Admin API sync 엔드포인트 |
| 2.2 | 사용자 활성화/비활성화 | AdminUserService, UserStatusHandler |
| 2.3 | 팀 생성 및 관리 | AdminTeamService |
| 2.4 | 팀 멤버십 관리 | AdminTeamService (멤버십), TeamStatusHandler |
| 2.5 | 모델 카탈로그 확장 관리 | AdminModelService |
| 2.6 | 모델 허용 정책 | UserModelPolicyHandler, TeamModelPolicyHandler |
| 2.7 | 모델 별칭 매핑 | AdminModelService (매핑 관리) |
| 2.8 | 예산 정책 생성 | AdminBudgetService |
| 2.9 | 예산 초과 차단 | UserBudgetPreCheckHandler, TeamBudgetPreCheckHandler, ModelBudgetPreCheckHandler, BudgetPolicyRepository.apply_costs |
| 2.10 | 캐시 정책 설정 | CachePolicyHandler, Admin API 캐시 정책 설정 |
| 3.1 | 토큰 사용량 저장 및 조회 | UsageService, AdminUsageService, UsageRollupService |
| 3.2 | ADOT 메트릭 전송 | MetricsService, ADOT sidecar 연동 |
| 3.3 | 감사 로그 기록 | AuditEventRepository, 각 서비스의 audit 기록 |
| 4.2 | 접근 통제 모니터링 | 감사 이벤트 기록, 인증 실패 로그 |
| 4.4 | 장애 원인 추적 | request_id 기반 로그/메트릭 correlation |

---

## 2. 스토리 커버리지 검증

### 전체 스토리 (23개)

| Story ID | 제목 | 할당 유닛 |
|----------|------|-----------|
| 1.1 | SSO 인증 후 Virtual Key 발급 | Unit 3 |
| 1.2 | Virtual Key로 Gateway 접근 | Unit 3 + Unit 4 |
| 1.3 | Claude Code 호환 Gateway 호출 | Unit 4 |
| 1.4 | 모델 매핑 및 Fallback | Unit 4 |
| 1.5 | Virtual Key 관리 | Unit 3 + Unit 4 |
| 1.6 | 기본 모델 카탈로그 등록 | Unit 4 |
| 2.1 | Identity Center 사용자 동기화 | Unit 4 |
| 2.2 | 사용자 활성화/비활성화 | Unit 4 |
| 2.3 | 팀 생성 및 관리 | Unit 4 |
| 2.4 | 팀 멤버십 관리 | Unit 4 |
| 2.5 | 모델 카탈로그 확장 관리 | Unit 4 |
| 2.6 | 모델 허용 정책 | Unit 4 |
| 2.7 | 모델 별칭 매핑 | Unit 4 |
| 2.8 | 예산 정책 생성 | Unit 4 |
| 2.9 | 예산 초과 차단 | Unit 4 |
| 2.10 | 캐시 정책 설정 | Unit 4 |
| 3.1 | 토큰 사용량 저장 및 조회 | Unit 4 |
| 3.2 | ADOT 메트릭 전송 | Unit 4 |
| 3.3 | 감사 로그 기록 | Unit 4 |
| 4.1 | TLS 통신 보장 | Unit 1 |
| 4.2 | 접근 통제 모니터링 | Unit 4 |
| 4.3 | 보안 정책 준수 확인 | Unit 1 |
| 4.4 | 장애 원인 추적 | Unit 4 |

### 커버리지 결과

- **총 스토리**: 23개
- **할당 완료**: 23개 (100%)
- **미할당**: 0개
- **복수 유닛 할당**: 2개 (Story 1.2, 1.5 — Token Service + Gateway에 걸쳐 있음)

---

## 3. 유닛별 스토리 수 요약

| 유닛 | 스토리 수 | 비고 |
|------|-----------|------|
| Unit 1: Foundation Infrastructure | 2 | NFR 스토리 (TLS, 보안 정책) |
| Unit 2: Shared Models & Migration | 0 | 기반 유닛, 간접 의존 |
| Unit 3: Token Service | 3 | Virtual Key 발급/관리 (일부 Unit 4와 공유) |
| Unit 4: Gateway | 20 | Runtime + Admin + Observability 전체 |

> Unit 4의 스토리 수가 가장 많지만, Unit 1~3이 완료된 환경에서 애플리케이션 로직에만 집중하므로 관리 가능하다.
