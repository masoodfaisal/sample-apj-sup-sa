# Components — Claude Code Proxy on AWS

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Application Design Plan](../plans/application-design-plan.md), [Requirements v1.1](../requirements/requirements.md)

---

## 1. 컴포넌트 개요

시스템은 6개 주요 컴포넌트로 구성되며, 각 컴포넌트는 명확한 책임 경계를 가진다.

| # | 컴포넌트 | 런타임 | 주요 책임 |
|---|----------|--------|-----------|
| C1 | CDK Infrastructure | CDK Python | VPC, 서브넷, VPC Endpoints, Aurora, RDS Proxy, ECS, Lambda, API Gateway, ALB, AMP |
| C2 | Lambda Token Service | Lambda (Python) | SigV4 인증 검증, 사용자 식별, Virtual Key 발급/조회 |
| C3 | FastAPI LLM Gateway | ECS Fargate (Python) | 정책 평가, Anthropic→Bedrock 변환, 스트리밍, 사용량 기록 |
| C4 | Admin API | ECS Fargate (Python, C3과 동일 프로세스) | 사용자/팀/모델/예산/캐시/Virtual Key 관리, Identity Sync |
| C5 | Shared Models & Migration | Python 패키지 | SQLAlchemy 모델, Alembic 마이그레이션, 공통 유틸리티 |
| C6 | Observability | ECS Sidecar + SDK | ADOT Collector, OTel 메트릭 계측, AMP remote write |

---

## 2. 컴포넌트 상세

### C1. CDK Infrastructure

**책임**:
- AWS 리소스 프로비저닝 및 구성 관리
- 네트워크 토폴로지 정의 (VPC, 서브넷, VPC Endpoints)
- 컴퓨트 리소스 정의 (ECS Fargate, Lambda)
- 데이터 리소스 정의 (Aurora Serverless v2, RDS Proxy)
- API 진입점 정의 (API Gateway, ALB)
- 관측 리소스 정의 (AMP workspace)
- IAM 역할 및 정책 관리

**스택 구조** (Q8: 계층별 분할):
- `NetworkStack` — VPC, 서브넷, VPC Endpoints, 보안 그룹
- `DataStack` — Aurora Serverless v2, RDS Proxy, Secrets Manager
- `ComputeStack` — ECS Cluster, Fargate Service, Lambda Function
- `ApiStack` — API Gateway, ALB, Target Groups
- `ObservabilityStack` — AMP Workspace, ADOT 설정

**인터페이스**: CDK CLI (`cdk deploy`, `cdk diff`)

---

### C2. Lambda Token Service

**책임**:
- API Gateway IAM Auth + SigV4 검증된 요청 수신
- IAM Principal에서 사용자 식별자 추출
- users 테이블에서 사용자 상태 확인 (ACTIVE만 허용)
- virtual_keys 테이블에서 활성 키 조회 또는 신규 생성
- KMS Encrypt/Decrypt를 통한 키 암호화/복호화
- key issuance/get-or-create 도메인 규칙 제공
- audit_events 기록 (키 생성 등)

**내부 구조**:
- `lambda/handler.py` — Lambda 진입점
- `lambda/services/` — VirtualKeyService, UserLookupService
- shared/ 패키지 import (SQLAlchemy 모델, KMS 유틸리티)

**인터페이스**: API Gateway → Lambda invocation

---

### C3. FastAPI LLM Gateway

**책임**:
- Virtual Key 기반 인증 (x-api-key 헤더)
- 10단계 정책 평가 체인 (Chain of Responsibility)
- Anthropic-compatible 요청 → Bedrock Converse 변환
- Bedrock Converse/ConverseStream 호출
- Bedrock 응답 → Anthropic-compatible 응답 변환
- SSE 스트리밍 응답 생성
- usage_events 저장 및 예산 사후 정산
- MetricsService를 통한 OTel 메트릭 emit
- reporting 집계는 별도 배치 경로에서 처리

**내부 구조** (Q1: 도메인별 모듈 분리):
```
gateway/
├── domains/
│   ├── runtime/          # LLM Gateway 도메인
│   │   ├── router.py     # POST /v1/messages, GET /v1/models, GET /healthz
│   │   ├── services.py   # GatewayService (오케스트레이션)
│   │   ├── converter/    # Anthropic↔Bedrock 변환
│   │   └── streaming.py  # SSE 스트리밍 처리
│   ├── policy/           # 정책 평가 도메인
│   │   ├── engine.py     # PolicyChain (Chain of Responsibility)
│   │   └── handlers/     # 개별 정책 핸들러
│   └── usage/            # 사용량 도메인
│       ├── services.py   # UsageService
│       ├── metrics.py    # MetricsService
│       └── rollup.py     # UsageRollupService (배치)
├── core/                 # 공통 인프라
│   ├── config.py         # 설정
│   ├── database.py       # DB 세션 관리
│   ├── dependencies.py   # FastAPI Depends 정의
│   └── exceptions.py     # 커스텀 예외 계층
├── repositories/         # 공유 Repository 레이어
└── main.py               # FastAPI 앱 진입점
```

**인터페이스**: ALB → ECS Fargate (HTTP)

---

### C4. Admin API

**책임**:
- 사용자 조회/활성화/비활성화 및 정책 override 관리
- 팀 생성/조회/비활성화 및 멤버십 관리
- 모델 카탈로그 등록/비활성화
- 모델 별칭 매핑 관리
- 모델 가격 정책 관리
- 예산 정책 생성/수정 및 예산 상태 조회
- 캐시 정책 설정
- Virtual Key metadata 조회/회전/폐기
- Identity Center 사용자 sync 실행
- 사용량 조회 (이벤트 상세 + 집계)

**내부 구조** (Q1: 도메인별 모듈 분리, C3과 동일 프로세스):
```
gateway/
├── domains/
│   ├── admin/            # Admin API 도메인
│   │   ├── router.py     # /v1/admin/* 라우트
│   │   ├── users.py      # 사용자 관리 서비스
│   │   ├── teams.py      # 팀/멤버십 관리 서비스
│   │   ├── models.py     # 모델/매핑/가격 관리 서비스
│   │   ├── budgets.py    # 예산 정책 관리 서비스
│   │   ├── virtual_keys.py # Virtual Key admin lifecycle 서비스
│   │   └── usage.py      # 사용량 조회 서비스
│   └── sync/             # Identity Sync 도메인
│       ├── router.py     # /v1/admin/sync/* 라우트
│       └── services.py   # IdentitySyncService
```

**인터페이스**: API Gateway (SigV4) → ALB → ECS Fargate (HTTP)

---

### C5. Shared Models & Migration

**책임**:
- SQLAlchemy ORM 모델 정의 (14개 테이블)
- Alembic 마이그레이션 스크립트 관리
- 공통 유틸리티 (KMS 헬퍼, 해시 유틸리티, 상수)
- 공통 스키마/DTO 정의

**내부 구조** (Q5: shared/ 패키지):
```
shared/
├── models/               # SQLAlchemy ORM 모델
│   ├── user.py
│   ├── team.py
│   ├── virtual_key.py
│   ├── model_catalog.py
│   ├── budget.py
│   ├── usage.py
│   └── audit.py
├── schemas/              # Pydantic 스키마 (공통)
├── utils/                # KMS, 해시, 상수
└── __init__.py
migrations/               # Alembic
├── alembic.ini
├── env.py
└── versions/
```

**인터페이스**: Python import (Lambda, Gateway 모두에서 사용)

---

### C6. Observability

**책임**:
- ADOT Collector Sidecar 설정 및 운영
- OTel SDK 기반 메트릭 계측 (MetricsService)
- 3개 primary metric emit: `bedrock.token.usage`, `bedrock.cost.usage`, `bedrock.request.duration`
- OTLP gRPC push (localhost:4317)
- AMP remote write (VPC Endpoint 경유)

**내부 구조** (Q9: 전용 MetricsService):
- `gateway/domains/usage/metrics.py` — MetricsService (OTel SDK 래퍼)
- ADOT Collector 설정 파일 (ECS task definition 내 sidecar)

**인터페이스**: Gateway → OTLP gRPC → ADOT → AMP remote write
