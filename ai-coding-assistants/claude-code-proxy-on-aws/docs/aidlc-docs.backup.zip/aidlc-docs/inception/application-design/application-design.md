# Application Design — Claude Code Proxy on AWS (통합 문서)

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 상세 문서: [components.md](./components.md), [component-methods.md](./component-methods.md), [services.md](./services.md), [component-dependency.md](./component-dependency.md)
- 근거: [Requirements v1.1](../requirements/requirements.md), [User Stories v1.1](../user-stories/stories.md), [Application Design Plan](../plans/application-design-plan.md)

---

## 1. 설계 결정 요약

| 질문 | 결정 | 선택지 |
|------|------|--------|
| Q1. Gateway/Admin 코드 구조 | 도메인별 모듈 분리 | B |
| Q2. 정책 평가 패턴 | Chain of Responsibility | A |
| Q3. 프로토콜 변환 구조 | Request/Response 분리 | B |
| Q4. DB 접근 패턴 | Repository 패턴 | A |
| Q5. Lambda-Gateway 코드 공유 | shared/ 패키지 | A |
| Q6. 스트리밍 처리 | AsyncGenerator 기반 | A |
| Q7. 예산 트랜잭션 경계 | 분리 트랜잭션 | B |
| Q8. CDK 스택 분할 | 계층별 분할 (5개 스택) | B |
| Q9. OTel 메트릭 위치 | 전용 MetricsService | B |
| Q10. DI 전략 | FastAPI Depends | A |
| Q11. 에러 처리 | 커스텀 예외 계층 | A |

---

## 2. 시스템 구조 개요

### 2.1 컴포넌트 구성

| 컴포넌트 | 런타임 | 주요 책임 |
|----------|--------|-----------|
| CDK Infrastructure | CDK Python (5개 스택) | AWS 리소스 프로비저닝 |
| Lambda Token Service | Lambda (Python, VPC 연결) | SigV4 인증, Virtual Key 발급/조회 |
| FastAPI LLM Gateway | ECS Fargate | 정책 평가, 프로토콜 변환, 스트리밍, 사용량 기록 |
| Admin API | ECS Fargate (Gateway와 동일 프로세스) | 사용자/팀/모델/예산/캐시/Virtual Key 관리, Identity Sync |
| Shared Models & Migration | Python 패키지 | SQLAlchemy 모델, Alembic, 공통 유틸리티 |
| Observability | ECS Sidecar + OTel SDK | ADOT Collector, 메트릭 계측 |

### 2.2 프로젝트 디렉토리 구조

```
claude-code-proxy-on-aws/
├── infra/                          # CDK Python
│   ├── app.py                      # CDK App 진입점
│   ├── stacks/
│   │   ├── network_stack.py        # VPC, Subnets, Endpoints, SG
│   │   ├── data_stack.py           # Aurora, RDS Proxy, Secrets
│   │   ├── compute_stack.py        # ECS, Lambda
│   │   ├── api_stack.py            # API Gateway, ALB
│   │   └── observability_stack.py  # AMP, ADOT config
├── gateway/                        # FastAPI (Gateway + Admin)
│   ├── main.py                     # FastAPI 앱 진입점
│   ├── core/                       # 공통 인프라
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── dependencies.py
│   │   └── exceptions.py
│   ├── domains/
│   │   ├── runtime/                # LLM Gateway
│   │   │   ├── router.py
│   │   │   ├── services.py
│   │   │   ├── converter/
│   │   │   │   ├── request_converter.py
│   │   │   │   └── response_converter.py
│   │   │   └── streaming.py
│   │   ├── policy/                 # 정책 평가
│   │   │   ├── engine.py
│   │   │   └── handlers/
│   │   ├── admin/                  # Admin API
│   │   │   ├── router.py
│   │   │   ├── users.py
│   │   │   ├── teams.py
│   │   │   ├── models.py
│   │   │   ├── budgets.py
│   │   │   ├── virtual_keys.py
│   │   │   └── usage.py
│   │   ├── sync/                   # Identity Sync
│   │   │   ├── router.py
│   │   │   └── services.py
│   │   └── usage/                  # 사용량/메트릭
│   │       ├── services.py
│   │       ├── metrics.py
│   │       └── rollup.py
│   └── repositories/               # 공유 Repository
├── lambda/                         # Lambda Token Service
│   ├── handler.py
│   └── services/
├── shared/                         # 공통 모듈
│   ├── models/                     # SQLAlchemy ORM
│   ├── schemas/                    # Pydantic 스키마
│   └── utils/                      # KMS, 해시, 상수
├── migrations/                     # Alembic
├── tests/                          # pytest
├── docker-compose.yml
├── pyproject.toml
└── uv.lock
```

---

## 3. 핵심 설계 패턴

### 3.1 Chain of Responsibility — 정책 평가

10단계 정책 체인이 `PolicyContext`를 순차 검증/enrichment한다. hard limit/정책 차단은 즉시 예외를 raise하고, soft limit 초과는 경고를 context에 누적한 뒤 요청을 계속 진행한다.

### 3.2 Repository 패턴 — 데이터 접근

14개 엔터티에 대한 Repository 클래스. 서비스 레이어와 DB 접근을 분리하여 테스트 용이성 확보.

### 3.3 분리 트랜잭션 — 예산 관리

사전 검사(읽기)와 사후 정산(원자적 UPDATE)을 별도 트랜잭션으로 분리한다. Bedrock 호출 중 DB 커넥션 점유를 방지하고, reporting 집계는 hot path가 아니라 별도 배치로 처리한다.

### 3.4 커스텀 예외 계층 — 에러 처리

도메인별 예외 클래스 → FastAPI exception handler → Anthropic-compatible 에러 응답 변환.

### 3.5 AsyncGenerator — 스트리밍

Bedrock ConverseStream을 `async for`로 소비하고 Anthropic SSE 이벤트로 변환하여 yield.

---

## 4. CDK 스택 의존성

```
NetworkStack → DataStack → ObservabilityStack → ComputeStack → ApiStack
```

배포 순서: Network → Data → Observability → Compute → Api
(ComputeStack의 ADOT sidecar가 AMP remote write URL을 cross-stack 참조하므로 ObservabilityStack이 먼저 생성되어야 함)

---

## 5. 보안 설계 요약

- 모든 외부 통신 TLS (SECURITY-01)
- Virtual Key 평문 비저장, KMS 암호화 (SECURITY-01)
- IAM 최소 권한 (SECURITY-06)
- VPC Endpoint 기반 private connectivity (SECURITY-07)
- 커스텀 예외 계층으로 fail-closed (SECURITY-15)
- 구조화된 로깅, 민감정보 비저장 (SECURITY-03)
- 입력 검증: Pydantic 스키마 기반 (SECURITY-05)

---

## 6. 상세 문서 참조

- 컴포넌트 정의 및 책임: [components.md](./components.md)
- 메서드 시그니처 및 인터페이스: [component-methods.md](./component-methods.md)
- 서비스 정의 및 오케스트레이션: [services.md](./services.md)
- 의존성 관계 및 통신 패턴: [component-dependency.md](./component-dependency.md)
