# Services — Claude Code Proxy on AWS

- 문서 버전: v1.0
- 작성일: 2026-03-31
- 상태: Draft
- 근거: [Components](./components.md), [Component Methods](./component-methods.md)

---

## 1. 서비스 계층 개요

시스템의 서비스 계층은 3개 레벨로 구성된다.

| 레벨 | 역할 | 예시 |
|------|------|------|
| Orchestration Service | 비즈니스 흐름 조율, 여러 도메인 서비스 조합 | GatewayService |
| Domain Service | 단일 도메인의 비즈니스 로직 캡슐화 | PolicyChain, UsageService, UsageRollupService, IdentitySyncService |
| Repository | 데이터 접근 추상화 | UserRepository, BudgetPolicyRepository |

---

## 2. 서비스 정의

### 2.1 GatewayService (Orchestration)

**책임**: Runtime Gateway 요청의 전체 흐름을 오케스트레이션한다.

**오케스트레이션 흐름 (비스트리밍)**:
```
1. PolicyChain.evaluate(context)
   → Bedrock 호출 전 terminal error면 UsageService.record_blocked_request()/record_error() 후 예외 전파
2. AnthropicToBedrockConverter.convert_request(...)
3. BedrockClient.converse(request)   # boto3 max_attempts=1
4. BedrockToAnthropicConverter.convert_response(...)
5. UsageService.record_success(context, usage)
6. return AnthropicResponse
```

**오케스트레이션 흐름 (스트리밍)**:
```
1. PolicyChain.evaluate(context)
   → Bedrock 호출 전 terminal error면 UsageService.record_blocked_request()/record_error() 후 예외 전파
2. AnthropicToBedrockConverter.convert_request(...)
3. BedrockClient.converse_stream(request)   # boto3 max_attempts=1
4. StreamProcessor.stream_response(bedrock_stream, context)
   → 각 이벤트를 SSE로 변환하여 yield
   → final metadata 수신 시 UsageService.record_success() 호출
5. yield SSEEvent sequence
```

**에러 기록 원칙**:
- `BLOCKED_POLICY`, `BLOCKED_BUDGET`: Bedrock 호출 전 zero-token row 기록 후 예외 전파
- `ERROR`: upstream usage가 없으면 zero-token row, 있으면 partial usage row 기록
- 스트리밍 중 DB write 실패: 이미 클라이언트에 partial response를 전송한 상태이므로 클라이언트 응답은 정상 종료하고, 에러 로그 + 메트릭으로 usage 누락을 기록한다. 누락된 usage는 Bedrock Invocation Logging 기반 사후 보정 배치로 대응한다.

**의존성**: PolicyChain, AnthropicToBedrockConverter, BedrockToAnthropicConverter, BedrockClient, StreamProcessor, UsageService

---

### 2.2 PolicyChain (Domain — Chain of Responsibility)

**책임**: 10단계 정책 평가를 순차적으로 실행한다. 각 핸들러는 독립적이며, hard limit/정책 위반 시 즉시 중단하고 커스텀 예외를 raise한다. soft limit 초과는 경고를 context에 누적하고 요청을 계속 진행한다.

**핸들러 실행 순서**:
```
1. VirtualKeyHandler      → InvalidKeyError (미존재/잘못된 키) / KeyRevokedError (REVOKED 키)
2. UserStatusHandler       → UserInactiveError
3. TeamStatusHandler       → TeamInactiveError
4. ModelResolverHandler    → (모델 매핑 해석, fallback 적용)
5. UserModelPolicyHandler  → ModelNotAllowedError
6. TeamModelPolicyHandler  → ModelNotAllowedError
7. UserBudgetPreCheckHandler
                           → BudgetExceededError (hard) / PolicyContext.warnings에 BudgetWarning 누적 (soft)
8. TeamBudgetPreCheckHandler
                           → BudgetExceededError (hard) / PolicyContext.warnings에 BudgetWarning 누적 (soft)
9. ModelBudgetPreCheckHandler
                           → BudgetExceededError (hard) / PolicyContext.warnings에 BudgetWarning 누적 (soft)
10. CachePolicyHandler     → (cache_control 보존, unsupported model downgrade, context에 설정)
```

**설계 원칙**:
- 각 핸들러는 `PolicyHandler` 인터페이스를 구현
- 핸들러는 `PolicyContext`를 받아 검증/enrichment 수행
- 실패 시 도메인 예외 raise (fail-closed, SECURITY-15)
- soft limit 초과는 block이 아니라 warning으로만 기록
- 성공 시 다음 핸들러로 전달
- team-less user인 경우 팀 관련 핸들러는 no-op 또는 시스템 기본값 fallback으로 처리

---

### 2.3 UsageService (Domain)

**책임**: terminal request 기록, 예산 사후 정산, 메트릭 emit을 조율한다.

**성공 요청 흐름**:
```
1. 비용 계산: ModelPricingRepository.get_active_pricing() → cost 산출
2. 예산 사후 정산: BudgetPolicyRepository.apply_costs() → applicable policy 집합 원자적 UPDATE
3. 사용량 기록: UsageEventRepository.create_event()
4. 메트릭 emit: MetricsService.emit_token_usage/cost_usage/request_duration()
```

**차단/오류 요청 흐름**:
```
1. 정책/애플리케이션 예외 수신
2. UsageEventRepository.create_event() → zero-token 또는 partial-usage row 기록
3. Bedrock 호출이 없거나 upstream usage/latency가 없으면 bedrock.* metric은 emit하지 않음
```

**트랜잭션 경계** (Q7: 분리 트랜잭션 + Q13: 혼합 집계 전략):
- FastAPI Depends는 동일 request scope 내에서 단일 `AsyncSession`을 공유한다
- "분리 트랜잭션"은 별도 세션이 아니라 **동일 세션에서 명시적 commit/rollback으로 트랜잭션을 분리**하는 것을 의미한다:
  - PolicyChain.evaluate() 완료 후 `session.commit()` (읽기 트랜잭션 종료, DB 커넥션 idle)
  - Bedrock 호출 (DB 커넥션 미점유)
  - apply_costs() + create_event()를 단일 쓰기 트랜잭션으로 실행 후 `session.commit()`
- Step 4 (메트릭 emit)는 트랜잭션 외부에서 실행 (fire-and-forget이 아닌 best-effort)
- `usage_daily_agg`, `usage_monthly_agg`는 runtime hot path에서 갱신하지 않음
- reporting 집계는 별도 batch/maintenance 경로에서 `usage_events` 기반으로 rollup
- DB write 실패 시 request 실패 처리 (부분 성공 없음)

**의존성**: ModelPricingRepository, BudgetPolicyRepository, UsageEventRepository, MetricsService

---

### 2.4 UsageRollupService (Batch)

**책임**: `usage_events`를 기반으로 reporting 집계 테이블(`usage_daily_agg`, `usage_monthly_agg`)을 배치 갱신한다.

**트리거**: v1에서는 Admin API를 통한 수동 실행. 향후 EventBridge Schedule 등 자동 스케줄링으로 확장 가능.

**배치 흐름**:
```
1. 집계 대상 시간 구간 결정
2. UsageEventRepository에서 source row 조회
3. UsageAggRepository.upsert_daily/monthly()
4. 집계 실행 이력/로그 기록
```

**의존성**: UsageEventRepository, UsageAggRepository

---

### 2.5 VirtualKeyService (Domain — Lambda)

**책임**: Virtual Key 발급/재조회 규칙 관리

**get_or_create_key 흐름**:
```
1. UserLookupService.resolve_user(principal_info)
2. UserLookupService.validate_user_active(user)
3. VirtualKeyRepository.get_active_by_user(user_id)
   → 활성 키 존재: KmsHelper.decrypt_key() → 반환
   → 활성 키 없음: 신규 키 생성 → KmsHelper.encrypt_key() → 저장 → 반환
4. AuditEventRepository.create_event() (키 생성 시)
```

**의존성**: UserLookupService, VirtualKeyRepository, KmsHelper, AuditEventRepository

---

### 2.6 IdentitySyncService (Domain)

**책임**: IAM Identity Center Identity Store에서 사용자 기본 정보를 동기화한다.

**sync 흐름**:
```
1. IdentitySyncRunRepository.create_run(status=STARTED)
2. Identity Store API로 사용자 목록 조회
3. 각 사용자에 대해:
   a. 기존 사용자 → 기본 정보 업데이트
   b. 신규 사용자 → INACTIVE로 생성
   c. source 삭제 판정 → INACTIVE 전환 + source_deleted_at 기록
4. IdentitySyncRunRepository.update_run(status=SUCCEEDED, counts)
5. AuditEventRepository.create_event()
```

**의존성**: UserRepository, IdentitySyncRunRepository, AuditEventRepository, IAM Identity Center SDK

---

### 2.7 MetricsService (Domain)

**책임**: OTel SDK를 래핑하여 3개 primary metric을 emit한다.

**설계 원칙**:
- OTel MeterProvider를 앱 시작 시 초기화
- OTLP gRPC exporter (localhost:4317) 설정
- Cumulative temporality (prometheusremotewrite 호환)
- emit 규칙은 FR-9에 정의된 조건을 따름
- `BLOCKED_*` 또는 upstream usage/latency 미확정 `ERROR` 요청에는 `bedrock.*` metric을 emit하지 않음

**의존성**: OpenTelemetry SDK, OTLP gRPC exporter

---

### 2.8 Admin Services (Domain)

Admin API의 각 서비스는 단순 CRUD + 비즈니스 검증 패턴을 따른다.

| 서비스 | 패턴 | 특이사항 |
|--------|------|----------|
| AdminUserService | CRUD + 상태 전환 검증 | ACTIVE 전환 시 audit 기록 |
| AdminTeamService | CRUD + 멤버십 관리 | `users.default_team_id` membership 일관성 검증 |
| AdminModelService | CRUD + 매핑/가격 관리 | effective_from versioning |
| AdminBudgetService | CRUD + 예산 상태 조회 | 집계 테이블 JOIN |
| AdminVirtualKeyService | metadata 조회 + lifecycle 관리 | rotate/revoke는 Admin ingress가 소유 |
| AdminUsageService | 읽기 전용 | 페이지네이션, 필터링 |
| IdentitySyncService | 수동 sync 실행/상태 조회 | Identity Store 기본 정보만 동기화 |

---

## 3. 에러 처리 전략 (Q11: 커스텀 예외 계층)

### 예외 계층 구조

```
AppError (base)
├── AuthenticationError
│   ├── InvalidKeyError
│   └── KeyRevokedError
├── AuthorizationError
│   ├── UserInactiveError
│   ├── TeamInactiveError
│   └── ModelNotAllowedError
├── BudgetExceededError (hard limit)
├── UpstreamError
│   ├── BedrockError
│   └── BedrockThrottlingError
├── ValidationError
└── InternalError
```

> **Note**: soft limit 초과는 예외가 아닌 `PolicyContext.warnings` 리스트에 `BudgetWarning` 데이터를 누적하여 처리한다. 요청은 중단되지 않고 계속 진행되며, 경고 정보는 usage_events 기록 시 함께 저장한다.

### Exception Handler 매핑

| 예외 | HTTP Status | Anthropic error type |
|------|-------------|---------------------|
| InvalidKeyError | 401 | authentication_error |
| KeyRevokedError | 401 | authentication_error |
| UserInactiveError | 403 | permission_error |
| TeamInactiveError | 403 | permission_error |
| ModelNotAllowedError | 403 | permission_error |
| BudgetExceededError (hard) | 403 | permission_error |
| BedrockThrottlingError | 429 | rate_limit_error |
| BedrockError | 502 | api_error |
| ValidationError | 400 | invalid_request_error |
| InternalError | 500 | api_error |

---

## 4. 의존성 주입 전략 (Q10: FastAPI Depends)

```python
# gateway/core/dependencies.py

async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        yield session

def get_user_repository(session=Depends(get_db_session)) -> UserRepository:
    return UserRepository(session)

def get_policy_chain(
    key_repo=Depends(get_virtual_key_repository),
    user_repo=Depends(get_user_repository),
    team_repo=Depends(get_team_repository),
    model_repo=Depends(get_model_alias_mapping_repository),
    budget_repo=Depends(get_budget_policy_repository),
    ...
) -> PolicyChain:
    return PolicyChain([
        VirtualKeyHandler(key_repo),
        UserStatusHandler(user_repo),
        TeamStatusHandler(team_repo),
        ModelResolverHandler(model_repo),
        UserModelPolicyHandler(user_model_repo),
        TeamModelPolicyHandler(team_model_repo),
        UserBudgetPreCheckHandler(budget_repo),
        TeamBudgetPreCheckHandler(budget_repo),
        ModelBudgetPreCheckHandler(budget_repo),
        CachePolicyHandler(user_model_repo, team_model_repo),
    ])

def get_gateway_service(
    policy_chain=Depends(get_policy_chain),
    request_converter=Depends(get_request_converter),
    response_converter=Depends(get_response_converter),
    bedrock_client=Depends(get_bedrock_client),
    stream_processor=Depends(get_stream_processor),
    usage_service=Depends(get_usage_service),
) -> GatewayService:
    return GatewayService(
        policy_chain,
        request_converter,
        response_converter,
        bedrock_client,
        stream_processor,
        usage_service,
    )
```
