# Component Dependency — Claude Code Proxy on AWS

- 문서 버전: v1.0
- 작성일: 2026-03-31
- 상태: Draft
- 근거: [Components](./components.md), [Services](./services.md)

---

## 1. 컴포넌트 의존성 매트릭스

| 의존 주체 ↓ / 대상 → | C1 CDK | C2 Lambda | C3 Gateway | C4 Admin | C5 Shared | C6 Observability |
|----------------------|--------|-----------|------------|----------|-----------|-----------------|
| C1 CDK Infrastructure | — | 배포 | 배포 | 배포 | — | 배포 |
| C2 Lambda Token Service | — | — | — | — | import | — |
| C3 FastAPI LLM Gateway | — | — | — | 동일 프로세스 | import | emit |
| C4 Admin API | — | — | 동일 프로세스 | — | import | — |
| C5 Shared Models | — | — | — | — | — | — |
| C6 Observability | — | — | 수신 | — | — | — |

---

## 2. 통신 패턴

### 2.1 외부 → 내부 통신

```
Claude Code
  ├─[SigV4]──→ API Gateway ──→ Lambda Token Service (C2)
  └─[x-api-key]──→ ALB ──→ ECS FastAPI (C3)

운영자
  └─[SigV4]──→ API Gateway ──→ ALB ──→ ECS FastAPI (C4)
```

### 2.2 내부 → AWS 서비스 통신

| 소스 | 대상 | Endpoint | 프로토콜 |
|------|------|----------|----------|
| C2 Lambda | Aurora (via RDS Proxy) | — (VPC 내부) | PostgreSQL TLS |
| C2 Lambda | KMS | kms interface | HTTPS |
| C3 Gateway | Aurora (via RDS Proxy) | — (VPC 내부) | PostgreSQL TLS |
| C3 Gateway | Bedrock Runtime | bedrock-runtime interface | HTTPS |
| C3 Gateway | ADOT Sidecar | — (localhost) | gRPC :4317 |
| C4 Admin | Aurora (via RDS Proxy) | — (VPC 내부) | PostgreSQL TLS |
| C4 Admin | IAM Identity Center Identity Store | identitystore interface | HTTPS |
| C6 ADOT | AMP | aps-workspaces interface | HTTPS |
| C6 ADOT | STS | sts interface | HTTPS |

### 2.3 내부 컴포넌트 간 통신

| 소스 | 대상 | 방식 | 설명 |
|------|------|------|------|
| C3 Gateway | C5 Shared | Python import | SQLAlchemy 모델, 유틸리티 |
| C4 Admin | C5 Shared | Python import | SQLAlchemy 모델, 유틸리티 |
| C2 Lambda | C5 Shared | Python import | SQLAlchemy 모델, KMS 헬퍼 |
| C3 Gateway | C6 MetricsService | 메서드 호출 | OTel metric emit |
| C3/C4 | Repository 레이어 | 메서드 호출 | DB 접근 추상화 |

---

## 3. 데이터 흐름

### 3.1 Virtual Key 발급 흐름

```
Claude Code
  │ SigV4 서명 요청
  ▼
API Gateway (IAM Auth)
  │
  ▼
Lambda Token Service (C2)
  │ 1. resolve_user(principal)
  │ 2. validate_user_active()
  │ 3. get_active_by_user() / create()
  │ 4. KMS encrypt/decrypt
  ▼
RDS Proxy → Aurora (C5 모델)
  │
  ▼
Virtual Key 응답 → Claude Code
```

### 3.2 Runtime Gateway 흐름

```
Claude Code
  │ x-api-key + Anthropic request
  ▼
ALB
  │
  ▼
FastAPI Gateway (C3)
  │ 1. PolicyChain.evaluate()
  │    ├─ VirtualKeyHandler → VirtualKeyRepository
  │    ├─ UserStatusHandler → UserRepository
  │    ├─ TeamStatusHandler → TeamRepository
  │    ├─ ModelResolverHandler → ModelAliasMappingRepository
  │    ├─ UserModelPolicyHandler → UserModelPolicyRepository
  │    ├─ TeamModelPolicyHandler → TeamModelPolicyRepository
  │    ├─ UserBudgetPreCheckHandler → BudgetPolicyRepository
  │    ├─ TeamBudgetPreCheckHandler → BudgetPolicyRepository
  │    ├─ ModelBudgetPreCheckHandler → BudgetPolicyRepository
  │    ├─ CachePolicyHandler → User/TeamModelPolicyRepository
  │    └─ [차단 시] UsageService.record_blocked_request() → UsageEventRepository (zero-token row)
  │ 2. AnthropicToBedrockConverter.convert_request()
  │    └─ block-level cache_control 보존 + automatic cachePoint 삽입
  │ 3. BedrockClient.converse() / converse_stream()  [max_attempts=1]
  │    └─→ Bedrock Runtime (VPC Endpoint)
  │ 4. BedrockToAnthropicConverter.convert_response()
  │ 5. UsageService.record_success()
  │    ├─ BudgetPolicyRepository.apply_costs() [원자적 UPDATE]
  │    ├─ UsageEventRepository.create_event()
  │    └─ MetricsService.emit_*() → ADOT (C6) → AMP
  │ 6. [배치] UsageRollupService → UsageAggRepository.upsert_daily/monthly()
  ▼
Anthropic-compatible 응답 → Claude Code
```

### 3.3 Admin API 흐름

```
운영자
  │ SigV4 서명 요청
  ▼
API Gateway (IAM Auth)
  │
  ▼
ALB
  │
  ▼
FastAPI Admin (C4, C3과 동일 프로세스)
  │ Admin*Service → Repository → RDS Proxy → Aurora
  ▼
JSON 응답 → 운영자
```

---

## 4. CDK 스택 의존성 (Q8: 계층별 분할)

```
NetworkStack
  │ VPC, Subnets, VPC Endpoints, Security Groups
  ▼
DataStack (depends: NetworkStack)
  │ Aurora Serverless v2, RDS Proxy, Secrets Manager
  ▼
ObservabilityStack (depends: NetworkStack)
  │ AMP Workspace, ADOT 설정
  ▼
ComputeStack (depends: NetworkStack, DataStack, ObservabilityStack)
  │ ECS Cluster, Fargate Task Definition (Gateway + ADOT skeleton), Lambda
  ▼
ApiStack (depends: NetworkStack, ComputeStack)
  │ API Gateway, ALB, Target Groups
```

**배포 순서**: NetworkStack → DataStack → ObservabilityStack → ComputeStack → ApiStack

---

## 5. 보안 경계

| 경계 | 인증 방식 | 네트워크 |
|------|-----------|----------|
| Claude Code → API Gateway | IAM + SigV4 | Public internet → API Gateway |
| Claude Code → ALB | x-api-key (Virtual Key) | Public internet → ALB |
| 운영자 → API Gateway | IAM + SigV4 | Public internet → API Gateway |
| API Gateway → Lambda | IAM invoke | AWS managed |
| API Gateway → ALB | Internal routing | VPC 내부 |
| Lambda → RDS Proxy | password (Secrets Manager) | Private subnet |
| ECS → RDS Proxy | password (Secrets Manager) | Private subnet |
| ECS → Bedrock | IAM role | VPC Endpoint (private) |
| ECS → ADOT | localhost | Same task |
| ADOT → AMP | SigV4 | VPC Endpoint (private) |

**보안 고려사항**:
- ALB는 public이므로, `/v1/admin/*` 경로에 대한 직접 접근을 차단해야 한다. API Gateway를 우회하면 SigV4 인증 없이 Admin API에 도달할 수 있다.
- 완화 방안: ALB 리스너 규칙에서 Admin 경로에 대해 API Gateway origin 검증(예: 공유 시크릿 헤더 또는 API Gateway가 삽입하는 커스텀 헤더 검증)을 수행하거나, Admin API 전용 내부 ALB를 분리하는 방안을 검토한다.
