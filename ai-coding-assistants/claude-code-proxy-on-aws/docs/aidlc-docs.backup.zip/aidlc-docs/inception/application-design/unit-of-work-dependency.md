# Unit of Work Dependency — Claude Code Proxy on AWS

- 문서 버전: v1.0
- 작성일: 2026-03-31
- 상태: Draft
- 근거: [Unit of Work](./unit-of-work.md)

---

## 1. 의존성 매트릭스

| 의존 주체 ↓ / 대상 → | Unit 1 (Infra) | Unit 2 (Shared) | Unit 3 (Token) | Unit 4 (Gateway) |
|----------------------|----------------|-----------------|----------------|------------------|
| Unit 1 (Infra) | — | — | — | — |
| Unit 2 (Shared) | 런타임 의존 (Aurora) | — | — | — |
| Unit 3 (Token) | 런타임 의존 (Lambda, RDS Proxy, KMS) + 인프라 보완 | 코드 의존 (models, utils) | — | — |
| Unit 4 (Gateway) | 런타임 의존 (ECS, ALB, Bedrock EP, ADOT, AMP) + 인프라 보완 | 코드 의존 (models, utils) | — | — |

---

## 2. 의존성 유형 설명

### 런타임 의존
실행 시 해당 유닛이 배포한 AWS 리소스가 필요함.
- Unit 2 → Unit 1: Alembic 마이그레이션 실행 시 Aurora 인스턴스 필요
- Unit 3 → Unit 1: Lambda 실행 시 RDS Proxy, KMS endpoint 필요
- Unit 4 → Unit 1: ECS 서비스 실행 시 ALB, Bedrock endpoint, ADOT sidecar 필요

### 코드 의존
빌드/import 시 해당 유닛의 코드가 필요함.
- Unit 3 → Unit 2: `shared/models/`, `shared/utils/` import
- Unit 4 → Unit 2: `shared/models/`, `shared/schemas/`, `shared/utils/` import

### 인프라 보완
해당 유닛의 애플리케이션 코드 구현 후 CDK 인프라 설정을 확정/보완함.
- Unit 3 → Unit 1: Lambda 함수 코드 경로, 환경변수, IAM 역할 확정
- Unit 4 → Unit 1: ECS task definition 확정 (컨테이너 이미지, 환경변수, health check, ADOT sidecar 설정)

---

## 3. 구현 순서 다이어그램

```
Unit 1: Foundation Infrastructure
  │
  │ Aurora, RDS Proxy, VPC Endpoints → 런타임 기반
  ▼
Unit 2: Shared Models & DB Migration
  │
  │ SQLAlchemy 모델, 유틸리티 → 코드 기반
  ├────────────────────────────────────┐
  ▼                                    ▼
Unit 3: Token Service           Unit 4: Gateway
  │                                    │
  │ Lambda 설정 확정                    │ ECS 설정 확정
  └─────── infra/ 보완 ───────────────┘
```

> Unit 3과 Unit 4는 서로 의존하지 않으므로 이론적으로 병렬 가능하나, 순차 구현 결정에 따라 Unit 3 → Unit 4 순서로 진행한다.

---

## 4. 배포 의존성

| 단계 | 배포 대상 | 선행 조건 |
|------|-----------|-----------|
| 1 | `cdk deploy` (전체 스택, skeleton) | 없음 |
| 2 | Alembic 마이그레이션 실행 | Aurora 가동 |
| 3 | Lambda 코드 배포 + CDK 보완 | 마이그레이션 완료 |
| 4 | Gateway 컨테이너 빌드/배포 + CDK 보완 | 마이그레이션 완료 |

---

## 5. 순환 의존성 검증

순환 의존성 없음. 의존 그래프는 DAG(방향성 비순환 그래프)를 형성한다.

```
Unit 1 ← Unit 2 ← Unit 3
                 ← Unit 4
```
