# Claude Code Proxy on AWS — Requirements Document

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Approved
- 근거 문서: [PRD v0.5](../../../docs/PRD.md), [System Architecture v0.3](../../../docs/SYSTEM_ARCHITECTURE.md), [ERD v0.3](../../../docs/ERD.md), [API Spec v0.4](../../../docs/API_SPEC.md), [Bedrock Converse Analysis](../../../docs/BEDROCK_CONVERSE_CLAUDE_CODE_ANALYSIS.md)
- 검증 질문: [requirement-verification-questions.md](./requirement-verification-questions.md)

## 1. 프로젝트 개요

AWS SSO로 인증된 사용자가 Claude Code에서 Virtual Key 기반으로 안전하게 Bedrock Converse 모델을 사용하도록 하고, 커스텀 LLM Gateway를 통해 모델 매핑, 예산, 사용량, 관측 체계 아래 통제하는 엔터프라이즈 플랫폼을 구축한다.

## 2. 구현 결정 사항 요약

### 2.1 기술 스택

| 항목 | 결정 | 근거 (Q#) |
| --- | --- | --- |
| 구현 언어 | Python (전체 통일) | Q1 |
| IaC | AWS CDK (Python) | Q2 |
| Gateway 프레임워크 | FastAPI | Q3 |
| DB 마이그레이션 | Alembic + SQLAlchemy | Q5 |
| 패키지 관리 | uv | Q20 |
| 테스트 프레임워크 | pytest (unit test 중심) | Q10 |

### 2.2 아키텍처 결정

| 항목 | 결정 | 근거 (Q#) |
| --- | --- | --- |
| v1 구현 범위 | Phase 1+2+3 전체 | Q4 |
| Admin API 배포 | ECS Gateway 동일 서비스 내 라우트 분리 | Q8 |
| Admin API 인증 | API Gateway SigV4 → ALB → ECS | Q17 |
| 모노레포 구조 | 단일 레포, 디렉토리 기반 분리 | Q9 |
| 배포 리전 | cdk.context 설정 기반, 기본값 ap-northeast-2 | Q11 |
| Bedrock model ID | model_catalog에 관리자가 직접 입력 (cross-region prefix 포함 가능) | Q21 |
| ALB 스트리밍 | idle timeout 300~600초 + HTTP/1.1 chunked | Q19 |
| CI/CD | v1은 로컬 `cdk deploy` 기반, 후속 도입 | Q18 |
| 로컬 개발 | Docker Compose(PostgreSQL) + AWS 개발 계정 | Q16 |

### 2.3 기능/정책 결정

| 항목 | 결정 | 근거 (Q#) |
| --- | --- | --- |
| Virtual Key 암호화 | KMS Encrypt 저장, 재반환 시 Decrypt | Q6 |
| Extended Thinking | v1 포함 (thinking/redacted_thinking 변환) | Q7 |
| Content block 범위 | text, tool_use, tool_result, image, document, thinking/redacted_thinking | Q12 |
| Prompt Cache 변환 | 정책 B — block-level + top-level automatic compile | Q25 |
| team-less user | 허용 — 시스템 기본 정책으로 fallback | Q23 |
| Bedrock retry | 없음 — 에러 즉시 전파, Claude Code 자체 retry 위임 | Q22 |
| ADOT 수집 방식 | OTLP push (gRPC :4317) | Q24 |

### 2.4 데이터/운영 결정

| 항목 | 결정 | 근거 (Q#) |
| --- | --- | --- |
| 집계 전략 | 혼합 — 예산 카운터 실시간 + 리포팅 배치 | Q13 |
| 예산 동시성 | 원자적 UPDATE ... RETURNING | Q14 |
| usage_events 파티셔닝 | 초기 없음, 추이 확인 후 추가 | Q15 |


## 3. 기능 요구사항 (PRD 기반 + 구현 결정 반영)

### FR-1. AWS SSO + SigV4 기반 Virtual Key 발급

- API Gateway IAM Auth + SigV4 검증
- Lambda(Python)가 IAM Principal에서 사용자 식별자 추출
- `ACTIVE` 상태 사용자만 발급 가능
- 활성 키 존재 시 KMS Decrypt로 원문 재반환 (Q6)
- 신규 키 생성 시 KMS Encrypt 후 `kms_ciphertext` 저장, SHA-256 `key_fingerprint` 동시 저장
- v1에서 사용자당 활성 키 1개
- 키 회전/폐기 지원

수용 기준:
- SSO 미인증 요청 → 401/403
- INACTIVE/미동기화 사용자 → 발급 거부
- p95 응답시간 1초 이하
- 폐기 키로 Gateway 호출 시 즉시 실패

### FR-2. Claude Code 호환 Gateway 엔드포인트

- FastAPI 기반 `POST /v1/messages` (non-streaming + streaming)
- `GET /v1/models` — caller 허용 모델 목록
- `GET /healthz` — ALB health check
- Northbound: Anthropic-compatible 최소 surface
- Southbound: Bedrock Converse/ConverseStream only
- 지원 content block: text, tool_use, tool_result, image, document, thinking, redacted_thinking (Q7, Q12)
- 모델 매핑: `model_alias_mappings` 기반, 미매핑 시 Sonnet 4.6 fallback
- Streaming: Anthropic SSE 이벤트 형식 (message_start → content_block_* → message_delta → message_stop)
- ALB idle timeout 300~600초 (Q19)
- Bedrock 호출 에러 시 retry 없이 즉시 클라이언트 전파, boto3 `max_attempts=1` (Q22)

수용 기준:
- Claude Code가 정상 프롬프트/툴/thinking 호출 수행 가능
- 스트리밍 세션 중도 종료 없음
- OpenAI-compatible endpoint 미제공

### FR-3. Virtual Key 관리

- 상태: ACTIVE, REVOKED, ROTATED, EXPIRED
- DB 저장: key_fingerprint(SHA-256) + kms_ciphertext(KMS 암호화 원문)
- 런타임 검증: key_fingerprint 해시 비교
- Admin API로 rotate/revoke 가능
- 감사 로그에 키 생성/회전/폐기 이력 기록

### FR-4. Bedrock 모델 관리

- `model_catalog`: canonical_name, bedrock_model_id(cross-region prefix 포함 가능, Q21), provider, capability flags
- `model_alias_mappings`: selected_model_pattern → target_model_id, priority 기반 평가, is_fallback
- `model_pricing`: 모델별 input/output/cache_read 단가 + cache_write 단가는 TTL별(5m/1h) 분리 관리, effective_from versioning
- v1 기본 지원: Claude 4.5+ 계열
- 사용자/팀별 허용 모델 allowlist
- 비활성 모델 즉시 전체 차단

### FR-5. 사용자/팀 관리

- 사용자: Identity Center 수동 sync → INACTIVE 기본 → 운영자 ACTIVE 전환
- 팀: Admin API로 내부 생성/관리 (외부 그룹 sync 아님)
- team_memberships: Admin API로 지정, 사용자당 다중 팀 가능
- team-less user 허용 — 시스템 기본 정책 fallback (Q23)
- 정책 우선순위: 사용자 override > 팀 기본값 > 시스템 기본값

### FR-6. 일/월별 예산 관리

- scope: USER/TEAM, period: DAILY/MONTHLY, optional model_id
- soft_limit_usd (경고) + hard_limit_usd (차단)
- 사전 검사: SELECT로 잔여 예산 확인
- 사후 정산: 원자적 `UPDATE ... SET current_used_usd = current_used_usd + $cost WHERE current_used_usd + $cost <= hard_limit_usd RETURNING current_used_usd` (Q14)
- `budget_policies` row는 정의와 현재 기간 enforcement 카운터를 함께 보유 (`current_used_usd`, `window_started_at`)
- 예산 카운터 실시간 갱신, 리포팅 집계는 배치 (Q13)
- 비용 계산: model_pricing 기반 input/output/cache_read 분리 계산 + cache_write는 적용된 TTL(5m/1h)에 따른 단가로 계산

### FR-7. Prompt Caching 정책

- 정책값: none, 5m, 1h (기본값 5m)
- 사용자/팀 단위 설정
- 변환 정책 B 적용 (Q25):
  - block-level `cache_control` → Bedrock `cachePoint` 변환
  - top-level automatic caching → tools/system/messages 순서로 마지막 cacheable block에 cachePoint 자동 삽입
- 미지원 모델은 자동 none downgrade
- cache 사용량: cached_read_tokens, cached_write_tokens 별도 저장

### FR-8. 사용자별 토큰 사용량 저장

- `usage_events`: 요청 단위 source of truth
  - input_tokens, output_tokens, cached_read_tokens, cached_write_tokens, total_tokens
  - cache_details_json, estimated_cost_usd, latency_ms
  - selected_model, resolved_model_id, request_status, request_id, bedrock_invocation_id
  - user_id, team_id (NULL 허용, Q23), virtual_key_id, budget_policy_id
- ConverseStream: final metadata event 수신 후 1건 기록
- 차단 요청도 zero-token row 기록
- 초기 파티셔닝 없음, 인덱스 기반 (Q15)
- 리포팅 집계: usage_daily_agg, usage_monthly_agg — 배치 갱신 (Q13)
- 프롬프트/응답 본문 비저장

### FR-9. ADOT Collector Sidecar 및 AMP 연동

- ECS task 내 ADOT Collector Sidecar
- Gateway → ADOT: OTLP gRPC push (localhost:4317) (Q24)
- ADOT → AMP: remote write (VPC Endpoint 경유)
- OTel SDK temporality: cumulative (prometheusremotewrite exporter 호환)
- 수집 범위: Proxy 프로세스/ECS 인프라 메트릭이 아니라, Bedrock 응답 + Gateway 정책 결과에서 확정되는 요청 단위 usage/cost/latency 메트릭
- 기록 시점: `usage_events` row 저장 성공 직후, 동일 request context로 OTel metric을 emit
- primary metric payload spec:
  - `bedrock.token.usage`
    - instrument: Counter
    - unit: tokens
    - value source: `input_tokens`, `output_tokens`, `cached_read_tokens`, `cached_write_tokens`
    - emit rule: 값이 0보다 큰 token type만 emit
    - required attribute: `user_id`, `team_id`, `model_id`, `status`, `stream`, `token_type`
    - `token_type`: `input|output|cache_read|cache_write`
  - `bedrock.cost.usage`
    - instrument: Counter
    - unit: USD
    - value source: `estimated_cost_usd`
    - emit rule: 값이 0보다 클 때만 emit
    - required attribute: `user_id`, `team_id`, `model_id`, `status`, `stream`
  - `bedrock.request.duration`
    - instrument: Histogram
    - unit: ms
    - value source: Bedrock `metrics.latencyMs` → `latency_ms`
    - emit rule: Bedrock 호출이 실제 수행되어 latency가 있는 경우 1회 emit
    - required attribute: `user_id`, `team_id`, `model_id`, `status`, `stream`
- attribute 정의:
  - `model_id`는 DB FK `resolved_model_id`가 아니라 실제 Bedrock `modelId` 문자열이다
  - `status`는 `SUCCESS|ERROR|BLOCKED_BUDGET|BLOCKED_POLICY`
  - `stream`은 boolean
  - 선택 attribute: `aws_region`, `service_tier`, `stop_reason`
  - `request_id`, `bedrock_invocation_id`, `virtual_key_id`, `budget_policy_id`, `cache_details_json`는 metric attribute가 아니라 DB/log 전용으로 유지한다
- emit 규칙:
  - `Converse`: 응답 body의 `usage.*`, `metrics.latencyMs`를 사용한다
  - `ConverseStream`: final `metadata.usage.*`, `metadata.metrics.latencyMs`를 사용한다
  - `BLOCKED_BUDGET`, `BLOCKED_POLICY`: Bedrock 호출이 없으므로 `bedrock.*` metric을 emit하지 않는다
  - `ERROR`: upstream usage/cost/latency가 없으면 `bedrock.*` metric을 emit하지 않는다
- v1 범위의 AMP 대시보드는 위 3개 primary metric 기준으로 시간별 사용량, 사용자별/팀별/모델별 토큰 사용량, 비용 추이, request latency 분포를 조회할 수 있어야 한다

### FR-10. 운영 및 감사

- audit_events 테이블: 인증 실패, 예산 차단, 모델 차단, 키 회전/폐기, sync 실패, 시스템 오류
- 모든 요청에 request_id (클라이언트 제공 또는 서버 생성)
- 민감정보 마스킹, 프롬프트/응답 본문 비저장
- 최소 디버깅 로그: request_id, user_id, resolved_model, cost_estimate, status, latency_ms

### FR-11. Identity Center 사용자 Sync

- Admin API `POST /v1/admin/sync/identity-center`로 수동 실행
- Identity Store에서 사용자 ID 기반 기본 정보만 읽기
- 신규 사용자: INACTIVE로 생성
- source 삭제 판정: INACTIVE 전환 + source_deleted_at 기록
- 팀/멤버십은 동기화하지 않음
- identity_sync_runs에 실행 이력 저장
- 실패 시 운영 알람


## 4. 비기능 요구사항

### NFR-1. 보안

- 모든 외부 통신 TLS
- Virtual Key 평문 저장 금지 (KMS 암호화)
- 시크릿: AWS Secrets Manager
- IAM 최소 권한 원칙
- Private Subnet First, VPC Endpoint 우선
- 프롬프트/응답 본문 비저장
- VPC Endpoint policy로 서비스 접근 범위 최소화

### NFR-2. 성능

- Virtual Key 발급 p95: 1초 이하
- Gateway 정책 검사 + Bedrock 전처리 p95: 300ms 이하
- 사용량 조회 API p95: 2초 이하

### NFR-3. 가용성

- 단일 리전(ap-northeast-2 기본), 멀티 AZ
- ECS 최소 2 task
- Aurora 멀티 AZ

### NFR-4. 운영성

- 메트릭/로그/trace correlation (request_id 기반)
- 주요 이벤트 알람
- IaC(CDK Python) 기반 재현 가능 배포
- `cdk diff` → `cdk deploy --require-approval broadening` 배포 절차 (Q18)

## 5. 프로젝트 구조

```text
claude-code-proxy-on-aws/
├── docs/                    # 설계 문서
├── aidlc-docs/              # AI-DLC 산출물
├── infra/                   # CDK Python 스택
├── gateway/                 # FastAPI LLM Gateway
├── lambda/                  # Virtual Key Lambda
├── shared/                  # 공통 모듈 (models, utils)
├── migrations/              # Alembic 마이그레이션
├── tests/                   # pytest (unit 중심)
├── docker-compose.yml       # 로컬 PostgreSQL
├── pyproject.toml           # uv 프로젝트 설정
└── uv.lock                  # 의존성 lock
```

## 6. 네트워크 토폴로지

### 6.1 기본 배포 모드

- Public subnet: ALB
- Private app subnet: ECS Fargate(Gateway + ADOT sidecar), VPC-attached Lambda
- Private data subnet: Aurora PostgreSQL Serverless v2, RDS Proxy
- API Gateway: AWS managed regional (VPC 외부)

### 6.2 필수 VPC Endpoints

- bedrock-runtime (interface)
- ecr.api, ecr.dkr (interface)
- s3 (gateway)
- logs (interface)
- secretsmanager (interface)
- kms (interface)
- identitystore (interface)
- sts (interface)
- aps-workspaces (interface)
- ecs (interface)

### 6.3 트래픽 경로

| 경로 | 흐름 |
| --- | --- |
| Token Service | Claude Code → API Gateway(SigV4) → Lambda → RDS Proxy → Aurora |
| Runtime Gateway | Claude Code → ALB(x-api-key) → ECS FastAPI → Bedrock(VPC Endpoint) |
| Admin API | 운영자 → API Gateway(SigV4) → ALB → ECS FastAPI → RDS Proxy → Aurora |
| 메트릭 | ECS FastAPI → ADOT Sidecar(OTLP gRPC) → AMP(VPC Endpoint) |
| Identity Sync | Admin API trigger → ECS FastAPI → IAM Identity Center → RDS Proxy → Aurora |

## 7. 설계 문서 정합성 메모

본 requirements 기준으로 다음 상위/연관 설계 문서와의 정합성을 유지한다.

1. **System Architecture 11.3절** — Bedrock 호출 오류는 retry 없이 즉시 클라이언트로 전파하고, boto3 `max_attempts=1`을 사용한다.
2. **System Architecture / PRD 상위 다이어그램** — Admin API 경로는 `API Gateway(SigV4) → ALB → ECS FastAPI`다.
3. **ERD `usage_events`** — team-less user 허용 결정(Q23)에 따라 `team_id`는 NULL일 수 있다.
4. **System Architecture 9.4절** — `thinking`, `redacted_thinking`, `output_format`/`output_config`의 Bedrock 변환 규칙은 Bedrock Converse Analysis 문서와 일치해야 한다.

## 8. 리스크 및 완화

| 리스크 | 완화 |
| --- | --- |
| Anthropic API surface 호환성 부족 | Q7(thinking), Q12(넓은 content block), Q25(cache 정책 B)로 호환성 최대화 |
| 예산 동시성 경합 | Q14(원자적 UPDATE) + hard limit 버퍼 |
| VPC Endpoint 누락/오구성 | CDK에서 endpoint 생성 자동화 + health check |
| 스트리밍 timeout | Q19(ALB idle timeout 연장) |
| 배포 실수 | Q18(cdk diff + require-approval) |
