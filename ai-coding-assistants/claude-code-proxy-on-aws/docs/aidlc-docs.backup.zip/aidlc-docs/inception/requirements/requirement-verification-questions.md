# Requirements Verification Questions

PRD, System Architecture, ERD, API Spec, Bedrock Converse Analysis 문서를 분석한 결과, 구현 착수 전 아래 항목의 확인이 필요합니다.
각 질문의 `[Answer]:` 태그 뒤에 선택지 문자를 기입해 주세요.

---

## Question 1
구현 언어와 런타임을 어떻게 결정하시겠습니까?

A) TypeScript (Node.js) — CDK, Lambda, ECS Gateway 모두 통일
B) Python (FastAPI) — Gateway/Lambda는 Python, IaC는 CDK TypeScript
C) TypeScript Gateway + Python Lambda 혼합
D) Other (please describe after [Answer]: tag below)

[Answer]: D) Python (FastAPI) + IaC (CDK Python)

---

## Question 2
IaC(Infrastructure as Code) 도구는 무엇을 사용하시겠습니까?

A) AWS CDK (TypeScript)
B) AWS CDK (Python)
C) Terraform
D) Other (please describe after [Answer]: tag below)

[Answer]: B) AWS CDK (Python)

---

## Question 3
LLM Gateway의 웹 프레임워크는 무엇을 사용하시겠습니까?

A) FastAPI (Python)
B) Express/Fastify (Node.js/TypeScript)
C) Hono (TypeScript, lightweight)
D) Other (please describe after [Answer]: tag below)

[Answer]: A) FastAPI (Python)

---

## Question 4
v1 구현 범위를 PRD의 Phase 기준으로 어떻게 잡으시겠습니까?

A) Phase 1만 (인증 + 기본 Gateway + Bedrock 연동 + 기본 사용량 기록)
B) Phase 1 + Phase 2 (거버넌스: Identity Sync, 팀/정책, 예산, 캐시 정책 포함)
C) Phase 1 + Phase 2 + Phase 3 (사용량 저장 + ADOT/AMP 관측 포함, 전체 범위)
D) Other (please describe after [Answer]: tag below)

[Answer]: C) Phase 1 + Phase 2 + Phase 3 전체 범위

---

## Question 5
DB 마이그레이션 도구는 무엇을 사용하시겠습니까?

A) Prisma (TypeScript 생태계)
B) Drizzle ORM (TypeScript, lightweight)
C) Alembic (Python/SQLAlchemy)
D) Raw SQL migration scripts
E) Other (please describe after [Answer]: tag below)

[Answer]: C) Alembic (Python/SQLAlchemy)

---

## Question 6
Virtual Key 암호화 전략에서 KMS ciphertext 저장 방식을 어떻게 하시겠습니까?

A) KMS Encrypt로 key 원문을 암호화해 `kms_ciphertext`에 저장하고, 재반환 시 Decrypt
B) Key 생성 시 한 번만 원문 반환, 이후 재반환 불가 (fingerprint 기반 검증만)
C) Other (please describe after [Answer]: tag below)

[Answer]: A)
[Rationale]: Claude Code의 `apiKeyHelper`는 TTL 기반으로 주기적(기본 5분)으로 키를 재요청하는 구조다 (ref: anthropics/claude-code#7660, #11639). 따라서 기존 키를 복호화해 재반환할 수 있어야 한다. 런타임 요청 검증은 `key_hash`로 수행하므로 KMS 호출은 키 발급/재반환 시에만 발생하며, 사용자당 5~15분에 1회 수준으로 비용/성능 영향이 무시 가능하다. 키 회전 시에도 다음 TTL 만료 시점에 새 키가 자동 전파되어 운영적으로 유리하다.

---

## Question 7
Extended Thinking (reasoning) 지원을 v1에 포함하시겠습니까?

A) Yes — thinking/redacted_thinking 변환 포함
B) No — v1에서는 기본 text/tool_use만 지원, thinking은 후속 버전
C) Other (please describe after [Answer]: tag below)

[Answer]: A)
[Rationale]: Claude Code는 extended thinking이 기본 활성화된 상태로 동작하며, 미지원 시 코드 품질과 tool use 정확도가 크게 저하된다. Converse API가 `reasoningContent`를 네이티브로 지원하므로 Anthropic `thinking` ↔ Converse `reasoningContent` 매핑 비용이 낮다.

---

## Question 8
Admin API의 배포 형태는 어떻게 하시겠습니까?

A) API Gateway + Lambda (서버리스)
B) ECS Fargate 별도 서비스
C) LLM Gateway와 동일 ECS 서비스 내 별도 라우트
D) Other (please describe after [Answer]: tag below)

[Answer]: C)
[Rationale]: v1에서 Admin API 호출 빈도는 운영자 수동 조작 수준으로 매우 낮고, Gateway와 동일한 DB/모델을 공유하므로 FastAPI 라우터 분리(`/v1/admin/*`)로 충분하다. 인프라 추가 없이 단순하게 유지하되, ALB path-based routing 규칙으로 Admin 경로에 대한 접근 통제를 별도로 적용한다.
[Design Note — Q8+Q17 조합]: Runtime 경로(Claude Code → ALB → ECS `/v1/messages`)와 Admin 경로(API Gateway → ALB → ECS `/v1/admin/*`)가 동일 ALB를 공유하므로, `/v1/admin/*`이 Claude Code에서 직접 호출되지 않도록 접근 통제가 필요하다. 설계 시 다음 중 하나 이상을 적용해야 한다: (1) ALB listener rule에서 API Gateway origin 헤더(예: `x-apigw-id`) 검증, (2) API Gateway → ALB 연결 시 VPC Link를 통한 네트워크 레벨 분리, (3) FastAPI 미들웨어에서 Admin 경로 요청의 origin 검증.

---

## Question 9
모노레포 구조를 어떻게 구성하시겠습니까?

A) 단일 레포, 패키지 매니저 워크스페이스 (npm/pnpm workspaces 등)
B) 단일 레포, 디렉토리 기반 분리 (워크스페이스 도구 없이)
C) 서비스별 별도 레포
D) Other (please describe after [Answer]: tag below)

[Answer]: B)
[Rationale]: Python + CDK Python 조합에서 별도 워크스페이스 도구 없이 `infra/`, `gateway/`, `lambda/`, `shared/`, `migrations/` 디렉토리 분리로 충분하다. 공통 코드를 상대 경로 import로 공유할 수 있고, CDK가 각 서비스 디렉토리를 Docker context로 참조하면 된다.

---

## Question 10
테스트 전략의 우선순위를 어떻게 잡으시겠습니까?

A) Unit test 중심 (핵심 비즈니스 로직 위주)
B) Integration test 중심 (API 엔드포인트 + DB 연동 위주)
C) Unit + Integration 균형
D) Other (please describe after [Answer]: tag below)

[Answer]: A)
[Rationale]: 핵심 복잡도가 Anthropic↔Converse 변환, 정책 평가, 예산 계산 등 순수 함수로 추출 가능한 비즈니스 로직에 집중되어 있다. 이 로직들의 버그는 비용 오계산이나 보안 정책 우회로 이어지므로 unit test 우선순위가 가장 높다. Integration test는 핵심 API 엔드포인트에 대한 최소 smoke test로 보완한다.

---

## Question 11
기본 배포 리전은 어디로 하시겠습니까?

A) us-east-1 (N. Virginia) — Bedrock Claude 모델 가용, 가장 넓은 서비스 지원
B) us-west-2 (Oregon) — Bedrock Claude 모델 가용, 레퍼런스 프로젝트 기본 리전
C) ap-northeast-1 (Tokyo) — 한국 사용자 지연시간 최소화
D) Other (please describe after [Answer]: tag below)

[Answer]: D) `cdk.context`에서 배포 리전과 Bedrock 호출 리전을 각각 설정 가능하도록 구성. 기본값은 둘 다 ap-northeast-2.
[Rationale]: 인프라 배포 리전과 Bedrock 모델 호출 리전을 분리하면 유연한 크로스 리전 구성이 가능하다(예: 인프라는 ap-northeast-2, Bedrock 호출은 us-west-2). 또한 최신 Claude 모델은 출시 당일 cross-region inference로 서울 리전에서도 호출 가능하므로, 리전 고정이 아닌 설정 기반 선택이 적합하다.

---

## Question 12
Converse API 변환 시 v1에서 지원할 content block 타입의 범위는 어떻게 하시겠습니까?

A) 최소 범위 — text, tool_use, tool_result만
B) 중간 범위 — text, tool_use, tool_result, image (base64)
C) 넓은 범위 — text, tool_use, tool_result, image, document, thinking/redacted_thinking 포함
D) Other (please describe after [Answer]: tag below)

[Answer]: C)
[Rationale]: Q7에서 extended thinking 포함을 결정했으므로 일관되게 넓은 범위를 지원한다. Claude Code는 image(스크린샷), document(파일), thinking을 모두 활용하며, Converse API가 이 타입들을 네이티브 지원하므로 매핑 구현 비용이 크지 않다.

---

## Question 13
일/월별 사용량 집계 전략은 어떻게 하시겠습니까?

A) 트리거 기반 실시간 갱신 — usage_events INSERT 시 집계 테이블 동시 갱신
B) 배치(scheduled) 집계 — 주기적(예: 5분/1시간)으로 미집계 이벤트를 합산
C) 혼합 — 예산 검사용 카운터는 실시간 갱신, 리포팅용 집계는 배치
D) Other (please describe after [Answer]: tag below)

[Answer]: C)
[Rationale]: PRD FR-6의 "요청 전 사전 예산 검사"를 위해 `budgets` 카운터는 요청마다 원자적으로 실시간 갱신해야 한다. 반면 `usage_daily_agg`/`usage_monthly_agg`는 리포팅 용도이므로 배치 집계(5분~1시간 주기)로 충분하다. 요청 처리 경로에서는 `usage_events` INSERT + `budgets` 카운터 갱신만 수행해 트랜잭션 범위를 최소화한다.

---

## Question 14
예산 검사 동시성 제어 방식은 어떻게 하시겠습니까?

A) DB 레벨 — SELECT FOR UPDATE 기반 비관적 잠금
B) DB 레벨 — advisory lock 또는 원자적 UPDATE ... RETURNING 활용
C) 애플리케이션 레벨 — 인메모리 카운터 + 주기적 DB 동기화
D) Other (please describe after [Answer]: tag below)

[Answer]: B)
[Rationale]: 원자적 `UPDATE ... SET current_used_usd = current_used_usd + $cost WHERE current_used_usd + $cost <= hard_limit_usd RETURNING current_used_usd` 패턴으로 검사와 갱신을 단일 쿼리로 수행한다. Bedrock 호출(수초) 동안 다른 요청을 블로킹하지 않아 동시성이 좋다. 동시 요청으로 인한 소폭 초과 가능성은 hard limit을 실제 조직 예산보다 낮게 설정하는 버퍼로 흡수한다. 사전 검사는 SELECT로 잔여 예산을 확인하고, 사후 정산에서 원자적 UPDATE를 적용한다.

---

## Question 15
usage_events 테이블 파티셔닝 및 데이터 보관 정책은 어떻게 하시겠습니까?

A) 월별 파티셔닝, 6개월 보관 후 아카이브/삭제
B) 월별 파티셔닝, 12개월 보관
C) 파티셔닝 없이 시작, 데이터 증가 추이 확인 후 결정
D) Other (please describe after [Answer]: tag below)

[Answer]: C)
[Rationale]: v1 초기 사용자 수가 제한적이고 일일 이벤트 수가 수천~수만 건 수준이므로 인덱스만으로 충분하다. 데이터 증가 패턴을 확인한 후 Alembic 마이그레이션으로 파티셔닝을 추가할 수 있다.

---

## Question 16
로컬 개발 환경 구성은 어떻게 하시겠습니까?

A) Docker Compose — PostgreSQL + LocalStack으로 AWS 서비스 에뮬레이션
B) Docker Compose — PostgreSQL만, AWS 서비스는 개발 계정 직접 사용
C) 로컬 DB 없이 개발 계정의 Aurora에 직접 연결
D) Other (please describe after [Answer]: tag below)

[Answer]: B)
[Rationale]: 핵심인 Bedrock Converse API는 LocalStack으로 에뮬레이션 불가하므로 실제 AWS 개발 계정이 필요하다. DB만 Docker Compose로 로컬에서 빠르게 돌리고, AWS 서비스는 `aws sso login`으로 개발 계정을 사용하면 프로덕션과 동일한 동작을 보장하면서 개발 속도를 확보할 수 있다.

---

## Question 17
Admin API의 인증/접근 통제 방식은 어떻게 하시겠습니까?

A) IAM 인증 (SigV4) — Token Service와 동일 방식
B) 별도 API Key 기반 인증
C) VPC 내부 접근만 허용 (네트워크 레벨 통제)
D) Other (please describe after [Answer]: tag below)

[Answer]: A)
[Rationale]: Token Service용 API Gateway(SigV4)가 이미 존재하므로 Admin 경로(`/v1/admin/*`)를 같은 API Gateway에 추가한다. 인증 체계가 통일되고, IAM 정책으로 Admin 역할만 허용하는 세분화가 가능하며, CloudTrail로 감사 추적이 자동 제공된다. 백엔드는 API Gateway → ALB → ECS(FastAPI)로 프록시한다.

---

## Question 18
CI/CD 파이프라인 구성은 어떻게 하시겠습니까?

A) GitLab CI — 빌드/테스트/CDK deploy 파이프라인
B) GitHub Actions
C) AWS CodePipeline + CodeBuild
D) Other (please describe after [Answer]: tag below)

[Answer]: D) v1에서는 로컬 배포 스크립트(`cdk deploy`) 기반으로 진행. CI/CD 파이프라인은 팀 확장 및 운영 안정화 후 도입.
[Rationale]: v1 초기 개발/운영 인원이 제한적이므로 CI/CD 파이프라인 구축보다 로컬에서 `cdk deploy`를 실행하는 배포 스크립트가 더 실용적이다. 파이프라인은 후속 범위로 둔다.
[Design Note — Q4+Q18 조합]: Phase 1~3 전체를 구현하면 ADOT/AMP 연동까지 포함되어 인프라 스택이 상당히 커진다. 로컬 배포 시 배포 실수 리스크를 줄이기 위해 배포 스크립트에 dry-run/diff 단계를 필수로 포함한다: `cdk diff --all`로 변경사항 사전 확인 후, `cdk deploy --all --require-approval broadening`으로 IAM/보안그룹 변경 시 명시적 승인을 요구한다.

---

## Question 19
ALB-ECS 구간 스트리밍(SSE) 설정 전략은 어떻게 하시겠습니까?

A) ALB idle timeout 연장(최대 4000초) + HTTP/1.1 chunked transfer
B) ALB 대신 NLB 사용으로 L4 레벨 스트리밍 지원
C) ALB 기본 설정(60초) + 클라이언트 재연결 로직으로 대응
D) Other (please describe after [Answer]: tag below)

[Answer]: A)
[Rationale]: ALB idle timeout을 300~600초로 설정하고 HTTP/1.1 chunked transfer로 SSE 스트리밍을 전달한다. timeout 연장에 따른 비용 영향은 없으며, ALB의 L7 기능(path routing, health check)을 유지해 Q8(라우트 분리), Q17(API Gateway→ALB 프록시) 결정과 호환된다. 정상 스트리밍 중에는 토큰이 계속 전송되므로 idle timeout에 걸리지 않고, extended thinking 구간의 최대 소요 시간을 감안해 여유있게 설정한다.

---

## Question 20
Python 패키지 관리 및 의존성 도구는 무엇을 사용하시겠습니까?

A) Poetry — lock 파일 기반 의존성 관리, pyproject.toml 중심
B) uv — Rust 기반 고속 패키지 관리, pip 호환
C) pip + requirements.txt — 전통적 방식
D) Other (please describe after [Answer]: tag below)

[Answer]: B)
[Rationale]: Rust 기반으로 의존성 설치 속도가 압도적이고, `pyproject.toml` + `uv.lock`으로 재현 가능한 빌드를 지원한다. CDK Python + FastAPI + Alembic 조합에서 빈번한 의존성 설치 시 개발 경험에 직접적인 이점이 있으며, Docker 빌드 캐시 효율도 좋다.

---

## Question 21
Bedrock 호출 시 cross-region inference를 사용하시겠습니까?

A) Yes — cross-region inference profile ID 사용 (예: `us.anthropic.claude-sonnet-4-6-20260219-v1:0`)
B) No — 단일 리전 model ID 직접 사용 (예: `anthropic.claude-sonnet-4-6-20260219-v1:0`)
C) 설정 기반 선택 — model_catalog에 cross-region 여부를 포함해 모델별로 결정
D) Other (please describe after [Answer]: tag below)

[Answer]: D) 별도 cross-region 설정 불필요. `model_catalog`의 `bedrock_model_id`에 관리자가 적절한 model ID(prefix 포함/미포함)를 직접 입력하는 것으로 충분.
[Rationale]: cross-region inference는 model ID에 리전 prefix(`us.` 등)를 붙이는 것만으로 동작하므로, 별도 플래그나 변환 로직 없이 `model_catalog.bedrock_model_id` 값 자체로 관리자가 결정한다.

---

## Question 22
Gateway의 Bedrock 호출 에러 재시도(retry) 전략은 어떻게 하시겠습니까?

A) SDK 기본 retry만 사용 (boto3 기본 3회)
B) 커스텀 retry — ThrottlingException, ServiceUnavailableException만 제한적 재시도 (최대 2회, exponential backoff)
C) retry 없음 — 에러를 즉시 클라이언트에 전파, Claude Code 자체 retry에 위임
D) Other (please describe after [Answer]: tag below)

[Answer]: C)
[Rationale]: Claude Code 자체에 재시도 로직이 있으므로 Gateway에서 재시도하면 이중 재시도로 Bedrock 부하와 비용이 증가한다. 스트리밍 응답 중 에러 시 재시도 처리도 복잡하므로, Gateway는 에러를 즉시 클라이언트에 전파하고 재시도 책임은 Claude Code에 위임한다. boto3 클라이언트 설정에서 `max_attempts=1`로 SDK 기본 retry도 비활성화한다.

---

## Question 23
team이 없는 사용자(team-less user)의 처리 정책은 어떻게 하시겠습니까?

A) 허용 — team 미소속 사용자도 시스템 기본 정책으로 Gateway 사용 가능
B) 차단 — 최소 1개 team 소속이 필수, 미소속 시 요청 거부
C) Other (please describe after [Answer]: tag below)

[Answer]: A)
[Rationale]: PRD 정책 우선순위(`사용자 override > 팀 기본값 > 시스템 기본값`)에서 팀 미소속 시 시스템 기본값으로 자연스럽게 fallback된다. 온보딩 절차를 단순화(ACTIVE 전환만으로 즉시 사용 가능)하고, 팀 미소속 사용량은 `team_id = NULL`로 별도 집계하여 리포팅에서 추적한다.

---

## Question 24
ADOT Collector의 메트릭 수집 방식은 어떻게 하시겠습니까?

A) Prometheus scrape — Gateway가 `/metrics` 엔드포인트 노출, ADOT가 주기적 scrape
B) OTLP push — Gateway가 OTLP exporter로 ADOT에 직접 push
C) Other (please describe after [Answer]: tag below)

[Answer]: B)
[Rationale]: Gateway가 OTel SDK를 통해 ADOT Collector Sidecar에 OTLP gRPC(:4317)로 메트릭을 push한다. ECS task 내부 통신(localhost)이므로 네트워크 노출 없이 안전하며, Bedrock 응답 usage/metrics와 Gateway 정책 결과에서 확정되는 사용자 단위 request-derived usage telemetry를 직접 전송할 수 있다. Primary metric은 `bedrock.token.usage`, `bedrock.cost.usage`, `bedrock.request.duration`이며, 공통 attribute로 `user_id`, `team_id`, `model_id`, `status`, `stream`를 사용한다. `bedrock.token.usage`는 추가로 `token_type=input|output|cache_read|cache_write`를 포함한다. Temporality는 `prometheusremotewrite` exporter 호환을 위해 cumulative로 설정한다. `request_id`와 `bedrock_invocation_id`는 metric이 아니라 DB/log에서 추적한다. 클라이언트(Claude Code)는 ADOT에 직접 전송하지 않는다.

---

## Question 25
Prompt Cache 변환 정책은 어떻게 하시겠습니까? (Bedrock Converse Analysis 문서의 정책 A/B 참조)

A) 정책 A — 명시적 block-level `cache_control`만 `cachePoint`로 변환
B) 정책 B — top-level automatic caching도 compile (마지막 cacheable block에 cachePoint 자동 삽입)
C) Other (please describe after [Answer]: tag below)

[Answer]: B)
[Rationale]: Bedrock Converse Analysis 문서의 최종 권고안에 따라, prompt cache는 Anthropic의 `cache_control`과 Bedrock의 `cachePoint`를 모두 이해하는 추상 레이어로 구현한다. 정책 B를 채택하여 block-level `cache_control` → `cachePoint` 변환뿐 아니라, top-level automatic caching도 tools → system → messages 순서로 훑어 마지막 cacheable block 뒤에 `cachePoint`를 자동 삽입한다. Claude Code가 Anthropic API 기준으로 동작하므로 호환성 확보에 필수적이며, "Anthropic automatic caching과 완전히 동일하지는 않다"는 점은 문서화로 명시한다.

---
