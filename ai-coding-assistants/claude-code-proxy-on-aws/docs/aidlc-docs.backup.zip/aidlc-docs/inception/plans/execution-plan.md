# Execution Plan

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Approved / In Execution
- 근거 문서: [Requirements v1.1](../requirements/requirements.md), [User Stories v1.1](../user-stories/stories.md), [PRD v0.5](../../../docs/PRD.md)

## 1. 상세 분석 요약

### 1.1 프로젝트 유형
- **프로젝트 유형**: Greenfield (소스 코드 없음, 설계 문서만 존재)
- **Reverse Engineering**: 해당 없음

### 1.2 변경 영향 평가

| 영향 영역 | 해당 여부 | 설명 |
| --- | --- | --- |
| 사용자 대면 변경 | Yes | Claude Code 호환 Gateway, Virtual Key 발급, Admin API |
| 구조적 변경 | Yes | 전체 시스템 신규 구축 (VPC, ECS, Lambda, Aurora, API Gateway) |
| 데이터 모델 변경 | Yes | 14개 테이블 신규 생성 (ERD v0.3 기준, budget counter 포함) |
| API 변경 | Yes | Token Service, Runtime Gateway, Admin API 전체 신규 |
| NFR 영향 | Yes | 보안(TLS, KMS, VPC Endpoint), 성능(p95 SLA), 가용성(멀티 AZ), 관측성(ADOT/AMP) |

### 1.3 리스크 평가
- **리스크 수준**: High
- **롤백 복잡도**: Low (Greenfield — CDK destroy로 전체 정리 가능)
- **테스트 복잡도**: Complex (Bedrock 연동, 스트리밍, 예산 동시성, 정책 평가 체인)

### 1.4 복잡도 요인
- 6개 주요 컴포넌트 (API Gateway, Lambda, ECS FastAPI, Aurora, ADOT, AMP)
- 14개 DB 테이블 + 집계 전략
- Anthropic → Bedrock Converse 프로토콜 변환 (thinking, cache, tool_use 포함)
- 10단계 정책 평가 체인
- 스트리밍 SSE 변환
- 3개 primary OTel 메트릭 + attribute 전략

## 2. Extension 구성

### 2.1 Security Baseline
- **상태**: Enabled
- **결정**: A — 모든 SECURITY 규칙 blocking constraint 적용

### 2.2 Property-Based Testing
- **상태**: Enabled
- **결정**: A — 모든 PBT 규칙 blocking constraint 적용

## 3. Workflow 시각화

### Mermaid Diagram

```mermaid
flowchart TD
    Start(["User Request"])

    subgraph INCEPTION["🔵 INCEPTION PHASE"]
        WD["Workspace Detection<br/><b>COMPLETED</b>"]
        RA["Requirements Analysis<br/><b>COMPLETED</b>"]
        US["User Stories<br/><b>COMPLETED</b>"]
        WP["Workflow Planning<br/><b>COMPLETED</b>"]
        AD["Application Design<br/><b>COMPLETED</b>"]
        UG["Units Generation<br/><b>COMPLETED</b>"]
    end

    subgraph CONSTRUCTION["🟢 CONSTRUCTION PHASE"]
        FD["Functional Design<br/><b>EXECUTE</b><br/>(per-unit)"]
        NFRA["NFR Requirements<br/><b>EXECUTE</b><br/>(per-unit)"]
        NFRD["NFR Design<br/><b>EXECUTE</b><br/>(per-unit)"]
        ID["Infrastructure Design<br/><b>EXECUTE</b><br/>(per-unit)"]
        CG["Code Generation<br/>(Planning + Generation)<br/><b>EXECUTE</b><br/>(per-unit)"]
        BT["Build and Test<br/><b>EXECUTE</b>"]
    end

    subgraph OPERATIONS["🟡 OPERATIONS PHASE"]
        OPS["Operations<br/><b>PLACEHOLDER</b>"]
    end

    Start --> WD
    WD --> RA
    RA --> US
    US --> WP
    WP --> AD
    AD --> UG
    UG --> FD
    FD --> NFRA
    NFRA --> NFRD
    NFRD --> ID
    ID --> CG
    CG -.->|Next Unit| FD
    CG --> BT
    BT -.-> OPS
    BT --> End(["Complete"])

    style WD fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style RA fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style US fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style WP fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style AD fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style UG fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style FD fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style NFRA fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style NFRD fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style ID fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style CG fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style BT fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style OPS fill:#BDBDBD,stroke:#424242,stroke-width:2px,stroke-dasharray: 5 5,color:#000
    style INCEPTION fill:#BBDEFB,stroke:#1565C0,stroke-width:3px,color:#000
    style CONSTRUCTION fill:#C8E6C9,stroke:#2E7D32,stroke-width:3px,color:#000
    style OPERATIONS fill:#FFF59D,stroke:#F57F17,stroke-width:3px,color:#000
    style Start fill:#CE93D8,stroke:#6A1B9A,stroke-width:3px,color:#000
    style End fill:#CE93D8,stroke:#6A1B9A,stroke-width:3px,color:#000

    linkStyle default stroke:#333,stroke-width:2px
```

### Text Alternative

```
Phase 1: INCEPTION
  - Workspace Detection      (COMPLETED)
  - Requirements Analysis     (COMPLETED)
  - User Stories              (COMPLETED)
  - Workflow Planning         (COMPLETED)
  - Application Design        (COMPLETED)
  - Units Generation          (COMPLETED)

Phase 2: CONSTRUCTION (per-unit loop)
  - Functional Design         (EXECUTE, per-unit)
  - NFR Requirements          (EXECUTE, per-unit)
  - NFR Design                (EXECUTE, per-unit)
  - Infrastructure Design     (EXECUTE, per-unit)
  - Code Generation           (EXECUTE, per-unit)
  - Build and Test            (EXECUTE)

Phase 3: OPERATIONS
  - Operations                (PLACEHOLDER)
```


## 4. 단계별 실행 계획

### 🔵 INCEPTION PHASE
- [x] Workspace Detection (COMPLETED)
- [x] Requirements Analysis (COMPLETED) — Comprehensive depth, 25개 질문, requirements.md 생성
- [x] User Stories (COMPLETED) — 3개 페르소나, 4개 Epic, 23개 스토리
- [x] Workflow Planning (COMPLETED)
- [x] Application Design (COMPLETED)
  - **근거**: 6개 주요 컴포넌트(API Gateway, Lambda, ECS FastAPI, Aurora, ADOT, AMP)의 서비스 레이어 설계, 컴포넌트 메서드 정의, 의존성 명확화 필요. PRD/System Architecture에 상위 설계가 있으나, 구현 수준의 컴포넌트 분해와 인터페이스 정의가 필요함.
- [x] Units Generation (COMPLETED)
  - **근거**: 시스템이 다수의 독립적 서비스/모듈로 구성됨. CDK 인프라, Lambda Token Service, FastAPI Gateway, DB 마이그레이션, ADOT 설정 등 구조적 분해가 필요. 단위별 순차 구현을 위한 의존성 분석과 구현 순서 결정 필요.

### 🟢 CONSTRUCTION PHASE (per-unit loop)
- Shared construction baseline artifact: [system-nfr-decisions.md](../../construction/system-nfr-decisions.md) - COMPLETED
- [ ] Functional Design — **EXECUTE** (per-unit)
  - **근거**: 14개 DB 테이블, Anthropic→Bedrock 프로토콜 변환, 10단계 정책 평가 체인, 예산 동시성 제어, 스트리밍 SSE 변환 등 복잡한 비즈니스 로직이 각 유닛에 존재. 상세 데이터 모델과 비즈니스 규칙 설계 필요.
- [ ] NFR Requirements — **EXECUTE** (per-unit)
  - **근거**: 보안(TLS, KMS, VPC Endpoint, IAM 최소 권한), 성능(p95 SLA), 가용성(멀티 AZ), 관측성(ADOT/AMP) 요구사항이 각 유닛에 영향. 유닛별 NFR 평가와 기술 스택 확정 필요.
- [ ] NFR Design — **EXECUTE** (per-unit)
  - **근거**: NFR Requirements에서 도출된 패턴을 각 유닛의 논리적 컴포넌트에 반영. VPC Endpoint 설계, 보안 그룹 규칙, KMS 암호화 패턴, OTel 계측 패턴 등.
- [ ] Infrastructure Design — **EXECUTE** (per-unit)
  - **근거**: CDK Python 기반 인프라 설계. VPC/서브넷, ECS Fargate, Aurora Serverless v2, RDS Proxy, API Gateway, ALB, VPC Endpoints, ADOT/AMP 등 AWS 리소스 매핑 필요.
- [ ] Code Generation — **EXECUTE** (per-unit, ALWAYS)
  - **근거**: 각 유닛의 설계를 기반으로 실제 코드 생성. Planning → Generation 2단계 실행.
- [ ] Build and Test — **EXECUTE** (ALWAYS)
  - **근거**: 전체 유닛 빌드 및 테스트 지침 생성.

### 🟡 OPERATIONS PHASE
- [ ] Operations — **PLACEHOLDER**
  - **근거**: 향후 배포/모니터링 워크플로우 확장 예정

## 5. 최종 유닛 구성

Units Generation 결과에 따라 아래 4개 유닛 구성이 최종 확정되었다.

| 유닛 | 주요 범위 | 의존성 |
| --- | --- | --- |
| Unit 1: Foundation Infrastructure | VPC, 서브넷, VPC Endpoints, 보안 그룹, Aurora, RDS Proxy, ECS/Lambda/API skeleton | 없음 |
| Unit 2: Shared Models & DB Migration | SQLAlchemy 모델, Alembic 마이그레이션, 공통 유틸리티 | Unit 1 |
| Unit 3: Token Service | API Gateway, Lambda, Virtual Key 발급/조회 | Unit 1, 2 |
| Unit 4: Gateway (Runtime + Admin + Observability) | FastAPI Runtime/Admin, 정책 평가, Anthropic→Bedrock 변환, 스트리밍, Identity Sync, OTel metrics | Unit 1, 2, 3 |

## 6. 성공 기준

- **Primary Goal**: Claude Code가 SSO 인증 → Virtual Key → Gateway → Bedrock Converse 전체 흐름으로 정상 동작
- **Key Deliverables**:
  - CDK Python 인프라 스택 (VPC, ECS, Aurora, API Gateway, ALB, VPC Endpoints)
  - Lambda Token Service (Virtual Key 발급/관리)
  - FastAPI LLM Gateway (정책 평가, 프로토콜 변환, 스트리밍)
  - Admin API (사용자/팀/모델/예산/캐시 관리)
  - Alembic DB 마이그레이션
  - ADOT/AMP 관측 파이프라인
  - pytest 기반 단위 테스트
- **Quality Gates**:
  - Claude Code 호환성 검증 (프롬프트, 도구 호출, 스트리밍, thinking)
  - 정책 평가 체인 정확성
  - 예산 동시성 제어 정확성
  - VPC Endpoint 기반 private connectivity 검증
