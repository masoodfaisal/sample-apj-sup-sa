# Unit of Work Plan

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Approved
- 근거: [Application Design](../application-design/application-design.md), [Requirements v1.1](../requirements/requirements.md), [User Stories v1.1](../user-stories/stories.md)

---

## 계획 (Checkboxes)

### Part 1: 질문 수집 및 분석
- [x] 유닛 분해 질문 생성
- [x] 사용자 답변 수집
- [x] 답변 분석 및 모호성 검증
- [x] 필요 시 후속 질문

### Part 2: 유닛 산출물 생성
- [x] unit-of-work.md — 유닛 정의 및 책임
- [x] unit-of-work-dependency.md — 유닛 의존성 매트릭스
- [x] unit-of-work-story-map.md — 스토리-유닛 매핑
- [x] 유닛 경계 및 의존성 검증
- [x] 모든 스토리가 유닛에 할당되었는지 확인

---

## 확정 유닛 구성 (4개)

| 유닛 | 범위 | 관련 컴포넌트 |
|------|------|--------------|
| Unit 1: Foundation Infrastructure | CDK 전체 (VPC, 서브넷, VPC Endpoints, Aurora, RDS Proxy, ECS skeleton, Lambda skeleton, API GW, ALB, AMP) | C1 |
| Unit 2: Shared Models & DB Migration | SQLAlchemy 모델, Alembic 마이그레이션, 공통 유틸리티, 프로젝트 설정 | C5 |
| Unit 3: Token Service | Lambda, Virtual Key 발급/조회 | C2 |
| Unit 4: Gateway (Runtime + Admin + Observability) | FastAPI 전체, 정책 평가, 변환, 스트리밍, 사용량, Admin API, Identity Sync, MetricsService | C3, C4, C6 |

---

## Units Generation 질문 및 답변

### Question 1: 유닛 분해 전략
**선택**: D + 수정 — 4개 유닛 (Unit 5 Admin + Unit 6 Observability를 Unit 4 Gateway에 통합)
**근거**: 순차 구현에서는 per-unit CONSTRUCTION 루프 횟수를 최소화하는 것이 효율적. Unit 6(Observability)는 코드량이 적어 별도 유닛 불필요. Admin API는 Gateway와 동일 프로세스이므로 함께 구현.

### Question 2: 구현 순서
**선택**: A — 의존성 순서 (Unit 1 → 2 → 3 → 4)
**근거**: 인프라 → 모델 → 서비스 순서로 자연스러운 의존성 해소

### Question 3: CDK 인프라 코드 할당
**선택**: A — 인프라 집중 (CDK 5개 스택 모두 Unit 1)
**근거**: 순차 구현에서는 CDK 분산의 이점이 적음. 인프라 일관성과 cross-reference 관리가 용이.

### Question 4: Gateway/Admin 코드 구분
**해소**: Q1에서 D 선택으로 Gateway + Admin이 동일 유닛(Unit 4)으로 통합되어 질문 해소

---

## 산출물

- [unit-of-work.md](../application-design/unit-of-work.md) — 유닛 정의 및 책임
- [unit-of-work-dependency.md](../application-design/unit-of-work-dependency.md) — 유닛 의존성 매트릭스
- [unit-of-work-story-map.md](../application-design/unit-of-work-story-map.md) — 스토리-유닛 매핑
