# Application Design Plan

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거 문서: [Requirements v1.1](../requirements/requirements.md), [User Stories v1.1](../user-stories/stories.md), [PRD v0.5](../../../docs/PRD.md), [System Architecture v0.3](../../../docs/SYSTEM_ARCHITECTURE.md), [ERD v0.3](../../../docs/ERD.md), [API Spec v0.4](../../../docs/API_SPEC.md)

---

## 설계 범위

본 Application Design은 다음 6개 주요 컴포넌트의 서비스 레이어 설계, 인터페이스 정의, 의존성 관계를 다룹니다.

1. CDK Infrastructure (IaC)
2. Lambda Token Service (Virtual Key 발급/관리)
3. FastAPI LLM Gateway (정책 평가, 프로토콜 변환, 스트리밍)
4. Admin API (사용자/팀/모델/예산/캐시 관리, Identity Sync)
5. Shared Models & DB Migration (SQLAlchemy, Alembic)
6. Observability (ADOT Sidecar, OTel 계측)

---

## 설계 계획 (Checkboxes)

### Part 1: 질문 수집 및 분석
- [x] 컴포넌트 경계 및 구조 질문 생성
- [x] 사용자 답변 수집
- [x] 답변 분석 및 모호성 검증 — 11개 답변 모두 명확, 모순 없음
- [x] 필요 시 후속 질문 — 불필요

### Part 2: 설계 산출물 생성
- [x] components.md — 컴포넌트 정의 및 책임
- [x] component-methods.md — 메서드 시그니처 및 인터페이스
- [x] services.md — 서비스 정의 및 오케스트레이션 패턴
- [x] component-dependency.md — 의존성 관계 및 통신 패턴
- [x] application-design.md — 통합 설계 문서
- [x] 설계 완전성 및 일관성 검증

---

## Application Design 질문

아래 질문에 답변해주세요. 각 질문의 `[Answer]:` 태그 뒤에 선택지 문자를 입력해주세요.

### 컴포넌트 경계 및 구조

## Question 1
Gateway(LLM Gateway)와 Admin API는 동일 FastAPI 앱 내에서 라우터 분리로 구현하기로 결정되었습니다(Q8). 내부 코드 구조를 어떻게 분리하시겠습니까?

A) 단일 패키지, 라우터만 분리 — `gateway/routers/runtime.py`, `gateway/routers/admin.py` 수준의 파일 분리
B) 도메인별 모듈 분리 — `gateway/domains/runtime/`, `gateway/domains/admin/`, `gateway/domains/sync/` 등 도메인 디렉토리로 분리하되 서비스/리포지토리 레이어 공유
C) 레이어드 아키텍처 — `gateway/api/`, `gateway/services/`, `gateway/repositories/`, `gateway/models/` 등 계층별 분리
X) Other (please describe after [Answer]: tag below)

[Answer]: B

## Question 2
정책 평가 체인(Virtual Key 검증 → 사용자 상태 → 팀 상태 → 모델 허용 → 예산 검사 → 캐시 정책)의 구현 패턴을 어떻게 하시겠습니까?

A) Chain of Responsibility 패턴 — 각 정책을 독립 핸들러로 구현하고 체인으로 연결
B) 단일 PolicyEngine 클래스 — 하나의 클래스에서 순차적으로 모든 정책을 평가하는 메서드 호출
C) Middleware 스택 — FastAPI middleware/dependency로 각 정책을 레이어링
X) Other (please describe after [Answer]: tag below)

[Answer]: A

## Question 3
Anthropic → Bedrock Converse 프로토콜 변환 로직의 구조를 어떻게 하시겠습니까?

A) 단일 Converter 클래스 — request 변환과 response 변환을 하나의 클래스에서 처리
B) Request/Response 분리 — `AnthropicToBedrock` (request 변환)과 `BedrockToAnthropic` (response 변환)을 별도 클래스로 분리
C) Content Block별 변환기 — text, tool_use, tool_result, image, document, thinking 등 content block 유형별로 개별 변환기를 두고 조합
X) Other (please describe after [Answer]: tag below)

[Answer]: B

### 서비스 레이어 설계

## Question 4
DB 접근 패턴을 어떻게 구성하시겠습니까?

A) Repository 패턴 — 엔터티별 Repository 클래스 (UserRepository, TeamRepository 등)를 두고 서비스에서 호출
B) 직접 쿼리 — 서비스 레이어에서 SQLAlchemy 세션을 직접 사용하여 쿼리 실행
C) DAO + Unit of Work — DAO 클래스와 Unit of Work 패턴을 조합하여 트랜잭션 관리
X) Other (please describe after [Answer]: tag below)

[Answer]: A

## Question 5
Lambda Token Service와 ECS FastAPI Gateway 간 코드 공유 전략은 어떻게 하시겠습니까?

A) shared/ 패키지 — SQLAlchemy 모델, 유틸리티, 상수를 shared/ 디렉토리에 두고 Lambda와 Gateway 모두에서 import
B) 독립 패키지 — Lambda와 Gateway가 각각 필요한 모델을 자체 정의 (중복 허용, 결합도 최소화)
C) 내부 PyPI 패키지 — shared 코드를 별도 Python 패키지로 빌드하여 Lambda와 Gateway에서 의존성으로 설치
X) Other (please describe after [Answer]: tag below)

[Answer]: A

## Question 6
스트리밍 응답(ConverseStream → Anthropic SSE) 처리 구조를 어떻게 하시겠습니까?

A) AsyncGenerator 기반 — `async for` 루프로 Bedrock 스트림을 소비하고 SSE 이벤트로 변환하여 yield
B) Callback 기반 — Bedrock 스트림 이벤트마다 콜백을 호출하여 SSE 이벤트를 생성
C) StreamProcessor 클래스 — 상태 머신 기반으로 Bedrock 이벤트를 추적하고 Anthropic SSE 이벤트 시퀀스를 관리
X) Other (please describe after [Answer]: tag below)

[Answer]: A

### 의존성 및 통신 패턴

## Question 7
예산 사전 검사와 사후 정산의 트랜잭션 경계를 어떻게 설정하시겠습니까?

A) 단일 트랜잭션 — 사전 검사 SELECT와 사후 정산 UPDATE를 하나의 DB 트랜잭션으로 묶음 (Bedrock 호출 중 커넥션 점유)
B) 분리 트랜잭션 — 사전 검사는 별도 읽기 트랜잭션, 사후 정산은 원자적 UPDATE ... RETURNING으로 별도 트랜잭션 (Q14 결정 기반)
C) 낙관적 잠금 — 사전 검사 시 버전을 읽고, 사후 정산 시 버전 일치 확인 후 업데이트
X) Other (please describe after [Answer]: tag below)

[Answer]: B

## Question 8
CDK 스택 분할 전략을 어떻게 하시겠습니까?

A) 단일 스택 — 모든 리소스를 하나의 CDK 스택에 정의
B) 계층별 분할 — NetworkStack (VPC/Endpoints), DataStack (Aurora/RDS Proxy), ComputeStack (ECS/Lambda), ApiStack (API Gateway/ALB), ObservabilityStack (AMP/ADOT)
C) 도메인별 분할 — TokenServiceStack, GatewayStack, AdminStack, SharedStack
X) Other (please describe after [Answer]: tag below)

[Answer]: B

## Question 9
OTel 메트릭 계측 코드의 위치를 어떻게 하시겠습니까?

A) Gateway 서비스 레이어에 직접 삽입 — usage_events 저장 직후 같은 서비스 메서드에서 metric emit
B) 전용 MetricsService — 메트릭 emit 로직을 별도 서비스로 분리하고, Gateway 서비스에서 호출
C) 이벤트 기반 — usage_events 저장 후 내부 이벤트를 발행하고, 메트릭 핸들러가 구독하여 emit
X) Other (please describe after [Answer]: tag below)

[Answer]: B

### 설계 패턴

## Question 10
FastAPI 의존성 주입(Dependency Injection) 전략을 어떻게 하시겠습니까?

A) FastAPI Depends 기본 — FastAPI의 `Depends()` 메커니즘으로 서비스/리포지토리를 주입
B) 수동 DI 컨테이너 — 앱 시작 시 서비스 인스턴스를 생성하고 `app.state`에 저장, 라우터에서 참조
C) DI 프레임워크 — `dependency-injector` 등 외부 DI 라이브러리 사용
X) Other (please describe after [Answer]: tag below)

[Answer]: A

## Question 11
에러 처리 및 응답 변환 전략을 어떻게 하시겠습니까?

A) 커스텀 예외 계층 — 도메인별 예외 클래스(BudgetExceededError, ModelNotAllowedError 등)를 정의하고 FastAPI exception handler에서 Anthropic-compatible 에러 응답으로 변환
B) Result 타입 — 서비스 메서드가 성공/실패를 Result 객체로 반환하고, 라우터에서 분기 처리
C) HTTP 예외 직접 사용 — FastAPI HTTPException을 서비스 레이어에서 직접 raise
X) Other (please describe after [Answer]: tag below)

[Answer]: A
