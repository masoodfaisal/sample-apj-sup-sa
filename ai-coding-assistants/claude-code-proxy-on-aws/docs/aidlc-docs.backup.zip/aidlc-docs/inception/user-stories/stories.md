# 사용자 스토리 (User Stories)

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거 문서: [PRD v0.5](../../../docs/PRD.md), [Requirements v1.1](../requirements/requirements.md), [personas.md](./personas.md)

---

## Epic 1: 인증 및 기본 Gateway

### Story 1.1 — SSO 인증 후 Virtual Key 발급

**Epic**: Epic 1 — 인증 및 기본 Gateway  
**페르소나**: 개발자  
**우선순위**: High  
**FR**: FR-1

**사용자 스토리**  
"SSO로 인증된 상태에서 Claude Code를 실행하면, 별도 작업 없이 Virtual Key가 자동으로 발급되어 이후 Gateway 호출에 사용되길 원한다."

**수용 기준 (AC)**:
- SSO 미인증 상태에서 Key 발급 요청 시 요청이 거부된다.
- INACTIVE 사용자 또는 미동기화 사용자의 Key 발급 요청이 거부된다.
- 정상 인증 사용자는 1초 내에 Virtual Key를 발급 또는 조회할 수 있다.
- 이미 활성 키가 존재하면 기존 키가 재반환된다.

**참조**: PRD 7.1, requirements.md FR-1

---

### Story 1.2 — Virtual Key로 Gateway 접근

**Epic**: Epic 1 — 인증 및 기본 Gateway  
**페르소나**: 개발자  
**우선순위**: High  
**FR**: FR-1, FR-3

**사용자 스토리**  
"발급받은 Virtual Key를 Claude Code의 API 요청 헤더에 포함하면, Gateway가 해당 키를 검증하고 요청을 처리하길 원한다."

**수용 기준 (AC)**:
- 유효한 Virtual Key로 Gateway 호출 시 정상 응답을 반환한다.
- 폐기된 Virtual Key로 Gateway 호출 시 요청이 즉시 실패한다.

**참조**: PRD 7.2, requirements.md FR-1, FR-3

---

### Story 1.3 — Claude Code 호환 Gateway 호출

**Epic**: Epic 1 — 인증 및 기본 Gateway  
**페르소나**: 개발자  
**우선순위**: High  
**FR**: FR-2

**사용자 스토리**  
"Claude Code가 보내는 Anthropic-compatible 요청을 Gateway가 올바르게 처리하고, Bedrock Converse API로 변환하여 결과를 반환하길 원한다."

**수용 기준 (AC)**:
- Claude Code가 커스텀 Gateway를 대상으로 정상 프롬프트/툴 호출을 수행할 수 있다.
- 스트리밍 응답 사용 시 세션이 중도 종료되지 않는다.
- Gateway는 Bedrock Converse/ConverseStream만 사용한다.

**참조**: PRD 7.2, requirements.md FR-2

---

### Story 1.4 — 모델 매핑 및 Fallback

**Epic**: Epic 1 — 인증 및 기본 Gateway  
**페르소나**: 개발자  
**우선순위**: Medium  
**FR**: FR-2, FR-4

**사용자 스토리**  
"Claude Code가 선택한 모델이 정의된 매핑 규칙에 따라 Bedrock 모델로 변환되길 원한다. 매핑되지 않는 모델은 기본 모델로 자동 라우팅되길 원한다."

**수용 기준 (AC)**:
- Claude Code가 선택한 모델에 대해 기본 매핑 규칙이 적용된다.
- 매핑되지 않는 모델은 Sonnet 4.6으로 fallback 된다.
- Claude Code의 프롬프트, 도구 호출, thinking 기능이 정상 동작한다.

**참조**: PRD 8.2, requirements.md FR-2, FR-4

---

### Story 1.5 — Virtual Key 관리

**Epic**: Epic 1 — 인증 및 기본 Gateway  
**페르소나**: 플랫폼 관리자, 보안 담당자  
**우선순위**: High  
**FR**: FR-3

**사용자 스토리**  
"사용자의 Virtual Key 상태를 조회하고, 필요 시 회전(rotate)하거나 즉시 폐기(revoke)할 수 있길 원한다."

**수용 기준 (AC)**:
- Admin API로 사용자별 Virtual Key 목록과 상태를 조회할 수 있다.
- Virtual Key 회전 시 새 키가 생성되고 기존 키는 비활성화된다.
- 보안 사고 시 Virtual Key를 즉시 폐기할 수 있고, 폐기된 키로 Gateway 호출이 실패한다.
- 키 생성/회전/폐기 이력이 감사 로그에 기록된다.

**참조**: requirements.md FR-3

---

### Story 1.6 — 기본 모델 카탈로그 등록

**Epic**: Epic 1 — 인증 및 기본 Gateway  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-4

**사용자 스토리**  
"Phase 1에서 Gateway가 동작하도록 Claude 4.5+ 기본 모델을 카탈로그에 등록하고, 매핑 규칙과 Sonnet 4.6 fallback을 설정할 수 있길 원한다."

**수용 기준 (AC)**:
- 기본 모델(Claude 4.5+ 계열)이 카탈로그에 등록된다.
- 모델 매핑 규칙이 설정되어 Gateway가 요청을 라우팅할 수 있다.
- fallback 모델(Sonnet 4.6)이 설정된다.

**참조**: PRD 8.4, requirements.md FR-4

---

## Epic 2: 거버넌스

### Story 2.1 — Identity Center 사용자 동기화

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-5, FR-11

**사용자 스토리**  
"IAM Identity Center의 사용자 정보를 시스템에 동기화할 수 있길 원한다. 신규 사용자는 INACTIVE 상태로 생성되고, 삭제된 사용자는 비활성화되길 원한다."

**수용 기준 (AC)**:
- Admin API로 sync 실행 시 Identity Store에서 사용자 정보를 가져온다.
- 신규 사용자는 INACTIVE로 생성된다.
- source에서 삭제된 사용자는 INACTIVE 전환 + source_deleted_at 기록된다.
- sync 실행 이력이 저장된다.

**참조**: PRD 7.3, requirements.md FR-5, FR-11

---

### Story 2.2 — 사용자 활성화/비활성화

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-5

**사용자 스토리**  
"동기화된 사용자를 ACTIVE 또는 INACTIVE로 수동 전환할 수 있길 원한다. ACTIVE 사용자만 Virtual Key 발급과 Gateway 사용이 가능하길 원한다."

**수용 기준 (AC)**:
- Admin API로 사용자 상태를 ACTIVE/INACTIVE로 변경할 수 있다.
- INACTIVE 사용자의 Key 발급 요청이 거부된다.
- INACTIVE 사용자의 Gateway 요청이 거부된다.

**참조**: PRD 8.5, requirements.md FR-5

---

### Story 2.3 — 팀 생성 및 관리

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-5

**사용자 스토리**  
"팀을 생성하고, 팀별 기본 예산 정책과 캐시 정책을 설정할 수 있길 원한다."

**수용 기준 (AC)**:
- Admin API로 팀을 생성/조회/비활성화할 수 있다.
- 팀별 기본 예산 정책(soft/hard limit)을 설정할 수 있다.
- 팀별 기본 캐시 정책(none/5m/1h)을 설정할 수 있다.

**참조**: PRD 8.5, requirements.md FR-5

---

### Story 2.4 — 팀 멤버십 관리

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-5

**사용자 스토리**  
"사용자를 팀에 추가하거나 제거할 수 있길 원한다. 한 사용자가 여러 팀에 소속될 수 있길 원한다."

**수용 기준 (AC)**:
- Admin API로 사용자-팀 멤버십을 추가/제거할 수 있다.
- 사용자당 다중 팀 소속이 가능하다.
- 기본 팀을 지정할 수 있다.
- 팀 미소속 사용자도 시스템 기본 정책으로 Gateway를 사용할 수 있다.

**참조**: PRD 8.5, requirements.md FR-5

---

### Story 2.5 — 모델 카탈로그 확장 관리

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-4

**사용자 스토리**  
"기본 카탈로그(Story 1.6) 외에 추가 Bedrock 모델을 등록하거나 기존 모델을 비활성화할 수 있길 원한다. 모델별 캐시 지원 여부와 capability를 관리하길 원한다."

**수용 기준 (AC)**:
- Admin API로 모델을 추가 등록/조회/비활성화할 수 있다.
- 비활성 모델은 전체 사용자에게 즉시 차단된다.
- capability 검증된 타 Converse 모델도 카탈로그에 추가할 수 있다.
- 모델별 가격 정책(input/output/cache_read 단가)을 설정하고 변경할 수 있다.
- cache_write 단가는 TTL(5m/1h)별로 별도 설정할 수 있다.

**참조**: PRD 8.4, requirements.md FR-4

---

### Story 2.6 — 모델 허용 정책

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-4

**사용자 스토리**  
"사용자 또는 팀별로 허용 모델 목록(allowlist)을 설정할 수 있길 원한다. 정책 우선순위는 사용자 override > 팀 기본값 > 시스템 기본값이길 원한다."

**수용 기준 (AC)**:
- Admin API로 사용자별 허용 모델을 설정할 수 있다.
- Admin API로 팀별 허용 모델을 설정할 수 있다.
- 허용되지 않은 모델 요청은 정책 오류로 차단된다.

**참조**: PRD 8.4, requirements.md FR-4

---

### Story 2.7 — 모델 별칭 매핑

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: Medium  
**FR**: FR-4

**사용자 스토리**  
"Claude Code가 선택하는 모델 패턴과 실제 Bedrock Model ID 간 매핑 규칙을 설정할 수 있길 원한다. priority 기반 평가와 fallback 여부를 설정하길 원한다."

**수용 기준 (AC)**:
- Admin API로 model_alias_mappings을 설정할 수 있다.
- selected_model_pattern → target_model_id 매핑이 가능하다.
- priority 기반 평가와 is_fallback 설정이 가능하다.

**참조**: requirements.md FR-4

---

### Story 2.8 — 예산 정책 생성

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-6

**사용자 스토리**  
"사용자 또는 팀별로 일/월 예산을 설정할 수 있길 원한다. soft_limit(경고)과 hard_limit(차단)을 분리하여 설정하길 원한다."

**수용 기준 (AC)**:
- Admin API로 USER/TEAM 범위의 DAILY/MONTHLY 예산을 생성할 수 있다.
- soft_limit_usd와 hard_limit_usd를 별도 설정할 수 있다.
- 선택적 model_id로 모델별 예산 정책을 설정할 수 있다.

**참조**: PRD 8.6, requirements.md FR-6

---

### Story 2.9 — 예산 초과 차단

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 개발자, 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-6

**사용자 스토리**  
"예산 hard_limit을 초과하면 추가 요청이 차단되길 원한다. soft_limit 초과 시 요청은 허용하되 경고가 발생하길 원한다."

**수용 기준 (AC)**:
- hard limit 초과 사용자는 추가 요청이 차단된다.
- soft limit 초과 시 요청은 허용하되 이벤트/메트릭이 기록된다.
- 일/월 집계가 자정 및 월 경계 기준으로 정확하게 반영된다.

**참조**: PRD 8.6, requirements.md FR-6

---

### Story 2.10 — 캐시 정책 설정

**Epic**: Epic 2 — 거버넌스  
**페르소나**: 플랫폼 관리자  
**우선순위**: Medium  
**FR**: FR-7

**사용자 스토리**  
"사용자 또는 팀별로 프롬프트 캐시 정책(none/5m/1h)을 설정할 수 있길 원한다. 기본값은 5분이길 원한다."

**수용 기준 (AC)**:
- Admin API로 사용자별 캐시 정책을 설정할 수 있다.
- Admin API로 팀별 캐시 정책을 설정할 수 있다.
- 기본값은 5분이다.
- 지원하지 않는 모델은 자동으로 none 처리된다.

**참조**: PRD 8.7, requirements.md FR-7

---

## Epic 3: 사용량 및 관측

### Story 3.1 — 토큰 사용량 저장 및 조회

**Epic**: Epic 3 — 사용량 및 관측  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-8

**사용자 스토리**  
"Gateway 요청마다 토큰 사용량과 비용이 저장되길 원한다. 사용자별, 팀별, 모델별로 요청 단위 상세와 일/월 집계를 조회할 수 있길 원한다."

**수용 기준 (AC)**:
- 개별 요청 상세와 일별/월별 합계가 모두 조회 가능하다.
- 사용자/팀/모델 조건으로 집계가 가능하다.
- 프롬프트/응답 본문은 저장하지 않는다.

**참조**: PRD 8.8, requirements.md FR-8

---

### Story 3.2 — ADOT 메트릭 전송

**Epic**: Epic 3 — 사용량 및 관측  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-9

**사용자 스토리**  
"Gateway가 Bedrock 응답에서 확정한 사용자 단위 usage/cost/request duration 메트릭이 ADOT Collector를 통해 AMP로 전송되길 원한다. 사용자/팀/모델 단위 attribute로 구분하여 조회할 수 있길 원한다."

**수용 기준 (AC)**:
- 메트릭이 1분 이내 AMP에서 확인 가능하다.
- `bedrock.token.usage`, `bedrock.cost.usage`, `bedrock.request.duration`가 AMP에서 조회 가능하다.
- 사용자/팀/모델 단위로 메트릭을 구분하여 조회할 수 있다.
- 토큰 사용량은 `token_type=input|output|cache_read|cache_write` 기준으로 분해 조회할 수 있다.

**참조**: PRD 8.9, requirements.md FR-9

---

### Story 3.3 — 감사 로그 기록

**Epic**: Epic 3 — 사용량 및 관측  
**페르소나**: 보안 담당자, 플랫폼 관리자  
**우선순위**: High  
**FR**: FR-10

**사용자 스토리**  
"인증 실패, 예산 차단, 모델 차단, 키 회전/폐기, 시스템 오류 등의 이벤트가 감사 로그에 기록되길 원한다."

**수용 기준 (AC)**:
- 보안/운영 이벤트가 audit_events 테이블에 기록된다.
- 모든 요청은 request_id로 추적 가능하다.
- 민감정보(Virtual Key 원문, 프롬프트/응답 본문)는 로그에 남지 않는다.

**참조**: PRD 8.10, requirements.md FR-10

---

## Epic 4: 보안 및 운영성 (Cross-cutting NFR)

> Epic 1~3은 PRD Phase 기반 대분류이며, Epic 4는 특정 Phase에 종속되지 않는 cross-cutting 보안/운영성 요구사항을 다룬다.

### Story 4.1 — TLS 통신 보장

**Epic**: Epic 4 — 보안  
**페르소나**: 보안 담당자  
**우선순위**: High  
**FR**: NFR-1

**사용자 스토리**  
"모든 외부 통신이 TLS로 암호화되길 원한다. 비암호화 통신은 거부되길 원한다."

**수용 기준 (AC)**:
- 모든 외부 통신이 TLS로 암호화된다.
- 비암호화 통신 경로가 존재하지 않는다.

**참조**: PRD 12.1, requirements.md NFR-1

---

### Story 4.2 — 접근 통제 모니터링

**Epic**: Epic 4 — 보안  
**페르소나**: 보안 담당자  
**우선순위**: High  
**FR**: NFR-1, FR-10

**사용자 스토리**  
"비정상적인 접근 시도를 탐지하고 알람을 받을 수 있길 원한다. 인증 실패 빈도가 높은 사용자를 식별할 수 있길 원한다."

**수용 기준 (AC)**:
- 인증 실패 이벤트가 감사 로그에 기록된다.
- 비정상 접근 패턴 탐지 가능
- 보안 알람 설정 가능

**참조**: PRD 12.1, requirements.md NFR-1, FR-10

---

### Story 4.3 — 보안 정책 준수 확인

**Epic**: Epic 4 — 보안  
**페르소나**: 보안 담당자  
**우선순위**: Medium  
**FR**: NFR-1

**사용자 스토리**  
"VPC Endpoint를 통한 비공개 통신, IAM 최소 권한 원칙 등 보안 정책이 준수되고 있는지 확인할 수 있길 원한다."

**수용 기준 (AC)**:
- VPC Endpoint 기반 private connectivity 확인
- IAM 권한 최소화 원칙 적용 확인
- 보안 그룹/NACL 설정 확인

**참조**: PRD 12.1.1, requirements.md NFR-1

---

### Story 4.4 — 장애 원인 추적

**Epic**: Epic 4 — 보안 및 운영성 (Cross-cutting)  
**페르소나**: 플랫폼 관리자  
**우선순위**: High  
**FR**: NFR-4

**사용자 스토리**  
"request_id 기반으로 메트릭, 로그, trace를 correlation하여 장애 원인을 추적할 수 있길 원한다."

**수용 기준 (AC)**:
- 모든 요청에 request_id가 부여되고 로그/메트릭에 포함된다.
- request_id로 특정 요청의 전체 처리 경로를 추적할 수 있다.
- 주요 운영 이벤트에 대한 알람이 설정 가능하다.

**참조**: requirements.md NFR-4

---

## 스토리 인덱스

| Epic | Story ID | 제목 | 페르소나 | 우선순위 |
|------|----------|------|----------|----------|
| Epic 1 | 1.1 | SSO 인증 후 Virtual Key 발급 | 개발자 | High |
| Epic 1 | 1.2 | Virtual Key로 Gateway 접근 | 개발자 | High |
| Epic 1 | 1.3 | Claude Code 호환 Gateway 호출 | 개발자 | High |
| Epic 1 | 1.4 | 모델 매핑 및 Fallback | 개발자 | Medium |
| Epic 1 | 1.5 | Virtual Key 관리 | 플랫폼 관리자, 보안 담당자 | High |
| Epic 1 | 1.6 | 기본 모델 카탈로그 등록 | 플랫폼 관리자 | High |
| Epic 2 | 2.1 | Identity Center 사용자 동기화 | 플랫폼 관리자 | High |
| Epic 2 | 2.2 | 사용자 활성화/비활성화 | 플랫폼 관리자 | High |
| Epic 2 | 2.3 | 팀 생성 및 관리 | 플랫폼 관리자 | High |
| Epic 2 | 2.4 | 팀 멤버십 관리 | 플랫폼 관리자 | High |
| Epic 2 | 2.5 | 모델 카탈로그 확장 관리 | 플랫폼 관리자 | High |
| Epic 2 | 2.6 | 모델 허용 정책 | 플랫폼 관리자 | High |
| Epic 2 | 2.7 | 모델 별칭 매핑 | 플랫폼 관리자 | Medium |
| Epic 2 | 2.8 | 예산 정책 생성 | 플랫폼 관리자 | High |
| Epic 2 | 2.9 | 예산 초과 차단 | 개발자, 플랫폼 관리자 | High |
| Epic 2 | 2.10 | 캐시 정책 설정 | 플랫폼 관리자 | Medium |
| Epic 3 | 3.1 | 토큰 사용량 저장 및 조회 | 플랫폼 관리자 | High |
| Epic 3 | 3.2 | ADOT 메트릭 전송 | 플랫폼 관리자 | High |
| Epic 3 | 3.3 | 감사 로그 기록 | 보안 담당자, 플랫폼 관리자 | High |
| Epic 4 | 4.1 | TLS 통신 보장 | 보안 담당자 | High |
| Epic 4 | 4.2 | 접근 통제 모니터링 | 보안 담당자 | High |
| Epic 4 | 4.3 | 보안 정책 준수 확인 | 보안 담당자 | Medium |
| Epic 4 | 4.4 | 장애 원인 추적 | 플랫폼 관리자 | High |

**총 스토리 수: 23개**
