# Code Reuse Review: token_service Module (Commit 5016015)

## Summary
The token_service module has SEVERAL significant reuse opportunities and some duplication patterns. The analysis below identifies where existing shared utilities could be leveraged and where new patterns should be centralized.

---

## CRITICAL ISSUES

### 1. Database Connection Setup (HIGH PRIORITY)
**File**: `token_service/core/database.py` - `get_database_url()` function

**Issue**: AWS Secrets Manager retrieval is duplicated. The `get_database_url()` function fetches database credentials from Secrets Manager inline. This pattern is NOT present elsewhere in the codebase but SHOULD be centralized.

**Current Code**:
```python
def get_database_url() -> str:
    secret_arn = os.environ["DB_SECRET_ARN"]
    rds_endpoint = os.environ["RDS_PROXY_ENDPOINT"]

    sm_client = boto3.client("secretsmanager")
    response = sm_client.get_secret_value(SecretId=secret_arn)
    secret = json.loads(response["SecretString"])

    username = secret["username"]
    password = secret["password"]

    return f"postgresql+asyncpg://{username}:{password}@{rds_endpoint}:5432/claude_proxy"
```

**Recommendation**: Move this to `shared/utils/secrets.py` or similar. This pattern will likely be reused by other Lambda functions.

**Why**: 
- Centralizes boto3 Secrets Manager handling (testable, maintainable)
- Reduces copy-paste errors across multiple Lambda services
- Single location for credential security concerns

---

### 2. Environment Variable Validation Pattern (MEDIUM PRIORITY)
**File**: `token_service/core/config.py` - `Config.validate()` class method

**Issue**: The `REQUIRED_VARS` validation pattern is specific to token_service but no centralized approach exists in shared utils for env var validation.

**Current Code**:
```python
@classmethod
def validate(cls) -> None:
    missing = [v for v in cls.REQUIRED_VARS if v not in os.environ]
    if missing:
        raise RuntimeError(f"Missing required environment variable(s): {', '.join(missing)}")
```

**Recommendation**: Create a reusable utility in `shared/utils/config.py` to validate required environment variables.

**Why**:
- Gateway module and other Lambda functions will need similar validation
- Centralizes error handling for missing config
- Consistent error messages across services

**Usage Pattern**:
```python
def validate_required_env(*vars: str) -> None:
    """Raise if any required env vars are missing."""
```

---

## MODERATE ISSUES

### 3. JSON Logging Formatter (MEDIUM PRIORITY)
**File**: `token_service/core/config.py` - `JSONFormatter` class

**Issue**: Custom JSON formatter for CloudWatch Logs Insights is specific to token_service. While the gateway module doesn't appear to have this, other Lambda services will likely need similar JSON structured logging for CloudWatch.

**Current Code**:
```python
class JSONFormatter(logging.Formatter):
    """CloudWatch Logs Insights compatible JSON formatter."""
    def format(self, record: logging.LogRecord) -> str:
        log_obj: dict[str, object] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
        }
        # ... adds contextual fields
```

**Recommendation**: Move to `shared/utils/logging.py` for reuse across Lambda functions.

**Why**:
- Multiple Lambda services will benefit from CloudWatch Logs Insights compatible logging
- Consistent log structure for observability
- Reusable across all microservices

---

### 4. Lambda Error Response Builder (MEDIUM PRIORITY)
**File**: `token_service/utils.py` - `handle_error()` function

**Issue**: The `handle_error()` function formats Lambda Proxy Integration responses. This will be needed by other Lambda handlers.

**Current Code**:
```python
def handle_error(
    status_code: int,
    error_code: str,
    message: str,
    request_id: str,
    retryable: bool,
) -> dict:
    """Build a Lambda Proxy Integration error response."""
```

**Recommendation**: Move to `shared/utils/lambda_response.py` alongside other Lambda utilities.

**Why**:
- Consistent error response format across all Lambda functions
- Single location for API contract compliance
- Reusable across token_service, gateway Lambda handlers, etc.

---

## MINOR ISSUES

### 5. Request ID Extraction (LOW-MEDIUM PRIORITY)
**File**: `token_service/utils.py` - `extract_request_id()` function

**Issue**: Request ID extraction from API Gateway event is also in `token_service/utils.py`. The gateway module has similar logic in `gateway/core/middleware.py::RequestIdMiddleware` but for FastAPI (not Lambda).

**Current Code** (token_service):
```python
def extract_request_id(event: dict) -> str:
    """Extract request ID: x-request-id header > API GW requestId > generated uuid."""
    headers = event.get("headers") or {}
    for key, value in headers.items():
        if key.lower() == "x-request-id" and value:
            return value
    api_gw_id = event.get("requestContext", {}).get("requestId")
    if api_gw_id:
        return api_gw_id
    return f"req_{uuid.uuid4().hex}"
```

**Comparison** (gateway):
```python
# In RequestIdMiddleware - FastAPI context
request_id = request.headers.get(self._settings.request_id_header) or f"req_{uuid4().hex}"
```

**Recommendation**: Create `shared/utils/request_id.py` with utilities for both Lambda event and FastAPI request contexts.

**Why**:
- Centralizes request ID generation logic
- Ensures consistent fallback behavior across services
- DRY principle

---

## DUPLICATION WITH EXISTING PATTERNS

### 6. AsyncSession Usage Pattern (CONFIRMED - NOT AN ISSUE)
**Files**: `token_service/handler.py`, `token_service/utils.py`

**Status**: ✓ GOOD - Correctly uses shared models (`AuditEvent` from `shared.models.audit`)

The pattern of creating AsyncSession and adding audit events is correct:
```python
async with AsyncSession(engine) as session:
    async with session.begin():
        audit_event = AuditEvent(...)
        session.add(audit_event)
```

No action needed - aligns with shared model usage.

---

## GOOD PATTERNS (NO ACTION NEEDED)

### 7. Service Layer Structure (CONFIRMED - GOOD)
**Files**: `token_service/services/user_lookup_service.py`, `token_service/services/virtual_key_service.py`

**Status**: ✓ GOOD - Well-designed, uses shared models and exceptions correctly

- Correctly imports `UserNotFoundError`, `UserInactiveError` from `shared.exceptions`
- Uses `shared.models.user.User`, `shared.models.virtual_key.VirtualKey`
- Uses `shared.utils.hashing.generate_api_key()` ✓
- Uses `shared.utils.kms.KmsHelper` ✓
- Uses `shared.utils.constants.UserStatus`, `VirtualKeyStatus` ✓

No refactoring needed here.

---

## SUMMARY TABLE

| Issue | File | Pattern | Priority | Action |
|-------|------|---------|----------|--------|
| Secrets Manager retrieval | `core/database.py` | `get_database_url()` | HIGH | Move to `shared/utils/secrets.py` |
| Env var validation | `core/config.py` | `Config.validate()` | MEDIUM | Create `shared/utils/config.py` utility |
| JSON logging format | `core/config.py` | `JSONFormatter` | MEDIUM | Move to `shared/utils/logging.py` |
| Lambda error responses | `utils.py` | `handle_error()` | MEDIUM | Move to `shared/utils/lambda_response.py` |
| Request ID extraction | `utils.py` | `extract_request_id()` | LOW-MEDIUM | Create `shared/utils/request_id.py` |

---

## RECOMMENDED REFACTORING ORDER

1. **Phase 1 (High Impact)**: 
   - Extract Secrets Manager pattern to `shared/utils/secrets.py`
   - This unblocks other Lambda services needing DB credentials

2. **Phase 2 (Medium Priority)**:
   - Extract JSON logging to `shared/utils/logging.py`
   - Extract error response builder to `shared/utils/lambda_response.py`
   - Extract env var validation to `shared/utils/config.py`

3. **Phase 3 (Nice to Have)**:
   - Extract request ID utilities to `shared/utils/request_id.py`
   - Consolidate with gateway's request ID handling

---

## CODE QUALITY ASSESSMENT

**Overall**: The token_service code is well-structured with good separation of concerns. The issues identified are **not defects** but rather **reuse opportunities** for future scalability.

- ✓ Correct exception hierarchy usage
- ✓ Proper async/await patterns
- ✓ Good service layer abstraction
- ✓ Uses shared models appropriately
- ⚠ Contains Lambda-specific utilities that should be centralized
- ⚠ Contains infrastructure code (DB setup, Secrets Manager) that blocks reuse
