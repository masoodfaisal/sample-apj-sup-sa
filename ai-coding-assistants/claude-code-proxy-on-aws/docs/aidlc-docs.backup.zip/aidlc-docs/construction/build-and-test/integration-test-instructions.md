# Integration Test Instructions

## Project: Claude Code Proxy on AWS

## Overview
Integration tests verify that the four units work together correctly:
- Unit 2 (Shared Models) ↔ Unit 3 (Token Service): Virtual key model contracts
- Unit 2 (Shared Models) ↔ Unit 4 (Gateway): User/team model contracts
- Unit 3 (Token Service) ↔ Unit 4 (Gateway): Virtual key lookup interface
- Unit 1 (Infrastructure) ↔ All: Environment variable and secret name conventions

## Prerequisites
- All unit tests passing
- PostgreSQL available (Docker recommended): `docker-compose up -d postgres`
- `DATABASE_URL` environment variable set

## Running Integration Tests

```bash
# Start dependencies
docker-compose up -d

# Wait for postgres ready
until docker exec $(docker ps -q -f name=postgres) pg_isready; do sleep 1; done

# Run migrations
DATABASE_URL=postgresql+asyncpg://proxy:proxy@localhost:5432/proxydb uv run alembic upgrade head

# Run integration tests (to be generated in tests/integration/)
uv run pytest tests/integration/ -v
```

## Integration Test Scope

### 1. Virtual Key Round-Trip (Unit 2 + Unit 3)
- Create a VirtualKey record via shared models
- Look up by fingerprint via token_service UserLookupService
- Verify KMS encrypt/decrypt round-trip

### 2. Policy Chain with DB Models (Unit 2 + Unit 4)
- Load User + Team from shared models
- Run Gateway PolicyChain handlers
- Verify budget enforcement results

### 3. Database Schema Consistency (Unit 2)
- Apply all Alembic migrations against real PostgreSQL
- Verify all tables/indexes exist per ERD

### 4. API Contract: Token Service → Gateway
- VirtualKeyResponse schema from Unit 3 matches what Gateway handlers expect
- ErrorResponse schema is consistent across units

## Docker Compose Reference
See `docker-compose.yml` at workspace root for service definitions.
