# Unit Test Instructions

## Project: Claude Code Proxy on AWS

### Test Framework
- pytest 8.3+ with pytest-asyncio 0.25+
- Coverage via pytest-cov 6+
- Property-based testing via hypothesis 6.131+

### Run All Unit Tests

```bash
uv run pytest tests/ --cov --cov-report=term-missing -v
```

### Run Per-Unit Tests

```bash
# Unit 1: Foundation Infrastructure (CDK stack tests)
uv run pytest tests/test_api_stack.py tests/test_compute_stack.py tests/test_data_stack.py tests/test_network_stack.py tests/test_observability_stack.py -v

# Unit 2: Shared Models & DB Migration
uv run pytest tests/unit/shared/ -v

# Unit 3: Token Service
uv run pytest tests/unit/token_service/ -v

# Unit 4: Gateway
uv run pytest tests/unit/gateway/ -v
```

### Coverage Thresholds
Per system-nfr-decisions.md:
- Unit 1 (CDK): no hard coverage requirement (infra snapshot tests)
- Unit 2 (Shared): ≥80% line coverage
- Unit 3 (Token Service): ≥80% line coverage
- Unit 4 (Gateway): ≥70% line coverage (2 smoke tests currently)

### Expected Test Counts
- Unit 1: CDK snapshot/stack tests (~5 test files)
- Unit 2: 127 passing tests (shared models, schemas, migration constraints, hashing, KMS)
- Unit 3: included in 127 count (config, database, handler, models, services)
- Unit 4: 2 smoke tests (core syntax)

### Property-Based Tests (Hypothesis)
Hypothesis strategies are in `tests/unit/token_service/strategies.py`.
Hypothesis tests run as part of the normal pytest suite — no separate invocation needed.

### Async Test Configuration
`asyncio_mode = "auto"` is set in `pyproject.toml` — all async test functions run automatically.
