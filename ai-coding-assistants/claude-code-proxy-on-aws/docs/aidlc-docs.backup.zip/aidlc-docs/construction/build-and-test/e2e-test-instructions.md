# End-to-End Test Instructions

## Project: Claude Code Proxy on AWS

## Overview
E2E tests verify complete user workflows against a running deployment.
These tests require a deployed environment (local docker-compose or AWS).

## Prerequisites
- All unit and integration tests passing
- Docker Compose running: `docker-compose up`
- Or: AWS deployment with `cdk deploy` complete

## E2E Test Scenarios

### Scenario 1: Virtual Key Lifecycle
1. Create a virtual key via Token Service (POST /tokens)
2. Use the virtual key to send a proxied message (POST /v1/messages) via Gateway
3. Verify token usage is recorded
4. Revoke the virtual key
5. Verify subsequent requests are rejected with 401

### Scenario 2: Budget Enforcement
1. Create a user with a hard budget limit (e.g., $1.00)
2. Send requests that consume the budget
3. Verify hard limit blocks further requests

### Scenario 3: Model Policy
1. Create a team with allowed models list
2. Send a request with a disallowed model
3. Verify 403 response with policy violation detail

### Scenario 4: Admin API (SigV4)
1. List virtual keys (GET /admin/keys) with valid SigV4 auth
2. Attempt same endpoint without auth — expect 403
3. Attempt same endpoint with Virtual Key auth — expect 403

## Running E2E Tests

```bash
# Local (docker-compose)
docker-compose up -d
export BASE_URL=http://localhost:8000
uv run pytest tests/e2e/ -v --timeout=60

# AWS deployment
export BASE_URL=https://<api-gateway-id>.execute-api.ap-northeast-2.amazonaws.com/prod
uv run pytest tests/e2e/ -v --timeout=120
```

## Note
E2E test scaffold files are to be generated in `tests/e2e/`. Manual execution is required as E2E tests need a running environment.
