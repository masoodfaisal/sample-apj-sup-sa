# Security Test Instructions

## Project: Claude Code Proxy on AWS

## Overview
Security baseline is level A (all SECURITY rules are blocking constraints) per system-nfr-decisions.md.

## Dependency Vulnerability Scan

```bash
# pip-audit (preferred)
uv run pip-audit

# safety (alternative)
uv run safety check
```

## Static Security Analysis (Bandit)

```bash
# Install bandit if not present
uv add --group dev bandit

# Run on all application code
uv run bandit -r shared/ token_service/ gateway/ -ll
```

## Key Security Checks

### KMS Encryption (5.1 in system-nfr-decisions.md)
- Virtual Keys must never be stored in plaintext
- Test: `tests/unit/shared/test_kms.py` validates KMS encrypt/decrypt
- Test: `tests/unit/shared/test_hashing.py` validates SHA-256 fingerprint

### Constant-Time Comparison
- Virtual Key lookups use SHA-256 fingerprint to prevent timing attacks
- Ensure no string equality comparison on raw key values

### SQL Injection
- All DB queries use SQLAlchemy ORM with parameterized queries
- No raw SQL string interpolation

### Secret Exposure
- No hardcoded credentials in source
- AWS Secrets Manager used for DB password (infra design)
- KMS key ARN from environment variable

### Audit Logging
- All authorization failures logged to `audit_events` table
- Review `gateway/core/` for audit log writes

## Running Security Checks in CI

```bash
uv run ruff check . --select S  # ruff security rules (subset of bandit)
uv run pip-audit --strict
```
