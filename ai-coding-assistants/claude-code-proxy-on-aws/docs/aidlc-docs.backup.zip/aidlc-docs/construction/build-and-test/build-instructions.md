# Build Instructions

## Project: Claude Code Proxy on AWS

### Prerequisites
- Python 3.13 (exactly, <3.14)
- uv package manager (https://github.com/astral-sh/uv)
- Docker (for database migration verification, optional)
- AWS credentials (for CDK synth, optional during unit tests)

### Environment Setup

```bash
# Install uv if not present
curl -LsSf https://astral.sh/uv/install.sh | sh

# Sync all dependencies including dev group
uv sync --group dev
```

### Configure Environment

```bash
# Copy sample env (if present) or set required env vars
export PYTHONPATH=.
export AWS_DEFAULT_REGION=ap-northeast-2
```

### Build All Units

This is a Python project. "Build" means verifying that all modules import without error and that static analysis passes.

```bash
# Verify Python compilation for all source modules
uv run python -m py_compile shared/__init__.py
uv run python -m py_compile shared/models/__init__.py
uv run python -m py_compile token_service/__init__.py
uv run python -m py_compile gateway/__init__.py

# Lint check (ruff)
uv run ruff check .

# CDK synth (optional — requires AWS credentials)
cd infra && uv run npx cdk synth --all 2>&1 || echo "CDK synth skipped (no AWS creds)"
```

### Verify Build Success

```bash
uv run python -c "import shared; import token_service; import gateway; print('All modules importable')"
```

### Troubleshooting

- **ImportError on shared models**: ensure `PYTHONPATH=.` is set
- **CDK synth fails**: ensure `cdk.json` exists in `infra/` and AWS credentials are configured
- **Python version mismatch**: use `uv python install 3.13` to install correct version
