# Code Generation Plan -- Unit 3: Token Service

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Functional Design](../functional-design/), [System NFR Decisions](../../system-nfr-decisions.md), [Unit 2 Code Gen Plan](../../unit-2-shared-models/code-generation/code-generation-plan.md)

---

## Unit Context

| 항목 | 내용 |
|------|------|
| 컴포넌트 | Unit 3 Token Service |
| 복잡도 | Low (~10개 파일) |
| 의존성 | Unit 1 (CDK infra), Unit 2 (shared models/utils) |
| 산출물 위치 | `token_service/`, `shared/exceptions.py`, `tests/unit/token_service/`, `infra/stacks/compute_stack.py` |

### 현재 코드베이스 상태

- `shared/models/` -- ORM 모델 존재 (User, VirtualKey, AuditEvent)
- `shared/utils/kms.py` -- KmsHelper 존재 (`KMS_KEY_ID` 환경변수 사용)
- `shared/utils/hashing.py` -- `generate_api_key()`, `sha256_hex()` 존재
- `shared/utils/constants.py` -- StrEnum 존재 (UserStatus, VirtualKeyStatus 등)
- `shared/exceptions.py` -- **미존재** (Unit 2에서 누락, Unit 3에서 생성 필요)
- `token_service/` -- **미존재** (신규 디렉토리, Python 예약어 `lambda`와 충돌 방지를 위해 이 이름 사용)
- `infra/stacks/compute_stack.py` -- Lambda skeleton (from_inline placeholder)

---

## Generation Steps

### Step 1: Shared Exceptions (선행 의존성)

- [ ] `shared/exceptions.py` 생성

| 항목 | 내용 |
|------|------|
| 경로 | `shared/exceptions.py` |
| 목적 | 전체 시스템 공유 예외 계층 (Unit 3, Unit 4 공용) |
| 핵심 클래스 | 전체 시스템 예외 계층 (Unit 3 + Unit 4 공용, 한번에 전체 생성하여 Unit 4에서 재수정 방지) |
| 의존성 | 없음 (순수 Python) |
| 예상 LOC | ~60 |

**예외 계층 구조** (system-nfr-decisions.md 3.2절 전체):
```
AppError (base)
+-- AuthenticationError
|   +-- InvalidKeyError          # Unit 4 Gateway
|   +-- KeyRevokedError          # Unit 4 Gateway
+-- AuthorizationError
|   +-- UserNotFoundError        # Unit 3 Token Service
|   +-- UserInactiveError        # Unit 3 Token Service, Unit 4 Gateway
|   +-- TeamInactiveError        # Unit 4 Gateway
|   +-- ModelNotAllowedError     # Unit 4 Gateway
+-- BudgetExceededError          # Unit 4 Gateway
+-- UpstreamError
|   +-- BedrockError             # Unit 4 Gateway
|   +-- BedrockThrottlingError   # Unit 4 Gateway
+-- ValidationError              # Unit 4 Gateway
+-- InternalError                # Unit 3, Unit 4
```

#### Test Plan -- shared/exceptions.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/shared/test_exceptions.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 100% |

**테스트 케이스**:
- [ ] `test_app_error_is_base_exception` -- AppError가 Exception의 서브클래스인지 확인
- [ ] `test_authentication_error_hierarchy` -- AuthenticationError -> AppError 상속 확인
- [ ] `test_invalid_key_error_hierarchy` -- InvalidKeyError -> AuthenticationError -> AppError
- [ ] `test_key_revoked_error_hierarchy` -- KeyRevokedError -> AuthenticationError -> AppError
- [ ] `test_authorization_error_hierarchy` -- AuthorizationError -> AppError
- [ ] `test_user_not_found_error_hierarchy` -- UserNotFoundError -> AuthorizationError
- [ ] `test_user_inactive_error_hierarchy` -- UserInactiveError -> AuthorizationError
- [ ] `test_internal_error_hierarchy` -- InternalError -> AppError
- [ ] `test_all_errors_carry_message` -- 각 예외가 사용자 메시지를 올바르게 전달
- [ ] `test_except_app_error_catches_all_subclasses` -- `except AppError`로 모든 하위 예외 catch 가능

**Assertions**:
- `isinstance(UserNotFoundError("msg"), AuthorizationError)` is True
- `isinstance(InvalidKeyError("msg"), AuthenticationError)` is True
- `str(InternalError("test"))` == "test"

---

### Step 2: Lambda Core Layer (config, database)

- [ ] `token_service/__init__.py` 생성
- [ ] `token_service/core/__init__.py` 생성
- [ ] `token_service/services/__init__.py` 생성
- [ ] `token_service/core/config.py` 생성
- [ ] `token_service/core/database.py` 생성

#### 2a. token_service/core/config.py

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/core/config.py` |
| 목적 | 환경변수 검증, JSON 로거 설정 |
| 핵심 요소 | `Config` 클래스 (validate()), `JSONFormatter`, 로거 설정 |
| 의존성 | `os`, `logging`, `json` (표준 라이브러리만) |
| 예상 LOC | ~80 |

**핵심 로직**:
- `Config.validate()`: 필수 환경변수 4개 검증 (`DB_SECRET_ARN`, `RDS_PROXY_ENDPOINT`, `KMS_KEY_ID`, `PROXY_BASE_URL`)
- `LOG_LEVEL`: 선택 (기본 INFO)
- `JSONFormatter`: CloudWatch Logs Insights 호환 JSON 포맷
- 모듈 레벨에서 `Config.validate()` 호출하지 **않음** (테스트 편의를 위해 handler.py 모듈 레벨에서 호출)

**주의**: `Config.validate()`의 모듈 레벨 실행은 `token_service/handler.py`에서 수행. config.py 자체는 클래스 정의만 포함하여 테스트 시 환경변수 없이도 import 가능하게 설계.

#### 2b. token_service/core/database.py

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/core/database.py` |
| 목적 | Module-level async engine 생성, DB URL 구성 |
| 핵심 함수 | `get_database_url()`, `get_engine()` |
| 의존성 | `sqlalchemy.ext.asyncio`, `boto3`, `json`, `os` |
| 예상 LOC | ~50 |

**핵심 로직**:
- `get_database_url()`: Secrets Manager에서 DB credentials 조회 -> connection string 구성
- `get_engine()`: lazy singleton 패턴으로 async engine 생성 (테스트에서 mock 가능)
- `pool_size=1, max_overflow=0, connect_args={"ssl": True}`

**주의**: engine을 모듈 레벨 전역 변수로 즉시 생성하지 않고, `get_engine()` 함수로 lazy 초기화. handler.py에서 모듈 레벨에 `engine = get_engine()` 호출. 이렇게 하면 테스트에서 database.py import 시 Secrets Manager 호출 없이 동작 가능.

#### Test Plan -- token_service/core/

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_config.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 90% |

**test_config.py 테스트 케이스**:
- [ ] `test_config_validate_success` -- 모든 필수 환경변수 존재 시 성공
- [ ] `test_config_validate_missing_db_secret_arn` -- DB_SECRET_ARN 누락 시 RuntimeError
- [ ] `test_config_validate_missing_rds_proxy_endpoint` -- RDS_PROXY_ENDPOINT 누락 시 RuntimeError
- [ ] `test_config_validate_missing_kms_key_id` -- KMS_KEY_ID 누락 시 RuntimeError
- [ ] `test_config_validate_missing_proxy_base_url` -- PROXY_BASE_URL 누락 시 RuntimeError
- [ ] `test_config_log_level_default` -- LOG_LEVEL 미설정 시 기본값 "INFO"
- [ ] `test_config_log_level_custom` -- LOG_LEVEL 설정 시 해당 값 사용
- [ ] `test_json_formatter_output_is_valid_json` -- JSONFormatter 출력이 유효한 JSON
- [ ] `test_json_formatter_includes_required_fields` -- timestamp, level, message, logger 필드 포함
- [ ] `test_json_formatter_includes_request_id_extra` -- request_id extra 필드 포함

**Assertions**:
- `RuntimeError` 메시지에 누락된 변수명 포함
- JSON 파싱 결과에 `timestamp`, `level`, `message` 키 존재

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_database.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 80% |

**test_database.py 테스트 케이스**:
- [ ] `test_get_database_url_constructs_valid_url` -- Secrets Manager mock -> 올바른 PostgreSQL URL 반환
- [ ] `test_get_database_url_uses_rds_proxy_endpoint` -- URL에 RDS_PROXY_ENDPOINT 포함
- [ ] `test_get_engine_returns_async_engine` -- AsyncEngine 인스턴스 반환
- [ ] `test_get_engine_singleton` -- 두 번 호출해도 동일 engine 반환 (teardown에서 singleton 상태 리셋)

**Assertions**:
- URL 형식: `postgresql+asyncpg://...@{endpoint}:5432/claude_proxy`

---

### Step 3: Lambda Models (dataclass)

- [ ] `token_service/models.py` 생성

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/models.py` |
| 목적 | TokenRequest, TokenResponse, ErrorResponse dataclass |
| 핵심 클래스 | `TokenRequest` (from_event), `TokenResponse` (to_dict), `ErrorResponse` (to_dict) |
| 의존성 | `shared.models.user.User`, `shared.models.virtual_key.VirtualKey` |
| 예상 LOC | ~120 |

**핵심 로직**:
- `TokenRequest.from_event(event)`: body JSON 파싱 (optional 필드), user_arn 추출, request_id 추출 (`token_service.utils.extract_request_id` import 사용)
- `TokenResponse.to_dict()`: API_SPEC.md 4.1절 형식 변환
- `ErrorResponse.to_dict()`: API_SPEC.md 3.3절 형식 변환

**주의**: request_id 추출 로직은 `token_service/utils.py`에 한 번만 정의. `models.py`에서 `from token_service.utils import extract_request_id`로 import하여 `from_event()` 내부에서 호출. 중복 정의 없음.

#### Test Plan -- token_service/models.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_models.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 90% |

**테스트 케이스**:
- [ ] `test_token_request_from_event_with_body` -- body JSON 포함 event에서 client_name/version/aws_profile 추출
- [ ] `test_token_request_from_event_empty_body` -- body 없는 event에서 모든 필드 None
- [ ] `test_token_request_from_event_null_body` -- body가 None인 event
- [ ] `test_token_request_from_event_extracts_user_arn` -- requestContext.identity.userArn 추출
- [ ] `test_token_request_from_event_extracts_request_id_from_header` -- x-request-id 헤더 우선
- [ ] `test_token_request_from_event_extracts_request_id_from_api_gw` -- 헤더 없을 때 API GW requestId
- [ ] `test_token_request_from_event_generates_request_id_fallback` -- 둘 다 없을 때 uuid 생성
- [ ] `test_token_request_from_event_case_insensitive_header` -- X-Request-Id (대소문자 혼합) 인식
- [ ] `test_token_response_to_dict_structure` -- user, virtual_key, proxy 구조 검증
- [ ] `test_token_response_to_dict_secret_included` -- virtual_key.secret 필드에 평문 키 포함
- [ ] `test_token_response_to_dict_expires_at_null` -- expires_at None 시 null 직렬화
- [ ] `test_error_response_to_dict_structure` -- error.code, message, request_id, retryable 구조
- [ ] `test_token_request_from_event_malformed_json_body` -- 잘못된 JSON body 시 예외 처리

**Property-Based Testing (Hypothesis)**:
- [ ] `test_extract_request_id_from_header_always_returns_string` -- 임의 헤더 값에 대해 항상 str 반환
- [ ] `test_token_request_from_event_never_raises_on_optional_fields` -- 임의 body에서 예외 없음

**Assertions**:
- `response["user"]["id"]`가 UUID 문자열
- `response["virtual_key"]["secret"]`가 `sk-` prefix
- `response["proxy"]["messages_path"]` == "/v1/messages"

---

### Step 4: Lambda Services

- [ ] `token_service/services/user_lookup_service.py` 생성
- [ ] `token_service/services/virtual_key_service.py` 생성

#### 4a. token_service/services/user_lookup_service.py

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/services/user_lookup_service.py` |
| 목적 | IAM Principal 추출, User 조회 (다단계 fallback), ACTIVE 검증 |
| 핵심 클래스/메서드 | `UserLookupService` (static: extract_identity_info, resolve_user, validate_user_active, get_active_user) |
| 의존성 | `sqlalchemy.ext.asyncio.AsyncSession`, `shared.models.user.User`, `shared.exceptions` |
| 예상 LOC | ~80 |

**핵심 로직**:
- `extract_identity_info(event)`: userArn 파싱 -> session-name 추출 (마지막 `/` 이후)
- `resolve_user(session, identity_info)`: identity_store_user_id 조회 -> (fallback) email 조회 -> UserNotFoundError
- `validate_user_active(user)`: status != ACTIVE -> UserInactiveError
- `get_active_user(session, identity_info)`: resolve_user + validate_user_active

#### Test Plan -- user_lookup_service.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_user_lookup_service.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 80% |

**테스트 케이스**:
- [ ] `test_extract_identity_info_valid_arn` -- 표준 IAM assumed-role ARN에서 session-name 추출
- [ ] `test_extract_identity_info_email_session_name` -- session-name이 이메일인 경우
- [ ] `test_extract_identity_info_missing_user_arn` -- requestContext.identity.userArn 누락 시 InternalError
- [ ] `test_extract_identity_info_empty_session_name` -- ARN 끝에 빈 session-name 시 InternalError
- [ ] `test_resolve_user_by_identity_store_user_id` -- identity_store_user_id로 User 찾기
- [ ] `test_resolve_user_fallback_to_email` -- identity_store_user_id 실패 -> email fallback 성공
- [ ] `test_resolve_user_not_found` -- 두 경로 모두 실패 시 UserNotFoundError
- [ ] `test_resolve_user_no_at_sign_skips_email_fallback` -- `@` 미포함 시 email 조회 생략
- [ ] `test_validate_user_active_success` -- ACTIVE 사용자 통과
- [ ] `test_validate_user_active_inactive_user` -- INACTIVE 사용자 시 UserInactiveError
- [ ] `test_get_active_user_success` -- ACTIVE 사용자 정상 반환
- [ ] `test_get_active_user_not_found` -- 미존재 사용자 시 UserNotFoundError
- [ ] `test_get_active_user_inactive` -- INACTIVE 사용자 시 UserInactiveError

**Property-Based Testing (Hypothesis)**:
- [ ] `test_extract_identity_info_valid_arn_always_returns_last_segment` -- 유효 ARN에서 항상 마지막 segment 반환
- [ ] `test_extract_identity_info_malformed_arn_raises` -- 잘못된 ARN 시 예외

**Assertions**:
- `extract_identity_info(valid_event)` == expected session-name
- `UserNotFoundError` 메시지에 identity_info 포함
- `UserInactiveError` 메시지에 user.id 포함

#### 4b. token_service/services/virtual_key_service.py

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/services/virtual_key_service.py` |
| 목적 | Virtual Key 발급/재조회 핵심 비즈니스 로직 |
| 핵심 클래스/메서드 | `VirtualKeyService` (static: get_or_create_key, _reuse_existing_key, _create_new_key) |
| 의존성 | `UserLookupService`, `KmsHelper`, `generate_api_key`, `AsyncSession`, shared models |
| 예상 LOC | ~120 |

**핵심 로직**:
- `get_or_create_key(session, identity_info, request)`: User 조회 -> 활성 키 조회 -> 재사용 또는 신규 생성
- `_reuse_existing_key(session, user, virtual_key)`: KMS decrypt -> last_used_at 갱신 -> 반환
- `_create_new_key(session, user, request)`: generate_api_key -> KMS encrypt -> fingerprint -> DB 저장 -> AuditEvent 기록 -> 반환

**보안 주의사항**:
- 평문 키를 로그에 절대 포함하지 않음
- `key_fingerprint` 또는 `key_last4`만 로깅

#### Test Plan -- virtual_key_service.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_virtual_key_service.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 90% (고위험 모듈) |

**테스트 케이스**:

Happy path:
- [ ] `test_get_or_create_key_new_user_first_key` -- 신규 사용자 첫 키 발급 성공
- [ ] `test_get_or_create_key_existing_active_key_reuse` -- 기존 활성 키 재사용 (KMS decrypt + last_used_at 갱신)

재사용 경로:
- [ ] `test_reuse_existing_key_decrypts_via_kms` -- KmsHelper.decrypt_key 호출 확인
- [ ] `test_reuse_existing_key_updates_last_used_at` -- last_used_at 갱신 확인
- [ ] `test_reuse_existing_key_no_audit_event` -- audit 이벤트 미생성 확인

신규 생성 경로:
- [ ] `test_create_new_key_calls_generate_api_key` -- generate_api_key() 호출 확인
- [ ] `test_create_new_key_encrypts_via_kms` -- KmsHelper.encrypt_key 호출 확인
- [ ] `test_create_new_key_generates_fingerprint` -- KmsHelper.generate_fingerprint 호출 확인
- [ ] `test_create_new_key_stores_key_last4` -- key_last4가 평문의 마지막 4자
- [ ] `test_create_new_key_creates_audit_event` -- VIRTUAL_KEY_ISSUED AuditEvent 생성 확인
- [ ] `test_create_new_key_audit_payload` -- audit payload에 client_name, client_version, aws_profile 포함
- [ ] `test_create_new_key_sets_active_status` -- VirtualKey.status == ACTIVE
- [ ] `test_create_new_key_expires_at_null` -- expires_at == None (v1 무기한)

에러 경로:
- [ ] `test_get_or_create_key_user_not_found` -- UserNotFoundError 전파
- [ ] `test_get_or_create_key_user_inactive` -- UserInactiveError 전파
- [ ] `test_reuse_existing_key_kms_decrypt_failure` -- KMS decrypt 실패 시 InternalError
- [ ] `test_create_new_key_kms_encrypt_failure` -- KMS encrypt 실패 시 InternalError

보안:
- [ ] `test_plaintext_key_not_in_log_output` -- 로그에 평문 키 미포함 확인

**Property-Based Testing (Hypothesis)**:
- [ ] `test_create_new_key_always_returns_sk_prefix` -- 생성된 키가 항상 `sk-` prefix
- [ ] `test_create_new_key_fingerprint_deterministic` -- 동일 평문 -> 동일 fingerprint

**Assertions**:
- 반환 tuple: (User, str, VirtualKey) 형식
- 반환된 plaintext_key가 `sk-` prefix
- VirtualKey.key_fingerprint == sha256_hex(plaintext_key)
- AuditEvent.event_type == "VIRTUAL_KEY_ISSUED"
- AuditEvent.actor_id == request.user_arn

---

### Step 5: Lambda Utils

- [ ] `token_service/utils.py` 생성

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/utils.py` |
| 목적 | extract_request_id, handle_error, record_failure_audit 헬퍼 |
| 핵심 함수 | `extract_request_id(event)`, `handle_error(...)`, `record_failure_audit(...)` |
| 의존성 | `uuid`, `json`, `logging`, `shared.models.audit.AuditEvent` |
| 예상 LOC | ~80 |

**핵심 로직**:
- `extract_request_id(event)`: 3-level fallback (x-request-id 헤더 -> API GW requestId -> uuid4)
- `handle_error(status_code, error_code, message, request_id, retryable)`: Lambda Proxy 응답 dict 구성
- `record_failure_audit(engine, identity_info, user_arn, request_id, reason)`: best-effort 실패 audit (별도 세션)

**참고**: `extract_request_id`는 `token_service/utils.py`에만 정의. `models.py`의 `TokenRequest.from_event()`에서 import하여 사용.

#### Test Plan -- token_service/utils.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_utils.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 90% |

**테스트 케이스**:
- [ ] `test_extract_request_id_from_header` -- x-request-id 헤더 값 우선 반환
- [ ] `test_extract_request_id_case_insensitive` -- X-Request-ID 등 대소문자 혼합 인식
- [ ] `test_extract_request_id_from_api_gateway` -- 헤더 없을 때 requestContext.requestId 사용
- [ ] `test_extract_request_id_fallback_uuid` -- 둘 다 없을 때 `req_` prefix + uuid hex
- [ ] `test_extract_request_id_empty_header_value` -- 빈 문자열 헤더 무시
- [ ] `test_extract_request_id_no_headers_key` -- headers 키 자체 없는 event
- [ ] `test_handle_error_returns_lambda_proxy_response` -- statusCode, headers, body 구조
- [ ] `test_handle_error_body_is_valid_json` -- body가 JSON 파싱 가능
- [ ] `test_handle_error_includes_x_request_id_header` -- 응답 headers에 x-request-id 포함
- [ ] `test_handle_error_error_structure` -- error.code, error.message, error.request_id, error.retryable 구조
- [ ] `test_record_failure_audit_creates_event` -- AuditEvent(VIRTUAL_KEY_REQUEST_FAILED) 생성
- [ ] `test_record_failure_audit_unknown_actor` -- user_arn None 시 actor_id = "UNKNOWN"
- [ ] `test_record_failure_audit_swallows_db_error` -- DB 저장 실패 시 예외 미전파 (best-effort)

**Property-Based Testing (Hypothesis)**:
- [ ] `test_extract_request_id_always_returns_non_empty_string` -- 어떤 event에도 비어있지 않은 문자열 반환
- [ ] `test_handle_error_body_always_parseable` -- 어떤 입력에도 JSON 파싱 가능한 body

**Assertions**:
- `extract_request_id({})` 결과가 `req_` prefix로 시작
- `handle_error(...)["statusCode"]` == 입력 status_code
- `json.loads(handle_error(...)["body"])["error"]["code"]` == 입력 error_code

---

### Step 6: Lambda Handler (진입점)

- [ ] `token_service/handler.py` 생성

| 항목 | 내용 |
|------|------|
| 경로 | `token_service/handler.py` |
| 목적 | Lambda 진입점 (sync wrapper -> async handler) |
| 핵심 함수 | `lambda_handler(event, context)`, `async_handler(event, context)` |
| 의존성 | 모든 token_service 모듈, shared/exceptions, shared/models |
| 예상 LOC | ~100 |

**핵심 로직**:
- `lambda_handler`: sync wrapper, `asyncio.run(async_handler(event, context))`
- `async_handler`: request_id 추출 -> TokenRequest 파싱 -> identity 추출 -> DB 세션 생성 -> VirtualKeyService 호출 -> TokenResponse 구성
- 에러 처리: UserNotFoundError(403), UserInactiveError(409), 기타(500)
- 실패 시 record_failure_audit 호출 (best-effort)

**모듈 레벨 초기화** (handler.py 최상위):
- `Config.validate()` -- 환경변수 검증
- `engine = get_engine()` -- DB engine lazy 초기화
- 로거 설정 (`setup_logger()`)

#### Test Plan -- token_service/handler.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/unit/token_service/test_handler.py` |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 80% |

**테스트 케이스**:

Happy path:
- [ ] `test_lambda_handler_new_key_success` -- 신규 키 발급 성공 (200 OK)
- [ ] `test_lambda_handler_existing_key_reuse` -- 기존 키 재사용 성공 (200 OK)
- [ ] `test_lambda_handler_response_includes_x_request_id` -- 응답 헤더에 x-request-id 포함
- [ ] `test_lambda_handler_response_body_structure` -- user, virtual_key, proxy 구조

에러 경로:
- [ ] `test_lambda_handler_user_not_found_returns_403` -- UserNotFoundError -> 403, user_not_synced
- [ ] `test_lambda_handler_user_inactive_returns_409` -- UserInactiveError -> 409, user_inactive
- [ ] `test_lambda_handler_internal_error_returns_500` -- InternalError -> 500, internal_error
- [ ] `test_lambda_handler_unhandled_exception_returns_500` -- 예상치 못한 예외 -> 500
- [ ] `test_lambda_handler_failure_audit_recorded` -- 실패 시 record_failure_audit 호출 확인
- [ ] `test_lambda_handler_failure_audit_failure_does_not_change_response` -- audit 실패가 응답에 영향 없음

**테스트 전략**: handler 테스트는 VirtualKeyService, UserLookupService, database 모듈을 mock/patch하여 integration-like unit test로 구성. 실제 DB 연결 없이 비즈니스 로직 흐름만 검증.

**Assertions**:
- 성공 응답: statusCode == 200, body에 user/virtual_key/proxy 포함
- 에러 응답: statusCode 확인, body에 error.code 확인
- record_failure_audit 호출 여부 확인 (mock.assert_called_once_with)

---

### Step 7: Hypothesis Strategies

- [ ] `tests/unit/token_service/strategies.py` 생성

| 항목 | 내용 |
|------|------|
| 경로 | `tests/unit/token_service/strategies.py` |
| 목적 | Property-based testing용 Hypothesis 전략 정의 |
| 핵심 전략 | `valid_iam_arn_strategy`, `invalid_arn_strategy`, `lambda_event_strategy`, `api_key_strategy` |
| 의존성 | `hypothesis.strategies` |
| 예상 LOC | ~50 |

---

### Step 8: Test conftest

- [ ] `tests/unit/token_service/__init__.py` 생성
- [ ] `tests/unit/token_service/conftest.py` 생성

| 항목 | 내용 |
|------|------|
| 경로 | `tests/unit/token_service/conftest.py` |
| 목적 | 공통 테스트 fixture (mock DB session, mock KmsHelper, sample event, sample user 등) |
| 핵심 fixture | `mock_session`, `mock_kms_helper`, `sample_event`, `sample_user`, `sample_virtual_key`, `env_vars` |
| 예상 LOC | ~80 |

**주요 fixture**:
- `env_vars` (autouse=True): 필수 환경변수를 monkeypatch로 설정. handler 모듈 import 시 Config.validate()가 트리거되므로 반드시 autouse로 선행 설정 필요.
- `mock_engine`: get_engine()을 patch하여 mock engine 반환. handler.py 모듈 레벨 `engine = get_engine()` 호출을 intercept.
- `mock_session`: AsyncSession mock. execute chain mock 패턴:
  ```python
  mock_result = AsyncMock()
  mock_result.scalar_one_or_none.return_value = sample_user  # 또는 None
  mock_session.execute.return_value = mock_result
  ```
- `sample_user`: ACTIVE 상태의 User 인스턴스
- `sample_virtual_key`: ACTIVE 상태의 VirtualKey 인스턴스
- `sample_event`: 유효한 API Gateway Lambda Proxy event dict

**handler 테스트 mock 전략**: handler.py는 모듈 레벨에서 Config.validate()와 get_engine()을 호출하므로, conftest.py의 env_vars fixture(autouse=True)가 먼저 실행되어야 함. get_engine은 `@pytest.fixture(autouse=True)`로 patch하거나, test 모듈 레벨에서 `unittest.mock.patch`를 사용.

---

### Step 9: CDK Infrastructure 업데이트

- [ ] `infra/stacks/compute_stack.py` 수정

| 항목 | 내용 |
|------|------|
| 경로 | `infra/stacks/compute_stack.py` |
| 목적 | Lambda skeleton -> 실제 코드 패키지로 전환 |
| 변경 사항 | 3가지 (아래 상세) |
| 예상 변경 LOC | ~15 (수정) |

**변경 사항**:

1. **Lambda code**: `from_inline(...)` -> `from_asset(".", bundling=...)` (BundlingOptions로 token_service/ + shared/ 번들링)
   **Lambda handler**: `handler.lambda_handler` -> `token_service.handler.lambda_handler`
2. **환경변수 추가**: `PROXY_BASE_URL`, `LOG_LEVEL` 추가
3. **환경변수 이름 변경**: `KMS_KEY_ARN` -> `KMS_KEY_ID` (KmsHelper가 `KMS_KEY_ID` 사용)

**변경 전** (현재):
```python
code=lambda_.Code.from_inline(...)
environment={
    "RDS_PROXY_ENDPOINT": ...,
    "DB_SECRET_ARN": ...,
    "KMS_KEY_ARN": ...,
}
```

**변경 후**:
```python
code=lambda_.Code.from_asset("token_service/")
environment={
    "RDS_PROXY_ENDPOINT": ...,
    "DB_SECRET_ARN": ...,
    "KMS_KEY_ID": self.virtual_key_kms_key.key_id,
    "PROXY_BASE_URL": context.node.try_get_context("proxy_base_url") or "https://placeholder.example.com",  # cdk.json 또는 --context proxy_base_url=https://... 로 주입
    "LOG_LEVEL": "INFO",
}
```

**Lambda 패키징 전략 (Step 10 통합)**:

`shared/` 모듈을 Lambda에서 import하려면 번들링이 필수. CDK `BundlingOptions`를 사용하여 프로젝트 루트에서 `token_service/`와 `shared/`를 함께 패키징:

```python
code=lambda_.Code.from_asset(
    ".",
    bundling=BundlingOptions(
        image=lambda_.Runtime.PYTHON_3_13.bundling_image,
        command=[
            "bash", "-c",
            "cp -r token_service shared /asset-output/ && "
            "pip install sqlalchemy asyncpg boto3 -t /asset-output/ 2>/dev/null; "
            "exit 0"
        ],
    ),
)
handler="token_service.handler.lambda_handler",  # handler 경로도 변경
```

이렇게 하면 Lambda 패키지에 `token_service/` + `shared/` + Python 의존성이 모두 포함됨. 로컬 테스트에서는 pyproject.toml의 `pythonpath = ["."]` 설정으로 shared/ import 가능.

#### Test Plan -- compute_stack.py

| 항목 | 내용 |
|------|------|
| 테스트 파일 | `tests/test_compute_stack.py` (기존 파일 수정) |
| 테스트 프레임워크 | pytest |
| 커버리지 목표 | 기존 수준 유지 |

**추가/수정 테스트 케이스**:
- [ ] 기존 스냅샷 테스트 업데이트 (Lambda 코드 변경 반영)
- [ ] `KMS_KEY_ID` 환경변수명 확인 (KMS_KEY_ARN -> KMS_KEY_ID)
- [ ] `PROXY_BASE_URL` 환경변수 존재 확인
- [ ] `LOG_LEVEL` 환경변수 존재 확인

---

### Step 10: pyproject.toml 업데이트

- [ ] `pyproject.toml` 수정

| 항목 | 내용 |
|------|------|
| 경로 | `pyproject.toml` |
| 변경 사항 | dev 의존성에 `pytest-asyncio`, `pytest-cov` 추가 + asyncio_mode = "auto" 설정 |

**추가 의존성 + 설정**:
```toml
[dependency-groups]
dev = [
    "hypothesis>=6.131,<7",
    "pytest>=8.3,<9",
    "pytest-asyncio>=0.25,<1",
    "pytest-cov>=6,<7",
    "ruff>=0.11,<0.12",
]

[tool.pytest.ini_options]
asyncio_mode = "auto"
```

`asyncio_mode = "auto"` 설정으로 async 테스트 함수에 `@pytest.mark.asyncio` 데코레이터 없이 자동 인식.

---

## File Generation Order (의존성 기반)

```
1.  shared/exceptions.py                          (선행 -- 전체 예외 계층, 무의존)
2.  token_service/__init__.py                     (패키지 초기화)
    token_service/core/__init__.py
    token_service/services/__init__.py
3.  token_service/core/config.py                  (표준 라이브러리만)
4.  token_service/core/database.py                (config 의존)
5.  token_service/utils.py                        (exceptions 의존)
6.  token_service/models.py                       (utils import — extract_request_id)
7.  token_service/services/user_lookup_service.py (shared.models, exceptions 의존)
8.  token_service/services/virtual_key_service.py (user_lookup_service, kms, hashing 의존)
9.  token_service/handler.py                      (전체 의존)
10. tests/unit/token_service/__init__.py
    tests/unit/token_service/strategies.py
    tests/unit/token_service/conftest.py          (autouse env_vars + mock_engine + mock_session 패턴)
    tests/unit/shared/test_exceptions.py
11. tests/unit/token_service/test_*.py            (전체 테스트)
12. infra/stacks/compute_stack.py                 (수정 — BundlingOptions + handler 경로 변경)
13. pyproject.toml                                (수정 — pytest-asyncio + asyncio_mode=auto)
```

---

## 파일 목록 요약

### 신규 생성 파일 (13개)

| # | 파일 경로 | 목적 | 예상 LOC |
|---|-----------|------|----------|
| 1 | `shared/exceptions.py` | 공유 예외 계층 | ~40 |
| 2 | `token_service/__init__.py` | 패키지 초기화 | ~1 |
| 3 | `token_service/core/__init__.py` | 패키지 초기화 | ~1 |
| 4 | `token_service/services/__init__.py` | 패키지 초기화 | ~1 |
| 5 | `token_service/core/config.py` | 환경변수 검증, JSON 로거 | ~80 |
| 6 | `token_service/core/database.py` | DB engine, URL 구성 | ~50 |
| 7 | `token_service/models.py` | TokenRequest, TokenResponse, ErrorResponse | ~120 |
| 8 | `token_service/utils.py` | extract_request_id, handle_error, record_failure_audit | ~80 |
| 9 | `token_service/services/user_lookup_service.py` | UserLookupService | ~80 |
| 10 | `token_service/services/virtual_key_service.py` | VirtualKeyService | ~120 |
| 11 | `token_service/handler.py` | Lambda 진입점 | ~100 |
| **합계** | | **애플리케이션 코드** | **~673** |

### 신규 테스트 파일 (10개)

| # | 파일 경로 | 대상 모듈 | 예상 LOC |
|---|-----------|-----------|----------|
| 1 | `tests/unit/shared/test_exceptions.py` | shared/exceptions.py | ~60 |
| 2 | `tests/unit/token_service/__init__.py` | 패키지 초기화 | ~1 |
| 3 | `tests/unit/token_service/strategies.py` | Hypothesis 전략 | ~50 |
| 4 | `tests/unit/token_service/conftest.py` | 공통 fixture | ~80 |
| 5 | `tests/unit/token_service/test_config.py` | token_service/core/config.py | ~80 |
| 6 | `tests/unit/token_service/test_database.py` | token_service/core/database.py | ~50 |
| 7 | `tests/unit/token_service/test_models.py` | token_service/models.py | ~120 |
| 8 | `tests/unit/token_service/test_utils.py` | token_service/utils.py | ~100 |
| 9 | `tests/unit/token_service/test_user_lookup_service.py` | user_lookup_service.py | ~120 |
| 10 | `tests/unit/token_service/test_virtual_key_service.py` | virtual_key_service.py | ~180 |
| 11 | `tests/unit/token_service/test_handler.py` | token_service/handler.py | ~150 |
| **합계** | | **테스트 코드** | **~991** |

### 수정 파일 (2개)

| # | 파일 경로 | 변경 내용 |
|---|-----------|-----------|
| 1 | `infra/stacks/compute_stack.py` | from_inline -> from_asset, 환경변수 변경 |
| 2 | `pyproject.toml` | pytest-asyncio, pytest-cov 추가 |

---

## Validation Steps

코드 생성 완료 후 다음 순서로 검증:

1. **ruff check**: `ruff check shared/exceptions.py token_service/ tests/unit/token_service/ tests/unit/shared/test_exceptions.py`
2. **ruff format**: `ruff format --check shared/exceptions.py token_service/ tests/unit/token_service/ tests/unit/shared/test_exceptions.py`
3. **Import 검증**: `python -c "from token_service.handler import lambda_handler; from shared.exceptions import AppError; print('OK')"`
4. **pytest 실행**: `pytest tests/unit/shared/test_exceptions.py tests/unit/token_service/ -v --tb=short`
5. **커버리지 확인**: `pytest tests/unit/token_service/ --cov=token_service --cov-report=term-missing` (목표: 전체 80%, VirtualKeyService 90%)
6. **CDK synth**: `cdk synth` (compute_stack.py 변경 후 스냅샷 검증)

---

## Extension Compliance Plan

### Security Baseline

| Rule | Applicability | 조치 |
|------|--------------|------|
| SECURITY-03 | Applicable | Virtual Key 평문 로깅 금지 확인 (handler, services 모듈) |
| SECURITY-05 | Applicable | KMS 암호화 필수 (VirtualKeyService._create_new_key) |
| SECURITY-06 | Applicable | Secrets Manager에서 DB credentials 조회 (database.py) |

### Property-Based Testing

| Rule | Applicability | 조치 |
|------|--------------|------|
| PBT-02 | Applicable | extract_request_id round-trip, TokenRequest.from_event round-trip |
| PBT-03 | Applicable | generate_api_key 형식 불변식, fingerprint 결정성 불변식 |
| PBT-04 | Applicable | IAM ARN 파싱 유효성/무효성 property |

---

## 핵심 비즈니스 불변식 (테스트로 검증)

1. **활성 키 유일성**: 사용자당 ACTIVE VirtualKey 최대 1개 (get_or_create_key에서 재사용 경로 분기)
2. **ACTIVE 사용자만**: user.status != ACTIVE -> UserInactiveError
3. **평문 키 노출 제한**: 응답 body에만 존재, 로그/DB/에러 미포함
4. **트랜잭션 원자성**: User 조회 -> VirtualKey -> AuditEvent 단일 트랜잭션
5. **KMS 암호화 필수**: DB에 kms_ciphertext만 저장
6. **Audit 일관성**: 성공 = VIRTUAL_KEY_ISSUED, 실패 = VIRTUAL_KEY_REQUEST_FAILED (best-effort)
