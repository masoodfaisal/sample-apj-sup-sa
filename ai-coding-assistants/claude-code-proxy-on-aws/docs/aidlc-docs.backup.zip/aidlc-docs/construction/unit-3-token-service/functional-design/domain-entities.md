# Domain Entities — Unit 3: Token Service

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Approved
- 근거: [Unit 2 Domain Entities](../../unit-2-shared-models/functional-design/domain-entities.md), [Design Questions](./design-questions.md)

---

## 1. 개요

이 문서는 Unit 3 Token Service에서 사용하는 도메인 엔터티를 정의한다. Token Service는 Unit 2 Shared Models의 ORM 모델을 재사용하며, 추가로 Lambda 핸들러 전용 dataclass와 에러 응답 구조체를 정의한다.

---

## 2. Unit 2 모델 참조

### 2.1 User (shared/models/user.py)

**Token Service에서 사용**:
- `UserLookupService.resolve_user()` — DB 조회
- `UserLookupService.validate_user_active()` — 상태 검증
- 응답 구성 — `user` 객체

**주요 필드**:
```python
id: UUID                         # PK
identity_store_user_id: str      # UNIQUE, 외부 sync 키
user_name: str
display_name: str
email: str
status: UserStatus               # ACTIVE, INACTIVE
source_deleted_at: datetime      # nullable
last_synced_at: datetime         # nullable
default_team_id: UUID            # FK → teams.id, nullable
last_login_at: datetime          # nullable
created_at: datetime
updated_at: datetime
```

**인덱스** (Unit 2 Domain Entities 3.1):
- `unique(identity_store_user_id)`
- `index(status)`
- `index(last_synced_at DESC)`
- `index(last_login_at DESC)`

**Enum 정의**:
```python
class UserStatus(StrEnum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
```

---

### 2.2 VirtualKey (shared/models/virtual_key.py)

**Token Service에서 사용**:
- `VirtualKeyService.get_or_create_key()` — 조회/생성
- `VirtualKeyService._reuse_existing_key()` — last_used_at 갱신
- `VirtualKeyService._create_new_key()` — 신규 키 생성
- 응답 구성 — `virtual_key` 객체

**주요 필드**:
```python
id: UUID                         # PK
user_id: UUID                    # FK → users.id
key_fingerprint: str             # UNIQUE, SHA-256
key_last4: str                   # 마지막 4자
kms_ciphertext: bytes            # KMS 암호화된 평문 키
status: VirtualKeyStatus         # ACTIVE, REVOKED, ROTATED, EXPIRED
issued_at: datetime
expires_at: datetime             # nullable, v1: null
last_used_at: datetime           # nullable
revoked_at: datetime             # nullable
created_at: datetime
updated_at: datetime
```

**제약** (Unit 2 Domain Entities 3.4):
- `unique(key_fingerprint)`
- partial unique `unique(user_id) WHERE status = 'ACTIVE'`

**Enum 정의**:
```python
class VirtualKeyStatus(StrEnum):
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    ROTATED = "ROTATED"
    EXPIRED = "EXPIRED"
```

**상태 전이** (Unit 2 Business Rules 1.3):
```
[생성] → ACTIVE
ACTIVE → REVOKED     (Admin 폐기)
ACTIVE → ROTATED     (Admin 회전)
ACTIVE → EXPIRED     (만료 시각 도달)
```

---

### 2.3 AuditEvent (shared/models/audit.py)

**Token Service에서 사용**:
- `VirtualKeyService._create_new_key()` — VIRTUAL_KEY_ISSUED 기록
- `record_failure_audit()` — VIRTUAL_KEY_REQUEST_FAILED 기록

**주요 필드**:
```python
id: UUID                         # PK
actor_type: str                  # IAM_PRINCIPAL
actor_id: str                    # IAM ARN or "UNKNOWN"
event_type: str                  # VIRTUAL_KEY_ISSUED, VIRTUAL_KEY_REQUEST_FAILED
object_type: str                 # VIRTUAL_KEY
object_id: str                   # virtual_key.id or "N/A"
request_id: str                  # nullable
sync_run_id: UUID                # FK → identity_sync_runs.id, nullable
payload_json: dict               # JSON, 변경 메타데이터
created_at: datetime
```

**Token Service 이벤트 타입** (Business Rules 5절):
1. `VIRTUAL_KEY_ISSUED`: 신규 키 생성 시
2. `VIRTUAL_KEY_REQUEST_FAILED`: 키 발급 실패 시

**payload_json 예시**:
```json
// VIRTUAL_KEY_ISSUED
{
  "client_name": "claude-code",
  "client_version": "1.0.0",
  "aws_profile": "company-dev"
}

// VIRTUAL_KEY_REQUEST_FAILED
{
  "reason": "UserInactiveError",
  "identity_info": "user-1234"
}
```

---

## 3. Token Service 전용 구조체

### 3.1 TokenRequest (lambda/models.py)

**용도**: API Gateway event를 파싱하여 요청 데이터를 캡슐화한다.

**정의**:
```python
from dataclasses import dataclass
from typing import Optional

@dataclass
class TokenRequest:
    """Token Service 요청 dataclass."""
    
    # 요청 본문 필드 (모두 optional, Q3)
    client_name: Optional[str] = None
    client_version: Optional[str] = None
    aws_profile: Optional[str] = None
    
    # 내부 필드 (event에서 추출)
    user_arn: Optional[str] = None      # IAM ARN (전체)
    request_id: Optional[str] = None    # request_id
    
    @classmethod
    def from_event(cls, event: dict) -> "TokenRequest":
        """
        API Gateway Lambda Proxy event에서 TokenRequest 생성.
        
        Args:
            event: API Gateway event dict
        
        Returns:
            TokenRequest instance
        """
        # 요청 본문 파싱 (optional)
        body = event.get("body")
        data = json.loads(body) if body else {}
        
        # IAM ARN 추출
        user_arn = event.get("requestContext", {}).get("identity", {}).get("userArn")
        
        # request_id 추출
        request_id = _extract_request_id_from_event(event)
        
        return cls(
            client_name=data.get("client_name"),
            client_version=data.get("client_version"),
            aws_profile=data.get("aws_profile"),
            user_arn=user_arn,
            request_id=request_id,
        )

def _extract_request_id_from_event(event: dict) -> str:
    """request_id 추출 (클라이언트 헤더 → API GW → uuid4)."""
    headers = event.get("headers") or {}
    for key, value in headers.items():
        if key.lower() == "x-request-id" and value:
            return value
    if api_gw_id := event.get("requestContext", {}).get("requestId"):
        return api_gw_id
    import uuid
    return f"req_{uuid.uuid4().hex}"
```

**설계 원칙** (Q1):
- Ultra-thin wrapper: event dict 파싱만 수행, 비즈니스 로직 없음
- 테스트 시 event dict를 매번 조립하지 않고 dataclass로 직접 주입 가능
- 핸들러 본체에서 딥 딕셔너리 접근 최소화

---

### 3.2 TokenResponse (lambda/models.py)

**용도**: Virtual Key 발급 성공 응답을 구성한다.

**정의**:
```python
from dataclasses import dataclass
from shared.models.user import User
from shared.models.virtual_key import VirtualKey

@dataclass
class TokenResponse:
    """Token Service 성공 응답 dataclass."""
    
    user: User
    virtual_key: VirtualKey
    virtual_key_secret: str      # 평문 키 (응답에만 포함)
    proxy_base_url: str          # 환경변수 PROXY_BASE_URL
    proxy_messages_path: str     # 하드코딩 "/v1/messages"
    
    def to_dict(self) -> dict:
        """
        API_SPEC.md 4.1절 형식으로 변환.
        
        Returns:
            JSON-serializable dict
        """
        return {
            "user": {
                "id": str(self.user.id),
                "identity_store_user_id": self.user.identity_store_user_id,
                "display_name": self.user.display_name,
                "email": self.user.email,
                "default_team_id": str(self.user.default_team_id) if self.user.default_team_id else None
            },
            "virtual_key": {
                "id": str(self.virtual_key.id),
                "secret": self.virtual_key_secret,
                "status": self.virtual_key.status.value,
                "issued_at": self.virtual_key.issued_at.isoformat(),
                "expires_at": self.virtual_key.expires_at.isoformat() if self.virtual_key.expires_at else None
            },
            "proxy": {
                "base_url": self.proxy_base_url,
                "messages_path": self.proxy_messages_path
            }
        }
```

**API_SPEC.md 4.1절 형식 준수**:
```json
{
  "user": {
    "id": "7a53cf13-3d59-4f8e-9a96-6c7872c3bf4c",
    "identity_store_user_id": "abcd1234-....",
    "display_name": "Jane Doe",
    "email": "jane@example.com",
    "default_team_id": "9dd44d3a-2d80-47c3-a2f8-72060204dd4b"
  },
  "virtual_key": {
    "id": "6d071d24-1656-4f1b-b0a8-4d8429ff0fd4",
    "secret": "sk-xxxxx",
    "status": "ACTIVE",
    "issued_at": "2026-03-30T09:00:00Z",
    "expires_at": null
  },
  "proxy": {
    "base_url": "https://proxy.example.com",
    "messages_path": "/v1/messages"
  }
}
```

**핵심 포인트** (Q10):
- `virtual_key.secret`: 평문 키 (응답에만 포함, 로그/DB 미포함)
- `proxy.base_url`: 환경변수 `PROXY_BASE_URL`에서 읽음
- `proxy.messages_path`: 하드코딩 `/v1/messages`
- `key_last4`: 응답에 미포함 (클라이언트가 전체 secret을 받으므로 불필요, Admin API 키 목록 조회 시 마스킹 표시용)

---

### 3.3 ErrorResponse (lambda/models.py)

**용도**: 에러 응답을 구성한다. Token Service 전용 포맷 (Anthropic-compatible이 아님).

**정의**:
```python
from dataclasses import dataclass

@dataclass
class ErrorResponse:
    """Token Service 에러 응답 dataclass."""
    
    code: str           # user_not_synced, user_inactive, internal_error
    message: str        # 사람이 읽을 수 있는 메시지
    request_id: str     # request_id
    retryable: bool     # v1: 모두 false
    
    def to_dict(self) -> dict:
        """
        API_SPEC.md 3.3절 형식으로 변환.
        
        Returns:
            JSON-serializable dict
        """
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "request_id": self.request_id,
                "retryable": self.retryable
            }
        }
```

**API_SPEC.md 3.3절 형식 준수**:
```json
{
  "error": {
    "code": "user_inactive",
    "message": "User is not active",
    "request_id": "req_01JQ...",
    "retryable": false
  }
}
```

**에러 코드** (Business Rules 7.1):
- `user_not_synced`: UserNotFoundError (403)
- `user_inactive`: UserInactiveError (409)
- `internal_error`: InternalError 또는 기타 예외 (500)

---

## 4. 예외 엔터티 (shared/exceptions.py)

### 4.1 예외 계층 구조

**공유 예외** (Q9, system-nfr-decisions.md 3.2):
```python
# shared/exceptions.py

class AppError(Exception):
    """Base application error."""
    pass

class AuthenticationError(AppError):
    """Authentication failed."""
    pass

class InvalidKeyError(AuthenticationError):
    """Virtual Key invalid or not found."""
    pass

class KeyRevokedError(AuthenticationError):
    """Virtual Key revoked."""
    pass

class AuthorizationError(AppError):
    """Authorization failed."""
    pass

class UserNotFoundError(AuthorizationError):
    """User not found in DB."""
    pass

class UserInactiveError(AuthorizationError):
    """User status is not ACTIVE."""
    pass

class InternalError(AppError):
    """Internal server error."""
    pass
```

**Token Service에서 사용하는 예외**:
- `UserNotFoundError`: 사용자 미존재
- `UserInactiveError`: 사용자 INACTIVE
- `InternalError`: KMS/DB 에러

**Gateway에서 추가로 사용하는 예외** (Unit 4):
- `InvalidKeyError`, `KeyRevokedError`: Virtual Key 검증
- `TeamInactiveError`, `ModelNotAllowedError`: 정책 평가
- `BudgetExceededError`: 예산 초과
- `BedrockError`, `BedrockThrottlingError`: Bedrock upstream
- `ValidationError`: 요청 검증

---

### 4.2 예외 → HTTP Status 매핑

| 예외 클래스 | HTTP Status | 에러 코드 | 사용 위치 |
|-------------|-------------|-----------|-----------|
| `UserNotFoundError` | 403 Forbidden | `user_not_synced` | Token Service |
| `UserInactiveError` | 409 Conflict | `user_inactive` | Token Service |
| `InternalError` | 500 Internal Server Error | `internal_error` | Token Service |
| `InvalidKeyError` | 401 Unauthorized | `authentication_error` | Gateway (Unit 4) |
| `KeyRevokedError` | 401 Unauthorized | `authentication_error` | Gateway (Unit 4) |
| `ModelNotAllowedError` | 403 Forbidden | `permission_error` | Gateway (Unit 4) |
| `BudgetExceededError` | 403 Forbidden | `permission_error` | Gateway (Unit 4) |

---

## 5. KMS 헬퍼 유틸리티 (shared/utils/kms.py)

### 5.1 KmsHelper

**용도**: KMS 암호화/복호화/fingerprint 생성을 캡슐화한다.

**정의** (기존 구현 참조):
```python
# shared/utils/kms.py

from typing import ClassVar, Any
import os
import boto3
from shared.utils.hashing import sha256_hex

class KmsHelper:
    """Thin wrapper around boto3 KMS operations."""
    
    _client: ClassVar[Any | None] = None
    
    @classmethod
    def _get_client(cls) -> Any:
        """Singleton KMS client (cold start optimization)."""
        if cls._client is None:
            cls._client = boto3.client("kms")
        return cls._client
    
    @classmethod
    def encrypt_key(cls, plaintext_key: str) -> bytes:
        """
        KMS 암호화.
        
        Args:
            plaintext_key: 평문 Virtual Key
        
        Returns:
            KMS ciphertext (bytes)
        
        Raises:
            InternalError: KMS 암호화 실패
        """
        response = cls._get_client().encrypt(
            KeyId=os.environ["KMS_KEY_ID"],
            Plaintext=plaintext_key.encode("utf-8"),
        )
        return response["CiphertextBlob"]
    
    @classmethod
    def decrypt_key(cls, ciphertext: bytes) -> str:
        """
        KMS 복호화.
        
        Args:
            ciphertext: KMS ciphertext
        
        Returns:
            평문 Virtual Key (str)
        
        Raises:
            InternalError: KMS 복호화 실패
        """
        response = cls._get_client().decrypt(CiphertextBlob=ciphertext)
        return response["Plaintext"].decode("utf-8")
    
    @staticmethod
    def generate_fingerprint(plaintext_key: str) -> str:
        """
        SHA-256 fingerprint 생성.
        
        Args:
            plaintext_key: 평문 Virtual Key
        
        Returns:
            SHA-256 hex digest (64자)
        """
        return sha256_hex(plaintext_key)
```

**사용 위치**:
- `VirtualKeyService._create_new_key()`: encrypt_key, generate_fingerprint
- `VirtualKeyService._reuse_existing_key()`: decrypt_key

**보안 규칙** (Business Rules 6.2):
- 모든 Virtual Key는 동일 KMS 키 사용
- KMS 키 ID는 환경변수 `KMS_KEY_ID`로 주입
- Lambda 실행 역할은 해당 KMS 키에 대한 Encrypt/Decrypt 권한 필요

---

### 5.2 sha256_hex (shared/utils/hashing.py)

**정의**:
```python
# shared/utils/hashing.py

import hashlib

def sha256_hex(text: str) -> str:
    """
    SHA-256 hex digest 생성.
    
    Args:
        text: 입력 문자열
    
    Returns:
        SHA-256 hex digest (64자)
    """
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
```

**사용 위치**:
- `KmsHelper.generate_fingerprint()`: Virtual Key fingerprint 생성

---

## 6. 상수 정의 (shared/utils/constants.py)

### 6.1 API Key Prefix

**정의**:
```python
# shared/utils/constants.py

API_KEY_PREFIX = "sk-"
API_KEY_RANDOM_BYTES = 32  # secrets.token_urlsafe(32) ≈ 43자
# 전체 키 길이: sk- (3자) + base64(32) (≈43자) ≈ 46자
```

**사용 위치**:
- `generate_api_key()` (shared/utils/hashing.py): 키 생성 시 prefix 사용
- property-based testing: 길이 검증

---

## 7. 환경변수 구조체 (lambda/core/config.py)

### 7.1 Config

**용도**: 환경변수를 캡슐화하고 검증한다.

**정의**:
```python
# lambda/core/config.py

import os
from typing import ClassVar

class Config:
    """Lambda 환경변수 설정."""
    
    # 필수 환경변수
    DB_SECRET_ARN: ClassVar[str]
    RDS_PROXY_ENDPOINT: ClassVar[str]
    KMS_KEY_ID: ClassVar[str]
    PROXY_BASE_URL: ClassVar[str]
    LOG_LEVEL: ClassVar[str]
    
    @classmethod
    def validate(cls) -> None:
        """
        필수 환경변수 검증.
        
        모듈 레벨에서 호출 (import 시점).
        
        Raises:
            RuntimeError: 필수 환경변수 누락
        """
        required_vars = [
            "DB_SECRET_ARN",
            "RDS_PROXY_ENDPOINT",
            "KMS_KEY_ID",
            "PROXY_BASE_URL",
        ]
        
        for var in required_vars:
            if var not in os.environ:
                raise RuntimeError(f"Missing required environment variable: {var}")
            setattr(cls, var, os.environ[var])

# 모듈 레벨 검증 (import 시점)
Config.validate()
```

**환경변수 목록** (Q16):
- `DB_SECRET_ARN`: Secrets Manager ARN (DB 자격증명)
- `RDS_PROXY_ENDPOINT`: RDS Proxy 엔드포인트
- `KMS_KEY_ID`: KMS 키 ARN
- `PROXY_BASE_URL`: Gateway ALB 주소 (응답에 포함)
- `LOG_LEVEL`: 로그 레벨 (선택, 기본값 INFO)

---

## 8. 데이터 흐름 다이어그램

### 8.1 신규 키 생성 (데이터 변환)

```
API Gateway Event (dict)
  ↓ TokenRequest.from_event()
TokenRequest (dataclass)
  ↓ extract_identity_info()
identity_info (str: session_name)
  ↓ UserLookupService.resolve_user()
User (ORM model)
  ↓ UserLookupService.validate_user_active()
User (ACTIVE)
  ↓ VirtualKeyService.get_or_create_key()
  ↓ generate_api_key()
plaintext_key (str: "sk-...")
  ↓ KmsHelper.encrypt_key()
kms_ciphertext (bytes)
  ↓ KmsHelper.generate_fingerprint()
key_fingerprint (str: SHA-256 hex)
  ↓ VirtualKeyRepository.create()
VirtualKey (ORM model)
  ↓ AuditEventRepository.create_event()
AuditEvent (ORM model)
  ↓ session.commit()
(User, plaintext_key, VirtualKey)
  ↓ TokenResponse(...)
TokenResponse (dataclass)
  ↓ TokenResponse.to_dict()
response dict
  ↓ json.dumps()
JSON string
  ↓ Lambda return
API Gateway Response
```

### 8.2 기존 키 재사용 (데이터 변환)

```
API Gateway Event (dict)
  ↓ TokenRequest.from_event()
TokenRequest (dataclass)
  ↓ extract_identity_info()
identity_info (str: session_name)
  ↓ UserLookupService.resolve_user()
User (ORM model)
  ↓ UserLookupService.validate_user_active()
User (ACTIVE)
  ↓ VirtualKeyService.get_or_create_key()
  ↓ VirtualKeyRepository.get_active_by_user()
VirtualKey (ORM model, existing)
  ↓ KmsHelper.decrypt_key(virtual_key.kms_ciphertext)
plaintext_key (str: "sk-...")
  ↓ update last_used_at
VirtualKey (updated)
  ↓ session.commit()
(User, plaintext_key, VirtualKey)
  ↓ TokenResponse(...)
TokenResponse (dataclass)
  ↓ TokenResponse.to_dict()
response dict
  ↓ json.dumps()
JSON string
  ↓ Lambda return
API Gateway Response
```

---

## 9. 엔터티 관계 다이어그램

```
┌────────────────────────┐
│       User             │
│  (shared/models/user)  │
├────────────────────────┤
│ id: UUID (PK)          │
│ identity_store_user_id │
│ status: UserStatus     │
│ ...                    │
└────────────┬───────────┘
             │ 1
             │
             │ *
┌────────────▼───────────┐
│    VirtualKey          │
│(shared/models/         │
│ virtual_key)           │
├────────────────────────┤
│ id: UUID (PK)          │
│ user_id: UUID (FK)     │
│ key_fingerprint: str   │
│ kms_ciphertext: bytes  │
│ status: VKeyStatus     │
│ ...                    │
└────────────────────────┘

┌────────────────────────┐
│     AuditEvent         │
│(shared/models/audit)   │
├────────────────────────┤
│ id: UUID (PK)          │
│ actor_type: str        │
│ actor_id: str          │
│ event_type: str        │
│ object_type: str       │
│ object_id: str         │
│ payload_json: dict     │
│ ...                    │
└────────────────────────┘
```

**관계**:
- User (1) → VirtualKey (*): 사용자는 여러 VirtualKey를 가질 수 있음 (단, ACTIVE는 최대 1개)
- VirtualKey → User: FK `user_id`
- AuditEvent는 독립적 (FK 없음, object_id는 문자열)

---

## 10. 엔터티 크기 추정

| 엔터티 | 평균 크기 | 비고 |
|--------|-----------|------|
| User (DB row) | ~500 bytes | display_name, email, timestamps |
| VirtualKey (DB row) | ~300 bytes | kms_ciphertext(~500 bytes), fingerprint(64 bytes) |
| AuditEvent (DB row) | ~200 bytes | payload_json 크기에 따라 변동 |
| TokenRequest (메모리) | ~100 bytes | Optional 필드 3개 |
| TokenResponse (메모리) | ~1 KB | User + VirtualKey 전체 |
| ErrorResponse (메모리) | ~50 bytes | 에러 메시지 길이에 따라 변동 |

**Lambda 메모리 사용 예상**:
- Cold start: ~100 MB (Python 런타임, SQLAlchemy, boto3)
- Warm invocation: ~50 MB 추가 (세션, ORM 객체)

---

## 11. 파일 구조 매핑

```
shared/
├── models/
│   ├── user.py              # User
│   ├── virtual_key.py       # VirtualKey
│   └── audit.py             # AuditEvent
├── utils/
│   ├── kms.py               # KmsHelper
│   ├── hashing.py           # sha256_hex
│   └── constants.py         # API_KEY_PREFIX, API_KEY_LENGTH
└── exceptions.py            # 공유 예외 계층

lambda/
├── models.py                # TokenRequest, TokenResponse, ErrorResponse
├── core/
│   └── config.py            # Config
├── services/
│   ├── virtual_key_service.py  # VirtualKeyService
│   └── user_lookup_service.py  # UserLookupService (extract_identity_info 포함)
└── utils.py                 # extract_request_id, handle_error
```

---

## 12. 구현 체크리스트

- [ ] Unit 2 모델 참조 확인 (User, VirtualKey, AuditEvent)
- [ ] `lambda/models.py` — TokenRequest, TokenResponse, ErrorResponse dataclass
- [ ] `shared/exceptions.py` 검증 — UserNotFoundError, UserInactiveError, InternalError
- [ ] `shared/utils/kms.py` 검증 — KmsHelper (encrypt_key, decrypt_key, generate_fingerprint)
- [ ] `shared/utils/hashing.py` 검증 — sha256_hex
- [ ] `shared/utils/constants.py` — API_KEY_PREFIX, API_KEY_LENGTH
- [ ] `lambda/core/config.py` — Config (환경변수 검증)
- [ ] 테스트에서 dataclass 재사용 검증 — TokenRequest, TokenResponse를 직접 주입하여 테스트
