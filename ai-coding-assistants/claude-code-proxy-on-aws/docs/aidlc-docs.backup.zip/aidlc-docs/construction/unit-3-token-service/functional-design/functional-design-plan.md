# Functional Design Plan — Unit 3: Token Service

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Approved
- 근거: [Design Questions](./design-questions.md), [Unit of Work](../../../inception/application-design/unit-of-work.md), [System NFR Decisions](../../system-nfr-decisions.md)

---

## 1. 개요

Unit 3 Token Service는 Lambda 기반 Virtual Key 발급/조회 서비스다. IAM Principal(Identity Center 사용자)에서 사용자를 식별하고, KMS 기반으로 암호화된 Virtual Key를 발급 또는 재조회하여 반환한다.

**핵심 설계 결정 (Q1-Q20 기반)**:
- Lambda Proxy 통합 + 경량 dataclass 래퍼 (Q1)
- IAM ARN 파싱 → 다단계 fallback 사용자 조회 (Q2)
- 요청 본문 필드는 모두 optional, audit payload에만 기록 (Q3)
- 무조건 키 재사용 정책 (v1, Q6)
- 모듈 레벨 engine + per-invocation async session (Q7)
- 단일 트랜잭션 (Q8)
- 공유 예외 계층 (Q9)
- Anthropic-compatible이 아닌 Token Service 전용 에러 포맷 (Q10)
- KMS 키는 CDK 환경변수로 주입 (Q11)
- Virtual Key 평문은 응답 body에만 존재, 로그/DB/에러 메시지 미포함 (Q12)
- Audit: VIRTUAL_KEY_ISSUED, VIRTUAL_KEY_REQUEST_FAILED 2종 (Q13)
- 같은 트랜잭션에서 audit 기록 (Q14)
- 모듈 레벨 초기화: engine, KMS client, 환경변수 검증, Secrets Manager credentials (Q15)
- 환경변수: DB_SECRET_ARN, RDS_PROXY_ENDPOINT, KMS_KEY_ID, PROXY_BASE_URL, LOG_LEVEL (Q16)
- VirtualKeyService는 90% 커버리지, property-based testing 적용 (Q17-Q18)
- API Gateway 통합은 Unit 1에서 완료, Unit 3에서 Lambda 코드 교체 (Q19)
- request_id: 클라이언트 헤더 → API Gateway requestId → Lambda 생성 (Q20)

---

## 2. 기능 설계 체크리스트

### 2.1 비즈니스 로직 모델링
- [x] Lambda 핸들러 진입점 설계 (sync wrapper → async handler)
- [x] IAM Principal 추출 전략 (ARN 파싱 + fallback)
- [x] VirtualKeyService.get_or_create_key 전체 흐름
- [x] UserLookupService (resolve_user, validate_user_active, get_active_user)
- [x] DB 세션 관리 (모듈 레벨 engine, per-invocation session)
- [x] 트랜잭션 경계 (단일 트랜잭션)
- [x] KMS 통합 (encrypt/decrypt via KmsHelper)
- [x] API 키 생성 (shared/utils/hashing.py의 generate_api_key() 재사용, sk- prefix)
- [x] 응답 구성 (user + virtual_key + proxy)
- [x] 에러 처리 흐름
- [x] request_id 추출 및 전파
- [x] 구조화된 JSON 로깅
- [x] Audit 이벤트 기록
- [x] Cold start 최적화

### 2.2 도메인 엔터티
- [x] Unit 2 모델 참조 (User, VirtualKey, AuditEvent)
- [x] Token Service 전용 dataclass (TokenRequest, TokenResponse)
- [x] 에러 응답 구조체

### 2.3 비즈니스 규칙
- [x] User 상태 검증 (ACTIVE만 허용)
- [x] Virtual Key 유일성 (partial unique index)
- [x] 키 재사용 정책 (v1: 무조건 재사용)
- [x] Audit 이벤트 트리거
- [x] 보안 규칙 (평문 로깅 금지, KMS 암호화 필수)
- [x] 에러 코드 매핑

---

## 3. 설계 결정 요약

### 3.1 Lambda 핸들러 아키텍처

```
lambda_handler(event, context)  [sync wrapper]
  → asyncio.run(async_handler(event, context))
    → TokenRequest.from_event(event)
    → UserLookupService.extract_identity_info(event)
    → VirtualKeyService.get_or_create_key(identity_info, request)
    → TokenResponse.to_dict()
```

**핵심 포인트**:
- Thin sync wrapper: Lambda는 sync 함수를 요구하므로 `asyncio.run()`으로 async handler 실행
- Dataclass 래퍼: event dict를 `TokenRequest`로 파싱, 테스트 시 직접 주입 가능
- 에러 경계: async handler 내 예외를 catch → Token Service 에러 포맷으로 변환

### 3.2 IAM Principal 식별 전략

**단계**:
1. `event['requestContext']['identity']['userArn']`에서 assumed-role ARN 추출
2. ARN 형식: `arn:aws:sts::<account>:assumed-role/AWSReservedSSO_<PermissionSet>_<random>/<session-name>`
3. 마지막 `/` 이후 session-name 추출
4. `UserLookupService.resolve_user(session_name)`에서 다단계 fallback:
   - 1차: `users.identity_store_user_id = session_name` 조회
   - 2차: session_name에 '@' 포함 시 `users.email = session_name` 조회
   - 미존재: UserNotFoundError(403)

**이유**: Identity Center session name 형식이 환경마다 다를 수 있음 (user_id 또는 이메일)

### 3.3 DB 세션 관리 및 트랜잭션

**모듈 레벨 초기화** (`lambda/core/database.py`):
```python
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

# Module-level engine (cold start optimization)
engine = create_async_engine(
    get_database_url(),  # Secrets Manager에서 조회
    pool_size=1,
    max_overflow=0,
    connect_args={"ssl": True}
)
```

**Per-invocation session** (`lambda/handler.py`):
```python
async def async_handler(event, context):
    async with AsyncSession(engine) as session:
        async with session.begin():
            # 전체 흐름: User 조회 → VirtualKey 생성/조회 → AuditEvent 기록
            ...
            # 암묵적 commit (트랜잭션 종료)
```

**트랜잭션 경계**: 단일 트랜잭션으로 User 조회 → VirtualKey 생성/갱신 → AuditEvent 기록을 원자적으로 처리

### 3.4 VirtualKeyService 핵심 로직

**get_or_create_key 흐름**:
```
1. UserLookupService.get_active_user(identity_info)
   → resolve_user (identity_store_user_id 또는 email로 조회)
   → validate_user_active (ACTIVE 확인, INACTIVE면 UserInactiveError)
2. VirtualKeyRepository.get_active_by_user(user_id)
3a. 활성 키 존재:
    → KmsHelper.decrypt_key(kms_ciphertext) → 평문 키 복호화
    → update last_used_at
    → return (user, plaintext_key, virtual_key_metadata)
3b. 활성 키 없음:
    → generate_api_key() → sk- + secrets.token_urlsafe(32)
    → KmsHelper.encrypt_key(plaintext) → ciphertext
    → KmsHelper.generate_fingerprint(plaintext) → SHA-256
    → VirtualKeyRepository.create(...)
    → AuditEventRepository.create_event(VIRTUAL_KEY_ISSUED)
    → return (user, plaintext_key, virtual_key_metadata)
```

**핵심 규칙**:
- 활성 키가 이미 있으면 무조건 재사용 (v1, Q6)
- `last_used_at` 갱신만 수행, 별도 audit 이벤트 없음 (Q4)
- 키 회전/폐기는 Admin API에서만 수행

### 3.5 에러 처리 및 응답

**예외 매핑** (shared/exceptions.py):
```
UserNotFoundError      → 403 user_not_synced
UserInactiveError      → 409 user_inactive
InternalError          → 500 internal_error
```

**에러 응답 형식** (API_SPEC.md 3.3):
```json
{
  "error": {
    "code": "user_inactive",
    "message": "User is not active",
    "request_id": "req_01JQ...",
    "retryable": false
  }
}
```

**성공 응답 형식** (API_SPEC.md 4.1):
```json
{
  "user": { "id": "...", "identity_store_user_id": "...", ... },
  "virtual_key": { "id": "...", "secret": "sk-...", "status": "ACTIVE", ... },
  "proxy": { "base_url": "https://...", "messages_path": "/v1/messages" }
}
```

### 3.6 Audit 이벤트

**기록 이벤트** (Q13):
1. **VIRTUAL_KEY_ISSUED**: 신규 키 생성 시
   - payload: `{"client_name": "...", "client_version": "...", "aws_profile": "..."}`
   - actor_type: "IAM_PRINCIPAL"
   - actor_id: userArn (전체)
   - object_type: "VIRTUAL_KEY"
   - object_id: virtual_key.id

2. **VIRTUAL_KEY_REQUEST_FAILED**: 키 발급 실패 시
   - payload: `{"reason": "UserNotFoundError", "identity_store_user_id": "..."}`
   - actor_type: "IAM_PRINCIPAL"
   - actor_id: userArn (추출 실패 시 "UNKNOWN")
   - object_type: "VIRTUAL_KEY"
   - object_id: "N/A"

**기록 시점** (Q14): VirtualKey 생성/실패와 같은 트랜잭션에서 기록

### 3.7 환경변수 및 Cold Start 최적화

**환경변수** (Q16):
- `DB_SECRET_ARN`: Secrets Manager에서 DB 자격증명 조회
- `RDS_PROXY_ENDPOINT`: RDS Proxy 엔드포인트
- `KMS_KEY_ID`: KMS 키 ARN (암복호화용)
- `PROXY_BASE_URL`: Gateway ALB 주소 (응답에 포함)
- `LOG_LEVEL`: 로그 레벨 (기본 INFO)

**모듈 레벨 초기화** (Q15, cold start 최적화):
- SQLAlchemy async engine
- boto3 KMS client (KmsHelper._client 싱글턴)
- 환경변수 검증 (누락 시 import 시점 즉시 실패)
- Secrets Manager에서 DB credentials 조회 및 캐싱

**Warm invocation 이점**:
- Engine 재사용 (TCP connection 유지)
- KMS client 재사용
- Secrets Manager 캐싱 (credential rotation 시 새 invocation이 새 값 가져옴)

### 3.8 테스트 전략

**커버리지 목표** (Q17):
- VirtualKeyService: 90% 이상 (고위험 모듈)
- UserLookupService, handler.py: 80% 이상

**Property-Based Testing** (Q18):
- `KmsHelper.generate_fingerprint`: 동일 입력 → 동일 출력 (deterministic)
- `generate_api_key`: 항상 `sk-` prefix, 길이 범위 내, URL-safe 문자만
- IAM ARN 파싱: 유효한 ARN → 정상 추출, 잘못된 ARN → 예외
- strategy 정의: `tests/strategies.py` (virtual_key_strategy, iam_arn_strategy)

**주요 테스트 시나리오** (Q17):
1. 신규 사용자 첫 키 발급 (성공)
2. 기존 사용자 활성 키 재조회 (KMS decrypt 성공)
3. INACTIVE 사용자 (409 거부)
4. 미동기화 사용자 (403 거부)
5. KMS 암호화/복호화 실패 (500)
6. DB 연결 실패 (500)
7. 잘못된 request body (정상 처리, optional 필드)
8. IAM principal 파싱 실패 (500)

### 3.9 로깅 및 Request ID

**로깅 형식** (system-nfr-decisions.md 2.1):
- 구조화된 JSON 로그
- 필수 필드: `timestamp`, `level`, `message`, `request_id`
- 표준 logging + JSON formatter 사용

**request_id 추출** (Q20):
1. 클라이언트 `x-request-id` 헤더 (대소문자 무시)
2. `event['requestContext']['requestId']` (API Gateway 생성)
3. Lambda에서 uuid4 생성 (최후 fallback)

**전파**:
- logging extra에 바인딩 (모든 로그에 자동 포함)
- 응답 headers에 `x-request-id` 포함
- audit_events.request_id 필드에 저장
- 에러 응답 `error.request_id`에 포함

### 3.10 API Gateway 통합

**현재 상태** (Q19):
- Unit 1에서 `POST /v1/auth/virtual-key` 리소스 + IAM Auth + Lambda Proxy 통합 이미 생성
- Lambda는 skeleton 상태 (from_inline placeholder 코드)

**Unit 3에서 보완**:
- Lambda code를 from_inline → from_asset (실제 코드 패키지)
- 환경변수 추가: PROXY_BASE_URL, LOG_LEVEL
- 환경변수 이름 변경: KMS_KEY_ARN → KMS_KEY_ID

---

## 4. 구현 파일 구조

```
lambda/
├── handler.py                  # Lambda 진입점 (sync wrapper → async handler)
├── core/
│   ├── __init__.py
│   ├── database.py             # Module-level engine, get_database_url()
│   └── config.py               # 환경변수 검증
├── models.py                   # TokenRequest, TokenResponse dataclass
├── services/
│   ├── __init__.py
│   ├── virtual_key_service.py  # VirtualKeyService (get_or_create_key)
│   └── user_lookup_service.py  # UserLookupService (resolve_user, validate_user_active, get_active_user)
└── utils.py                    # extract_request_id, handle_error

tests/
├── __init__.py
├── strategies.py               # Hypothesis strategies
├── test_handler.py
├── test_virtual_key_service.py
├── test_user_lookup_service.py
└── test_utils.py
```

**Shared 패키지 재사용**:
- Unit 2의 `shared/models/` 모델 import
- `shared/utils/kms.py` KmsHelper 사용
- `shared/utils/hashing.py` generate_api_key() 사용
- `shared/exceptions.py` 예외 계층 사용 (Unit 3 코드 생성 시 먼저 생성 필요 — Unit 2에서 누락됨)

---

## 5. 보안 고려사항

**Virtual Key 평문 보호** (Q12):
- 허용: Lambda 응답 body, 메모리 내 변수
- 금지: CloudWatch Logs, DB, 에러 메시지
- 가드레일: 로그에 key_fingerprint 또는 key_last4만 포함

**KMS 권한** (system-nfr-decisions.md 4.4):
- Lambda 실행 역할: KMS Encrypt/Decrypt (특정 키)
- 최소 권한 원칙

**DB 접속** (system-nfr-decisions.md 4.5):
- Secrets Manager에서 런타임 조회
- 환경변수에 평문 자격증명 금지
- TLS 연결 (`sslmode=require`)

---

## 6. NFR 준수

| NFR 항목 | 준수 방법 |
|----------|-----------|
| 인증 (1.1) | API Gateway IAM Auth + SigV4 (Unit 1에서 설정) |
| 로깅 (2.1) | 구조화된 JSON 로그, CloudWatch Logs |
| Request ID (2.4) | 클라이언트 헤더 → API Gateway → Lambda 생성 |
| 에러 응답 (3.1) | Token Service 전용 포맷 (API_SPEC.md 3.3) |
| 예외 계층 (3.2) | shared/exceptions.py 공유 예외 |
| 저장 암호화 (4.1) | KMS 암호화 (평문 미저장) |
| 전송 암호화 (4.2) | API Gateway TLS 1.2+ |
| 네트워크 (4.3) | Lambda private subnet, VPC Endpoint |
| IAM (4.4) | 최소 권한 Lambda 역할 |
| 민감 데이터 (4.5) | 평문 키 로그 금지, Secrets Manager credentials |
| DB 기술 (6.1) | Aurora Serverless v2 + RDS Proxy |
| ORM (6.2) | SQLAlchemy 2.0 async |
| 트랜잭션 (6.4) | 단일 트랜잭션 (명시적 경계) |
| Python (8.1) | Python 3.13, type hints |
| 패키지 관리 (8.2) | uv |
| 코드 스타일 (8.3) | ruff |
| 테스트 (9.1-9.3) | pytest, 80-90% 커버리지, property-based |
| Timeout (10.2) | Lambda 30초 (API Gateway 29초) |

---

## 7. 다음 단계

설계 승인 후 Code Generation 단계로 진행:
1. `lambda/handler.py` — Lambda 진입점
2. `lambda/core/database.py` — DB 세션 관리
3. `lambda/services/virtual_key_service.py` — 핵심 비즈니스 로직
4. `lambda/services/user_lookup_service.py` — 사용자 식별 로직
5. `lambda/models.py` — 요청/응답 dataclass
6. `lambda/utils.py` — extract_request_id, handle_error
7. `shared/exceptions.py` — 공유 예외 계층 (신규 생성, Unit 2에서 누락)
8. `tests/` — 단위 테스트 + property-based 테스트
8. `infra/stacks/compute_stack.py` 보완 — Lambda 설정 확정
