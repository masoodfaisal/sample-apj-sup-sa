# Business Logic Model — Unit 3: Token Service

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Approved
- 근거: [Design Questions](./design-questions.md), [Functional Design Plan](./functional-design-plan.md)

---

## 1. 개요

이 문서는 Unit 3 Token Service의 비즈니스 로직 흐름을 상세히 기술한다. Lambda 핸들러 진입점에서 Virtual Key 발급/재조회까지의 전체 흐름, 에러 처리, DB 세션 관리, Audit 이벤트 기록을 포함한다.

---

## 2. Lambda 핸들러 흐름

### 2.1 진입점 구조

```python
# lambda/handler.py

def lambda_handler(event: dict, context: LambdaContext) -> dict:
    """
    API Gateway Lambda Proxy 통합 진입점.
    Sync wrapper로 async handler를 실행한다.
    """
    try:
        return asyncio.run(async_handler(event, context))
    except Exception as e:
        logger.exception("Unhandled exception in lambda_handler")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "error": {
                    "code": "internal_error",
                    "message": "Internal server error",
                    "request_id": extract_request_id(event),
                    "retryable": False
                }
            })
        }
```

**설계 원칙**:
- Lambda는 sync 함수를 요구하므로 `asyncio.run()`으로 async handler 실행
- 최상위 try-except: 미처리 예외를 catch하여 500 에러 응답
- async handler 내부는 비즈니스 예외를 적절히 처리

### 2.2 Async Handler 흐름

```python
async def async_handler(event: dict, context: LambdaContext) -> dict:
    """
    1. Request ID 추출
    2. Request 파싱
    3. Identity 추출
    4. DB 세션 생성
    5. VirtualKeyService 호출
    6. Response 구성
    """
    # Step 1: Request ID 추출 및 로거 바인딩
    request_id = extract_request_id(event)
    logger.info("Token request received", extra={"request_id": request_id})
    
    try:
        # Step 2: Request 파싱 (optional 필드)
        request = TokenRequest.from_event(event)
        
        # Step 3: IAM Principal identity 추출
        identity_info = UserLookupService.extract_identity_info(event)
        
        # Step 4: DB 세션 생성 (per-invocation)
        async with AsyncSession(engine) as session:
            async with session.begin():
                # Step 5: Virtual Key 발급/조회
                user, plaintext_key, virtual_key = await VirtualKeyService.get_or_create_key(
                    session, identity_info, request
                )
                
                # 암묵적 commit (트랜잭션 종료)
        
        # Step 6: Response 구성
        response = TokenResponse(
            user=user,
            virtual_key=virtual_key,
            virtual_key_secret=plaintext_key,
            proxy_base_url=os.environ["PROXY_BASE_URL"],
            proxy_messages_path="/v1/messages"
        )
        
        logger.info(
            "Token request succeeded",
            extra={
                "request_id": request_id,
                "user_id": str(user.id),
                "virtual_key_id": str(virtual_key.id),
                "key_fingerprint": virtual_key.key_fingerprint
            }
        )
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "x-request-id": request_id
            },
            "body": json.dumps(response.to_dict())
        }
    
    except UserNotFoundError as e:
        return handle_error(403, "user_not_synced", str(e), request_id, False)
    except UserInactiveError as e:
        return handle_error(409, "user_inactive", str(e), request_id, False)
    except Exception as e:
        logger.exception("Internal error", extra={"request_id": request_id})
        return handle_error(500, "internal_error", "Internal server error", request_id, False)
```

**핵심 포인트**:
- Request ID는 로그 correlation에 사용 (logging extra로 바인딩)
- DB 세션은 `async with` context manager로 관리
- 단일 트랜잭션: User 조회 → VirtualKey 생성/갱신 → AuditEvent 기록
- 비즈니스 예외는 명시적으로 catch하여 적절한 HTTP status code로 변환

---

## 3. Request ID 추출 로직

### 3.1 우선순위

```python
def extract_request_id(event: dict) -> str:
    """
    1. 클라이언트 x-request-id 헤더 (대소문자 무시)
    2. API Gateway requestContext.requestId
    3. Lambda에서 UUID v4 생성
    """
    # 1. 클라이언트 헤더
    headers = event.get("headers", {})
    for key, value in headers.items():
        if key.lower() == "x-request-id" and value:
            return value
    
    # 2. API Gateway requestId
    request_context = event.get("requestContext", {})
    if api_gw_id := request_context.get("requestId"):
        return api_gw_id
    
    # 3. Lambda 생성
    return f"req_{uuid.uuid4().hex}"
```

**근거**: system-nfr-decisions.md 2.4절 준수

---

## 4. IAM Principal 추출 로직

### 4.1 ARN 파싱 (UserLookupService의 static method)

```python
# lambda/services/user_lookup_service.py

@staticmethod
def extract_identity_info(event: dict) -> str:
    """
    API Gateway event에서 IAM Principal 정보 추출.
    
    ARN 형식:
    arn:aws:sts::<account>:assumed-role/AWSReservedSSO_<PermissionSet>_<random>/<session-name>
    
    Returns:
        session-name (identity_store_user_id 또는 email)
    
    Raises:
        InternalError: ARN 파싱 실패
    """
    try:
        user_arn = event["requestContext"]["identity"]["userArn"]
        
        # 마지막 '/' 이후 session-name 추출
        session_name = user_arn.split("/")[-1]
        
        if not session_name:
            raise ValueError("Empty session name")
        
        return session_name
    
    except (KeyError, IndexError, ValueError) as e:
        logger.error(f"Failed to extract identity from event: {e}")
        raise InternalError("Failed to extract user identity")
```

**예시**:
- ARN: `arn:aws:sts::123456789012:assumed-role/AWSReservedSSO_Dev_abc123/user-1234`
- 추출: `user-1234`

**다단계 fallback**: `UserLookupService.resolve_user()`에서 처리 (다음 섹션 참조)

---

## 5. UserLookupService 로직

### 5.1 resolve_user (다단계 fallback)

```python
class UserLookupService:
    """사용자 식별 및 검증 서비스."""
    
    @staticmethod
    async def resolve_user(session: AsyncSession, identity_info: str) -> User:
        """
        IAM principal session-name으로 User 조회 (다단계 fallback).
        
        1차: identity_store_user_id 조회
        2차: session-name에 '@' 포함 시 email 조회
        
        Args:
            session: DB 세션
            identity_info: IAM session-name (identity_store_user_id 또는 email)
        
        Returns:
            User 모델
        
        Raises:
            UserNotFoundError: 사용자 미존재
        """
        # 1차: identity_store_user_id로 조회
        stmt = select(User).where(User.identity_store_user_id == identity_info)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        
        if user:
            logger.debug(f"User found by identity_store_user_id: {identity_info}")
            return user
        
        # 2차: email로 조회 (session_name에 '@' 포함 시)
        if "@" in identity_info:
            stmt = select(User).where(User.email == identity_info)
            result = await session.execute(stmt)
            user = result.scalar_one_or_none()
            
            if user:
                logger.debug(f"User found by email: {identity_info}")
                return user
        
        # 미존재
        logger.warning(f"User not found: {identity_info}")
        raise UserNotFoundError(f"User not found for identity: {identity_info}")
```

**설계 이유**:
- Identity Center session name 형식이 환경마다 다를 수 있음 (user_id 또는 이메일)
- 2단계 fallback으로 유연성 확보

### 5.2 validate_user_active

```python
@staticmethod
def validate_user_active(user: User) -> None:
    """
    사용자 ACTIVE 상태 검증.
    
    Args:
        user: 검증 대상 User
    
    Raises:
        UserInactiveError: 사용자 INACTIVE
    """
    if user.status != UserStatus.ACTIVE:
        logger.warning(f"User is not active: {user.id}, status={user.status}")
        raise UserInactiveError(f"User {user.id} is not active")
```

**비즈니스 규칙**:
- ACTIVE 상태만 Virtual Key 발급/사용 가능
- INACTIVE 사용자는 즉시 차단

### 5.3 get_active_user (convenience method)

```python
@staticmethod
async def get_active_user(session: AsyncSession, identity_info: str) -> User:
    """
    사용자 조회 + ACTIVE 검증을 한 번에 수행.
    
    Returns:
        ACTIVE 상태의 User
    
    Raises:
        UserNotFoundError: 사용자 미존재
        UserInactiveError: 사용자 INACTIVE
    """
    user = await UserLookupService.resolve_user(session, identity_info)
    UserLookupService.validate_user_active(user)
    return user
```

**사용 예**: `VirtualKeyService.get_or_create_key()`에서 호출

---

## 6. VirtualKeyService 로직

### 6.1 get_or_create_key 전체 흐름

```python
class VirtualKeyService:
    """Virtual Key 발급/조회 서비스."""
    
    @staticmethod
    async def get_or_create_key(
        session: AsyncSession,
        identity_info: str,
        request: TokenRequest
    ) -> tuple[User, str, VirtualKey]:
        """
        Virtual Key 발급/재조회.
        
        흐름:
        1. User 조회 + ACTIVE 검증
        2. 활성 VirtualKey 조회
        3a. 존재 시: KMS decrypt + last_used_at 갱신
        3b. 부재 시: 신규 키 생성 + KMS encrypt + audit 기록
        
        Returns:
            (User, plaintext_key, VirtualKey)
        
        Raises:
            UserNotFoundError: 사용자 미존재
            UserInactiveError: 사용자 INACTIVE
            InternalError: KMS/DB 에러
        """
        # Step 1: User 조회 + ACTIVE 검증
        user = await UserLookupService.get_active_user(session, identity_info)
        
        # Step 2: 활성 VirtualKey 조회
        stmt = select(VirtualKey).where(
            VirtualKey.user_id == user.id,
            VirtualKey.status == VirtualKeyStatus.ACTIVE
        )
        result = await session.execute(stmt)
        existing_key = result.scalar_one_or_none()
        
        if existing_key:
            # Step 3a: 기존 키 재사용
            return await VirtualKeyService._reuse_existing_key(
                session, user, existing_key
            )
        else:
            # Step 3b: 신규 키 생성
            return await VirtualKeyService._create_new_key(
                session, user, request
            )
```

### 6.2 기존 키 재사용 (_reuse_existing_key)

```python
@staticmethod
async def _reuse_existing_key(
    session: AsyncSession,
    user: User,
    virtual_key: VirtualKey
) -> tuple[User, str, VirtualKey]:
    """
    활성 Virtual Key 재사용.
    
    1. KMS decrypt로 평문 복호화
    2. last_used_at 갱신
    3. 반환
    
    audit 이벤트 없음 (last_used_at 갱신으로 충분).
    """
    try:
        # KMS decrypt
        plaintext_key = KmsHelper.decrypt_key(virtual_key.kms_ciphertext)
        
        # last_used_at 갱신
        virtual_key.last_used_at = datetime.now(timezone.utc)
        session.add(virtual_key)
        
        logger.info(
            "Reusing existing virtual key",
            extra={
                "user_id": str(user.id),
                "virtual_key_id": str(virtual_key.id),
                "key_fingerprint": virtual_key.key_fingerprint
            }
        )
        
        return user, plaintext_key, virtual_key
    
    except Exception as e:
        logger.exception("Failed to decrypt virtual key")
        raise InternalError(f"Failed to decrypt virtual key: {e}")
```

**핵심 규칙**:
- 활성 키가 존재하면 무조건 재사용 (v1, Q6)
- `last_used_at` 갱신만 수행, 별도 audit 이벤트 없음 (Q4)

### 6.3 신규 키 생성 (_create_new_key)

```python
@staticmethod
async def _create_new_key(
    session: AsyncSession,
    user: User,
    request: TokenRequest
) -> tuple[User, str, VirtualKey]:
    """
    신규 Virtual Key 생성.
    
    1. API 키 생성 (sk- prefix + secrets.token_urlsafe(32))
    2. KMS encrypt
    3. SHA-256 fingerprint 생성
    4. DB 저장
    5. Audit 이벤트 기록
    """
    try:
        # Step 1: API 키 생성
        plaintext_key = generate_api_key()
        
        # Step 2: KMS encrypt
        kms_ciphertext = KmsHelper.encrypt_key(plaintext_key)
        
        # Step 3: Fingerprint 생성
        key_fingerprint = KmsHelper.generate_fingerprint(plaintext_key)
        
        # last4 추출
        key_last4 = plaintext_key[-4:]
        
        # Step 4: DB 저장
        now = datetime.now(timezone.utc)
        virtual_key = VirtualKey(
            id=uuid.uuid4(),
            user_id=user.id,
            key_fingerprint=key_fingerprint,
            key_last4=key_last4,
            kms_ciphertext=kms_ciphertext,
            status=VirtualKeyStatus.ACTIVE,
            issued_at=now,
            expires_at=None,  # v1: 무기한
            last_used_at=now,
            revoked_at=None
        )
        session.add(virtual_key)
        
        # Step 5: Audit 이벤트 기록
        audit_event = AuditEvent(
            id=uuid.uuid4(),
            actor_type="IAM_PRINCIPAL",
            actor_id=request.user_arn,  # 전체 ARN
            event_type="VIRTUAL_KEY_ISSUED",
            object_type="VIRTUAL_KEY",
            object_id=str(virtual_key.id),
            request_id=request.request_id,
            sync_run_id=None,
            payload_json={
                "client_name": request.client_name,
                "client_version": request.client_version,
                "aws_profile": request.aws_profile
            },
            created_at=now
        )
        session.add(audit_event)
        
        logger.info(
            "Created new virtual key",
            extra={
                "user_id": str(user.id),
                "virtual_key_id": str(virtual_key.id),
                "key_fingerprint": key_fingerprint
            }
        )
        
        return user, plaintext_key, virtual_key
    
    except Exception as e:
        logger.exception("Failed to create virtual key")
        raise InternalError(f"Failed to create virtual key: {e}")
```

**보안 규칙**:
- 평문 키는 메모리에만 존재, DB에 저장 금지
- KMS ciphertext + SHA-256 fingerprint만 DB 저장
- 로그에 `key_fingerprint`만 포함, 평문 키 미포함

---

## 7. API 키 생성 로직

### 7.1 generate_api_key (shared/utils/hashing.py — 기존 구현 재사용)

```python
# shared/utils/hashing.py (Unit 2에서 이미 구현됨)

def generate_api_key() -> str:
    """Generate a Claude-proxy API key."""
    return f"sk-{secrets.token_urlsafe(32)}"
```

**Token Service에서의 사용**: `from shared.utils.hashing import generate_api_key`로 import. `lambda/utils.py`에 재정의하지 않음 (코드 중복 방지).

**형식**: `sk-` prefix + `secrets.token_urlsafe(32)` ≈ 46자

**property-based testing** (Q18):
- 항상 `sk-` prefix로 시작
- 길이 범위 내 (약 46자)
- URL-safe 문자만 포함 (alphanumeric + `-_`)

---

## 8. DB 세션 관리

### 8.1 모듈 레벨 Engine 초기화

```python
# lambda/core/database.py

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
import json
import boto3

# Secrets Manager에서 DB 자격증명 조회 (모듈 레벨 캐싱)
def get_database_url() -> str:
    """
    Secrets Manager에서 DB credentials 조회하여 connection string 구성.
    
    모듈 레벨에서 한 번만 호출 (cold start 최적화).
    """
    secret_arn = os.environ["DB_SECRET_ARN"]
    rds_endpoint = os.environ["RDS_PROXY_ENDPOINT"]
    
    # Secrets Manager 조회
    sm_client = boto3.client("secretsmanager")
    response = sm_client.get_secret_value(SecretId=secret_arn)
    secret = json.loads(response["SecretString"])
    
    username = secret["username"]
    password = secret["password"]
    
    # PostgreSQL async connection string
    return (
        f"postgresql+asyncpg://{username}:{password}@{rds_endpoint}:5432/claude_proxy"
    )

# Module-level engine (warm invocation에서 재사용)
engine = create_async_engine(
    get_database_url(),
    pool_size=1,
    max_overflow=0,
    connect_args={"ssl": True},
    echo=False
)
```

**설계 원칙**:
- 모듈 레벨 engine 초기화 → warm invocation에서 재사용
- `pool_size=1, max_overflow=0`: Lambda는 단일 동시 요청, RDS Proxy가 서버사이드 pooling 담당
- `sslmode=require`: system-nfr-decisions.md 6.1 준수

### 8.2 Per-invocation Session

```python
# lambda/handler.py

async def async_handler(event: dict, context: LambdaContext) -> dict:
    async with AsyncSession(engine) as session:
        async with session.begin():
            # 전체 흐름: User 조회 → VirtualKey 생성/조회 → AuditEvent 기록
            user, key, metadata = await VirtualKeyService.get_or_create_key(...)
            # 암묵적 commit (트랜잭션 종료)
```

**트랜잭션 경계**:
- `async with session.begin()`: 트랜잭션 시작
- context manager 종료 시 자동 commit (성공) 또는 rollback (예외)
- 단일 트랜잭션: User 조회 → VirtualKey 생성/갱신 → AuditEvent 기록

**이점**:
- 원자성 보장 (VirtualKey 생성 실패 시 AuditEvent도 롤백)
- 리소스 누수 방지 (context manager로 세션 자동 종료)

---

## 9. 에러 처리 흐름

### 9.1 예외 처리 계층

```
UserNotFoundError      → 403 user_not_synced
UserInactiveError      → 409 user_inactive
InternalError          → 500 internal_error
(기타 예외)            → 500 internal_error
```

### 9.2 handle_error 헬퍼

```python
def handle_error(
    status_code: int,
    error_code: str,
    message: str,
    request_id: str,
    retryable: bool
) -> dict:
    """
    Token Service 에러 응답 구성.
    
    API_SPEC.md 3.3절 형식 준수.
    """
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "x-request-id": request_id
        },
        "body": json.dumps({
            "error": {
                "code": error_code,
                "message": message,
                "request_id": request_id,
                "retryable": retryable
            }
        })
    }
```

### 9.3 실패 Audit 기록

**시나리오**: 키 발급 실패 (UserNotFoundError, UserInactiveError, InternalError)

```python
# 실패 audit는 별도 세션/트랜잭션에서 best-effort 기록
async def record_failure_audit(
    identity_info: str,
    user_arn: str,
    request_id: str,
    reason: str
) -> None:
    """
    실패 audit 이벤트 기록 (best-effort).
    
    audit 저장 실패가 에러 응답을 바꾸지는 않는다.
    """
    try:
        async with AsyncSession(engine) as session:
            async with session.begin():
                audit_event = AuditEvent(
                    id=uuid.uuid4(),
                    actor_type="IAM_PRINCIPAL",
                    actor_id=user_arn if user_arn else "UNKNOWN",
                    event_type="VIRTUAL_KEY_REQUEST_FAILED",
                    object_type="VIRTUAL_KEY",
                    object_id="N/A",
                    request_id=request_id,
                    sync_run_id=None,
                    payload_json={
                        "reason": reason,
                        "identity_info": identity_info  # raw 식별자 (ARN session-name 또는 이메일)
                    },
                    created_at=datetime.now(timezone.utc)
                )
                session.add(audit_event)
    except Exception as e:
        logger.warning(f"Failed to record failure audit: {e}")
```

**사용 위치**: async_handler의 except 블록에서 호출

---

## 10. 응답 구성

### 10.1 TokenResponse 구조

```python
@dataclass
class TokenResponse:
    """Token Service 성공 응답."""
    user: User
    virtual_key: VirtualKey
    virtual_key_secret: str  # 평문 키
    proxy_base_url: str
    proxy_messages_path: str
    
    def to_dict(self) -> dict:
        """API_SPEC.md 4.1절 형식으로 변환."""
        return {
            "user": {
                "id": str(self.user.id),
                "identity_store_user_id": self.user.identity_store_user_id,
                "display_name": self.user.display_name,
                "email": self.user.email,
                "default_team_id": str(self.user.default_team_id) if self.user.default_team_id else None
            },
            "virtual_key": {
                "id": str(self.virtual_key.id),
                "secret": self.virtual_key_secret,
                "status": self.virtual_key.status.value,
                "issued_at": self.virtual_key.issued_at.isoformat(),
                "expires_at": self.virtual_key.expires_at.isoformat() if self.virtual_key.expires_at else None
            },
            "proxy": {
                "base_url": self.proxy_base_url,
                "messages_path": self.proxy_messages_path
            }
        }
```

**핵심 포인트**:
- `virtual_key.secret`: 평문 키 (응답에만 포함, 로그/DB 미포함)
- `proxy.base_url`: 환경변수 `PROXY_BASE_URL`에서 읽음
- `proxy.messages_path`: 하드코딩 `/v1/messages`
- `key_last4`: 응답에 미포함 (클라이언트가 전체 secret을 받으므로 불필요)

---

## 11. 로깅 전략

### 11.1 구조화된 JSON 로깅

```python
# lambda/core/config.py

import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    """CloudWatch Logs Insights 호환 JSON formatter."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_obj = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "request_id": getattr(record, "request_id", None)
        }
        
        # extra 필드 병합
        if hasattr(record, "user_id"):
            log_obj["user_id"] = record.user_id
        if hasattr(record, "virtual_key_id"):
            log_obj["virtual_key_id"] = record.virtual_key_id
        if hasattr(record, "key_fingerprint"):
            log_obj["key_fingerprint"] = record.key_fingerprint
        
        return json.dumps(log_obj)

# 로거 설정
logger = logging.getLogger()
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger.addHandler(handler)
logger.setLevel(os.environ.get("LOG_LEVEL", "INFO"))
```

**로그 예시**:
```json
{
  "timestamp": "2026-04-01T12:34:56Z",
  "level": "INFO",
  "message": "Token request succeeded",
  "logger": "lambda.handler",
  "request_id": "req_01JQ...",
  "user_id": "7a53cf13-...",
  "virtual_key_id": "6d071d24-...",
  "key_fingerprint": "abc123..."
}
```

**금지 사항** (Q12):
- Virtual Key 평문 로깅 금지
- KMS ciphertext 로깅 금지
- `key_fingerprint` 또는 `key_last4`만 로깅 허용

---

## 12. Cold Start 최적화

### 12.1 모듈 레벨 초기화 항목

**초기화 항목** (Q15):
1. SQLAlchemy async engine
2. boto3 KMS client (KmsHelper._client 싱글턴)
3. 환경변수 검증 (누락 시 import 시점 즉시 실패)
4. Secrets Manager에서 DB credentials 조회 및 캐싱

**코드 예시**:
```python
# lambda/core/config.py

# 환경변수 검증 (import 시점)
REQUIRED_ENV_VARS = [
    "DB_SECRET_ARN",
    "RDS_PROXY_ENDPOINT",
    "KMS_KEY_ID",
    "PROXY_BASE_URL",
]

for var in REQUIRED_ENV_VARS:
    if var not in os.environ:
        raise RuntimeError(f"Missing required environment variable: {var}")

# LOG_LEVEL은 선택 (기본값 INFO)
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

# lambda/core/database.py
# Module-level engine 초기화 (위 8.1절 참조)
engine = create_async_engine(...)
```

### 12.2 Warm Invocation 이점

- Engine 재사용 (TCP connection 유지)
- KMS client 재사용 (boto3 클라이언트 초기화 비용 절감)
- Secrets Manager credentials 캐싱 (매 invocation마다 조회하지 않음)

**Credential Rotation 대응**:
- Secrets Manager credential rotation 시 새 Lambda invocation이 새 값을 가져옴
- 기존 warm container는 이전 credentials 사용 (rotation 완료 후 점진적 교체)

---

## 13. 시퀀스 다이어그램

### 13.1 신규 키 발급 (성공)

```
Client                  API Gateway         Lambda Handler      VirtualKeyService   UserLookupService   VirtualKeyRepository   KmsHelper   AuditEventRepository
  |                           |                     |                      |                      |                         |               |                  |
  |--POST /v1/auth/virtual-key (SigV4)------------>|                      |                      |                         |               |                  |
  |                           |--Lambda invoke---->|                      |                      |                         |               |                  |
  |                           |                     |--extract_request_id-->                      |                         |               |                  |
  |                           |                     |--extract_identity_info->                    |                         |               |                  |
  |                           |                     |--TokenRequest.from_event->                  |                         |               |                  |
  |                           |                     |--AsyncSession.begin()-->                    |                         |               |                  |
  |                           |                     |                      |                      |                         |               |                  |
  |                           |                     |--get_or_create_key()->|                      |                         |               |                  |
  |                           |                     |                      |--get_active_user()-->|                         |               |                  |
  |                           |                     |                      |                      |--resolve_user()-------->|               |                  |
  |                           |                     |                      |                      |<--User (ACTIVE)---------|               |                  |
  |                           |                     |                      |<--User---------------|                         |               |                  |
  |                           |                     |                      |                      |                         |               |                  |
  |                           |                     |                      |--get_active_by_user()->|                        |               |                  |
  |                           |                     |                      |<--None (신규)---------|                         |               |                  |
  |                           |                     |                      |                      |                         |               |                  |
  |                           |                     |                      |--generate_api_key()-->|                         |               |                  |
  |                           |                     |                      |<--plaintext_key-------|                         |               |                  |
  |                           |                     |                      |                      |--encrypt_key()--------->|               |                  |
  |                           |                     |                      |                      |<--ciphertext------------|               |                  |
  |                           |                     |                      |                      |--generate_fingerprint()->|              |                  |
  |                           |                     |                      |                      |<--fingerprint-----------|               |                  |
  |                           |                     |                      |--VirtualKey.create()->|                         |               |                  |
  |                           |                     |                      |--AuditEvent.create()-------------------------------->|create_event()|
  |                           |                     |                      |<--commit-------------|                         |               |                  |
  |                           |                     |<--(User, key, metadata)|                    |                         |               |                  |
  |                           |                     |                      |                      |                         |               |                  |
  |                           |                     |--TokenResponse.to_dict()->                  |                         |               |                  |
  |                           |<--200 OK (JSON)-----|                      |                      |                         |               |                  |
  |<--200 OK (JSON)-----------|                     |                      |                      |                         |               |                  |
```

### 13.2 기존 키 재사용 (성공)

```
Client                  API Gateway         Lambda Handler      VirtualKeyService   UserLookupService   VirtualKeyRepository   KmsHelper
  |                           |                     |                      |                      |                         |
  |--POST /v1/auth/virtual-key (SigV4)------------>|                      |                      |                         |
  |                           |--Lambda invoke---->|                      |                      |                         |
  |                           |                     |--AsyncSession.begin()->                    |                         |
  |                           |                     |                      |                      |                         |
  |                           |                     |--get_or_create_key()->|                      |                         |
  |                           |                     |                      |--get_active_user()-->|                         |
  |                           |                     |                      |<--User (ACTIVE)------|                         |
  |                           |                     |                      |--get_active_by_user()->|                        |
  |                           |                     |                      |<--VirtualKey (존재)--|                         |
  |                           |                     |                      |                      |--decrypt_key()--------->|
  |                           |                     |                      |                      |<--plaintext_key---------|
  |                           |                     |                      |--update last_used_at->|                         |
  |                           |                     |                      |<--commit-------------|                         |
  |                           |                     |<--(User, key, metadata)|                    |                         |
  |                           |                     |                      |                      |                         |
  |                           |                     |--TokenResponse.to_dict()->                  |                         |
  |                           |<--200 OK (JSON)-----|                      |                      |                         |
  |<--200 OK (JSON)-----------|                     |                      |                      |                         |
```

### 13.3 사용자 미존재 (실패)

```
Client                  API Gateway         Lambda Handler      VirtualKeyService   UserLookupService   VirtualKeyRepository
  |                           |                     |                      |                      |
  |--POST /v1/auth/virtual-key (SigV4)------------>|                      |                      |
  |                           |--Lambda invoke---->|                      |                      |
  |                           |                     |--AsyncSession.begin()->                    |
  |                           |                     |                      |                      |
  |                           |                     |--get_or_create_key()->|                      |
  |                           |                     |                      |--get_active_user()-->|
  |                           |                     |                      |                      |--resolve_user()-------->|
  |                           |                     |                      |                      |<--None (미존재)---------|
  |                           |                     |                      |                      |--raise UserNotFoundError|
  |                           |                     |                      |<--UserNotFoundError--|                         |
  |                           |                     |<--UserNotFoundError--|                      |                         |
  |                           |                     |--rollback()--------->|                      |                         |
  |                           |                     |--record_failure_audit (best-effort)-------->|                         |
  |                           |                     |--handle_error()----->|                      |                         |
  |                           |<--403 (user_not_synced)|                  |                      |                         |
  |<--403 (user_not_synced)---|                     |                      |                      |                         |
```

---

## 14. 핵심 비즈니스 불변식 (Invariants)

1. **활성 키 유일성**: 사용자당 `ACTIVE` 상태의 VirtualKey는 최대 1개 (DB partial unique index로 강제)
2. **키 재사용**: v1에서 활성 키가 존재하면 무조건 재사용, 신규 생성하지 않음
3. **ACTIVE 사용자만 발급**: `user.status = ACTIVE`인 사용자만 Virtual Key 발급/재조회 가능
4. **평문 키 노출 제한**: Virtual Key 평문은 Lambda 응답 body에만 존재, 로그/DB/에러 메시지 미포함
5. **트랜잭션 원자성**: User 조회 → VirtualKey 생성/갱신 → AuditEvent 기록은 단일 트랜잭션
6. **KMS 암호화 필수**: VirtualKey 평문은 반드시 KMS로 암호화하여 DB 저장
7. **Audit 일관성**: 성공 시 `VIRTUAL_KEY_ISSUED`, 실패 시 `VIRTUAL_KEY_REQUEST_FAILED` (best-effort)

---

## 15. 비기능 요구사항 준수

| NFR | 준수 방법 |
|-----|-----------|
| 인증 (1.1) | API Gateway IAM Auth + SigV4 |
| 로깅 (2.1) | 구조화된 JSON 로그, request_id 바인딩 |
| Request ID (2.4) | 클라이언트 헤더 → API Gateway → Lambda 생성 |
| 에러 형식 (3.1) | Token Service 전용 포맷 (API_SPEC.md 3.3) |
| 예외 계층 (3.2) | shared/exceptions.py 공유 예외 |
| 저장 암호화 (4.1) | KMS 암호화 (평문 미저장) |
| 전송 암호화 (4.2) | API Gateway TLS 1.2+ |
| 민감 데이터 (4.5) | 평문 키 로그 금지, Secrets Manager credentials |
| DB (6.1) | Aurora Serverless v2 + RDS Proxy, TLS |
| ORM (6.2) | SQLAlchemy 2.0 async |
| 트랜잭션 (6.4) | 단일 트랜잭션, 명시적 경계 |
| Python (8.1) | Python 3.13, type hints |
| 테스트 (9.1-9.3) | pytest, 80-90% 커버리지, property-based |

---

## 16. 구현 체크리스트

- [ ] `lambda/handler.py` — Lambda 진입점 (sync wrapper + async handler)
- [ ] `lambda/core/database.py` — Module-level engine, get_database_url()
- [ ] `lambda/core/config.py` — 환경변수 검증, JSON 로거 설정
- [ ] `lambda/models.py` — TokenRequest, TokenResponse dataclass
- [ ] `lambda/services/virtual_key_service.py` — VirtualKeyService (get_or_create_key, _reuse_existing_key, _create_new_key)
- [ ] `lambda/services/user_lookup_service.py` — UserLookupService (resolve_user, validate_user_active, get_active_user)
- [ ] `lambda/utils.py` — extract_request_id, handle_error
- [ ] `tests/strategies.py` — Hypothesis strategies (virtual_key_strategy, iam_arn_strategy)
- [ ] `tests/test_handler.py` — Lambda 핸들러 통합 테스트
- [ ] `tests/test_virtual_key_service.py` — VirtualKeyService 단위 테스트 (90% 커버리지)
- [ ] `tests/test_user_lookup_service.py` — UserLookupService 단위 테스트 (80% 커버리지)
- [ ] `tests/test_utils.py` — 유틸리티 함수 + property-based 테스트
- [ ] `infra/stacks/compute_stack.py` 보완 — Lambda 설정 확정 (code path, 환경변수)
