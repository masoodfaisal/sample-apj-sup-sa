# Design Questions — Unit 3: Token Service

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Answered
- 근거: [Unit of Work](../../../inception/application-design/unit-of-work.md), [Services](../../../inception/application-design/services.md), [System NFR Decisions](../../system-nfr-decisions.md)

---

## 목적

Unit 3 Token Service의 상세 비즈니스 로직, Lambda 핸들러 설계, API Gateway 통합, DB 세션 관리, 에러 처리 전략에 대한 명확화가 필요합니다.

---

## 질문 범주

### A. Lambda 핸들러 설계

**Q1. Lambda 핸들러 진입점 구조**

Lambda `handler.py`의 진입점 함수 시그니처와 반환 형식을 어떻게 설계해야 하나요?

- **Option A**: API Gateway Lambda Proxy 통합 표준 형식 사용
  ```python
  def lambda_handler(event: dict, context) -> dict:
      # event는 API Gateway proxy event 형식
      # return은 statusCode, headers, body 포함 dict
  ```
- **Option B**: 커스텀 이벤트 래퍼 클래스 사용
  ```python
  def lambda_handler(event: dict, context) -> dict:
      request = ApiGatewayRequest.from_event(event)
      response = process_request(request)
      return response.to_dict()
  ```

**배경**: API Gateway → Lambda 통합 시 event 구조 파싱과 에러 응답 형식의 일관성을 확보해야 합니다.

[Answer]: Option B. API Gateway Lambda Proxy 통합 표준 형식(`proxy=True`, Unit 1 ApiStack에서 이미 설정)을 사용하되, 내부적으로 가벼운 dataclass 래퍼(`TokenRequest`/`TokenResponse`)를 `lambda/models.py`에 정의하여 event 파싱을 캡슐화한다. 테스트 시 event dict를 매번 조립하지 않고 dataclass로 직접 주입 가능하며, 핸들러 본체에서 딥 딕셔너리 접근을 최소화한다. 래퍼는 ultra-thin (변환만, 비즈니스 로직 없음).

---

**Q2. IAM Principal 정보 추출 전략**

API Gateway IAM Auth를 통과한 event에서 사용자 식별자(`identity_store_user_id`)를 추출하는 방법은?

- **Option A**: `event['requestContext']['identity']['userArn']`에서 IAM User ARN 파싱 후 Identity Center User ID 매핑
- **Option B**: `event['requestContext']['authorizer']['claims']`에서 Identity Center principal 정보 직접 추출
- **Option C**: Custom authorizer에서 주입한 `event['requestContext']['authorizer']['userId']` 사용

**배경**: FR-1에서 "IAM Principal에서 사용자 식별자 추출"이 필요하며, Identity Center SSO 사용자를 정확히 식별해야 합니다.

**참고**: System Architecture 문서의 인증 흐름에서는 "API Gateway IAM Auth + SigV4"를 명시하고 있습니다.

[Answer]: Option A. `event['requestContext']['identity']['userArn']`에서 assumed-role ARN을 파싱한다. ARN 형식: `arn:aws:sts::<account>:assumed-role/AWSReservedSSO_<PermissionSet>_<random>/<session-name>`. 마지막 `/` 이후의 session-name을 추출하여 `users.identity_store_user_id` 또는 `users.email`로 조회한다. Identity Center session name 형식이 환경마다 다를 수 있으므로(user_id 또는 이메일), `UserLookupService.resolve_user`에서 다단계 fallback 수행: 1차 identity_store_user_id 조회 → 2차 이메일 조회(session_name에 '@' 포함 시). 파싱 로직은 `lambda/services/user_lookup_service.py`의 `extract_identity_info(event)` 메서드에 격리한다. Option B는 Cognito Authorizer 전용이라 부적합, Option C는 Custom authorizer 추가로 아키텍처 변경이 필요하므로 부적합.

---

**Q3. 요청 본문 파싱 및 검증**

Lambda가 받는 요청 본문(`client_name`, `client_version`, `aws_profile`)의 검증 수준은?

- **Option A**: 필수 필드만 검증 (Pydantic schema 최소 검증)
- **Option B**: 허용 값 범위까지 검증 (예: `client_name`이 'claude-code'인지 확인)
- **Option C**: 검증 없이 모두 optional로 처리

**배경**: API_SPEC.md의 Token Service 요청 본문에는 3개 필드가 있지만, Virtual Key 발급에 필수적인 정보는 아닙니다.

[Answer]: Option C. `client_name`, `client_version`, `aws_profile`은 Virtual Key 발급에 필수 정보가 아니다. 빈 body나 이 필드가 없는 요청도 허용한다. 다만, 제공된 값은 audit_events `payload_json`에 기록하여 추후 분석에 활용한다.

---

### B. 비즈니스 로직 흐름

**Q4. VirtualKeyService.get_or_create_key 상세 흐름**

`get_or_create_key` 메서드의 단계별 로직과 트랜잭션 경계는?

**제안 흐름**:
```
1. UserLookupService.resolve_user(principal_info) → User 조회
2. UserLookupService.validate_user_active(user) → ACTIVE 상태 확인, INACTIVE면 예외
3. VirtualKeyRepository.get_active_by_user(user_id) → 기존 활성 키 조회
4a. 활성 키 존재:
    - KmsHelper.decrypt_key(kms_ciphertext) → 평문 키 복호화
    - last_used_at 갱신
    - AuditEventRepository.create_event(KEY_REUSED)
4b. 활성 키 없음:
    - generate_api_key() → 평문 키 생성 (sk- prefix)
    - KmsHelper.encrypt_key(plaintext) → 암호화
    - KmsHelper.generate_fingerprint(plaintext) → SHA-256
    - VirtualKeyRepository.create(user_id, fingerprint, ciphertext, last4) → 저장
    - AuditEventRepository.create_event(KEY_CREATED)
5. return (user, plaintext_key, key_metadata)
```

**질문**:
- 각 단계별 에러 처리는?
- `last_used_at` 갱신은 별도 트랜잭션인가, 같은 트랜잭션인가?
- `generate_api_key` 형식은? (예: `sk-` + 32바이트 base64 = 약 45자)

[Answer]: 제안 흐름 채택 + 보완. 에러 처리: Step 1 resolve_user 미존재 → UserNotFoundError(403), Step 2 validate_user_active INACTIVE → UserInactiveError(409), Step 3-4 DB/KMS 에러 → InternalError(500). `last_used_at` 갱신은 같은 트랜잭션에서 수행 (Lambda 단발성 요청). `generate_api_key` 형식: API_SPEC.md 예시에 따라 `ak_live_` prefix + `secrets.token_urlsafe(32)` ≈ 51자. KEY_REUSED audit는 기록하지 않음 — audit은 상태 변경(생성/회전/폐기)에만 기록, 매 조회마다 row를 쌓으면 불필요한 데이터 증가, `last_used_at` 갱신으로 마지막 사용 시점 추적 충분.

---

**Q5. UserLookupService 설계**

`resolve_user`와 `validate_user_active`를 별도 메서드로 분리하는 이유와 각각의 책임은?

- **Option A**: 분리
  - `resolve_user`: identity_store_user_id로 User 조회, 미존재 시 예외
  - `validate_user_active`: User.status == ACTIVE 확인, INACTIVE면 예외
- **Option B**: 통합
  - `get_active_user`: 조회 + 검증을 한 번에 수행

**배경**: services.md에는 별도 메서드로 정의되어 있으나, 항상 같이 호출되는지 확인 필요합니다.

[Answer]: Option A (분리). `resolve_user`는 IAM principal → DB User 매핑 단일 책임, `validate_user_active`는 비즈니스 규칙 검증 별도 책임. Unit 4 Gateway에서도 유사 패턴 사용하므로 일관성 유지. 테스트 시 각 메서드 독립 검증 가능. 단, convenience method `get_active_user(principal_info)`도 제공하되 내부적으로 두 메서드를 순차 호출.

---

**Q6. 키 재사용 vs 신규 생성 판단 로직**

활성 키가 이미 존재할 때 무조건 재사용하는지, 아니면 특정 조건(예: 만료 임박)에서 자동 rotate하는지?

- **Option A**: 무조건 재사용 (v1)
- **Option B**: `expires_at`이 7일 이내이면 자동 rotate
- **Option C**: 재사용하되, 응답에 경고 플래그 포함 (예: `"expires_soon": true`)

**배경**: FR-1에서는 "활성 키 존재 시 KMS Decrypt로 원문 재반환"이라고 명시되어 있습니다.

[Answer]: Option A (무조건 재사용, v1). FR-1에서 "활성 키 존재 시 KMS Decrypt로 원문 재반환"으로 명시. v1에서 자동 rotate나 만료 경고는 scope 밖. 키 회전/폐기는 Admin API(AdminVirtualKeyService.rotate_key/revoke_key)를 통해서만 수행. `expires_at`은 v1에서 `null`(무기한).

---

### C. 데이터베이스 세션 관리

**Q7. Lambda DB 세션 전략**

Lambda 함수 내에서 DB 세션을 어떻게 생성하고 관리해야 하나요?

- **Option A**: Lambda 핸들러 함수 시작 시 세션 생성, 종료 시 close (per-invocation session)
- **Option B**: 모듈 레벨에서 engine 생성, 핸들러에서 세션 팩토리 사용
- **Option C**: 컨텍스트 매니저 기반 세션 (`async with`)

**질문**:
- SQLAlchemy async session 사용 시 Lambda에서 권장 패턴은?
- RDS Proxy 연결 시 connection pool 설정은?
- Lambda cold start 최적화를 위해 모듈 레벨 초기화가 필요한가?

[Answer]: Option B + C 혼합. 모듈 레벨에서 `create_async_engine` 생성(warm invocation에서 engine 재사용), 핸들러에서 `async with` 세션 사용(per-invocation session, 리소스 누수 방지). RDS Proxy 연결: `pool_size=1, max_overflow=0` (Lambda는 단일 동시 요청, RDS Proxy가 서버사이드 pooling 담당). `sslmode=require` (system-nfr-decisions.md 6.1 준수). Lambda에서는 `asyncio.run()`으로 async handler를 실행하는 thin sync wrapper를 `lambda_handler`에 둔다.

---

**Q8. 트랜잭션 경계**

`get_or_create_key` 실행 중 트랜잭션 경계는?

- **Option A**: 전체를 단일 트랜잭션으로
  - User 조회 → VirtualKey 조회/생성 → AuditEvent 생성 → commit
- **Option B**: 읽기와 쓰기 트랜잭션 분리
  - 읽기 트랜잭션: User 조회, VirtualKey 조회 → commit
  - 쓰기 트랜잭션: VirtualKey 생성 또는 last_used_at 갱신 + AuditEvent 생성 → commit

**배경**: system-nfr-decisions.md에서 Gateway는 "분리된 트랜잭션" 전략을 사용하지만, Lambda Token Service의 경우는 명시되지 않았습니다.

[Answer]: Option A (단일 트랜잭션). Lambda Token Service는 Gateway와 달리 중간에 장시간 외부 호출(Bedrock)이 없다. KMS 호출은 수십 ms 수준이므로 트랜잭션을 유지해도 문제 없다. 전체 흐름(User 조회 → VirtualKey 조회/생성 → AuditEvent 생성)을 단일 트랜잭션으로 묶어 원자성을 보장. 실패 시 전체 롤백.

---

### D. 에러 처리 및 응답 형식

**Q9. 예외 계층 재사용**

Token Service에서 사용할 예외 계층은 Gateway와 동일하게 `shared/exceptions.py`를 재사용하나요, 아니면 Lambda 전용 예외를 정의하나요?

**예외 시나리오**:
- User 미존재 → `UserNotFoundError` (404)
- User INACTIVE → `UserInactiveError` (403)
- KMS 암호화/복호화 실패 → `InternalError` (500)
- DB 연결 실패 → `InternalError` (500)

**질문**:
- system-nfr-decisions.md 3.2절의 예외 계층을 Lambda에서도 사용하는가?
- Lambda 응답은 Anthropic-compatible 형식이 아니므로, 에러 응답 구조는?

[Answer]: 공유 예외를 `shared/exceptions.py`에 정의하여 Gateway와 Lambda 모두에서 사용. system-nfr-decisions.md 3.2절에서 "Lambda Token Service도 동일 예외 계층 사용 (shared 패키지)"로 명시. Lambda 핸들러 최상위에서 예외를 catch하여 API_SPEC.md 3.3절의 Token Service 에러 포맷으로 변환. 예외 매핑: UserNotFoundError → 403 user_not_synced, UserInactiveError → 409 user_inactive, InternalError → 500 internal_error.

---

**Q10. Lambda 응답 형식**

성공 및 에러 응답의 HTTP status code와 body 구조는?

**성공 응답 (200)**:
```json
{
  "user": {
    "id": "uuid",
    "identity_store_user_id": "...",
    "display_name": "...",
    "email": "...",
    "default_team_id": "uuid or null"
  },
  "virtual_key": {
    "id": "uuid",
    "secret": "sk-...",
    "status": "ACTIVE",
    "issued_at": "ISO8601",
    "expires_at": "ISO8601 or null"
  },
  "proxy": {
    "base_url": "https://proxy.example.com",
    "messages_path": "/v1/messages"
  }
}
```

**에러 응답**:
```json
{
  "error": {
    "code": "user_inactive",
    "message": "User is not active",
    "request_id": "req_...",
    "retryable": false
  }
}
```

**질문**:
- `proxy.base_url`은 환경변수에서 읽어야 하는가?
- 에러 응답에 스택 트레이스를 포함하는가? (민감정보 제외)

[Answer]: API_SPEC.md 4.1절의 형식 그대로 채택. 성공 응답(200): `user` + `virtual_key` + `proxy` 객체. `proxy.base_url`은 환경변수 `PROXY_BASE_URL`에서 읽음, `proxy.messages_path`는 하드코딩 `/v1/messages`. 에러 응답: API_SPEC.md 3.3절 Token Service 에러 포맷(`error.code`, `error.message`, `error.request_id`, `error.retryable`). 스택 트레이스는 절대 포함하지 않음(system-nfr-decisions.md 3.1 준수). `key_last4`는 응답에 미포함(클라이언트가 secret 전체를 받으므로 불필요, Admin API 키 목록 조회 시 마스킹 표시용). Virtual Key prefix: API_SPEC.md 예시에 따라 `ak_live_` 사용.

---

### E. KMS 통합 및 보안

**Q11. KMS 키 관리**

KMS Key ID는 어떻게 Lambda에 전달되나요?

- **Option A**: 환경변수 `KMS_KEY_ID`
- **Option B**: CDK에서 Lambda 함수에 KMS 키 ARN을 환경변수로 주입
- **Option C**: Systems Manager Parameter Store 또는 Secrets Manager에서 런타임에 조회

**배경**: shared/utils/kms.py에서 `os.environ["KMS_KEY_ID"]`를 사용하므로 환경변수 방식이 기본입니다.

[Answer]: Option B (CDK에서 환경변수로 주입). Unit 1 ComputeStack에서 이미 `KMS_KEY_ARN`을 Lambda 환경변수로 주입하고 있다. `shared/utils/kms.py`는 `os.environ["KMS_KEY_ID"]`를 참조하므로, ComputeStack의 환경변수명을 `KMS_KEY_ID`로 변경한다 (KMS API는 ARN도 KeyId 파라미터로 수용).

---

**Q12. Virtual Key 평문 노출 범위**

Virtual Key 평문이 존재하는 시점과 위치는?

**허용**:
- Lambda 응답 body (`virtual_key.secret`)
- Lambda 메모리 내 변수 (KMS decrypt 후)

**금지**:
- CloudWatch Logs
- DB (kms_ciphertext + key_fingerprint만 저장)
- 에러 메시지

**질문**:
- 로그에 키 평문이 실수로 노출되지 않도록 하는 가드레일은?
- `key_last4`는 어디에 사용되나? (응답에 포함되는가?)

[Answer]: 질문에 제시된 허용/금지 범위 그대로 적용. 가드레일: 로깅 시 Virtual Key 평문을 직접 로깅하는 코드 금지(로그에는 key_fingerprint 또는 key_last4만 포함), Lambda 응답 body의 `virtual_key.secret`은 API Gateway → 클라이언트 TLS 채널로만 전달, 예외 메시지에 평문 키 미포함. `key_last4`: DB 저장 + Admin API 키 목록 조회에 사용, Lambda 응답에는 미포함(클라이언트가 전체 secret을 받으므로 불필요).

---

### F. Audit 이벤트 기록

**Q13. Audit 이벤트 종류**

Token Service에서 기록해야 할 audit event 종류는?

**제안**:
- `KEY_ISSUED`: 신규 Virtual Key 생성
- `KEY_REUSED`: 기존 활성 키 재반환
- `KEY_REQUEST_FAILED`: 키 발급 실패 (User INACTIVE, 미동기화 등)
- `USER_LOOKUP_FAILED`: IAM principal에서 사용자 식별 실패

**질문**:
- 각 이벤트의 `payload_json`에 포함할 정보는?
- `actor_type`과 `actor_id`는 무엇으로 설정하나? (예: `actor_type="IAM_PRINCIPAL"`, `actor_id=userArn`)

[Answer]: 최소 2종류만 기록. VIRTUAL_KEY_ISSUED(신규 키 생성 시, payload: client_name/client_version/aws_profile), VIRTUAL_KEY_REQUEST_FAILED(키 발급 실패 시, payload: reason/identity_store_user_id). KEY_REUSED는 불필요(last_used_at 갱신으로 충분), USER_LOOKUP_FAILED는 VIRTUAL_KEY_REQUEST_FAILED에 통합(reason 필드로 구분). actor_type="IAM_PRINCIPAL", actor_id=userArn(전체 ARN). 성공: object_type="VIRTUAL_KEY", object_id=virtual_key.id. 실패: object_type="VIRTUAL_KEY", object_id="N/A".

---

**Q14. Audit 이벤트 기록 시점**

Audit 이벤트는 언제 DB에 저장되나요?

- **Option A**: VirtualKey 생성/갱신과 같은 트랜잭션 (Q8 Option A)
- **Option B**: VirtualKey 트랜잭션 commit 후 별도 트랜잭션
- **Option C**: 비동기 큐 (SQS)로 전송 후 별도 Lambda에서 처리

**배경**: Audit 이벤트 저장 실패가 키 발급 실패로 이어져야 하는지, 아니면 best-effort로 처리해야 하는지 명확화가 필요합니다.

[Answer]: Option A (같은 트랜잭션). Q8에서 단일 트랜잭션을 선택했으므로 VirtualKey 생성과 AuditEvent 생성을 같은 트랜잭션에서 수행. 키가 생성되었는데 audit이 없는 상황을 방지. 실패 audit도 마찬가지 — 실패 처리 경로에서 별도 세션/트랜잭션으로 best-effort 기록하되, audit 저장 실패가 에러 응답을 바꾸지는 않는다.

---

### G. Cold Start 최적화

**Q15. Lambda 초기화 전략**

Lambda cold start 최적화를 위해 모듈 레벨에서 초기화할 것들은?

**후보**:
- SQLAlchemy engine (모듈 레벨)
- boto3 KMS client (shared/utils/kms.py에서 이미 싱글턴)
- Pydantic 스키마 (모듈 레벨 import)

**질문**:
- RDS Proxy 연결 시 Lambda가 재사용될 때 connection이 유지되는가?
- 환경변수 검증은 모듈 레벨에서 한 번만 수행하는가?

[Answer]: 모듈 레벨 초기화 항목: SQLAlchemy async engine(warm invocation에서 engine 재사용), boto3 KMS client(KmsHelper._client 이미 싱글턴), 환경변수 검증(누락 시 import 시점에 즉시 실패), Pydantic 모델(import 캐시). RDS Proxy 연결: warm invocation 시 기존 TCP connection 재사용 가능, RDS Proxy가 유휴 연결 관리하므로 Lambda에서 별도 keepalive 불필요. Secrets Manager에서 DB credentials 조회도 모듈 레벨에서 수행하고 캐싱(credential rotation 시 새 Lambda invocation이 새 값을 가져옴).

---

**Q16. Lambda 환경변수**

Token Service Lambda에 필요한 환경변수 목록은?

**제안**:
- `DATABASE_URL`: RDS Proxy 연결 문자열 (Secrets Manager에서 조회)
- `KMS_KEY_ID`: KMS 키 ARN
- `PROXY_BASE_URL`: Gateway ALB 주소 (응답에 포함)
- `LOG_LEVEL`: 로그 레벨 (기본 INFO)

**질문**:
- `DATABASE_URL`을 환경변수로 직접 주입하는가, 아니면 Secrets Manager ARN을 주입하고 런타임에 조회하는가?
- 추가 필요한 환경변수가 있는가?

[Answer]: 환경변수 목록: DB_SECRET_ARN(CDK 주입, 이미 설정됨, Secrets Manager에서 DB 자격증명 조회), RDS_PROXY_ENDPOINT(CDK 주입, 이미 설정됨, DB 연결 호스트), KMS_KEY_ID(CDK 주입, KMS_KEY_ARN에서 이름 변경, KMS 암복호화), PROXY_BASE_URL(CDK 주입, 신규 추가, 응답의 proxy.base_url), LOG_LEVEL(CDK 주입, 기본 INFO). DATABASE_URL은 직접 주입하지 않음 — DB_SECRET_ARN으로 Secrets Manager에서 런타임 조회하여 구성(system-nfr-decisions.md 4.5 준수).

---

### H. 테스트 전략

**Q17. Lambda 단위 테스트 범위**

Token Service의 단위 테스트 커버리지 목표와 주요 테스트 시나리오는?

**주요 시나리오**:
- 신규 사용자 첫 키 발급
- 기존 사용자 활성 키 재조회
- INACTIVE 사용자 키 발급 거부
- User 미동기화 (identity_store_user_id 미존재) 거부
- KMS 암호화/복호화 실패 처리
- DB 연결 실패 처리

**질문**:
- 고위험 모듈(`VirtualKeyService`)은 90% 이상 커버리지 목표인가? (system-nfr-decisions.md 9.3)
- Mock 전략: DB는 pytest-mock으로, KMS는 boto3 stubber로?

[Answer]: VirtualKeyService는 고위험 모듈이므로 90% 이상 커버리지 목표(system-nfr-decisions.md 9.3 명시). UserLookupService, handler.py는 80% 이상. 주요 시나리오: 신규 사용자 첫 키 발급(성공), 기존 사용자 활성 키 재조회(KMS decrypt 성공), INACTIVE 사용자(409 거부), 미동기화 사용자(403 거부), KMS 암호화/복호화 실패(500), DB 연결 실패(500), 잘못된 request body(정상 처리, optional 필드), IAM principal 파싱 실패(500). Mock 전략: DB는 AsyncSession mock(Repository 레이어를 mock), KMS는 botocore.stub.Stubber 또는 단순 mock. 실제 DB 통합 테스트는 Build & Test 단계에서 수행.

---

**Q18. Property-Based Testing 적용**

Hypothesis를 사용한 property-based testing을 어디에 적용하나요?

**후보**:
- `generate_fingerprint`: 동일 입력은 항상 동일 출력
- `encrypt_key` → `decrypt_key`: 역함수 관계
- Virtual Key 형식 검증: `sk-` prefix + base64 패턴

**질문**:
- Extension A (PBT)가 MANDATORY이므로, Token Service에서 어떤 함수에 적용하는가?
- `tests/strategies.py`에 Virtual Key 생성 strategy를 정의하는가?

[Answer]: 적용 대상: KmsHelper.generate_fingerprint(동일 입력 → 동일 출력, deterministic, strategy: st.text(min_size=1, max_size=200)), generate_api_key(항상 ak_live_ prefix로 시작, 길이 범위 내, URL-safe 문자만 포함, parameterless), IAM ARN 파싱(유효한 ARN → 정상 추출, 잘못된 ARN → 예외, custom ARN strategy). encrypt_key → decrypt_key roundtrip은 실제 KMS 호출이 필요하므로 PBT 대상에서 제외. `tests/strategies.py`에 `virtual_key_strategy`, `iam_arn_strategy` 추가.

---

### I. 통합 및 배포

**Q19. API Gateway 통합 설정**

Token Service Lambda와 API Gateway 통합 시 CDK 설정은?

**확인 필요**:
- API Gateway 엔드포인트: `POST /v1/auth/virtual-key`
- 인증: IAM + SigV4
- Lambda Proxy 통합 vs REST API 통합
- CORS 설정 필요 여부 (Claude Code는 CLI이므로 불필요?)
- Timeout 설정: API Gateway 29초, Lambda 30초?

**질문**:
- Unit 1에서 API Gateway skeleton이 생성되었는가? 아니면 Unit 3에서 보완하는가?
- API Gateway stage 변수 사용 여부 (예: `${stageVariables.lambdaAlias}`)

[Answer]: Unit 1에서 이미 생성 완료 확인: api_stack.py에서 `POST /v1/auth/virtual-key` 리소스 + IAM Auth + Lambda Proxy 통합 설정됨. CORS 불필요(Claude Code는 CLI). Timeout: API Gateway 기본 29초, Lambda 30초(Unit 1에서 설정됨). Unit 3에서 보완할 사항: Lambda code를 from_inline skeleton에서 실제 코드 패키지(from_asset)로 교체, 환경변수에 PROXY_BASE_URL/LOG_LEVEL 추가, KMS_KEY_ARN → KMS_KEY_ID로 환경변수명 변경. Stage 변수는 사용하지 않음(CDK에서 직접 Lambda ARN 참조).

---

**Q20. request_id 전파**

Token Service에서 `request_id`를 어떻게 생성하고 응답 및 로그에 전파하나요?

**제안**:
1. 클라이언트가 `x-request-id` 헤더를 보내면 그대로 사용
2. 없으면 API Gateway `requestContext.requestId`를 fallback으로 사용 (system-nfr-decisions.md 2.4)
3. 둘 다 없으면 Lambda에서 UUID v4 생성

**질문**:
- Lambda 함수 내에서 request_id를 로거에 어떻게 바인딩하나?
- 응답 헤더에 `x-request-id`를 포함하는가?

[Answer]: 제안 흐름 그대로 채택(system-nfr-decisions.md 2.4 준수). 우선순위: 1) 클라이언트 x-request-id 헤더(대소문자 무시), 2) event['requestContext']['requestId'](API Gateway 생성), 3) Lambda에서 uuid4 생성(최후 fallback). 전파: request_id를 logging extra에 바인딩하여 모든 로그에 자동 포함, 응답 headers에 x-request-id 포함, audit_events request_id 필드에 저장, 에러 응답 error.request_id에 포함. 로거: 표준 logging + JSON formatter 사용(structlog는 의존성 대비 이점 크지 않음).

---

## 답변 요약

위 질문에 대한 답변을 다음 형식으로 제공해 주세요:

```markdown
[Answer Q1]: Option A를 선택합니다. API Gateway Lambda Proxy 통합 표준 형식을 사용하여...

[Answer Q2]: Option B를 선택합니다. Identity Center principal 정보는...

...
```

모든 답변 완료. 상태: Answered (2026-04-01)
