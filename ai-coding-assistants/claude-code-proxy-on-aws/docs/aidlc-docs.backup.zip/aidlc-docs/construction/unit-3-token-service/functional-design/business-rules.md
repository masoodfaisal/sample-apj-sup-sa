# Business Rules — Unit 3: Token Service

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Approved
- 근거: [Design Questions](./design-questions.md), [Business Logic Model](./business-logic-model.md), [Unit 2 Business Rules](../../unit-2-shared-models/functional-design/business-rules.md)

---

## 1. 개요

이 문서는 Unit 3 Token Service의 비즈니스 규칙을 정의한다. 사용자 상태 검증, Virtual Key 유일성, 키 재사용 정책, Audit 이벤트 트리거, 보안 규칙, 에러 코드 매핑을 포함한다.

---

## 2. 사용자 상태 검증 규칙

### 2.1 ACTIVE 사용자만 허용

**규칙**: Virtual Key 발급 및 재조회는 `user.status = ACTIVE`인 사용자만 가능하다.

**적용 시점**: `UserLookupService.validate_user_active()` (User 조회 직후)

**위반 시 처리**:
- 예외: `UserInactiveError`
- HTTP status: 409 Conflict
- 에러 코드: `user_inactive`
- Audit 이벤트: `VIRTUAL_KEY_REQUEST_FAILED` (reason: "UserInactiveError")

**관련 비즈니스 규칙** (Unit 2 Business Rules 1.1):
```
[생성] → INACTIVE
INACTIVE → ACTIVE    (Admin 명시적 활성화)
ACTIVE → INACTIVE    (Admin 비활성화 또는 source 삭제 판정)
```

**근거**:
- 신규 sync 사용자는 항상 `INACTIVE`로 생성 (Unit 2)
- `ACTIVE` 전환은 Admin API를 통해서만 가능 (Unit 4)
- source 삭제 판정 시 `INACTIVE` 전환 + `source_deleted_at` 기록 (IdentitySyncService)

---

### 2.2 사용자 미존재 처리

**규칙**: IAM Principal에서 추출한 identity_info로 User를 찾을 수 없으면 키 발급을 거부한다.

**적용 시점**: `UserLookupService.resolve_user()` (다단계 fallback 후)

**다단계 fallback 순서**:
1. `users.identity_store_user_id = identity_info` 조회
2. identity_info에 `@` 포함 시 `users.email = identity_info` 조회
3. 둘 다 미존재: `UserNotFoundError` 발생

**위반 시 처리**:
- 예외: `UserNotFoundError`
- HTTP status: 403 Forbidden
- 에러 코드: `user_not_synced`
- Audit 이벤트: `VIRTUAL_KEY_REQUEST_FAILED` (reason: "UserNotFoundError")

**근거**:
- Identity Center 사용자가 DB에 동기화되지 않은 경우
- Identity Center session name 형식이 환경마다 다를 수 있음 (user_id 또는 이메일)

---

## 3. Virtual Key 유일성 규칙

### 3.1 사용자당 활성 키 최대 1개

**규칙**: 동일 사용자의 `ACTIVE` 상태 VirtualKey는 최대 1개만 존재한다.

**적용 수단**:
1. Application 레벨: `VirtualKeyService.get_or_create_key()`에서 활성 키 조회 후 존재 시 신규 생성하지 않음
2. Database 레벨: partial unique index `unique(user_id) WHERE status = 'ACTIVE'`

**위반 시 처리**:
- Application 레벨: 활성 키가 이미 있으면 재사용 경로로 분기 (신규 생성 시도하지 않음)
- Database 레벨: unique constraint violation (최후 안전장치)

**관련 DB 제약** (Unit 2 Domain Entities 3.4):
```
virtual_keys:
  제약: unique(key_fingerprint), partial unique(user_id) WHERE status = 'ACTIVE'
```

---

### 3.2 Fingerprint 유일성

**규칙**: `key_fingerprint` (SHA-256 hash)는 전체 시스템에서 유일해야 한다.

**적용 수단**:
- Database 레벨: `unique(key_fingerprint)` 제약

**충돌 가능성**:
- SHA-256 충돌 확률: 사실상 0 (2^128 공간)
- `secrets.token_urlsafe(32)` 중복 확률: 사실상 0 (2^192 엔트로피)

**위반 시 처리**:
- DB unique constraint violation (이론적으로 발생하지 않음)
- 발생 시 `InternalError` (500)

---

## 4. 키 재사용 정책

### 4.1 v1: 무조건 재사용

**규칙**: 활성 VirtualKey가 이미 존재하면 무조건 재사용한다. 신규 키를 생성하지 않는다.

**적용 시점**: `VirtualKeyService._reuse_existing_key()`

**재사용 동작**:
1. KMS decrypt로 평문 복호화
2. `last_used_at` 갱신
3. 평문 키 + metadata 반환

**Audit 이벤트**: 없음 (키 재사용은 상태 변경이 아니므로 audit 미기록, `last_used_at` 갱신으로 충분)

**예외 케이스**: 없음 (v1에서 자동 rotate/만료 경고 등 추가 로직 없음)

**근거** (Q6):
- FR-1에서 "활성 키 존재 시 KMS Decrypt로 원문 재반환"으로 명시
- v1에서 자동 rotate나 만료 경고는 scope 밖
- 키 회전/폐기는 Admin API(AdminVirtualKeyService.rotate_key/revoke_key)를 통해서만 수행

---

### 4.2 키 회전 및 폐기

**규칙**: 키 회전(rotate)과 폐기(revoke)는 Admin API를 통해서만 수행할 수 있다. Token Service는 읽기 전용이다.

**Token Service 책임**: 없음 (읽기 및 발급만)

**Admin API 책임** (Unit 4):
- `POST /v1/admin/virtual-keys/{keyId}/rotate`: 기존 키를 `ROTATED` 상태로 전환, 신규 `ACTIVE` 키 생성
- `POST /v1/admin/virtual-keys/{keyId}/revoke`: 키를 `REVOKED` 상태로 전환

**상태 전이 규칙** (Unit 2 Business Rules 1.3):
```
[생성] → ACTIVE
ACTIVE → REVOKED     (Admin 폐기)
ACTIVE → ROTATED     (Admin 회전 — 기존 키)
ACTIVE → EXPIRED     (만료 시각 도달)
```

**v1에서 `expires_at`**: `null` (무기한)

---

## 5. Audit 이벤트 규칙

### 5.1 VIRTUAL_KEY_ISSUED (신규 키 생성 시)

**트리거**: `VirtualKeyService._create_new_key()` 성공 시

**이벤트 속성**:
```json
{
  "event_type": "VIRTUAL_KEY_ISSUED",
  "actor_type": "IAM_PRINCIPAL",
  "actor_id": "arn:aws:sts::123456789012:assumed-role/...",
  "object_type": "VIRTUAL_KEY",
  "object_id": "6d071d24-1656-4f1b-b0a8-4d8429ff0fd4",
  "request_id": "req_01JQ...",
  "payload_json": {
    "client_name": "claude-code",
    "client_version": "1.0.0",
    "aws_profile": "company-dev"
  }
}
```

**기록 시점**: VirtualKey 생성과 같은 트랜잭션 (Q14)

**payload 내용**:
- `client_name`, `client_version`, `aws_profile`: 요청 본문의 optional 필드 (제공된 경우만 기록)

---

### 5.2 VIRTUAL_KEY_REQUEST_FAILED (키 발급 실패 시)

**트리거**:
- `UserNotFoundError` (사용자 미존재)
- `UserInactiveError` (사용자 INACTIVE)
- `InternalError` (KMS/DB 에러)

**이벤트 속성**:
```json
{
  "event_type": "VIRTUAL_KEY_REQUEST_FAILED",
  "actor_type": "IAM_PRINCIPAL",
  "actor_id": "arn:aws:sts::123456789012:assumed-role/..." or "UNKNOWN",
  "object_type": "VIRTUAL_KEY",
  "object_id": "N/A",
  "request_id": "req_01JQ...",
  "payload_json": {
    "reason": "UserInactiveError",
    "identity_info": "user-1234"          // raw 식별자 (ARN session-name 또는 이메일)
  }
}
```

**기록 시점**: 별도 세션/트랜잭션에서 best-effort 기록 (Q14)

**best-effort 의미**:
- audit 저장 실패가 에러 응답을 바꾸지 않음
- 이미 실패한 요청이므로 audit 누락이 critical하지 않음

**actor_id fallback**:
- IAM ARN 추출 성공 시: 전체 ARN
- 추출 실패 시: `"UNKNOWN"`

---

### 5.3 Audit 이벤트 제외 케이스

**KEY_REUSED**: 기록하지 않음 (Q13)
- 이유: 키 재사용은 상태 변경이 아님
- `last_used_at` 갱신으로 마지막 사용 시점 추적 충분
- 매 조회마다 audit row를 쌓으면 불필요한 데이터 증가

**USER_LOOKUP_FAILED**: `VIRTUAL_KEY_REQUEST_FAILED`에 통합 (Q13)
- reason 필드로 구분: `"UserNotFoundError"` vs `"UserInactiveError"`

---

## 6. 보안 규칙

### 6.1 Virtual Key 평문 노출 제한

**허용 위치**:
- Lambda 응답 body (`virtual_key.secret`)
- Lambda 메모리 내 변수 (KMS decrypt 후)

**금지 위치**:
- CloudWatch Logs
- DB (kms_ciphertext + key_fingerprint만 저장)
- 에러 메시지
- Audit payload

**가드레일** (Q12):
- 로깅 시 Virtual Key 평문을 직접 로깅하는 코드 금지
- 로그에는 `key_fingerprint` 또는 `key_last4`만 포함
- Lambda 응답 body의 `virtual_key.secret`은 API Gateway → 클라이언트 TLS 채널로만 전달
- 예외 메시지에 평문 키 미포함

**코드 예시**:
```python
# ✅ GOOD: 로그에 fingerprint만 포함
logger.info("Created new virtual key", extra={"key_fingerprint": key_fingerprint})

# ❌ BAD: 평문 키 로깅
logger.info(f"Created key: {plaintext_key}")  # 절대 금지
```

---

### 6.2 KMS 암호화 필수

**규칙**: Virtual Key 평문은 반드시 KMS로 암호화하여 DB에 저장한다. 평문으로 DB에 저장해서는 안 된다.

**적용 수단**:
- `VirtualKeyService._create_new_key()`에서 `KmsHelper.encrypt_key()` 호출 (신규 키 생성 시)
- DB에는 `kms_ciphertext` + `key_fingerprint` + `key_last4`만 저장

**KMS 키 관리**:
- KMS 키 ID는 환경변수 `KMS_KEY_ID`로 주입 (CDK에서 설정)
- 모든 Virtual Key는 동일 KMS 키 사용

**IAM 권한** (system-nfr-decisions.md 4.4):
- Lambda 실행 역할: KMS Encrypt/Decrypt (특정 키)
- ECS Admin 경로: KMS Encrypt (rotate 시 신규 키 생성용, Unit 4에서 구현)

---

### 6.3 DB 접속 자격증명 보호

**규칙**: DB 접속 자격증명은 Secrets Manager에서 런타임에 조회한다. 환경변수에 평문으로 주입하지 않는다.

**적용 수단**:
- 환경변수: `DB_SECRET_ARN` (Secrets Manager ARN)
- `get_database_url()` (모듈 레벨): Secrets Manager에서 username/password 조회하여 connection string 구성
- 캐싱: 모듈 레벨 초기화로 warm invocation에서 재사용

**TLS 연결** (system-nfr-decisions.md 6.1):
- `connect_args={"ssl": True}` (SQLAlchemy async engine)

---

## 7. 에러 코드 매핑

### 7.1 예외 → HTTP Status + 에러 코드

| 예외 클래스 | HTTP Status | 에러 코드 | retryable |
|-------------|-------------|-----------|-----------|
| `UserNotFoundError` | 403 Forbidden | `user_not_synced` | false |
| `UserInactiveError` | 409 Conflict | `user_inactive` | false |
| `InternalError` | 500 Internal Server Error | `internal_error` | false |
| (기타 미처리 예외) | 500 Internal Server Error | `internal_error` | false |

**에러 응답 형식** (API_SPEC.md 3.3):
```json
{
  "error": {
    "code": "user_inactive",
    "message": "User is not active",
    "request_id": "req_01JQ...",
    "retryable": false
  }
}
```

**retryable 정책**:
- v1에서 모든 에러는 `retryable: false`
- Claude Code 클라이언트가 자체 재시도 로직 소유

---

### 7.2 예외 정의 (shared/exceptions.py)

**공유 예외 계층** (Q9):
```python
# shared/exceptions.py

class AppError(Exception):
    """Base application error."""
    pass

class AuthenticationError(AppError):
    """Authentication failed."""
    pass

class InvalidKeyError(AuthenticationError):
    """Virtual Key invalid or not found."""
    pass

class KeyRevokedError(AuthenticationError):
    """Virtual Key revoked."""
    pass

class AuthorizationError(AppError):
    """Authorization failed."""
    pass

class UserNotFoundError(AuthorizationError):
    """User not found in DB."""
    pass

class UserInactiveError(AuthorizationError):
    """User status is not ACTIVE."""
    pass

class InternalError(AppError):
    """Internal server error."""
    pass
```

**사용 위치**:
- Unit 3 (Token Service): `UserNotFoundError`, `UserInactiveError`, `InternalError`
- Unit 4 (Gateway): 전체 예외 계층 사용

---

## 8. 요청 본문 검증 규칙

### 8.1 모든 필드 optional

**규칙**: `client_name`, `client_version`, `aws_profile` 필드는 모두 optional이다. 빈 body나 이 필드가 없는 요청도 허용한다.

**검증 수준** (Q3): 없음 (필수 필드 검증하지 않음)

**사용 용도**:
- 제공된 값은 audit_events `payload_json`에 기록
- Virtual Key 발급 로직에는 영향 없음

**코드 예시**:
```python
@dataclass
class TokenRequest:
    """Token Service 요청."""
    client_name: Optional[str] = None
    client_version: Optional[str] = None
    aws_profile: Optional[str] = None
    user_arn: Optional[str] = None  # IAM ARN (internal)
    request_id: Optional[str] = None  # request_id (internal)
    
    @classmethod
    def from_event(cls, event: dict) -> "TokenRequest":
        """API Gateway event에서 TokenRequest 생성."""
        body = event.get("body")
        data = json.loads(body) if body else {}
        
        return cls(
            client_name=data.get("client_name"),
            client_version=data.get("client_version"),
            aws_profile=data.get("aws_profile")
        )
```

---

## 9. 트랜잭션 규칙

### 9.1 단일 트랜잭션 경계

**규칙**: User 조회 → VirtualKey 생성/갱신 → AuditEvent 기록을 단일 트랜잭션에서 수행한다.

**적용 수단** (Q8):
```python
async with AsyncSession(engine) as session:
    async with session.begin():
        # User 조회
        user = await UserLookupService.get_active_user(session, identity_info)
        
        # VirtualKey 생성 또는 갱신
        virtual_key = ...
        
        # AuditEvent 기록
        audit_event = ...
        session.add(audit_event)
        
        # 암묵적 commit (트랜잭션 종료)
```

**이점**:
- 원자성: VirtualKey 생성 실패 시 AuditEvent도 롤백
- 일관성: 키가 생성되었는데 audit이 없는 상황 방지

**KMS 호출과 트랜잭션** (Q8):
- KMS 호출은 수십 ms 수준이므로 트랜잭션 유지해도 문제 없음
- Gateway와 달리 중간에 장시간 외부 호출(Bedrock) 없음

---

### 9.2 실패 Audit 기록 (별도 트랜잭션)

**규칙**: 키 발급 실패 시 audit 이벤트는 별도 세션/트랜잭션에서 best-effort로 기록한다.

**적용 수단** (Q14):
```python
# async_handler의 except 블록
except UserInactiveError as e:
    # 별도 세션에서 audit 기록 (best-effort)
    await record_failure_audit(identity_info, user_arn, request_id, "UserInactiveError")
    
    # 에러 응답 반환
    return handle_error(409, "user_inactive", str(e), request_id, False)
```

**best-effort 의미**:
- audit 저장 실패가 에러 응답을 바꾸지 않음
- 이미 실패한 요청이므로 audit 누락이 critical하지 않음
- 실패는 로그로 기록

---

## 10. 환경변수 검증 규칙

### 10.1 필수 환경변수

**규칙**: 다음 환경변수가 누락되면 Lambda import 시점에 즉시 실패한다.

**필수 환경변수** (Q16):
- `DB_SECRET_ARN`: Secrets Manager ARN (DB 자격증명)
- `RDS_PROXY_ENDPOINT`: RDS Proxy 엔드포인트
- `KMS_KEY_ID`: KMS 키 ARN (암복호화)
- `PROXY_BASE_URL`: Gateway ALB 주소 (응답에 포함)

**선택 환경변수**:
- `LOG_LEVEL`: 로그 레벨 (기본값 `INFO`, 누락 시 기본값 사용)

**검증 시점**: 모듈 레벨 (import 시)

**코드 예시**:
```python
# lambda/core/config.py

REQUIRED_ENV_VARS = [
    "DB_SECRET_ARN",
    "RDS_PROXY_ENDPOINT",
    "KMS_KEY_ID",
    "PROXY_BASE_URL",
]

for var in REQUIRED_ENV_VARS:
    if var not in os.environ:
        raise RuntimeError(f"Missing required environment variable: {var}")
```

**이점**: 잘못된 설정으로 Lambda가 배포되면 첫 invocation에서 즉시 실패 (명확한 에러 메시지). `LOG_LEVEL`은 기본값이 있으므로 필수가 아님 — 로컬 테스트에서도 누락 시 정상 동작.

---

## 11. Cold Start 최적화 규칙

### 11.1 모듈 레벨 초기화 항목

**규칙**: 다음 항목은 모듈 레벨에서 초기화하여 warm invocation에서 재사용한다.

**초기화 항목** (Q15):
1. SQLAlchemy async engine
2. boto3 KMS client (KmsHelper._client 싱글턴)
3. 환경변수 검증
4. Secrets Manager에서 DB credentials 조회 및 캐싱

**cold start 시간 단축**:
- Engine 초기화, KMS client 초기화, Secrets Manager 조회는 첫 invocation에만 수행
- Warm invocation은 기존 초기화 결과 재사용

**credential rotation 대응**:
- Secrets Manager credential rotation 시 새 Lambda invocation이 새 값을 가져옴
- 기존 warm container는 이전 credentials 사용 (rotation 완료 후 점진적 교체)

---

## 12. 로깅 규칙

### 12.1 구조화된 JSON 로깅

**규칙**: 모든 로그는 CloudWatch Logs Insights 호환 JSON 형식으로 출력한다.

**필수 필드** (system-nfr-decisions.md 2.1):
- `timestamp`: ISO 8601 UTC
- `level`: DEBUG, INFO, WARNING, ERROR, CRITICAL
- `message`: 로그 메시지
- `request_id`: 요청 식별자

**추가 필드** (선택):
- `user_id`: 사용자 UUID
- `virtual_key_id`: Virtual Key UUID
- `key_fingerprint`: SHA-256 fingerprint

**금지 필드**:
- `virtual_key_secret`: 평문 키 (절대 로깅 금지)
- `kms_ciphertext`: KMS ciphertext (로깅 금지)

---

### 12.2 로그 레벨 정책

| 레벨 | 사용 시나리오 |
|------|---------------|
| DEBUG | IAM ARN 파싱 상세, User 조회 경로 상세 |
| INFO | 요청 수신, 키 발급 성공, 키 재사용 |
| WARNING | 사용자 미존재, 사용자 INACTIVE, audit 저장 실패 |
| ERROR | KMS 에러, DB 에러, IAM ARN 파싱 실패 |
| CRITICAL | 미사용 |

**환경변수 제어**: `LOG_LEVEL` (기본 INFO)

---

## 13. 테스트 규칙

### 13.1 커버리지 목표

**규칙** (Q17):
- VirtualKeyService: 90% 이상 (고위험 모듈)
- UserLookupService, handler.py: 80% 이상

**CI 강제**: pytest --cov, 커버리지 미달 시 빌드 실패

---

### 13.2 Property-Based Testing

**규칙** (Q18): 다음 함수에 Hypothesis property-based testing 적용

**적용 대상**:
1. `KmsHelper.generate_fingerprint`: 동일 입력 → 동일 출력 (deterministic)
2. `generate_api_key`: 항상 `sk-` prefix, 길이 범위 내, URL-safe 문자만
3. IAM ARN 파싱: 유효한 ARN → 정상 추출, 잘못된 ARN → 예외

**strategy 정의**: `tests/strategies.py`
```python
# tests/strategies.py

from hypothesis import strategies as st

# Virtual Key strategy
virtual_key_strategy = st.text(
    alphabet=st.characters(
        whitelist_categories=("Lu", "Ll", "Nd"),
        whitelist_characters="-_"
    ),
    min_size=51,
    max_size=51
)

# IAM ARN strategy
iam_arn_strategy = st.one_of(
    # Valid ARN
    st.builds(
        lambda session_name: f"arn:aws:sts::123456789012:assumed-role/AWSReservedSSO_Dev_abc123/{session_name}",
        st.text(min_size=1, max_size=64, alphabet=st.characters(blacklist_categories=("Cs",)))
    ),
    # Invalid ARN
    st.text(min_size=0, max_size=100)
)
```

---

## 14. NFR 준수 체크리스트

| NFR 항목 | 비즈니스 규칙 |
|----------|---------------|
| 인증 (1.1) | API Gateway IAM Auth + SigV4 (Unit 1에서 설정) |
| 인가 (1.2) | ACTIVE 사용자만 허용 (UserLookupService.validate_user_active) |
| 로깅 (2.1) | 구조화된 JSON 로그, 평문 키 미포함 |
| Request ID (2.4) | 클라이언트 헤더 → API Gateway → Lambda 생성 |
| 에러 응답 (3.1) | Token Service 전용 포맷 (user_not_synced, user_inactive, internal_error) |
| 예외 계층 (3.2) | shared/exceptions.py 공유 예외 |
| 저장 암호화 (4.1) | KMS 암호화 필수, 평문 미저장 |
| 전송 암호화 (4.2) | API Gateway TLS 1.2+ |
| 민감 데이터 (4.5) | 평문 키 로그 금지, Secrets Manager credentials |
| DB 기술 (6.1) | Aurora Serverless v2 + RDS Proxy, TLS |
| 트랜잭션 (6.4) | 단일 트랜잭션 (User → VirtualKey → AuditEvent) |
| 테스트 (9.1-9.3) | 80-90% 커버리지, property-based testing |

---

## 15. 규칙 위반 시 처리 요약

| 규칙 | 위반 시 처리 | HTTP Status | 에러 코드 |
|------|-------------|-------------|-----------|
| ACTIVE 사용자만 허용 | UserInactiveError | 409 | user_inactive |
| 사용자 미존재 | UserNotFoundError | 403 | user_not_synced |
| 활성 키 유일성 | 재사용 경로 분기 (신규 생성 금지) | N/A | N/A |
| Fingerprint 유일성 | DB unique constraint violation | 500 | internal_error |
| KMS 암호화 필수 | Application 레벨 강제 (신규 키 생성 시) | N/A | N/A |
| 평문 키 로그 금지 | Code review + 테스트 검증 | N/A | N/A |
| 환경변수 누락 | 모듈 import 시 RuntimeError | N/A | N/A |
| 트랜잭션 원자성 | Context manager 자동 rollback | 500 | internal_error |

---

## 16. 구현 체크리스트

- [ ] UserLookupService.validate_user_active() — ACTIVE 검증
- [ ] UserLookupService.resolve_user() — 다단계 fallback
- [ ] VirtualKeyService.get_or_create_key() — 활성 키 조회 후 재사용/신규 생성 분기
- [ ] VirtualKeyService._reuse_existing_key() — last_used_at 갱신, audit 없음
- [ ] VirtualKeyService._create_new_key() — KMS 암호화, audit 기록
- [ ] generate_api_key() — shared/utils/hashing.py 재사용 (sk- prefix)
- [ ] KmsHelper.encrypt_key() — KMS 암호화
- [ ] KmsHelper.generate_fingerprint() — SHA-256
- [ ] handle_error() — Token Service 에러 포맷
- [ ] record_failure_audit() — 실패 audit (best-effort)
- [ ] get_database_url() — Secrets Manager credentials 조회
- [ ] JSONFormatter — 구조화된 JSON 로그
- [ ] 환경변수 검증 — 모듈 레벨 (lambda/core/config.py)
- [ ] tests/strategies.py — Hypothesis strategies (virtual_key_strategy, iam_arn_strategy)
- [ ] tests/test_virtual_key_service.py — 90% 커버리지
- [ ] tests/test_user_lookup_service.py — 80% 커버리지
- [ ] tests/test_utils.py — property-based testing
