# 시스템 전체 NFR 결정 사항

본 문서는 CONSTRUCTION phase의 모든 유닛에 공통 적용되는 비기능 요구사항 및 기술 결정을 정의한다.
per-unit NFR 분석 시 반드시 본 문서를 먼저 확인해야 한다.

**최종 수정**: 2026-04-01T00:00:00Z
**적용 유닛**: Unit 1 (Foundation Infrastructure), Unit 2 (Shared Models & DB Migration), Unit 3 (Token Service), Unit 4 (Gateway)

---

## 1. 인증 및 인가

### 1.1 인증 전략

**결정**: 이중 인증 전략
- **Virtual Key (x-api-key)** — Gateway Runtime API (`POST /v1/messages`, `GET /v1/models`)
- **AWS SigV4** — Token Service 및 Admin API

**근거**:
- Virtual Key는 Claude Code 클라이언트에서 AWS 자격증명 설정 없이 사용 가능
- SigV4는 AWS SSO ID 기반의 안전하고 감사 가능한 관리 작업 접근 보장
- 런타임 트래픽은 단순 bearer 스타일 인증, 관리 트래픽은 AWS 네이티브 ID 사용

**적용 대상**:
- Unit 3 (Token Service): API Gateway IAM Auth를 통한 SigV4 검증
- Unit 4 (Gateway Runtime): x-api-key 헤더를 통한 Virtual Key 검증
- Unit 4 (Admin API): API Gateway IAM Auth를 통한 SigV4 검증

**제약사항**:
- Virtual Key는 반드시 KMS로 암호화 저장 (5.1절 참조)
- Virtual Key 검증 시 SHA-256 fingerprint 비교를 통한 상수 시간 조회 사용
- 매 요청마다 Virtual Key 상태 확인 (ACTIVE만 허용)
- SigV4 검증 시 IAM principal 정보 추출하여 사용자 식별
- Admin API는 Virtual Key 인증 수락 불가
- Runtime API는 SigV4 인증 수락 불가

**준수 수준**: MANDATORY

---

### 1.2 인가 전략

**결정**: 계층적 정책 평가 기반 RBAC
- **사용자 override** > **팀 정책** > **시스템 기본 정책**
- 10단계 정책 체인 (Chain of Responsibility 패턴)으로 집행
- team-less 사용자 허용, 시스템 기본값으로 fallback

**적용 대상**: Unit 4 (Gateway Runtime — PolicyChain)

**제약사항**:
- PolicyChain 핸들러 실행 순서 고정: VirtualKey → UserStatus → TeamStatus → ModelResolver → UserModelPolicy → TeamModelPolicy → UserBudgetPreCheck → TeamBudgetPreCheck → ModelBudgetPreCheck → CachePolicy
- 각 핸들러는 fail-closed (정책 위반 시 예외 발생)
- hard budget limit 초과 시 즉시 차단
- soft budget limit 도달 시 PolicyContext.warnings에 경고 추가, 요청은 계속 진행
- team-less 사용자는 시스템 기본 정책으로 fallback (팀 정책 미적용)
- 모든 인가 실패는 audit_events에 기록

**준수 수준**: MANDATORY

---

## 2. 관측성 (로깅, 메트릭, 트레이싱)

### 2.1 로깅 형식

**결정**: CloudWatch Logs Insights 호환 구조화된 JSON 로깅

**적용 대상**: 전체 유닛 (Unit 1 CloudWatch 로그 그룹, Unit 3-4 애플리케이션 로깅)

**제약사항**:
- 모든 로그 항목은 유효한 JSON 객체
- 필수 필드: `timestamp` (ISO 8601), `level`, `message`, `request_id`
- 런타임 요청 로그 필수 필드: `user_id`, `team_id` (nullable), `resolved_model_id`, `status`, `latency_ms`, `estimated_cost_usd`
- 로그에 포함 금지: 프롬프트/응답 본문, Virtual Key 평문, KMS ciphertext
- 민감 필드 마스킹 (예: 키 fingerprint 부분 노출만)
- 로그 레벨은 환경변수로 설정 가능 (기본값: INFO)

**준수 수준**: MANDATORY

---

### 2.2 메트릭 전략

**결정**: OpenTelemetry SDK + ADOT Collector sidecar + Amazon Managed Prometheus (AMP)

**적용 대상**: Unit 1 (AMP workspace, ADOT sidecar 정의), Unit 4 (MetricsService)

**제약사항**:
- OTel SDK는 cumulative temporality 사용 (prometheusremotewrite exporter 요구사항)
- OTLP gRPC로 localhost:4317에 push
- ADOT Collector는 ECS sidecar로 실행 (별도 서비스 아님)
- AMP로 VPC Endpoint (aps-workspaces) 경유 export
- 3개 primary metric 반드시 emit (아래 2.2.1절 참조)
- 메트릭은 usage_events DB 저장 성공 후 emit
- BLOCKED_BUDGET, BLOCKED_POLICY 요청은 Bedrock 호출이 없으므로 metric emit 안 함
- 메트릭 emit 실패 시 로그 기록하되 요청 실패시키지 않음

**준수 수준**: MANDATORY

#### 2.2.1 Primary Metric 사양

3개 primary metric (FR-9):

1. **`bedrock.token.usage`**
   - Instrument: Counter | Unit: tokens
   - Value source: `input_tokens`, `output_tokens`, `cached_read_tokens`, `cached_write_tokens`
   - Emit 규칙: token count > 0인 경우만, token type별 개별 emit
   - 필수 attribute: `user_id`, `team_id`, `model_id`, `status`, `stream`, `token_type` (input|output|cache_read|cache_write)

2. **`bedrock.cost.usage`**
   - Instrument: Counter | Unit: USD
   - Value source: `estimated_cost_usd`
   - Emit 규칙: cost > 0인 경우만
   - 필수 attribute: `user_id`, `team_id`, `model_id`, `status`, `stream`

3. **`bedrock.request.duration`**
   - Instrument: Histogram | Unit: ms
   - Value source: Bedrock `metrics.latencyMs`
   - Emit 규칙: Bedrock 호출이 실제 수행되어 latency가 있는 경우만
   - 필수 attribute: `user_id`, `team_id`, `model_id`, `status`, `stream`

**Attribute 정의**:
- `model_id`: 실제 Bedrock model ID 문자열 (DB FK 아님)
- `status`: SUCCESS | ERROR | BLOCKED_BUDGET | BLOCKED_POLICY
- `stream`: boolean (ConverseStream=true, Converse=false)
- 선택 attribute: `aws_region`, `service_tier`, `stop_reason`
- `request_id`, `bedrock_invocation_id`, `virtual_key_id`, `budget_policy_id`, `cache_details_json`은 DB/로그 전용 (metric attribute 아님)

---

### 2.3 분산 트레이싱

**결정**: OTel SDK로 계측 준비, X-Ray export는 post-v1로 연기

**제약사항**:
- v1에서 OTel SDK 초기화하되 tracing export는 비활성화
- request_id를 로그 상관관계에 사용 (v1에서 trace ID 사용하지 않음)
- ADOT Collector 설정에 X-Ray exporter placeholder 포함 (주석 처리)
- per-unit 구현에서 커스텀 트레이싱 솔루션 도입 금지

**준수 수준**: RECOMMENDED (v1에서 구현 연기)

---

### 2.4 Request ID 전략

**결정**: UUID v4, 클라이언트 미제공 시 서버 생성

**적용 대상**: Unit 4 (Gateway Runtime, Admin API)

**제약사항**:
- Gateway는 `x-request-id` 헤더 확인 (대소문자 구분 없음)
- 미제공 시 UUID v4 생성 후 `x-request-id` 응답 헤더에 설정
- request_id는 해당 요청의 모든 로그 항목에 포함
- usage_events 테이블에 저장
- 응답 `x-request-id` 헤더로 클라이언트에 반환
- Lambda Token Service도 `x-request-id`를 우선 사용하고, 없으면 API Gateway `requestContext.requestId`를 fallback으로 사용

**준수 수준**: MANDATORY

---

### 2.5 Health Check 규약

**결정**: 단일 `/healthz` 엔드포인트

**적용 대상**: Unit 4 (Gateway Runtime)

**제약사항**:
- 엔드포인트: `GET /healthz` (다른 이름 사용 금지)
- 정상 시 200 OK, 비정상 시 503 Service Unavailable
- DB 커넥션 풀 가용성만 확인
- Bedrock API 호출, 복잡한 쿼리, DB 외 외부 의존성 확인 금지
- ALB health check: 30초 간격, unhealthy threshold 2, healthy threshold 2 (Unit 1 설정)

**준수 수준**: MANDATORY

---

## 3. 에러 처리 및 응답 형식

### 3.1 에러 응답 형식

**결정**: Runtime API 전체에 Anthropic 호환 에러 응답 형식 적용

**적용 대상**: Unit 4 (Gateway Runtime)

**제약사항**:
- Runtime API 에러는 반드시 다음 JSON 구조 반환:
  ```json
  {
    "type": "error",
    "error": {
      "type": "<error_type>",
      "message": "<사람이 읽을 수 있는 메시지>"
    }
  }
  ```
- Admin API는 단순 에러 형식 사용 가능 (Anthropic 호환 불필요)
- 에러 메시지에 포함 금지: 내부 스택 트레이스, DB 스키마 상세, AWS 리소스 ARN

**준수 수준**: MANDATORY

---

### 3.2 예외 계층 구조

**결정**: 도메인별 커스텀 예외 클래스 계층

**적용 대상**: Unit 4 (Gateway core/exceptions.py)

**제약사항**:
- 모든 애플리케이션 예외는 `AppError` 기반 클래스 상속
- 예외 계층:
  ```
  AppError (base)
  +-- AuthenticationError
  |   +-- InvalidKeyError          -> 401, authentication_error
  |   +-- KeyRevokedError          -> 401, authentication_error
  +-- AuthorizationError
  |   +-- UserInactiveError        -> 403, permission_error
  |   +-- TeamInactiveError        -> 403, permission_error
  |   +-- ModelNotAllowedError     -> 403, permission_error
  +-- BudgetExceededError          -> 403, permission_error
  +-- UpstreamError
  |   +-- BedrockError             -> 502, api_error
  |   +-- BedrockThrottlingError   -> 429, rate_limit_error
  +-- ValidationError              -> 400, invalid_request_error
  +-- InternalError                -> 500, api_error
  ```
- soft budget limit 경고는 예외 사용 금지 (PolicyContext.warnings 리스트 사용)
- 미처리 예외는 FastAPI 전역 핸들러에서 500 Internal Error로 처리
- Lambda Token Service도 동일 예외 계층 사용 (shared 패키지)

**준수 수준**: MANDATORY

---

### 3.3 재시도 정책

**결정**: Bedrock 애플리케이션 레이어 재시도 없음, boto3 `max_attempts=1` (adaptive mode 비활성화)

**근거**:
- Claude Code 클라이언트에 자체 재시도 로직 있음
- 즉시 에러 전파로 지연 시간 누적 방지
- 스트리밍 시나리오에서 adaptive retry의 예측 불가능한 지연 방지

**적용 대상**: Unit 4 (Gateway Runtime — BedrockClient)

**제약사항**:
- boto3 Bedrock 클라이언트: `max_attempts=1`
- retry mode: `standard` (adaptive 아님)
- Bedrock API 에러는 애플리케이션 레이어 재시도 없이 즉시 클라이언트에 전파
- 일시적 AWS 서비스 에러(throttling, 5xx)도 클라이언트에 반환하여 client-side retry 위임

**준수 수준**: MANDATORY

---

## 4. 보안 표준

### 4.1 저장 시 암호화

**결정**:
- Virtual Key 평문: KMS 암호화
- 데이터베이스: Aurora 기본 암호화 (AWS 관리형 RDS 키)
- Secrets Manager: AWS 관리형 키로 자동 암호화

**적용 대상**: Unit 1 (KMS key, Aurora 암호화, Secrets Manager), Unit 3 (KMS encrypt/decrypt), Unit 4 (Admin Virtual Key rotate 경로의 신규 ciphertext 생성)

**제약사항**:
- Virtual Key 평문은 절대 DB에 저장하지 않음 (KMS ciphertext + SHA-256 fingerprint만 저장)
- 모든 Virtual Key에 동일 KMS 키 ARN 사용
- Virtual Key 평문 존재 위치: Lambda Token Service 응답, 클라이언트 메모리만
- DB 접속 자격증명은 Secrets Manager에 저장 (환경변수 아님)
- 런타임 Gateway의 Virtual Key 검증은 fingerprint 비교만 사용하며 저장된 key ciphertext 복호화 권한을 요구하지 않는다.
- IAM 정책에서 최소 권한 KMS 접근 부여 (Lambda Token Service: encrypt/decrypt, ECS Admin 경로: 필요 시 encrypt only)

**준수 수준**: MANDATORY

---

### 4.2 전송 시 암호화

**결정**: 모든 외부 및 내부 통신에 TLS 1.2+

**적용 대상**: 전체 유닛

**제약사항**:
- ALB는 HTTPS 강제 (HTTP 리스너 없음)
- ALB는 ACM 인증서로 TLS 종료
- API Gateway는 TLS 1.2+ 강제
- RDS Proxy 연결은 TLS 사용 (`sslmode=require`)
- VPC Endpoint는 TLS 사용 (기본값)
- Bedrock API 호출은 TLS 사용 (boto3 기본: HTTPS)

**준수 수준**: MANDATORY

---

### 4.3 네트워크 보안

**결정**: Private subnet 우선, VPC Endpoint 기반 연결, NAT Gateway 없음

**적용 대상**: Unit 1 (NetworkStack)

**제약사항**:
- ECS Fargate task는 private app subnet에서 실행
- Lambda 함수는 private app subnet에 연결
- Aurora는 private data subnet에 위치
- ALB는 internet-facing (public subnet)이나 보안 그룹으로 인바운드 제한
- 필수 VPC Endpoint: bedrock-runtime, ecr.api, ecr.dkr, s3 (gateway), logs, secretsmanager, kms, identitystore, sts, aps-workspaces, ecs
- VPC Endpoint policy로 특정 리소스 ARN에 대한 접근만 허용
- 보안 그룹은 최소 권한 (필수 포트/소스만 허용)

**준수 수준**: MANDATORY

---

### 4.4 IAM 최소 권한

**결정**: 최소 필요 권한만 가진 IAM 역할, 와일드카드 리소스 ARN 사용 지양

**적용 대상**: Unit 1 (ECS, Lambda, API Gateway용 IAM 역할)

**제약사항**:
- Lambda 실행 역할: KMS Encrypt/Decrypt (특정 키), Secrets Manager read (특정 시크릿), VPC 네트워크 인터페이스
- ECS task execution 역할: ECR pull (특정 리포지토리), Secrets Manager read (특정 시크릿), CloudWatch Logs write (특정 로그 그룹)
- ECS task 역할: Bedrock InvokeModel/InvokeModelWithResponseStream (특정 리전), Secrets Manager read (특정 시크릿), AMP remote write (특정 워크스페이스), Identity Store read (특정 identity store), Admin rotate 구현 시 필요 범위의 KMS Encrypt
- API Gateway 실행 역할: Lambda invoke (특정 함수), CloudWatch Logs write
- 와일드카드 리소스 ARN(`*`) 허용 예외: ec2:DescribeNetworkInterfaces (읽기 전용), logs:CreateLogStream (동적 로그 스트림)

**준수 수준**: MANDATORY

---

### 4.5 민감 데이터 처리

**결정**:
- 프롬프트/응답 본문 로깅 및 저장 금지
- Virtual Key 평문 로그 마스킹 (마지막 4자만 노출)
- 시크릿은 Secrets Manager에서 환경변수로 주입 (하드코딩 금지)

**적용 대상**: Unit 3-4 (애플리케이션 로깅, DB 스키마)

**제약사항**:
- usage_events 테이블에 프롬프트/응답 본문 포함 금지
- Virtual Key 평문 마스킹 (예: `vk-...abc123xyz` → `vk-...*******xyz`)
- DB 접속 문자열은 런타임에 Secrets Manager에서 조회
- Secrets Manager 시크릿 이름 규약: `<app>/<env>/db-credentials` (예: `claude-proxy/dev/db-credentials`)
- KMS ciphertext나 원시 시크릿 로깅 금지

**준수 수준**: MANDATORY

---

## 5. API 규약

### 5.1 API 버전 관리

**결정**: `/v1/` 접두사 기반 URI 버전 관리

**적용 대상**: Unit 4 (Gateway Runtime, Admin API)

**제약사항**:
- Runtime API: `/v1/messages`, `/v1/models`
- Admin API: `/v1/admin/users`, `/v1/admin/teams` 등
- Health check `/healthz`는 버전 접두사 미사용 (운영 엔드포인트)
- 버전은 첫 번째 경로 세그먼트 (쿼리 파라미터, 헤더 아님)

**준수 수준**: MANDATORY

---

### 5.2 페이지네이션

**결정**: Admin API 대용량 결과 집합에 페이지 번호 기반 페이지네이션

**적용 대상**: Unit 4 (Admin API — usage 조회)

**제약사항**:
- 쿼리 파라미터: `page` (기본값 1), `page_size` (기본값 100, 최대 1000)
- 응답 형식:
  ```json
  {
    "items": [...],
    "next_page": 2
  }
  ```
- 비페이지네이션 엔드포인트는 단순 배열 또는 객체 반환

**준수 수준**: MANDATORY

---

### 5.3 Rate Limiting

**결정**: v1에서 애플리케이션 레이어 rate limiting 없음 (예산 제어에 의존)

**제약사항**:
- 예산 hard limit이 초과 시 요청 차단 (사실상 rate limit 역할)
- ALB connection limit 설정 (기본: 타겟당 1000 동시 연결)
- per-unit 구현에서 시스템 전체 승인 없이 커스텀 rate limiting 추가 금지

**준수 수준**: RECOMMENDED (post-v1 연기)

---

## 6. 데이터베이스 및 데이터 접근 패턴

### 6.1 데이터베이스 기술

**결정**: Aurora PostgreSQL Serverless v2 + RDS Proxy

**적용 대상**: Unit 1 (DataStack), Unit 2-4 (SQLAlchemy 설정)

**제약사항**:
- PostgreSQL 호환 에디션 사용 (MySQL 아님)
- Serverless v2 사용 (프로비저닝 인스턴스 아님)
- 모든 DB 연결은 RDS Proxy 경유 (Lambda, ECS 모두)
- 연결 문자열에 RDS Proxy 엔드포인트 사용 (Aurora writer 엔드포인트 아님)
- 커넥션 풀: 최소 0.5 ACU, 최대 1.0 ACU (v1 기본값, 런칭 후 조정)
- 모든 DB 접근은 TLS (`sslmode=require`)

**준수 수준**: MANDATORY

---

### 6.2 ORM 및 마이그레이션

**결정**: SQLAlchemy 2.0 (async) + Alembic

**적용 대상**: Unit 2 (Shared Models), Unit 3-4 (애플리케이션 코드)

**제약사항**:
- SQLAlchemy 2.0 API 스타일 사용 (1.x 레거시 API 아님)
- 모든 ORM 작업은 async session (`AsyncSession`) 사용
- Alembic 마이그레이션은 순차적 (분기 없음)
- Alembic은 async engine으로 마이그레이션 실행
- 마이그레이션 스크립트는 배포 전 버전 관리에 커밋
- DB 스키마 변경은 반드시 Alembic 경유 (수동 ALTER TABLE 금지)

**준수 수준**: MANDATORY

---

### 6.3 Repository 패턴

**결정**: 데이터 접근 추상화를 위한 Repository 패턴

**적용 대상**: Unit 4 (Gateway repositories/)

**제약사항**:
- 각 ORM 모델에 대응하는 Repository 클래스 (14개)
- Repository 메서드는 생성자에서 `AsyncSession` 주입 (FastAPI Depends)
- Repository 메서드는 도메인 모델 또는 DTO 반환 (ORM 객체 직접 반환 아님)
- Repository에 비즈니스 로직 포함 금지 (CRUD 및 쿼리 작업만)
- 서비스 레이어는 모든 DB 접근에 Repository 사용 (직접 ORM 쿼리 금지)

**준수 수준**: MANDATORY

---

### 6.4 트랜잭션 관리

**결정**: 정책 평가와 사용량 기록에 분리된 트랜잭션, 명시적 트랜잭션 경계

**적용 대상**: Unit 4 (Gateway Runtime — GatewayService, UsageService)

**제약사항**:
- FastAPI Depends에서 요청당 단일 `AsyncSession` 제공
- PolicyChain.evaluate() 완료 후 commit/rollback (읽기 트랜잭션 종료)
- Bedrock 호출은 트랜잭션 외부에서 수행 (DB 연결 유휴)
- UsageService.record_success()는 `apply_costs() + create_event()`를 단일 쓰기 트랜잭션에서 실행
- 쓰기 트랜잭션 commit/rollback 후 메트릭 emit
- 중첩 트랜잭션은 savepoint 사용 (`session.begin_nested()`)
- 장기 실행 작업(>5초)은 트랜잭션을 유지하지 않음

**준수 수준**: MANDATORY

---

### 6.5 데이터 일관성

**결정**: 예산은 강한 일관성 (원자적 업데이트), 리포팅 집계는 최종 일관성

**적용 대상**: Unit 4 (UsageService, BudgetPolicyRepository, UsageRollupService)

**제약사항**:
- 예산 업데이트는 원자적 SQL 사용: `UPDATE budget_policies SET current_used_usd = current_used_usd + $cost WHERE current_used_usd + $cost <= hard_limit_usd RETURNING current_used_usd`
- 예산 검사 실패 시 트랜잭션 롤백 및 BudgetExceededError 발생
- usage_events가 모든 사용량 데이터의 source of truth
- usage_daily_agg, usage_monthly_agg는 배치 rollup으로 갱신 (요청 핫패스가 아님)
- Rollup 배치는 UPSERT 패턴 사용 (`INSERT ... ON CONFLICT DO UPDATE`)
- 리포팅 쿼리는 집계 테이블 사용 (usage_events 직접 쿼리 아님)

**준수 수준**: MANDATORY

---

## 7. 인프라 규약

### 7.1 Infrastructure as Code

**결정**: AWS CDK (Python), context 기반 설정

**적용 대상**: Unit 1 (infra/)

**제약사항**:
- CDK는 Python 사용 (TypeScript 등 다른 언어 아님)
- 모듈러 스택: NetworkStack, DataStack, ComputeStack, ApiStack, ObservabilityStack
- 스택 의존성은 명시적 (`stack_b.add_dependency(stack_a)`)
- 환경 설정은 CDK context 사용 (cdk.json 또는 --context CLI 플래그)
- Context 파라미터: `environment` (dev/staging/prod), `region` (기본값: ap-northeast-2), `vpc_cidr`, `aurora_min_capacity`, `aurora_max_capacity`
- 배포: `cdk diff` 검토 후 `cdk deploy --require-approval broadening`
- CDK 버전은 pyproject.toml에 고정

**준수 수준**: MANDATORY

---

### 7.2 멀티 스택 전략

**결정**: 5개 스택 CDK 아키텍처, 계층별 의존성

**적용 대상**: Unit 1 (infra/stacks/)

**제약사항**:
- 스택 의존성 순서: NetworkStack → DataStack → ObservabilityStack → ComputeStack → ApiStack
- 크로스 스택 참조는 CDK export 사용 (하드코딩 ARN 아님)
- 스택 이름 규약: `<app>-<env>-<layer>` (예: `claude-proxy-dev-network`)

**준수 수준**: MANDATORY

---

### 7.3 컨테이너 전략

**결정**:
- ECS Fargate (멀티 컨테이너 task: app + ADOT sidecar)
- ECR 컨테이너 이미지 레지스트리
- Docker 멀티 스테이지 빌드

**적용 대상**: Unit 1 (ComputeStack), Unit 4 (Dockerfile)

**제약사항**:
- Gateway 이미지: `python:3.13-slim` 기반
- ADOT Collector sidecar: `public.ecr.aws/aws-observability/aws-otel-collector:latest`
- Dockerfile은 멀티 스테이지 빌드 (builder + runtime)
- 의존성 설치는 uv 사용 (pip 아님)
- 컨테이너는 non-root 사용자로 실행
- Health check은 ECS task definition에서 정의 (Dockerfile 아님)
- 로그는 stdout/stderr로 출력 (awslogs 드라이버로 CloudWatch Logs 전송)

**준수 수준**: MANDATORY

---

## 8. 개발 표준

### 8.1 프로그래밍 언어

**결정**: Python 3.13 — 전체 애플리케이션 코드 (Lambda, Gateway, Admin API, CDK)

**적용 대상**: 전체 유닛

**제약사항**:
- Python 버전: 3.13 (3.12 이하 아님)
- 모든 공개 함수 및 메서드에 type hint 사용
- Lambda 런타임: `python3.13`
- Docker 베이스 이미지: `python:3.13-slim`
- pyproject.toml: `requires-python = ">=3.13"`

**준수 수준**: MANDATORY

---

### 8.2 패키지 관리

**결정**: uv

**적용 대상**: 전체 유닛

**제약사항**:
- 패키지 의존성은 pyproject.toml에 선언
- 의존성 버전은 uv.lock에 잠금
- uv.lock은 버전 관리에 커밋
- 프로덕션 설치: `uv pip install --no-cache` (uv sync 아님)
- 개발 설치: `uv sync --all-extras` 사용 가능
- CI/CD: `uv pip compile --generate-hashes`로 재현 가능한 빌드

**준수 수준**: MANDATORY

---

### 8.3 코드 스타일

**결정**: ruff (black, isort, flake8 대체)

**적용 대상**: 전체 유닛

**제약사항**:
- ruff 설정은 pyproject.toml `[tool.ruff]` 섹션
- 줄 길이: 100자
- import 정렬: isort 호환 스타일
- docstring: Google 스타일
- CI: `ruff check` 및 `ruff format --check` 실행, 위반 시 실패
- pre-commit hook에서 ruff 실행 (개발자 선택)

**준수 수준**: MANDATORY

---

### 8.4 커밋 규약

**결정**: Conventional Commits 사양

**제약사항**:
- 형식: `<type>(<scope>): <description>`
- 허용 type: feat, fix, docs, refactor, test, chore, ci
- scope는 유닛 또는 컴포넌트 이름 (예: `feat(gateway): add budget policy`)
- 첫 줄 72자 이내

**준수 수준**: RECOMMENDED

---

## 9. 테스트 표준

### 9.1 테스트 프레임워크

**결정**: pytest (전체 테스트 유형)

**적용 대상**: Unit 2-4 (tests/)

**제약사항**:
- 테스트 파일: `test_*.py` 또는 `*_test.py`
- 테스트 함수: `test_*`
- 테스트 구조는 소스 구조 반영 (예: `tests/domains/runtime/test_services.py`)
- 테스트 fixture는 `conftest.py`에 정의
- CI: `pytest --cov --cov-report=term --cov-report=xml`, 커버리지 < 80% 시 실패

**준수 수준**: MANDATORY

---

### 9.2 Property-Based Testing (Extension A)

**결정**: Hypothesis를 사용한 property-based testing 활성화 (Extension A)

**적용 대상**: Unit 2-4 (tests/)

**제약사항**:
- 모든 입력 검증 함수에 property-based 테스트 포함
- 주요 대상: 프로토콜 변환기 (Anthropic <-> Bedrock), 예산 계산 로직, 캐시 정책 변환, Virtual Key fingerprint 생성
- Hypothesis strategy는 `tests/strategies.py`에 정의
- property-based 테스트는 example-based 테스트를 대체하지 않음 (둘 다 사용)
- CI: `--hypothesis-show-statistics` 옵션으로 실행

**준수 수준**: MANDATORY

---

### 9.3 테스트 커버리지

**결정**: 최소 80% 코드 커버리지, 인프라 코드는 커버리지 요구사항 제외

**적용 대상**: Unit 2-4 (애플리케이션 코드만)

**제약사항**:
- CI에서 최소 80% 코드 커버리지 강제
- 커버리지 보고서 제외 대상: `infra/*`, `tests/*`, `migrations/versions/*`
- 고위험 모듈은 90% 이상: `domains/policy/*`, `domains/usage/*`, `lambda/services/virtual_key_service.py`
- 커버리지 감소 시 CI 실패 (단순 낮은 절대값이 아님)

**준수 수준**: MANDATORY

---

## 10. 재시도 및 복원력

### 10.1 AWS SDK Retry 설정

**결정**: Bedrock은 `max_attempts=1`, 기타 서비스는 boto3 기본값

**적용 대상**: Unit 3-4 (boto3 클라이언트 설정)

**제약사항**:
- Bedrock 클라이언트: `max_attempts=1` (재시도 없음)
- Bedrock 클라이언트: `standard` retry mode (adaptive 아님)
- 기타 boto3 클라이언트: 기본 retry 설정 사용 가능
- retry 설정은 클라이언트 초기화 코드에서 명시적 (환경변수에 의존하지 않음)

**준수 수준**: MANDATORY

---

### 10.2 타임아웃 설정

**결정**:
- ALB idle timeout: 300초 (장시간 스트리밍 지원)
- boto3 Bedrock timeout: 300초 (connect + read)
- DB 쿼리 timeout: 30초 (statement_timeout)

**적용 대상**: Unit 1 (ALB 설정), Unit 4 (boto3 클라이언트, DB 설정)

**제약사항**:
- ALB idle timeout: 300초 (기본값 60초 아님)
- Bedrock connect timeout: 10초
- Bedrock read timeout: 290초 (ALB timeout - 버퍼)
- DB session `statement_timeout`: 30초
- Health check timeout: 5초 (ALB health check 간격보다 빠르게)

**준수 수준**: MANDATORY

---

### 10.3 Circuit Breaker

**결정**: v1에서 circuit breaker 패턴 미적용 (post-v1 연기)

**제약사항**:
- per-unit 구현에서 시스템 전체 승인 없이 circuit breaker 추가 금지
- Bedrock throttling 에러는 즉시 클라이언트에 전파 (circuit breaker 없음)
- post-v1 circuit breaker 추가 시 shared 라이브러리에 중앙 집중화

**준수 수준**: RECOMMENDED

---

## 11. Prompt Caching

### 11.1 Prompt Caching 정책

**결정**: 3단계 정책 기반 (none, 5m, 1h), 변환 정책 B (block-level + top-level automatic)

**적용 대상**: Unit 4 (Gateway Runtime — CachePolicyHandler, AnthropicToBedrockConverter)

**제약사항**:
- 캐시 TTL 정책: none (비활성), 5m (300초), 1h (3600초)
- 기본 정책: 5m
- 정책 우선순위: 사용자 override > 팀 정책 > 시스템 기본값
- 변환 정책 B 규칙:
  - Block-level `cache_control` (Anthropic 요청) → `cachePoint` (Bedrock 요청) 변환 유지
  - Top-level automatic caching → tools > system > messages 순서로 마지막 eligible block에 cachePoint 자동 삽입
- 미지원 모델은 자동으로 `none` 정책으로 downgrade (모든 cache point 제거)
- 캐시 사용량 별도 기록: `cached_read_tokens`, `cached_write_tokens`
- 캐시 가격은 TTL별 요율: cache_write_5m_usd, cache_write_1h_usd (model_pricing 테이블)

**준수 수준**: MANDATORY

---

## 부록 A: 결정 요약표

| 카테고리 | 주요 결정 | 준수 수준 |
|----------|-----------|-----------|
| 인증 | Virtual Key (Runtime), SigV4 (Admin/Token) | MANDATORY |
| 인가 | 10단계 정책 체인, 계층적, fail-closed | MANDATORY |
| 로깅 | JSON 구조화, CloudWatch Logs | MANDATORY |
| 메트릭 | OTel + ADOT Sidecar + AMP, 3개 primary metric | MANDATORY |
| 트레이싱 | OTel SDK (v1은 메트릭만), X-Ray 연기 | RECOMMENDED |
| Request ID | UUID v4, 서버 생성 fallback | MANDATORY |
| Health Check | 단일 `/healthz` 엔드포인트 | MANDATORY |
| 에러 형식 | Anthropic 호환 (Runtime API) | MANDATORY |
| 예외 계층 | 커스텀 도메인 예외 | MANDATORY |
| 재시도 정책 | Bedrock 재시도 없음, max_attempts=1 | MANDATORY |
| 저장 암호화 | KMS (Virtual Key), Aurora 암호화 | MANDATORY |
| 전송 암호화 | TLS 1.2+ 전체 통신 | MANDATORY |
| 네트워크 | Private subnet, VPC Endpoint, NAT 없음 | MANDATORY |
| IAM | 최소 권한, 명시적 리소스 ARN | MANDATORY |
| 민감 데이터 | 프롬프트/응답 미저장, 시크릿 마스킹 | MANDATORY |
| API 버전 | URI 기반 `/v1/` 접두사 | MANDATORY |
| 페이지네이션 | 커서 기반 (Admin API) | MANDATORY |
| Rate Limiting | 앱 레이어 rate limit 없음 (예산 제어) | RECOMMENDED |
| 데이터베이스 | Aurora PostgreSQL Serverless v2 + RDS Proxy | MANDATORY |
| ORM | SQLAlchemy 2.0 async + Alembic | MANDATORY |
| Repository | Repository 패턴 전체 데이터 접근 | MANDATORY |
| 트랜잭션 | 분리된 트랜잭션, 명시적 경계 | MANDATORY |
| 데이터 일관성 | 강한 일관성 (예산), 최종 일관성 (리포팅) | MANDATORY |
| IaC | AWS CDK Python, 5개 스택 | MANDATORY |
| 컨테이너 | ECS Fargate, 멀티 컨테이너 (app + ADOT) | MANDATORY |
| 언어 | Python 3.13 전체 | MANDATORY |
| 패키지 관리 | uv | MANDATORY |
| 코드 스타일 | ruff | MANDATORY |
| 커밋 규약 | Conventional Commits | RECOMMENDED |
| 테스트 | pytest | MANDATORY |
| PBT | Hypothesis (Extension A) | MANDATORY |
| 테스트 커버리지 | 80% 최소, 고위험 90% | MANDATORY |
| AWS SDK Retry | max_attempts=1 (Bedrock), 기본값 (기타) | MANDATORY |
| 타임아웃 | ALB 300초, Bedrock 300초, DB 30초 | MANDATORY |
| Circuit Breaker | v1 미적용 | RECOMMENDED |
| Prompt Caching | 정책 기반 (none/5m/1h), 정책 B | MANDATORY |

---

**시스템 전체 NFR 결정 사항 v1.0 끝**
