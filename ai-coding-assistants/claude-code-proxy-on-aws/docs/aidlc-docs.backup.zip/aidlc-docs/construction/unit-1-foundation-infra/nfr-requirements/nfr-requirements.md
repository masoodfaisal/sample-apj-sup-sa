# Unit 1: Foundation Infrastructure - NFR 요구사항 명세

- **문서 버전**: v1.0
- **작성일**: 2026-04-01
- **상태**: Final
- **단계**: CONSTRUCTION - NFR Requirements
- **근거 문서**:
  - [System NFR Decisions](../../../construction/system-nfr-decisions.md)
  - [Functional Design](../functional-design/functional-design.md)
  - [Questions Round 1 (답변 완료)](./questions-round1.md)

---

## 문서 개요

본 문서는 Claude Code Proxy on AWS의 Unit 1 (Foundation Infrastructure)에 대한 비기능 요구사항(Non-Functional Requirements)을 정의한다.

Unit 1은 인프라 유닛으로, 일반적인 애플리케이션 NFR(예: API 응답 시간, 처리량)보다는 **인프라 자체의 품질 속성**에 초점을 맞춘다:
- 네트워크 보안 및 성능
- 데이터 암호화 및 접근 제어
- 백업/복구 전략
- 인프라 관측성
- 배포 안정성
- 코드 품질 (CDK 테스트 전략)

모든 NFR은 Questions Round 1의 답변을 기반으로 하며, System NFR Decisions 문서와 일관성을 유지한다.

---

## 1. Performance (성능)

### 1.1 Aurora Serverless v2 용량 설정

**요구사항**:
- 초기 최소/최대 용량: **0.5 ACU / 1.0 ACU**
- 예상 초기 동시 사용자: 약 100명
- 예상 동시 DB 연결 수: 50~100개

**성공 기준**:
- CloudWatch CPUUtilization 메트릭이 정상 운영 시 80% 미만 유지
- RDS Proxy 연결 대기 시간(borrow timeout) 초과 이벤트 없음

**용량 확장 기준**:
- **트리거**: CloudWatch CPUUtilization 80% 초과가 10분 이상 지속
- **조치**: CDK context `aurora_max_capacity` 값 상향 조정 (1.0 → 2.0 → 4.0 단계적)
- **방법**: `cdk deploy DataStack -c aurora_max_capacity=2.0` 실행으로 즉시 반영

**운영 프로세스**:
- v1에서는 수동 모니터링 및 수동 조정
- v2에서 CloudWatch Alarm + SNS 알림 자동화 고려

**근거**:
- 초기 트래픽 규모가 작으므로 최소 용량으로 시작하여 비용 최적화
- Serverless v2는 실시간 자동 확장을 지원하므로 갑작스러운 트래픽 증가에도 대응 가능
- CDK context 기반 설정으로 코드 변경 없이 즉시 배포 가능

---

### 1.2 ALB Idle Timeout 설정

**요구사항**:
- ALB idle timeout: **300초 (5분)**

**성공 기준**:
- Claude Code의 thinking 포함 최대 응답 시간(통상 120~180초)을 충분히 커버
- 정상 스트리밍 세션이 timeout으로 중단되지 않음

**설정 근거**:
- Claude Code의 thinking + 응답 생성 시간이 최대 180초 수준
- 300초면 1.67배의 여유 확보
- 600초로 늘릴 경우 비정상 연결이 오래 유지되어 리소스 낭비 발생
- System NFR Decisions 10.2절의 타임아웃 표준 준수

**모니터링**:
- ALB access logs에서 `elb_status_code=504` (Gateway Timeout) 발생 빈도 추적
- 504 에러 발생 시 timeout 설정 재검토

---

### 1.3 RDS Proxy Connection Borrow Timeout

**요구사항**:
- Connection borrow timeout: **120초**
- Idle client timeout: **1800초 (30분)**

**성공 기준**:
- 피크 시간대에도 connection borrow timeout 초과 이벤트 없음
- RDS Proxy 연결 풀 활용률 80% 미만 유지

**설정 근거**:
- 예상 동시 사용자 100명 기준, RDS Proxy의 연결 멀티플렉싱이 연결 부족 상황을 효과적으로 방지
- 연결 부족 발생 시 우선 대응은 Aurora max capacity 상향 (borrow timeout 단축 아님)
- 120초는 DB 쿼리 timeout (30초) 대비 충분한 여유

**확장 경로**:
1. 1차 대응: Aurora max capacity 상향 (연결 처리 능력 증가)
2. 2차 대응: RDS Proxy 최대 연결 비율 조정 (기본 100%)
3. 최종 대응: borrow timeout 값 조정 검토

---

### 1.4 VPC Endpoint 대역폭 고려

**요구사항**:
- 예상 Bedrock API 호출량: 초당 **10~30 요청**
- VPC Endpoint 대역폭 제한에 대한 별도 처리 불필요

**성공 기준**:
- Bedrock API 호출 시 네트워크 latency가 일관되게 유지 (변동계수 < 20%)
- VPC Endpoint throttling 이벤트 없음

**설정 근거**:
- 동시 사용자 100명이지만 LLM 응답 시간이 길어(평균 30~60초) 동시 요청이 시간적으로 분산됨
- 초당 10~30 요청은 VPC Endpoint의 기본 대역폭 제한을 훨씬 하회
- AWS VPC Endpoint는 자동으로 확장되므로 사전 용량 설정 불필요

**모니터링**:
- CloudWatch Logs에서 Bedrock API latency 메트릭 추적
- Latency 급등 시 VPC Endpoint 대역폭 재검토

---

## 2. Security (보안)

### 2.1 Aurora 암호화 키 관리

**요구사항**:
- Aurora 저장 시 암호화: **AWS 관리형 RDS 키** 사용
- Virtual Key 암호화: **고객 관리형 KMS 키** (`alias/{app}-{env}-virtual-key`)

**성공 기준**:
- Aurora 데이터베이스가 기본 암호화 활성화 상태로 생성
- Virtual Key ciphertext가 고객 관리형 KMS 키로 암호화되어 DB에 저장

**설정 근거**:
- **Aurora는 AWS 관리형 키로 충분**:
  - 내부 개발자용 프록시로 특정 산업 규제나 컴플라이언스 요구사항 없음
  - Virtual Key 암호화는 이미 별도 고객 관리형 KMS 키로 처리
  - Aurora 암호화까지 고객 관리형으로 전환할 비즈니스 가치 낮음
- **Virtual Key는 고객 관리형 KMS 키 필수**:
  - 키 회전, 접근 감사, 역할별 권한 분리 필요
  - Lambda Token Service와 ECS Gateway Task의 KMS 권한 분리 (encrypt/decrypt vs encrypt only)

**IAM 권한 분리**:
- Lambda Token Service: KMS Encrypt/Decrypt/GenerateDataKey (Virtual Key 발급/재조회)
- ECS Gateway Task: KMS Encrypt only (Admin API rotate 경로)
- ECS Gateway Runtime: KMS 권한 불필요 (fingerprint 비교만 수행)

---

### 2.2 VPC Endpoint 정책 세분화

**요구사항**:
- Bedrock Runtime VPC Endpoint 정책: **모든 Bedrock 모델 접근 허용** (현행 유지)
- 기타 VPC Endpoint 정책: **계정/리전 제한** (`aws:PrincipalAccount` 조건)

**성공 기준**:
- Bedrock Endpoint를 통한 모델 호출이 정상 동작
- 모델 추가 시 인프라 재배포 불필요

**설정 근거**:
- **Endpoint 레벨에서 모델 제한 불필요**:
  - 모델 접근 제어는 Gateway의 10단계 정책 평가 체인(ModelAccessHandler)에서 처리
  - Endpoint 정책에 모델 ARN 패턴(예: `us.anthropic.*`)을 하드코딩하면 새 모델 추가 시 인프라 재배포 필요 (운영 부담 증가)
  - Endpoint는 네트워크 접근 통로일 뿐, 비즈니스 로직 수준의 접근 제어는 애플리케이션 레이어에서 처리
- **계정/리전 제한은 유지**:
  - 다른 AWS 계정의 리소스가 VPC Endpoint를 악용하는 것 방지
  - 최소 권한 원칙 준수

**정책 변경 시나리오**:
- v2에서 멀티 리전 배포 시 `aws:PrincipalAccount` 조건 유지, 리전 조건 조정 검토

---

### 2.3 Security Group IP 화이트리스트

**요구사항**:
- ALB 보안 그룹: **0.0.0.0/0에서 포트 443 허용** (IP 화이트리스트 없음)
- 접근 제어: **Gateway 인증(x-api-key Virtual Key)으로 처리**

**성공 기준**:
- ALB가 모든 인터넷 IP에서 접근 가능하되, Virtual Key 없는 요청은 401 에러 반환
- 사무실 IP 제한 없이도 안전한 접근 제어 유지

**설정 근거**:
- ALB는 internet-facing이지만 Gateway 인증(x-api-key Virtual Key)으로 접근 제어
- **사무실 IP 제한 불필요**:
  - VPN/네트워크 레벨 제한이 아닌 Virtual Key 발급 자체로 사용자 통제
  - IP 기반 제한은 재택근무, 외부 네트워크 사용 시 관리 부담 증가
  - Virtual Key는 사용자별로 발급되므로 감사 추적 가능
- **현재 보안 그룹 매트릭스로 충분**:
  - ALB → ECS, ECS → RDS/Endpoint, Lambda → RDS/Endpoint 경로만 허용
  - 최소 권한 원칙 준수

**추가 보안 강화 옵션 (v2 고려)**:
- AWS WAF 적용 (rate limiting, SQL injection 차단)
- CloudFront CDN 앞단 배치 (DDoS 방어)

---

### 2.4 KMS Key 접근 제어 세분화

**요구사항**:
- Lambda Token Service: **Encrypt/Decrypt/GenerateDataKey**
- ECS Gateway Task: **Encrypt only**
- ECS Gateway Runtime: **KMS 권한 불필요** (fingerprint 비교만 수행)

**성공 기준**:
- Lambda가 Virtual Key 발급 시 평문 → ciphertext 암호화 성공
- Lambda가 Virtual Key 재조회 시 ciphertext → 평문 복호화 성공
- ECS Admin API가 Virtual Key rotate 시 신규 ciphertext 생성 성공
- ECS Runtime이 Virtual Key 검증 시 KMS 호출 없이 fingerprint 비교만 수행

**권한 분리 근거**:
- **Lambda Token Service (Encrypt/Decrypt)**:
  - Virtual Key 발급: 평문 생성 → KMS Encrypt → ciphertext DB 저장
  - Virtual Key 재조회: ciphertext DB 조회 → KMS Decrypt → 평문 응답
- **ECS Gateway Task (Encrypt only)**:
  - Admin API rotate 경로: 신규 평문 생성 → KMS Encrypt → ciphertext DB 저장
  - Runtime은 저장된 ciphertext 복호화 권한 불필요 (fingerprint만 비교)
- **최소 권한 원칙 준수**:
  - ECS Runtime은 매 요청마다 실행되므로 KMS Decrypt 권한을 주면 공격 표면 증가
  - Runtime은 SHA-256 fingerprint 비교만 수행하여 KMS 호출 횟수 및 비용 절감

**추가 조건 (v2 고려)**:
- KMS 키 정책에 `kms:EncryptionContext` 조건 추가 (특정 사용자 ID만 암복호화 허용)
- KMS CloudTrail 로그 모니터링으로 비정상 암복호화 시도 탐지

---

## 3. Reliability (신뢰성)

### 3.1 Aurora 백업 및 복구 정책

**요구사항**:
- **RPO (Recovery Point Objective)**: 5분
- **RTO (Recovery Time Objective)**: 1시간
- 백업 보존 기간: **7일** (전 환경 동일)
- PITR (Point-in-Time Recovery): **활성화**

**성공 기준**:
- Aurora가 연속 백업을 유지하여 최근 5분 이내 시점으로 복원 가능
- 데이터 유실 시 1시간 이내에 서비스 재개 가능

**설정 근거**:
- **RPO 5분**:
  - Aurora PITR은 기본적으로 연속 백업을 수행 (5분 간격 WAL 로그 백업)
  - 데이터 손실 허용 범위가 최대 5분 이내로 제한
- **RTO 1시간**:
  - PITR 복원 + Gateway/Lambda 서비스 재연결 포함 시간
  - 내부 개발자 도구로 1시간 이내 복구면 충분
- **백업 보존 7일**:
  - 내부 개발자 도구로 7일 이상 과거 데이터 복구 필요성 낮음
  - Virtual Key 유실 시 재발급으로 복구 가능 (DB 복원 의존도 낮음)
  - 비용 최적화 (보존 기간 증가 시 스토리지 비용 선형 증가)

**복구 시나리오**:
1. **데이터 손상 시**: PITR로 특정 시점 복원
2. **클러스터 전체 장애 시**: 자동 백업에서 새 클러스터 생성 → RDS Proxy endpoint 재설정 → 서비스 재시작

**운영 프로세스**:
- 주간 백업 테스트 (복원 시간 실측)
- 복구 절차 문서화 및 정기 검토

---

### 3.2 ECS Task Health Check 설정

**요구사항**:
- Health check start period: **60초** (현행 유지)
- Health check interval: **30초**
- Health check timeout: **5초**
- Unhealthy threshold: **3회**

**성공 기준**:
- Unit 1 skeleton (nginx) 및 Unit 4 실제 FastAPI 앱 모두 60초 내 health check pass
- 정상 Task가 health check 실패로 종료되지 않음

**설정 근거**:
- **60초 start period로 충분**:
  - Unit 1 skeleton은 nginx:latest로 즉시 기동 (1~2초)
  - Unit 4의 실제 FastAPI 앱도 DB 연결(RDS Proxy) + OTel SDK 초기화 포함 10~15초 이내 부팅 예상
  - 60초는 4~6배의 여유 확보
- **부팅 시간 실측 후 조정**:
  - Unit 4 구현 후 CloudWatch Container Insights에서 Task 시작 시간 실측
  - 부팅 시간이 30초 초과 시 start period 상향 검토

**모니터링**:
- ECS Task stopped events에서 `essential container exited` 원인 추적
- Health check 실패가 빈번하면 start period 조정

---

### 3.3 Deletion Protection 정책

**요구사항**:
- Aurora deletion protection: **prod만 활성화**
- ALB deletion protection: **prod만 활성화**
- dev/staging: **비활성화** (인프라 변경 테스트 용이성)

**성공 기준**:
- prod 환경에서 Aurora/ALB 삭제 시도 시 AWS API 에러 반환
- dev/staging에서 인프라 변경 시 deletion protection으로 인한 배포 실패 없음

**설정 근거**:
- **prod만 보호**:
  - prod는 실제 사용자 데이터 및 장기 운영 상태 유지
  - 실수로 인한 리소스 삭제 방지 필수
- **staging은 비활성화**:
  - staging은 필요 시 재생성 가능한 환경
  - 장기 운영 데이터를 보관하지 않음
  - 인프라 변경 테스트 시 deletion protection이 오히려 방해 (예: 스택 재생성 시)
- **dev는 비활성화**:
  - 개발자가 빠르게 인프라를 재생성해야 하는 경우 많음
  - deletion protection이 개발 속도 저하

**추가 보호 장치 (v2 고려)**:
- CloudTrail 로그 모니터링으로 prod 리소스 삭제 시도 시 SNS 알람
- AWS Config로 deletion protection 비활성화 시도 차단

---

## 4. Scalability (확장성)

### 4.1 Aurora Serverless v2 최대 용량 확장

**요구사항**:
- 초기 최대 용량: **1.0 ACU**
- 확장 트리거: **CloudWatch CPUUtilization 80% 초과 10분 지속**
- 확장 단계: **1.0 → 2.0 → 4.0 ACU** (단계적 조정)

**성공 기준**:
- Aurora가 트래픽 증가 시 max capacity까지 자동 확장
- CPU 80% 초과 시 수동 개입 없이 용량 상향 결정 가능

**확장 절차**:
1. **모니터링**: CloudWatch CPUUtilization 메트릭 추적
2. **판단**: 80% 초과가 10분 이상 지속 확인
3. **조치**: CDK context 변경 (`aurora_max_capacity=2.0`)
4. **배포**: `cdk deploy DataStack -c aurora_max_capacity=2.0`
5. **검증**: Aurora가 새 max capacity로 확장되는지 확인

**자동화 계획 (v2)**:
- CloudWatch Alarm + SNS 알림으로 CPU 80% 초과 시 운영자에게 알림
- EventBridge + Lambda로 자동 max capacity 상향 (CDK 재배포 자동화)

**모니터링 지표**:
- Aurora CPUUtilization (80% 기준)
- Aurora DatabaseConnections (max 대비 비율)
- RDS Proxy ConnectionBorrowTimeout events (연결 부족 감지)

---

### 4.2 Lambda Token Service 동시성 제한

**요구사항**:
- 예약 동시성(reserved concurrency): **미설정**
- 계정 기본 한도 사용

**성공 기준**:
- Lambda 함수가 계정 기본 동시성 한도 내에서 정상 실행
- 다른 Lambda 함수와의 동시성 경합 없음

**설정 근거**:
- **Token Service 호출 빈도 매우 낮음**:
  - 사용자당 최초 1회 Virtual Key 발급
  - 이후 간헐적 조회 (주로 Gateway Runtime의 fingerprint 검증 사용)
  - 예상 호출량: 월 수백~수천 건 수준
- **동시성 경합 없음**:
  - 현재 프로젝트에 Lambda 함수가 Token Service 하나뿐
  - 향후 Lambda 함수 추가 시 재검토 (예: 배치 작업, 알람 핸들러)
- **예약 동시성 설정 시 단점**:
  - 계정 전체 동시성 한도를 고정 할당하여 다른 Lambda에 영향
  - 사용하지 않는 동시성 슬롯 낭비

**향후 검토 시나리오**:
- Lambda 함수 추가 시 각 함수의 예약 동시성 할당 계획 수립
- 계정 동시성 한도 확인 및 필요 시 AWS Support를 통해 한도 증가 요청

---

### 4.3 ECS Task Auto-scaling 사전 고려

**요구사항**:
- Unit 1에서 사전 결정 **불필요** (Auto-scaling은 Unit 4 scope)
- Unit 4 설계 시 기준값:
  - 최소 Task: **dev 1, staging/prod 2**
  - 최대 Task: **10개** (참고값)

**성공 기준**:
- Unit 4에서 ECS Service Auto-scaling 구현 시 Unit 1의 ComputeStack 수정 불필요
- 최대 Task 수 제한이 ALB Target Group capacity 내에 수용 가능

**설정 근거**:
- **Unit 1에서 결정 불필요**:
  - ECS Service 자체가 Unit 4 scope
  - Auto-scaling 정책(예: CPU 기반, Request count 기반)은 Gateway 애플리케이션 성능 프로파일링 후 결정
- **참고값 제공**:
  - 최소 Task 2개는 Multi-AZ 고가용성 보장 (각 AZ에 1개)
  - 최대 Task 10개는 초기 트래픽 규모(동시 100명) 대비 충분한 여유

**Unit 4 Auto-scaling 구현 시 고려사항**:
- Target Tracking Scaling Policy: ALB RequestCountPerTarget 기준
- Scheduled Scaling: 예측 가능한 트래픽 패턴 시 사전 확장
- CloudWatch Alarm: CPU 80% 초과 시 알림

---

## 5. Maintainability (유지보수성)

### 5.1 CDK 테스트 전략

**요구사항**:
- `cdk synth` 성공 검증: **필수**
- CDK snapshot test: **적용**
- Integration test (실제 배포): **Build & Test 단계에서 수행**

**성공 기준**:
- `cdk synth --all` 실행 시 모든 스택의 CloudFormation 템플릿 생성 성공
- Snapshot test에서 의도치 않은 리소스 변경 감지 (Security Group 규칙, IAM 정책 변경 등)
- PR merge 전 snapshot 변경 리뷰 필수

**구현 방법**:
- **CDK synth 검증**:
  ```bash
  cd infra
  cdk synth --all  # 모든 스택 synthesize
  ```
- **Snapshot test**:
  - `pytest` + `aws-cdk-lib.assertions` 모듈 사용
  - 각 스택별 snapshot 파일 생성 (`tests/snapshots/*.json`)
  - 리소스 속성 변경 시 snapshot 차이 자동 감지
  - 예시 테스트 코드:
    ```python
    from aws_cdk.assertions import Template
    def test_network_stack_snapshot(network_stack):
        template = Template.from_stack(network_stack)
        template.resource_count_is("AWS::EC2::VPC", 1)
        template.has_resource_properties("AWS::EC2::SecurityGroup", {
            "GroupDescription": Match.string_like_regexp(".*alb-sg.*")
        })
    ```
- **Integration test는 Build & Test 단계**:
  - 실제 `cdk deploy` 실행하여 AWS 리소스 생성 검증
  - 리소스 생성 후 기본 연결성 테스트 (예: ALB endpoint 응답, RDS Proxy 연결)

**리포팅**:
- CI/CD 파이프라인에서 snapshot test 실패 시 빌드 실패
- Snapshot 변경 시 PR 리뷰어가 의도적 변경인지 확인

---

### 5.2 리소스 태깅 전략

**요구사항**:
- CDK App 레벨에서 공통 태그 자동 적용
- 필수 태그:
  - **Project**: `claude-proxy`
  - **Environment**: `{env}` (dev/staging/prod)
  - **ManagedBy**: `cdk`
- 선택 태그:
  - **CostCenter**: v1에서 불필요 (단일 프로젝트)

**성공 기준**:
- 모든 CDK로 생성된 리소스에 필수 태그 자동 적용
- AWS Console 또는 CLI에서 태그로 리소스 필터링 가능

**구현 방법**:
```python
# infra/app.py
from aws_cdk import App, Tags

app = App()

# 공통 태그 적용
Tags.of(app).add("Project", "claude-proxy")
Tags.of(app).add("Environment", app.node.try_get_context("environment") or "dev")
Tags.of(app).add("ManagedBy", "cdk")
```

**태그 확장성**:
- 추가 태그 필요 시 CDK context로 전달 가능:
  ```bash
  cdk deploy -c cost_center=dev-team
  ```
- 스택별 추가 태그는 각 스택 생성자에서 `Tags.of(stack).add()` 호출

**비용 추적**:
- AWS Cost Explorer에서 `Project` 태그로 비용 그룹화
- `Environment` 태그로 dev/staging/prod 비용 분리 추적

---

### 5.3 CDK Stack 업데이트 방식

**요구사항**:
- Unit 3/4에서 `compute_stack.py` **직접 수정** 방식 유지
- Overlay/patch 메커니즘 **불필요**

**성공 기준**:
- Unit 3/4의 Code Generation 단계에서 `compute_stack.py` 수정 사항이 명확히 문서화
- 수정 후 `cdk diff`로 변경 사항 확인 가능

**설정 근거**:
- **직접 수정 방식의 장점**:
  - Overlay/patch 메커니즘은 불필요한 복잡성 추가
  - Unit 3/4의 Functional Design에 수정 지점이 명확히 정의됨 (12.2, 12.3절)
  - CDK 코드는 단순 Python 파일이므로 Git diff로 변경 이력 추적 가능
- **직접 수정 대상**:
  - **Unit 3**: Lambda 코드 경로, 환경변수 값
  - **Unit 4**: ECS 컨테이너 이미지, 환경변수 값, ADOT 설정
- **검증 절차**:
  1. `compute_stack.py` 수정
  2. `cdk diff ComputeStack` 실행하여 변경 사항 확인
  3. `cdk deploy ComputeStack` 실행
  4. CloudWatch Logs에서 Task/Lambda 정상 기동 확인

**코드 리뷰**:
- Unit 3/4 PR에서 `compute_stack.py` 변경 사항 필수 리뷰
- Functional Design 문서와 실제 코드 일치 여부 확인

---

## 6. Observability (관측성)

### 6.1 CloudWatch Logs 보존 기간

**요구사항**:
- prod: **30일**
- dev/staging: **7일**

**성공 기준**:
- 로그 보존 기간 만료 후 자동 삭제
- 비용이 보존 기간에 비례하여 증가

**설정 근거**:
- **현행 유지**:
  - 내부 도구 수준에서 적절한 비용/가시성 균형
  - dev 3일로 줄이면 디버깅 시 로그 유실 가능성 (주말 포함 7일 필요)
  - prod 60일은 비용 대비 이점 낮음 (내부 도구는 장기 감사 로그 불필요)
- **로그 그룹별 보존 기간**:
  - ECS Task Logs: prod 30일, dev/staging 7일
  - Lambda Logs: prod 30일, dev/staging 7일
  - API Gateway Logs: prod 30일, dev/staging 7일

**비용 추정**:
- CloudWatch Logs 비용: 약 $0.50/GB (저장) + $0.03/GB (Insights 쿼리)
- 예상 로그 볼륨: dev 1GB/일, prod 5GB/일
- 월 비용: dev $3.5 (7일), prod $75 (30일)

**로그 아카이빙 (v2 고려)**:
- S3로 로그 내보내기 (장기 보존, 비용 절감)
- CloudWatch Logs → S3 → Glacier (90일 이상 보존)

---

### 6.2 AMP Grafana 대시보드 사전 구성

**요구사항**:
- Unit 1 단계에서 기본 대시보드 **사전 구성 불필요**
- Unit 4 완료 후 **수동 설정으로 충분**

**성공 기준**:
- AMP Workspace가 정상 생성되고 ADOT Collector가 메트릭 전송 성공
- Grafana 대시보드는 Unit 4 완료 후 수동으로 구성

**설정 근거**:
- **Unit 1 단계에서 대시보드 불필요**:
  - Unit 1에서는 메트릭 데이터가 없음 (ECS Service/Task 미생성)
  - 대시보드를 사전 구성해도 검증 불가
  - Amazon Managed Grafana는 CDK 범위 밖으로 별도 프로비저닝 필요
- **Unit 4 완료 후 수동 설정**:
  - Unit 4에서 Gateway 메트릭 emit 시작 후 실제 데이터로 대시보드 구성
  - Grafana 대시보드 JSON을 Git에 커밋하여 재현 가능
- **자동화 계획 (v2)**:
  - Grafana as Code (Terraform `grafana_dashboard` 리소스 또는 Grafana HTTP API)
  - CI/CD 파이프라인에서 대시보드 자동 프로비저닝

**대시보드 구성 항목 (Unit 4 참고)**:
- Bedrock 토큰 사용량 (user/team별)
- Bedrock 비용 사용량 (user/team별)
- Bedrock 요청 지연 시간 (P50, P95, P99)
- ECS Task CPU/Memory 사용률
- Aurora CPU/연결 수
- ALB 요청 수, 5xx 에러율

---

## 7. Availability (가용성)

### 7.1 Aurora 유지보수 창 시간대

**요구사항**:
- 유지보수 창: **일요일 09:00-10:00 UTC** (KST 일요일 18:00-19:00)

**성공 기준**:
- 유지보수 창 시간 내 Aurora 패치 자동 적용
- 유지보수 중 서비스 단절 시간 최소화 (Multi-AZ failover 활용)

**설정 근거**:
- **현행 유지**:
  - 일요일 KST 18:00-19:00은 내부 개발자 사용이 최소인 시간대
  - 운영 시간 충돌 없음
- **Multi-AZ failover**:
  - Aurora Serverless v2는 스토리지 레벨 복제로 failover 시간 짧음 (수십 초 이내)
  - 유지보수 중 writer 인스턴스 교체 시 RDS Proxy가 자동으로 새 writer로 연결

**모니터링**:
- CloudWatch Events에서 Aurora maintenance events 추적
- 유지보수 완료 후 서비스 정상 동작 확인 (health check)

---

### 7.2 ECS Task 롤링 업데이트 전략

**요구사항**:
- Deployment Configuration:
  - **Min healthy percent: 100%**
  - **Max percent: 200%**
- Circuit Breaker: **활성화** (rollback on failure)

**성공 기준**:
- 배포 중 기존 Task가 유지된 채 새 Task 기동 후 교체
- 신규 Task가 health check 실패 시 자동 롤백
- Zero-downtime 배포 보장

**설정 근거**:
- **Min healthy 100%, Max 200%**:
  - 배포 중 기존 Task 유지 (가용성 100% 유지)
  - 신규 Task를 추가 생성 후 health check pass 확인
  - 신규 Task 정상 확인 후 기존 Task 종료
  - 더 보수적인 설정(Min 50%)은 일시적 가용성 저하 가능성
- **Circuit Breaker 활성화**:
  - 신규 Task가 연속 health check 실패 시 자동 롤백
  - 운영자 개입 없이 안전한 배포 보장
- **Health check grace period 60초**:
  - 신규 Task 부팅 시간 고려 (FastAPI 앱 초기화 포함)
  - 60초 내 health check pass 못하면 Task 종료

**배포 절차**:
1. 신규 Task 생성 (Max 200%까지 허용)
2. Health check grace period (60초) 대기
3. 신규 Task가 health check pass
4. ALB Target Group에 신규 Task 등록
5. 기존 Task deregistration delay (30초) 후 종료
6. 모든 Task가 교체될 때까지 반복

**모니터링**:
- ECS deployment events (CloudWatch Events)
- Circuit breaker rollback events 추적

---

## 8. Tech Stack 결정 사항

### 8.1 인프라 기술 스택

| 카테고리 | 기술 | 버전/설정 | 선택 근거 |
|---------|------|----------|----------|
| **IaC** | AWS CDK | Python 3.13 | - System NFR Decisions 7.1절 준수<br>- 타입 안전성 (Python type hints)<br>- 모듈화 (5개 스택 분리)<br>- Context 기반 환경 설정 |
| **Database** | Aurora PostgreSQL | Serverless v2 | - System NFR Decisions 6.1절 준수<br>- 자동 확장 (0.5~1.0 ACU)<br>- Multi-AZ 스토리지 복제<br>- PITR 연속 백업 |
| **Connection Pooling** | RDS Proxy | - | - 연결 멀티플렉싱 (Lambda/ECS 공통)<br>- Secrets Manager 인증<br>- 연결 재사용으로 성능 향상 |
| **Compute** | ECS Fargate | Task: 0.75 vCPU, 1.5GB | - Serverless 컨테이너 (인프라 관리 불필요)<br>- Multi-container task (app + ADOT sidecar)<br>- awsvpc 네트워크 모드 (Security Group 직접 제어) |
| **Function** | Lambda | python3.13, 512MB | - Token Service 전용<br>- VPC 연결 (RDS Proxy 접근)<br>- 저빈도 호출에 적합 |
| **Load Balancing** | ALB | - | - HTTPS 종료 (ACM 인증서)<br>- Path-based routing<br>- Health check (ECS Task) |
| **API Gateway** | API Gateway | REST API, IAM Auth | - Lambda 통합<br>- SigV4 인증 (Token Service)<br>- Regional endpoint |
| **Container Registry** | ECR | Private | - 취약점 스캔 자동화<br>- Lifecycle policy (untagged 30일 삭제) |
| **Secrets** | Secrets Manager | AWS managed key | - RDS 자격증명 자동 생성<br>- Lambda/ECS 자동 주입 |
| **Encryption** | KMS | Customer managed key | - Virtual Key 암호화 전용<br>- 자동 rotation (1년)<br>- 역할별 권한 분리 |
| **Observability** | AMP + CloudWatch | - | - Prometheus 호환 메트릭<br>- ADOT sidecar 수집<br>- CloudWatch Logs 통합 |
| **Networking** | VPC | 10.0.0.0/16 | - Private subnet 우선<br>- VPC Endpoint 기반 AWS 서비스 접근<br>- NAT Gateway 없음 (비용 절감) |

### 8.2 System NFR 준수 확인

| System NFR 항목 | Unit 1 구현 방식 | 준수 여부 |
|----------------|-----------------|----------|
| 7.1 Infrastructure as Code | AWS CDK Python, 5개 스택 모듈화 | ✓ |
| 7.2 멀티 스택 전략 | NetworkStack → DataStack → ObservabilityStack → ComputeStack → ApiStack | ✓ |
| 7.3 컨테이너 전략 | ECS Fargate, 멀티 컨테이너 (app + ADOT sidecar), ECR | ✓ |
| 6.1 데이터베이스 기술 | Aurora PostgreSQL Serverless v2 + RDS Proxy | ✓ |
| 4.1 저장 시 암호화 | KMS (Virtual Key), Aurora 기본 암호화, Secrets Manager | ✓ |
| 4.2 전송 시 암호화 | TLS 1.2+ (ALB, RDS Proxy, VPC Endpoint) | ✓ |
| 4.3 네트워크 보안 | Private subnet, VPC Endpoint, NAT Gateway 없음 | ✓ |
| 4.4 IAM 최소 권한 | 역할별 명시적 리소스 ARN, 와일드카드 최소화 | ✓ |
| 2.1 로깅 형식 | CloudWatch Logs (JSON 구조화는 Unit 4 애플리케이션 레벨) | ✓ |
| 2.2 메트릭 전략 | AMP + ADOT Collector sidecar | ✓ |
| 10.2 타임아웃 설정 | ALB 300s, RDS Proxy 120s | ✓ |

### 8.3 기술 스택 일관성

**Unit 1 이후 유닛과의 일관성**:
- Unit 2 (Shared Models & DB Migration): Aurora PostgreSQL 사용 (Unit 1에서 프로비저닝)
- Unit 3 (Token Service): Lambda python3.13 (Unit 1에서 skeleton 생성)
- Unit 4 (Gateway): ECS Fargate (Unit 1에서 Task Definition 생성)

**기술 스택 변경 불가 항목**:
- AWS CDK Python (다른 IaC 도구 사용 금지)
- Aurora PostgreSQL (MySQL 등 다른 DB 엔진 사용 금지)
- Python 3.13 (다른 버전 사용 금지)

**기술 스택 확장 가능 항목**:
- Context 파라미터 추가 (새로운 설정 추가 가능)
- VPC Endpoint 추가 (새 AWS 서비스 사용 시)
- IAM 정책 확장 (새 리소스 접근 시)

---

## 9. NFR 요구사항 우선순위

| 우선순위 | NFR 카테고리 | 핵심 요구사항 | 비즈니스 영향 |
|---------|------------|--------------|--------------|
| **P0 (Critical)** | Security | 저장/전송 암호화, IAM 최소 권한, Private subnet | 데이터 유출 방지, 컴플라이언스 |
| **P0 (Critical)** | Reliability | Aurora PITR, Multi-AZ, Health check | 데이터 손실 방지, 서비스 가용성 |
| **P1 (High)** | Performance | Aurora 0.5/1.0 ACU, ALB 300s timeout | 사용자 경험, 초기 트래픽 처리 |
| **P1 (High)** | Observability | CloudWatch Logs, AMP | 문제 진단, 운영 메트릭 추적 |
| **P2 (Medium)** | Scalability | Aurora max capacity 확장 절차 | 트래픽 증가 대응 |
| **P2 (Medium)** | Maintainability | CDK snapshot test, 리소스 태깅 | 코드 품질, 운영 편의성 |
| **P3 (Low)** | Availability | 유지보수 창 최적화 | 최소 다운타임 |

**우선순위 정의**:
- **P0 (Critical)**: 미충족 시 시스템 출시 불가 또는 심각한 보안/안정성 문제 발생
- **P1 (High)**: 미충족 시 사용자 경험 저하 또는 운영 부담 증가
- **P2 (Medium)**: 미충족 시 장기 운영에 영향, 단기적으로는 수동 대응 가능
- **P3 (Low)**: 편의성 개선, 미충족 시에도 시스템 정상 동작

---

## 10. 검증 및 승인

### 10.1 NFR 검증 체크리스트

- [ ] 모든 System NFR Decisions 항목이 Unit 1 NFR에 반영됨
- [ ] Functional Design의 설계 결정이 NFR로 정량화됨
- [ ] Questions Round 1의 모든 답변이 NFR 요구사항으로 문서화됨
- [ ] 환경별 차이(dev/staging/prod)가 명확히 정의됨
- [ ] 성공 기준이 측정 가능한 지표로 표현됨
- [ ] Tech Stack이 System NFR과 일관성 유지

### 10.2 승인 이후 단계

본 문서 승인 후:
1. **NFR Design (Unit 1)**: 구체적 설계 명세 (보안 그룹 규칙, IAM 정책 상세)
2. **Infrastructure Design (Unit 1)**: CDK 코드 구조 및 리소스 정의 상세
3. **Code Generation (Unit 1)**: CDK Python 코드 생성
4. **Build & Test (Unit 1)**: `cdk deploy` 및 리소스 검증

---

## 문서 끝

본 문서는 Unit 1: Foundation Infrastructure의 **NFR Requirements**를 완료했다. 모든 비기능 요구사항은 측정 가능한 성공 기준과 함께 정의되었으며, System NFR Decisions 및 Functional Design과 일관성을 유지한다.

**주요 NFR 요약**:
- **Performance**: Aurora 0.5/1.0 ACU, ALB 300s timeout, RDS Proxy 120s borrow timeout
- **Security**: 전송/저장 암호화, IAM 최소 권한, Private subnet 우선, VPC Endpoint policy
- **Reliability**: RPO 5분, RTO 1시간, PITR 활성화, 백업 7일 보존
- **Scalability**: Aurora max capacity 단계적 확장 (1.0 → 2.0 → 4.0 ACU)
- **Maintainability**: CDK snapshot test, 리소스 태깅, 직접 수정 방식
- **Observability**: CloudWatch Logs (prod 30일, dev/staging 7일), AMP + ADOT
- **Availability**: Multi-AZ, 롤링 업데이트 (Min 100%, Max 200%)
- **Tech Stack**: AWS CDK Python, Aurora Serverless v2, ECS Fargate, Lambda python3.13

**다음 단계: NFR Design**
