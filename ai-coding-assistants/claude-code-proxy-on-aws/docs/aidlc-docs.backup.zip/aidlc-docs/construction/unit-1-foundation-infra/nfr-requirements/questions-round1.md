# Unit 1: Foundation Infrastructure - NFR Requirements 질문 (Round 1)

- **유닛**: Unit 1 (Foundation Infrastructure)
- **작성일**: 2026-04-01
- **상태**: Answered

---

## 질문 응답 가이드

각 질문 아래의 `[Answer]:` 줄에 답변을 작성해주세요. 명확한 수치, 구체적인 값, 또는 명시적인 선택을 제공해주시기 바랍니다. "일반적인", "표준", "적당한" 같은 모호한 표현은 추가 질문을 유발할 수 있습니다.

---

## Performance (성능)

### Q1. Aurora Serverless v2 초기 용량 설정
현재 Functional Design에서 Aurora Serverless v2의 최소/최대 용량이 0.5 ACU / 1.0 ACU로 설정되어 있습니다. v1 런칭 초기 예상 동시 사용자 수와 요청 패턴을 고려할 때, 이 용량이 충분한가요?

- 예상 동시 요청 수는 얼마인가요?
- 피크 시간대 DB 연결 수는 어느 정도로 예상하나요?
- 성능 문제 발생 시 용량을 즉시 조정할 수 있는 운영 프로세스가 준비되어 있나요?

[Answer]: 초기 동시 사용자 약 100명, 동시 DB 연결 50~100개 수준 예상. 0.5/1.0 ACU로 시작하되, CloudWatch CPUUtilization 80% 초과 10분 지속 시 CDK context (aurora_max_capacity)를 올려서 cdk deploy로 즉시 조정. 별도 운영 프로세스 불필요.

### Q2. ALB idle timeout 설정
ALB idle timeout이 300초로 설정되어 있습니다. Claude Code의 최대 스트리밍 세션 길이와 thinking 처리 시간을 고려할 때, 300초가 충분한가요? 아니면 더 긴 timeout(예: 600초)이 필요한가요?

[Answer]: 300초 유지. Claude Code의 thinking 포함 최대 응답 시간이 통상 120~180초이므로 300초면 충분한 여유. 600초로 늘리면 비정상 연결이 오래 유지되는 부작용이 있으므로 현 설정 유지.

### Q3. RDS Proxy connection borrow timeout
RDS Proxy의 connection borrow timeout이 120초로 설정되어 있습니다. 피크 시간대에 Aurora 연결이 부족할 경우, 120초 대기 후 타임아웃이 발생합니다. 이 값이 적절한가요, 아니면 더 짧게(예: 60초) 또는 길게(예: 180초) 조정이 필요한가요?

[Answer]: 120초 유지. 동시 사용자 100명 기준 RDS Proxy가 연결 멀티플렉싱을 처리하므로 연결 부족 가능성 낮음. 타임아웃 발생 시 Aurora max capacity 상향이 우선 대응이며, borrow timeout 단축은 불필요.

### Q4. VPC Endpoint 처리량 고려
VPC Endpoint(특히 bedrock-runtime)의 대역폭 제한이 성능에 영향을 줄 수 있습니다. 예상 Bedrock API 호출량(요청/초)은 어느 정도인가요? 초당 100 요청 이하인가요, 아니면 그 이상인가요?

[Answer]: 초당 Bedrock API 호출 10~30 요청 수준 예상 (동시 100명이지만 LLM 응답 시간이 길어 동시 요청은 분산됨). VPC Endpoint 대역폭 제한에 걸릴 가능성 없음. 별도 처리량 고려 불필요.

---

## Security (보안)

### Q5. VPC Flow Logs 활성화 범위
현재 VPC Flow Logs는 context flag로 제어되며 기본값이 활성화입니다. 모든 환경(dev/staging/prod)에서 활성화할 것인가요, 아니면 prod 환경만 활성화할 것인가요?

[Answer]: 모든 환경(dev/staging/prod)에서 활성화. Security Baseline이 blocking constraint로 적용되어 있으므로 dev에서도 네트워크 이상 탐지 필요. 비용은 보존 기간으로 제어 (dev/staging 7일, prod 30일).

### Q6. Aurora 암호화 키 관리
Aurora는 AWS 관리형 RDS 키로 암호화됩니다. 고객 관리형 KMS 키가 필요한 컴플라이언스 요구사항이 있나요? (예: 특정 산업 규제, 키 회전 정책 커스터마이징)

[Answer]: AWS 관리형 RDS 키로 충분. 특정 산업 규제나 컴플라이언스 요구사항 없음 (내부 개발자용 프록시). Virtual Key 암호화는 별도 고객 관리형 KMS 키(alias/{app}-{env}-virtual-key)로 이미 설계됨. Aurora 암호화까지 고객 관리형으로 전환할 필요 없음.

### Q7. VPC Endpoint 정책 세분화
Bedrock Runtime VPC Endpoint 정책이 현재 모든 Bedrock 모델에 대한 접근을 허용합니다. 특정 모델 ARN 패턴으로 제한할 필요가 있나요? (예: `us.anthropic.*` 모델만 허용)

[Answer]: 현행 유지 — VPC Endpoint 레벨에서 모델 제한 불필요. 모델 접근 제어는 Gateway의 10단계 정책 평가 체인(ModelAccessHandler)에서 처리. Endpoint 정책에 모델 ARN을 하드코딩하면 모델 추가 시 인프라 재배포가 필요해져 운영 부담 증가.

### Q8. Security Group 규칙 검증
보안 그룹 매트릭스가 설계되어 있습니다. 추가적인 IP 화이트리스트(예: 특정 사무실 IP에서만 ALB 접근 허용) 또는 포트 제한이 필요한가요?

[Answer]: 추가 IP 화이트리스트 불필요. ALB는 internet-facing이지만 Gateway 인증(x-api-key Virtual Key)으로 접근 제어. 사무실 IP 제한은 VPN/네트워크 레벨이 아닌 Virtual Key 발급 자체로 통제. 현재 보안 그룹 매트릭스(alb-sg: 443 from 0.0.0.0/0)로 충분.

### Q9. KMS Key 접근 제어 세분화
현재 Lambda는 KMS Encrypt/Decrypt 권한을, ECS Task는 Encrypt only 권한을 가집니다. 이 권한 분리가 충분한가요? 추가적인 조건(예: ViaService 조건, 특정 IAM principal만 허용)이 필요한가요?

[Answer]: 현재 권한 분리로 충분. Lambda(Encrypt/Decrypt/GenerateDataKey)와 ECS Task(Encrypt only) 분리가 최소 권한 원칙을 준수. v1에서는 IAM role 기반 분리만으로 충분. 향후 필요 시 kms:EncryptionContext 조건 추가 고려.

---

## Reliability (신뢰성)

### Q10. Aurora 백업 및 복구 정책
Aurora 백업 보존 기간이 7일로 설정되어 있습니다. 비즈니스 요구사항에 따른 RPO(Recovery Point Objective)와 RTO(Recovery Time Objective)는 어떻게 되나요?

- RPO: 데이터 손실 허용 범위 (예: 1시간, 24시간)
- RTO: 복구 소요 시간 목표 (예: 4시간, 8시간)
- 백업 보존 7일이 충분한가요, 아니면 더 긴 기간(예: 14일, 30일)이 필요한가요?

[Answer]: RPO: 5분 (Aurora PITR 기본 연속 백업). RTO: 1시간 (PITR 복원 + 서비스 재연결). 백업 보존 7일로 충분 — 내부 개발자 도구이므로 7일 이상 과거 데이터 복구 필요성 낮음. 데이터 유실 시 Virtual Key 재발급으로 복구 가능.

### Q11. ECS Task Health Check 설정
ECS Task Health Check의 start period가 60초로 설정되어 있습니다. Gateway 애플리케이션의 실제 부팅 시간(DB 연결 초기화, OTel SDK 초기화 포함)은 얼마나 되나요? 60초가 충분한가요?

[Answer]: 60초 유지. Unit 1 skeleton은 nginx:latest로 즉시 기동. Unit 4의 실제 FastAPI 앱도 DB 연결(RDS Proxy) + OTel SDK 초기화 포함 10~15초 이내 부팅 예상. 60초면 충분한 여유. Unit 4 구현 후 실측하여 필요 시 조정.

### Q12. Deletion Protection 정책
prod 환경에서만 Aurora와 ALB deletion protection이 활성화되어 있습니다. staging 환경에서도 실제 데이터가 있거나 장기 운영이 예상되는 경우 deletion protection이 필요한가요?

[Answer]: prod만 활성화 유지. staging은 필요 시 재생성 가능한 환경이며 장기 운영 데이터를 보관하지 않음. staging에서 인프라 변경 테스트 시 deletion protection이 오히려 방해될 수 있음.

---

## Scalability (확장성)

### Q13. Aurora Serverless v2 최대 용량 확장
Aurora 최대 용량이 1.0 ACU입니다. v1 런칭 후 트래픽 급증 시나리오를 고려할 때, 어느 시점에서 최대 용량을 상향 조정할 계획인가요? (예: 동시 사용자 100명 초과 시, DB CPU 80% 초과 10분 지속 시)

[Answer]: CloudWatch CPUUtilization 80% 초과 10분 지속 시 max capacity 상향. 초기 1.0 ACU → 2.0 → 4.0 단계적 조정. CDK context 변경 + cdk deploy로 즉시 반영. v1에서는 수동 모니터링, v2에서 CloudWatch Alarm + SNS 알림 고려.

### Q14. Lambda Token Service 동시성 제한
Lambda 함수에 예약 동시성(reserved concurrency) 제한이 설정되어 있지 않습니다. 계정 기본 한도로 충분한가요, 아니면 특정 값(예: 100)으로 제한하여 다른 Lambda 함수의 동시성을 보호할 필요가 있나요?

[Answer]: 예약 동시성 미설정, 계정 기본 한도로 충분. Token Service 호출 빈도가 매우 낮음 (사용자당 최초 1회 발급, 이후 간헐적 조회). 다른 Lambda 함수도 없으므로 동시성 경합 없음. 향후 Lambda 함수 추가 시 재검토.

### Q15. ECS Task Auto-scaling 사전 고려
Unit 4에서 ECS Auto-scaling을 구현할 예정입니다. Unit 1 단계에서 최대 Task 수 제한(예: 10개)이나 최소 Task 수(예: 2개)를 미리 결정해둘 필요가 있나요?

[Answer]: Unit 1에서 사전 결정 불필요. ECS Service 자체가 Unit 4 scope이므로 Auto-scaling 설정도 Unit 4에서 결정. 다만 참고값으로: 최소 Task dev 1 / staging·prod 2, 최대 Task 10개를 Unit 4 설계 시 기준으로 사용.

---

## Maintainability (유지보수성)

### Q16. CDK 테스트 전략
CDK 코드의 품질 검증을 위해 `cdk synth` 성공 여부만 확인할 것인가요, 아니면 CDK snapshot test 또는 integration test를 추가할 것인가요?

[Answer]: cdk synth 성공 + snapshot test 적용. snapshot test로 의도치 않은 리소스 변경 감지 (Security Group 규칙 변경, IAM 정책 변경 등). integration test(실제 배포)는 Build & Test 단계에서 수행하므로 Unit 1 코드 레벨에서는 synth + snapshot으로 충분. pytest + aws-cdk-lib assertions 모듈 사용.

### Q17. 리소스 태깅 전략
현재 리소스 명명 규칙은 정의되어 있지만, AWS 리소스 태그(예: Environment, Project, CostCenter)를 자동으로 추가할 필요가 있나요?

[Answer]: CDK App 레벨에서 공통 태그 자동 적용. 태그: Project: claude-proxy, Environment: {env}, ManagedBy: cdk. CostCenter 태그는 v1에서 불필요 (단일 프로젝트). 추가 태그 필요 시 CDK context로 확장 가능.

### Q18. CDK Stack 업데이트 방식
Unit 3/4에서 `compute_stack.py`를 직접 수정하는 전략이 설계되어 있습니다. 이 방식이 충분한가요, 아니면 별도의 overlay 또는 patch 파일로 분리하는 것이 선호되나요?

[Answer]: 직접 수정 방식 유지. overlay/patch 메커니즘은 불필요한 복잡성 추가. Unit 3/4의 Code Generation 단계에서 compute_stack.py 수정 사항이 명확히 문서화되어 있으므로 (Functional Design 12.2, 12.3절) 직접 수정으로 충분.

---

## Observability (관측성)

### Q19. CloudWatch Logs 보존 기간
현재 prod 30일, dev/staging 7일로 설정되어 있습니다. 비용 대비 적절한가요? 더 짧게(예: dev 3일) 또는 길게(예: prod 60일) 조정이 필요한가요?

[Answer]: 현행 유지 (prod 30일, dev/staging 7일). 내부 도구 수준에서 적절한 비용/가시성 균형. dev 3일로 줄이면 디버깅 시 로그 유실 가능성. prod 60일은 비용 대비 이점 낮음.

### Q20. AMP Grafana 대시보드 사전 구성
AMP Workspace는 Unit 1에서 생성되지만, Grafana 대시보드는 수동 구성으로 계획되어 있습니다. Unit 1 단계에서 기본 대시보드를 코드로 프로비저닝할 필요가 있나요, 아니면 Unit 4 완료 후 수동 설정으로 충분한가요?

[Answer]: Unit 4 완료 후 수동 설정으로 충분. Unit 1 단계에서는 메트릭 데이터가 없으므로 대시보드를 사전 구성해도 검증 불가. Amazon Managed Grafana는 CDK 범위 밖으로 별도 프로비저닝. v2에서 Grafana as Code (Terraform/API) 고려.

---

## Availability (가용성)

### Q21. Aurora 유지보수 창 시간대
Aurora 유지보수 창이 일요일 09:00-10:00 UTC (KST 일요일 18:00-19:00)로 설정되어 있습니다. 이 시간대가 운영 시간과 충돌하지 않나요? 조정이 필요한가요?

[Answer]: 현행 유지. 일요일 KST 18:00-19:00은 내부 개발자 사용이 최소인 시간대. 운영 시간 충돌 없음.

### Q22. ECS Task 롤링 업데이트 전략
ECS 배포 설정이 Min healthy 100%, Max 200%입니다. 이는 배포 중 기존 Task를 유지한 채 새 Task를 먼저 기동하므로 zero-downtime을 보장합니다. 이 전략이 적절한가요, 아니면 더 보수적인 설정(예: Min 50%, Max 100%)이 필요한가요?

[Answer]: Min healthy 100%, Max 200% 유지. Zero-downtime 배포 보장. 배포 중 기존 Task 유지 + 새 Task 기동 후 교체. 더 보수적인 설정(Min 50%)은 일시적 가용성 저하 가능성이 있으므로 불필요.

---

## 응답 완료 후

모든 질문에 답변을 완료한 후, 이 파일을 저장하고 AI-DLC 에이전트에게 알려주세요. 답변 내용을 바탕으로 `nfr-requirements.md`와 `tech-stack-decisions.md` 문서를 생성하겠습니다.
