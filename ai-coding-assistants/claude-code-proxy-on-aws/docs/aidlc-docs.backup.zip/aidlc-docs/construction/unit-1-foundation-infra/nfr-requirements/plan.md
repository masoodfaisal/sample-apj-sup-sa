# Unit 1: Foundation Infrastructure - NFR Requirements 계획

- **유닛**: Unit 1 (Foundation Infrastructure)
- **작성일**: 2026-04-01
- **상태**: Completed

---

## 계획 개요

본 계획은 Unit 1 (Foundation Infrastructure)의 비기능 요구사항(NFR) 및 기술 스택 결정 사항을 수립하기 위한 세부 작업 계획이다.

Unit 1은 인프라 유닛으로, 일반적인 애플리케이션 NFR(예: 응답 시간, 처리량)보다는 **인프라 자체의 품질 속성**에 초점을 맞춘다:
- 네트워크 보안 (VPC Endpoint, Security Group, Private connectivity)
- 암호화 (저장 시/전송 시)
- IAM 최소 권한 원칙
- 모니터링/관측성 (CloudWatch, AMP)
- 백업/복구 (Aurora PITR)
- CDK 코드 품질 (테스트, Synth 검증)
- 배포 안정성 (Rolling update, Health check)

---

## NFR 평가 체크리스트

### 1. Performance (인프라 성능)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- Aurora Serverless v2 용량 목표 (Min/Max ACU)
- RDS Proxy 연결 타임아웃 설정
- ALB idle timeout (스트리밍 지원)
- VPC Endpoint latency 고려

### 2. Security (보안)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- 저장 시 암호화 (Aurora, KMS, Secrets Manager)
- 전송 시 암호화 (TLS 1.2+)
- 네트워크 격리 (Private subnet, VPC Endpoint)
- IAM 최소 권한
- VPC Endpoint 정책
- NAT 없는 기본 egress 통제

### 3. Reliability (신뢰성)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- Aurora Multi-AZ 스토리지 복제
- RDS Proxy 연결 풀 관리
- ECS Task Health Check
- ALB Health Check
- Aurora PITR 및 백업 보존
- Deletion protection (prod)

### 4. Scalability (확장성)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- Aurora Serverless v2 자동 확장
- ECS Fargate Task 수평 확장 준비 (Unit 4에서 Auto-scaling 적용)
- Lambda 동시성 제한 설정
- ALB Target Group 용량

### 5. Maintainability (유지보수성)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- CDK 코드 모듈화 (5개 스택)
- 리소스 명명 규칙 일관성
- Context 기반 환경 설정
- Cross-stack 참조 전략
- CDK 테스트 전략 (Synth, Snapshot)

### 6. Observability (관측성)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- CloudWatch Logs (VPC Flow, ECS, Lambda, API Gateway)
- CloudWatch Container Insights (ECS)
- AMP Workspace 및 ADOT Collector 설정
- 로그 보존 기간 (환경별)
- 알람 설정 (Aurora CPU, ALB 5xx, ECS Task 실패)

### 7. Availability (가용성)
- [x] 요구사항 수집 완료
- [x] 분석 완료
- [x] 문서화 완료

**평가 항목**:
- Multi-AZ 배포 (Aurora, ALB, ECS)
- 유지보수 창 설정
- 백업/복구 RPO/RTO 목표
- ECS Task 롤링 업데이트 전략

---

## Tech Stack 평가 체크리스트

### 기술 스택 결정
- [x] System NFR Decisions 검토 완료
- [x] 필수 기술 스택 확인 완료 (Python 3.13, CDK, Aurora, ECS Fargate)
- [x] CDK 구성 전략 문서화 완료
- [x] 이전 유닛과의 일관성 확인 완료 (Unit 1이 첫 번째 유닛이므로 해당 없음)

**주요 기술 스택**:
- IaC: AWS CDK Python
- Database: Aurora PostgreSQL Serverless v2
- Compute: ECS Fargate, Lambda (python3.13)
- API: API Gateway REST API (IAM Auth), ALB
- Observability: CloudWatch Logs, AMP, ADOT Collector
- Security: KMS, Secrets Manager, VPC Endpoint

---

## 질문 생성 단계

다음 필수 질문을 사용자에게 제시한다:

### Performance 질문
1. Aurora Serverless v2 용량 설정 (0.5 ACU ~ 1.0 ACU)이 예상 트래픽을 충분히 처리할 수 있는가? v1에서 동시 요청 수 예상치는?
2. ALB idle timeout 300초는 최대 스트리밍 시간을 충분히 커버하는가?
3. RDS Proxy connection borrow timeout 120초가 피크 시간대 연결 대기 시간으로 적절한가?

### Security 질문
4. NAT Gateway 없는 기본 배포 모드를 유지할 것인가, 아니면 특정 외부 연동을 위한 예외 egress 경로가 필요한가?
5. Aurora 암호화에 AWS 관리형 RDS 키를 사용하는 것이 충분한가, 아니면 고객 관리형 KMS 키가 필요한가?
6. VPC Endpoint 정책 범위가 충분히 제한적인가? 예를 들어, Bedrock Endpoint는 전체 서비스 접근 허용으로 설정되어 있는데 특정 모델로 제한이 필요한가?

### Reliability 질문
7. Aurora 백업 보존 기간 7일이 복구 요구사항을 충족하는가? RPO/RTO 목표는 무엇인가?
8. ECS Task Health Check (interval 30s, timeout 5s, retries 3)가 애플리케이션 부팅 시간을 충분히 커버하는가?
9. prod 환경에서 deletion protection 활성화 외에 추가 보호 장치(예: MFA delete, CloudTrail 모니터링)가 필요한가?

### Scalability 질문
10. Aurora Serverless v2의 최대 용량 1.0 ACU가 v1 런칭 후 예상 peak 트래픽을 처리하기에 충분한가? 더 높은 용량이 필요한 시나리오는?
11. Lambda Token Service에 예약 동시성(reserved concurrency) 제한이 필요한가, 아니면 계정 기본 한도로 충분한가?
12. ECS Task 수평 확장은 Unit 4에서 Auto-scaling으로 구현 예정인데, Unit 1 단계에서 고려해야 할 사전 설정(예: 최대 Task 수 제한)이 있는가?

### Maintainability 질문
13. CDK 테스트 전략: `cdk synth` 검증만으로 충분한가, 아니면 snapshot test 또는 integration test가 필요한가?
14. 리소스 명명 규칙에 추가 규칙(예: 비용 센터, 프로젝트 태그)이 필요한가?
15. CDK Stack 업데이트 정책: Unit 3/4에서 compute_stack.py를 직접 수정하는 전략이 바람직한가, 아니면 별도 overlay/patch 메커니즘이 필요한가?

### Observability 질문
16. CloudWatch Logs 보존 기간 (prod 30일, dev/staging 7일)이 충분한가? 비용 대비 적절한 기간인가?
17. AMP Workspace에 Grafana 대시보드를 사전 구성해야 하는가, 아니면 Unit 4 이후 수동 설정으로 충분한가?
18. v1 운영 추적은 CloudWatch Logs와 AMP만으로 충분한가, 아니면 별도 네트워크 감사 로그가 필요한가?

### Availability 질문
19. Aurora 유지보수 창 (일요일 09:00-10:00 UTC, KST 18:00-19:00)이 운영 시간과 충돌하지 않는가?
20. ECS Task 롤링 업데이트 설정 (Min healthy 100%, Max 200%)이 배포 중 가용성을 보장하는가? Zero-downtime 배포가 필수 요구사항인가?

---

## 산출물 체크리스트

- [x] `nfr-requirements.md` 작성 완료
- [x] Tech Stack은 nfr-requirements.md의 Section 8에 통합 작성 완료
- [x] System NFR Decisions와의 일관성 확인 완료
- [ ] 사용자 승인 대기

---

## 다음 단계

NFR Requirements 완료 후:
1. NFR Design (Unit 1) — 구체적 설계 명세
2. Infrastructure Design (Unit 1) — CDK 상세 구현 명세
3. Code Generation (Unit 1) — CDK Python 코드 생성
