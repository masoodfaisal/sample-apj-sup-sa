# Unit 1: Foundation Infrastructure - NFR Design

- **문서 버전**: v1.0
- **작성일**: 2026-04-01
- **상태**: Final
- **단계**: CONSTRUCTION - NFR Design
- **근거 문서**:
  - [NFR Requirements](../nfr-requirements/nfr-requirements.md)
  - [Functional Design](../functional-design/functional-design.md)
  - [System NFR Decisions](../../../construction/system-nfr-decisions.md)

---

## 문서 개요

본 문서는 Unit 1 (Foundation Infrastructure)의 NFR 요구사항을 구현하기 위한 구체적인 설계 패턴, 아키텍처 컴포넌트, 구현 전략을 정의한다.

NFR Requirements에서 정의된 각 비기능 요구사항(Performance, Security, Reliability, Scalability, Maintainability, Observability, Availability)을 CDK 인프라 코드로 구현하기 위한 상세 명세를 제공한다.

---

## 1. NFR Design 패턴 카탈로그

### 1.1 Resilience Patterns (신뢰성 패턴)

#### 1.1.1 Database Point-in-Time Recovery (PITR)

**문제 해결**: 데이터 손상 또는 운영 실수로 인한 데이터 유실 방지

**솔루션 접근**:
- Aurora Serverless v2의 연속 백업 기능 활용
- WAL(Write-Ahead Log) 기반 5분 단위 복원 지점 제공
- 백업 보존 기간 7일로 설정하여 최근 일주일 내 임의 시점 복구 가능

**품질 속성**: Reliability (RPO 5분, RTO 1시간)

**Trade-offs**:
- 비용: 백업 스토리지 비용 발생 (보존 기간에 비례)
- 복원 시간: 백업 크기에 따라 복원 시간 변동 (예상 10~30분)
- 복잡성: 복원 절차 문서화 및 정기 테스트 필요

**구현 노트**:
```python
# CDK DataStack
aurora_cluster = rds.DatabaseCluster(
    self, "AuroraCluster",
    backup=rds.BackupProps(
        retention=Duration.days(7),
        preferred_window="02:00-03:00"  # UTC, 트래픽 최소 시간대
    ),
    point_in_time_recovery=True  # PITR 활성화
)
```

#### 1.1.2 Multi-AZ Storage Replication

**문제 해결**: 단일 AZ 장애 시 데이터베이스 가용성 보장

**솔루션 접근**:
- Aurora Serverless v2는 스토리지 레벨에서 자동으로 3개의 AZ에 6개 복제본 유지
- Writer 인스턴스 장애 시 스토리지는 유지되며 새 Writer로 빠르게 failover (수십 초)
- RDS Proxy를 사용하여 애플리케이션 레벨에서 failover 투명하게 처리

**품질 속성**: Availability (Multi-AZ), Reliability (자동 장애 복구)

**Trade-offs**:
- 비용: Multi-AZ 스토리지 복제 비용 (단일 AZ 대비 약 2배)
- 일관성: Failover 시 최대 수십 초 쓰기 불가 (읽기는 가능)
- 운영: Failover 이벤트 모니터링 및 알람 설정 필요

**구현 노트**:
```python
# Aurora Serverless v2는 기본적으로 Multi-AZ 스토리지 복제 제공
# 추가 설정 불필요, 단 RDS Proxy는 명시적으로 Multi-AZ 서브넷 그룹 설정
db_subnet_group = rds.SubnetGroup(
    self, "DbSubnetGroup",
    subnets=network_stack.private_data_subnets,  # 2 AZ
    vpc=network_stack.vpc
)
```

#### 1.1.3 ECS Task Health Check with Grace Period

**문제 해결**: ECS Task 부팅 중 조기 종료 방지 및 비정상 Task 자동 교체

**솔루션 접근**:
- Container health check: 애플리케이션 `/healthz` endpoint 30초 간격 확인
- Start period 60초: 부팅 시간 고려하여 health check 실패를 무시
- Unhealthy threshold 3회: 연속 3회 실패 시 Task 종료
- ALB health check grace period 60초: ECS Service 레벨에서도 부팅 시간 고려

**품질 속성**: Availability (자동 복구), Reliability (비정상 Task 격리)

**Trade-offs**:
- 복구 시간: Health check 간격 30초 × 3회 = 최대 90초 후 Task 교체
- 부팅 시간: Start period 60초 내 부팅 못하면 Task 반복 재시작
- 비용: 비정상 Task 조기 종료로 리소스 절약

**구현 노트**:
```python
# ECS Task Definition - App Container
app_container = task_definition.add_container(
    "gateway-app",
    health_check=ecs.HealthCheck(
        command=["CMD-SHELL", "curl -f http://localhost:8000/healthz || exit 1"],
        interval=Duration.seconds(30),
        timeout=Duration.seconds(5),
        retries=3,
        start_period=Duration.seconds(60)
    )
)

# ECS Service (Unit 4에서 생성)
ecs_service = ecs.FargateService(
    self, "GatewayService",
    health_check_grace_period=Duration.seconds(60)
)
```

#### 1.1.4 Circuit Breaker for ECS Deployment

**문제 해결**: 배포 실패 시 자동 롤백으로 서비스 가용성 보호

**솔루션 접근**:
- ECS Circuit Breaker 활성화: 배포 중 health check 실패 시 자동 롤백
- Failure threshold: 연속 2회 Task health check 실패
- Rollback 전략: 이전 Task Definition으로 자동 복원

**품질 속성**: Availability (배포 안전성), Reliability (자동 복구)

**Trade-offs**:
- 배포 속도: Circuit breaker 판단 시간 추가 (약 2~3분)
- 롤백 비용: 롤백 후 재배포 시 다시 전체 배포 시간 소요
- 운영: Circuit breaker 발동 시 근본 원인 분석 필요

**구현 노트**:
```python
# ECS Service (Unit 4에서 생성)
ecs_service = ecs.FargateService(
    self, "GatewayService",
    circuit_breaker=ecs.DeploymentCircuitBreaker(
        rollback=True  # 실패 시 자동 롤백
    )
)
```

---

### 1.2 Scalability Patterns (확장성 패턴)

#### 1.2.1 Aurora Serverless v2 Auto-scaling

**문제 해결**: 트래픽 증가에 따른 데이터베이스 용량 자동 확장

**솔루션 접근**:
- Min/Max ACU 설정으로 용량 범위 정의 (초기: 0.5/1.0 ACU)
- CloudWatch CPUUtilization 모니터링으로 확장 트리거 결정 (80% 초과 10분 지속)
- CDK context 기반 즉시 조정 가능 (`cdk deploy -c aurora_max_capacity=2.0`)

**품질 속성**: Scalability (자동 확장), Performance (CPU 80% 미만 유지)

**Trade-offs**:
- 비용: Max ACU 증가 시 비용 증가 (사용량 기반 과금)
- 확장 속도: Aurora는 실시간 확장하지만, max 한도 변경은 배포 필요
- 운영: CPU 모니터링 및 수동 조정 필요 (v1에서는 자동화 없음)

**구현 노트**:
```python
# CDK DataStack
aurora_max_capacity = self.node.try_get_context("aurora_max_capacity") or 1.0
aurora_cluster = rds.DatabaseCluster(
    self, "AuroraCluster",
    serverless_v2_min_capacity=0.5,
    serverless_v2_max_capacity=aurora_max_capacity
)

# CloudWatch Alarm (v2에서 추가 예정)
# cpu_alarm = cloudwatch.Alarm(
#     self, "AuroraCpuAlarm",
#     metric=aurora_cluster.metric_cpu_utilization(),
#     threshold=80,
#     evaluation_periods=2,
#     datapoints_to_alarm=2
# )
```

#### 1.2.2 RDS Proxy Connection Multiplexing

**문제 해결**: Lambda/ECS의 많은 DB 연결 요청을 연결 풀로 효율화

**솔루션 접근**:
- RDS Proxy가 애플리케이션과 Aurora 사이에서 연결 풀 관리
- 최대 연결 비율 100% (Aurora max_connections의 100% 활용)
- Connection borrow timeout 120초로 연결 부족 시 대기
- Idle client timeout 1800초로 유휴 연결 재사용

**품질 속성**: Scalability (연결 효율화), Performance (연결 대기 시간 단축)

**Trade-offs**:
- 복잡성: RDS Proxy 추가 레이어로 디버깅 어려움
- 비용: RDS Proxy 인스턴스 비용 (시간당 $0.015)
- Latency: Proxy 홉 추가로 약 1~2ms latency 증가

**구현 노트**:
```python
# CDK DataStack
rds_proxy = rds.DatabaseProxy(
    self, "RdsProxy",
    proxy_target=rds.ProxyTarget.from_cluster(aurora_cluster),
    secrets=[db_secret],
    db_proxy_name=f"{app_name}-{env}-rds-proxy",
    max_connections_percent=100,  # 기본값
    max_idle_connections_percent=50,  # 기본값
    borrow_timeout=Duration.seconds(120),
    idle_client_timeout=Duration.seconds(1800),
    vpc=network_stack.vpc,
    vpc_subnets=ec2.SubnetSelection(subnets=network_stack.private_data_subnets)
)
```

#### 1.2.3 ECS Task Rolling Update Strategy

**문제 해결**: 배포 중 서비스 가용성 유지 (Zero-downtime deployment)

**솔루션 접근**:
- Min healthy percent 100%: 기존 Task 유지하며 신규 Task 추가 기동
- Max percent 200%: 최대 기존 Task의 2배까지 동시 실행 허용
- Health check grace period 60초: 신규 Task 부팅 시간 고려
- Deregistration delay 30초: 기존 Task 종료 전 연결 드레인

**품질 속성**: Availability (배포 중 무중단), Scalability (순차 배포)

**Trade-offs**:
- 비용: 배포 중 일시적으로 Task 수 2배 증가 (약 2~3분)
- 배포 속도: Min 100% 설정으로 배포 시간 증가 (Task별 순차 교체)
- 리소스: 배포 중 ALB Target Group에 Task 2배 등록

**구현 노트**:
```python
# ECS Service (Unit 4에서 생성)
ecs_service = ecs.FargateService(
    self, "GatewayService",
    deployment_configuration=ecs.DeploymentConfiguration(
        minimum_healthy_percent=100,
        maximum_percent=200
    )
)
```

---

### 1.3 Performance Patterns (성능 패턴)

#### 1.3.1 ALB Idle Timeout for Long-polling

**문제 해결**: Claude Code의 thinking 포함 장시간 응답 처리

**솔루션 접근**:
- ALB idle timeout 300초 (5분)로 설정
- Claude Code 최대 응답 시간 180초 대비 1.67배 여유
- 비정상 연결 방지를 위해 600초로 늘리지 않음

**품질 속성**: Performance (응답 시간 충족), Availability (timeout 방지)

**Trade-offs**:
- 비용: 장시간 연결 유지로 ALB 연결 수 증가 (비용 영향 미미)
- 리소스: 비정상 연결 유지 시 ALB/ECS Task 리소스 낭비
- 모니터링: 504 Gateway Timeout 발생 시 timeout 재조정 필요

**구현 노트**:
```python
# CDK ApiStack
alb = elbv2.ApplicationLoadBalancer(
    self, "Alb",
    idle_timeout=Duration.seconds(300)
)
```

#### 1.3.2 RDS Proxy Connection Borrow Timeout

**문제 해결**: 피크 시간대 DB 연결 부족 시 대기 시간 확보

**솔루션 접근**:
- Borrow timeout 120초로 연결 부족 시 대기
- DB 쿼리 timeout (30초) 대비 4배 여유
- 연결 부족 발생 시 우선 Aurora max capacity 상향

**품질 속성**: Performance (연결 대기 시간 최소화), Availability (연결 부족 방지)

**Trade-offs**:
- 사용자 경험: 연결 대기 시 응답 시간 증가 (최대 120초)
- 확장 전략: Borrow timeout 초과 빈번하면 Aurora max capacity 상향 필요
- 모니터링: ConnectionBorrowTimeout 메트릭 추적 필요

**구현 노트**:
```python
# RDS Proxy 설정 (1.2.2 참조)
# borrow_timeout=Duration.seconds(120)
```

#### 1.3.3 VPC Endpoint 대역폭 최적화

**문제 해결**: Bedrock API 호출 시 네트워크 latency 최소화

**솔루션 접근**:
- VPC Endpoint를 private-app subnet에 배치하여 NAT Gateway 우회
- Bedrock Runtime Endpoint 전용 보안 그룹으로 트래픽 격리
- VPC Endpoint는 자동 확장되므로 사전 용량 설정 불필요

**품질 속성**: Performance (latency 최소화), Cost Efficiency (NAT Gateway 비용 절감)

**Trade-offs**:
- 비용: VPC Endpoint 시간당 비용 ($0.01/hr) vs NAT Gateway ($0.045/hr + 데이터 전송 비용)
- 관리: Endpoint 정책 및 보안 그룹 관리 복잡도 증가
- 확장성: VPC Endpoint는 자동 확장하지만, 극단적 트래픽 시 AWS 한도 검토 필요

**구현 노트**:
```python
# CDK NetworkStack
bedrock_endpoint = vpc.add_interface_endpoint(
    "BedrockRuntimeEndpoint",
    service=ec2.InterfaceVpcEndpointAwsService.BEDROCK_RUNTIME,
    subnets=ec2.SubnetSelection(subnets=private_app_subnets),
    security_groups=[endpoint_sg],
    private_dns_enabled=True
)
```

---

### 1.4 Security Patterns (보안 패턴)

#### 1.4.1 Defense in Depth - Network Segmentation

**문제 해결**: 네트워크 레벨에서 공격 표면 최소화

**솔루션 접근**:
- 3계층 서브넷: Public (ALB), Private-app (ECS/Lambda), Private-data (Aurora)
- 보안 그룹 매트릭스로 최소 권한 트래픽만 허용
- Private subnet 우선 전략: 인터넷 접근 불필요한 리소스는 모두 Private

**품질 속성**: Security (네트워크 격리), Compliance (최소 권한 원칙)

**Trade-offs**:
- 복잡성: 3계층 서브넷 + 5개 보안 그룹 관리
- 디버깅: Private subnet 리소스는 VPN/Bastion 통해서만 접근
- 비용: VPC Endpoint 비용 (NAT Gateway 대비 저렴하지만 여러 Endpoint 필요)

**구현 노트**:
```python
# CDK NetworkStack
# Public subnet: ALB만 배치
public_subnets = [
    ec2.Subnet(self, "PublicSubnet2a", cidr_block="10.0.0.0/24", availability_zone="ap-northeast-2a"),
    ec2.Subnet(self, "PublicSubnet2c", cidr_block="10.0.1.0/24", availability_zone="ap-northeast-2c")
]

# Private-app subnet: ECS, Lambda, VPC Endpoints
private_app_subnets = [
    ec2.Subnet(self, "PrivateAppSubnet2a", cidr_block="10.0.16.0/20", availability_zone="ap-northeast-2a"),
    ec2.Subnet(self, "PrivateAppSubnet2c", cidr_block="10.0.32.0/20", availability_zone="ap-northeast-2c")
]

# Private-data subnet: Aurora, RDS Proxy
private_data_subnets = [
    ec2.Subnet(self, "PrivateDataSubnet2a", cidr_block="10.0.48.0/24", availability_zone="ap-northeast-2a"),
    ec2.Subnet(self, "PrivateDataSubnet2c", cidr_block="10.0.49.0/24", availability_zone="ap-northeast-2c")
]
```

#### 1.4.2 Encryption at Rest and in Transit

**문제 해결**: 저장 및 전송 데이터 암호화로 데이터 유출 방지

**솔루션 접근**:
- **저장 시 암호화**:
  - Aurora: AWS 관리형 RDS 키 (자동 암호화)
  - Virtual Key: 고객 관리형 KMS 키 (키 회전 1년, 역할별 권한 분리)
  - Secrets Manager: AWS 관리형 키
- **전송 시 암호화**:
  - ALB: TLS 1.2+ (ELBSecurityPolicy-TLS13-1-2-2021-06)
  - RDS Proxy: TLS 1.2+ 강제
  - VPC Endpoint: AWS PrivateLink로 AWS 백본 네트워크 통신

**품질 속성**: Security (데이터 보호), Compliance (암호화 표준 준수)

**Trade-offs**:
- 비용: KMS 키 요청 비용 ($0.03/10,000 requests), KMS 키 유지 비용 ($1/month)
- 성능: KMS 암복호화 latency 추가 (약 5~10ms)
- 복잡성: KMS 키 정책 관리 및 역할별 권한 분리

**구현 노트**:
```python
# CDK DataStack - Aurora
aurora_cluster = rds.DatabaseCluster(
    self, "AuroraCluster",
    storage_encrypted=True  # AWS 관리형 RDS 키 사용
)

# CDK ComputeStack - KMS Key
kms_key = kms.Key(
    self, "VirtualKeyKmsKey",
    alias=f"alias/{app_name}-{env}-virtual-key",
    enable_key_rotation=True,  # 자동 rotation 1년
    pending_window=Duration.days(30)
)

# Lambda Token Service: Encrypt/Decrypt
kms_key.grant_encrypt_decrypt(lambda_execution_role)

# ECS Gateway Task: Encrypt only (Admin rotate)
kms_key.grant_encrypt(ecs_task_role)

# CDK ApiStack - ALB TLS
alb_listener = alb.add_listener(
    "HttpsListener",
    port=443,
    protocol=elbv2.ApplicationProtocol.HTTPS,
    certificates=[elbv2.ListenerCertificate.from_arn(acm_cert_arn)],
    ssl_policy=elbv2.SslPolicy.TLS13_1_2_2021_06
)
```

#### 1.4.3 IAM Least Privilege with Resource-level Permissions

**문제 해결**: IAM 역할별 최소 권한 부여로 권한 남용 방지

**솔루션 접근**:
- 모든 IAM 정책은 특정 리소스 ARN으로 제한 (와일드카드 최소화)
- 역할별 권한 분리:
  - Lambda Token Service: KMS Encrypt/Decrypt (Virtual Key 발급/조회)
  - ECS Gateway Task: KMS Encrypt only (Admin rotate), Bedrock, AMP, Identity Store
  - ECS Execution Role: ECR, Secrets Manager, CloudWatch Logs
- CDK grant 메서드로 inline policy 자동 생성

**품질 속성**: Security (최소 권한), Compliance (IAM 모범 사례)

**Trade-offs**:
- 복잡성: 역할별 세밀한 권한 관리 필요
- 유지보수: 리소스 ARN 변경 시 IAM 정책 업데이트 필요
- 디버깅: 권한 부족 에러 발생 시 정확한 권한 범위 파악 어려움

**구현 노트**:
```python
# CDK ComputeStack - Lambda Execution Role
lambda_execution_role = iam.Role(
    self, "TokenServiceExecutionRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
    inline_policies={
        "KmsAccess": iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    effect=iam.Effect.ALLOW,
                    actions=["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey"],
                    resources=[kms_key.key_arn]  # 특정 KMS 키만
                )
            ]
        )
    }
)

# CDK grant 메서드로 Secrets Manager 권한 자동 부여
db_secret.grant_read(lambda_execution_role)
```

#### 1.4.4 VPC Endpoint Policy Scoping

**문제 해결**: VPC Endpoint를 통한 비인가 AWS 서비스 접근 차단

**솔루션 접근**:
- Bedrock Runtime Endpoint: 모든 모델 접근 허용 (애플리케이션 레벨에서 제어)
- S3 Gateway Endpoint: ECR 이미지 레이어 버킷만 허용
- 기타 Interface Endpoint: aws:PrincipalAccount 조건으로 계정/리전 제한

**품질 속성**: Security (네트워크 접근 제어), Compliance (최소 권한 원칙)

**Trade-offs**:
- 운영: Endpoint 정책 변경 시 인프라 재배포 필요
- 확장성: 새 AWS 서비스 추가 시 Endpoint 및 정책 추가 필요
- 복잡성: Endpoint별 정책 관리 부담

**구현 노트**:
```python
# CDK NetworkStack - Bedrock Endpoint Policy
bedrock_endpoint_policy = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.AnyPrincipal()],
            actions=["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"],
            resources=["*"]  # 모든 모델 허용
        )
    ]
)

# S3 Gateway Endpoint Policy (ECR 전용)
s3_endpoint_policy = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.AnyPrincipal()],
            actions=["s3:GetObject"],
            resources=["arn:aws:s3:::prod-ap-northeast-2-starport-layer-bucket/*"]
        )
    ]
)

# 기타 Interface Endpoint Policy (계정 제한)
default_endpoint_policy = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.AnyPrincipal()],
            actions=["*"],
            resources=["*"],
            conditions={
                "StringEquals": {
                    "aws:PrincipalAccount": Aws.ACCOUNT_ID
                }
            }
        )
    ]
)
```

#### 1.4.5 Private Connectivity by Default

**문제 해결**: 불필요한 인터넷 egress와 NAT 의존으로 인한 공격 표면 및 운영 복잡도 증가 방지

**솔루션 접근**:
- 기본 배포 모드에서는 NAT Gateway를 두지 않는다.
- 애플리케이션/데이터 계층은 private subnet에만 배치한다.
- AWS 서비스 접근은 VPC Endpoint와 endpoint policy를 통해서만 허용한다.
- public subnet은 ingress ALB처럼 외부 진입점에 한정한다.

**품질 속성**: Security (egress 통제), Cost Efficiency (NAT 비용 제거)

**Trade-offs**:
- 운영: 새 AWS 서비스 추가 시 필요한 Endpoint를 함께 정의해야 한다.
- 배포 제약: 인터넷 egress가 필요한 워크로드는 별도 예외 설계가 필요하다.
- 복잡성: Route table과 endpoint inventory를 명시적으로 관리해야 한다.

**구현 노트**:
```python
# CDK NetworkStack
vpc = ec2.Vpc(
    self, "Vpc",
    nat_gateways=0,
    subnet_configuration=[
        ec2.SubnetConfiguration(name="public", subnet_type=ec2.SubnetType.PUBLIC, cidr_mask=24),
        ec2.SubnetConfiguration(name="private-app", subnet_type=ec2.SubnetType.PRIVATE_ISOLATED, cidr_mask=20),
        ec2.SubnetConfiguration(name="private-data", subnet_type=ec2.SubnetType.PRIVATE_ISOLATED, cidr_mask=24),
    ],
)
```

---

### 1.5 Observability Patterns (관측성 패턴)

#### 1.5.1 Centralized Logging with CloudWatch Logs

**문제 해결**: 분산 컴포넌트(ECS, Lambda)의 로그 중앙 집중화

**솔루션 접근**:
- ECS Task: awslogs 드라이버로 CloudWatch Logs 전송
- Lambda: 기본 CloudWatch Logs 통합
- 로그 그룹 명명 규칙: `/aws/{service}/{app}-{env}-{component}`
- 보존 기간: dev/staging 7일, prod 30일

**품질 속성**: Observability (로그 가시성), Maintainability (디버깅 용이성)

**Trade-offs**:
- 비용: CloudWatch Logs 비용 (약 $0.50/GB 저장)
- 보존 기간: 장기 보존 시 비용 증가 (S3 아카이빙은 v2)
- 쿼리 성능: CloudWatch Logs Insights 쿼리 시 비용 발생

**구현 노트**:
```python
# CDK ComputeStack - ECS Task
env = self.node.try_get_context("environment") or "dev"
retention_days = logs.RetentionDays.ONE_MONTH if env == "prod" else logs.RetentionDays.ONE_WEEK

ecs_log_group = logs.LogGroup(
    self, "EcsLogGroup",
    log_group_name=f"/ecs/{app_name}-{env}-gateway",
    retention=retention_days
)

app_container.add_log_configuration(
    ecs.LogDrivers.aws_logs(
        stream_prefix="gateway-app",
        log_group=ecs_log_group
    )
)
```

#### 1.5.2 Prometheus Metrics with AMP and ADOT

**문제 해결**: Gateway 메트릭(Bedrock 토큰/비용, latency)을 Prometheus 형식으로 수집

**솔루션 접근**:
- Gateway 애플리케이션이 OpenTelemetry SDK로 메트릭 생성
- ADOT Collector sidecar가 OTLP gRPC로 메트릭 수신 (localhost:4317)
- ADOT가 AMP remote write endpoint로 메트릭 전송
- Grafana에서 AMP를 데이터 소스로 시각화

**품질 속성**: Observability (메트릭 가시성), Performance (메트릭 기반 최적화)

**Trade-offs**:
- 비용: AMP 비용 (샘플 수집 $0.30/million samples, 쿼리 $0.01/million samples)
- 복잡성: ADOT sidecar 추가로 Task 리소스 증가 (0.25 vCPU, 512MB)
- 설정: ADOT 설정 YAML을 환경변수로 inline 전달 (Unit 1에서 전체 정의)

**구현 노트**:
```python
# CDK ObservabilityStack - AMP Workspace
amp_workspace = aps.CfnWorkspace(
    self, "AmpWorkspace",
    alias=f"{app_name}-{env}"
)

# CDK ComputeStack - ADOT Sidecar
adot_config_yaml = f"""
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317

processors:
  batch:
    timeout: 60s
    send_batch_size: 50

exporters:
  prometheusremotewrite:
    endpoint: {observability_stack.amp_remote_write_url}
    auth:
      authenticator: sigv4auth
    resource_to_telemetry_conversion:
      enabled: true

extensions:
  sigv4auth:
    region: ap-northeast-2
    service: aps

service:
  extensions: [sigv4auth]
  pipelines:
    metrics:
      receivers: [otlp]
      processors: [batch]
      exporters: [prometheusremotewrite]
"""

adot_container = task_definition.add_container(
    "adot-collector",
    image=ecs.ContainerImage.from_registry(
        "public.ecr.aws/aws-observability/aws-otel-collector:latest"
    ),
    cpu=256,
    memory_limit_mib=512,
    environment={
        "AOT_CONFIG_CONTENT": adot_config_yaml,
        "AWS_REGION": "ap-northeast-2"
    },
    logging=ecs.LogDrivers.aws_logs(
        stream_prefix="adot-collector",
        log_group=ecs_log_group
    )
)

adot_container.add_port_mappings(
    ecs.PortMapping(container_port=4317, protocol=ecs.Protocol.TCP)
)
```

#### 1.5.3 Resource Tagging for Cost Tracking

**문제 해결**: AWS 리소스 비용을 프로젝트/환경별로 추적

**솔루션 접근**:
- CDK App 레벨에서 공통 태그 자동 적용
- 필수 태그: Project, Environment, ManagedBy
- AWS Cost Explorer에서 태그 기반 비용 그룹화

**품질 속성**: Observability (비용 가시성), Maintainability (리소스 식별)

**Trade-offs**:
- 복잡성: 추가 태그 필요 시 CDK context로 전달 필요
- 일관성: 모든 리소스에 태그가 자동 적용되지 않으면 비용 추적 불완전
- 비용: 태그 자체는 비용 없음

**구현 노트**:
```python
# CDK app.py
from aws_cdk import App, Tags

app = App()
env = app.node.try_get_context("environment") or "dev"

# 공통 태그 적용
Tags.of(app).add("Project", "claude-proxy")
Tags.of(app).add("Environment", env)
Tags.of(app).add("ManagedBy", "cdk")
```

---

### 1.6 Maintainability Patterns (유지보수성 패턴)

#### 1.6.1 Infrastructure as Code with CDK

**문제 해결**: 인프라 변경의 재현성 및 버전 관리

**솔루션 접근**:
- AWS CDK Python으로 인프라 코드화
- 5개 스택 모듈화 (Network, Data, Observability, Compute, Api)
- CDK context로 환경별 설정 분리
- Git으로 인프라 변경 이력 추적

**품질 속성**: Maintainability (코드 재사용성), Reliability (재현 가능성)

**Trade-offs**:
- 학습 곡선: CDK Python 문법 및 Construct 이해 필요
- 디버깅: CloudFormation 템플릿 생성 오류 시 CDK 코드와 매핑 어려움
- 배포 속도: CloudFormation 스택 업데이트 시간 (약 15~20분)

**구현 노트**:
```python
# CDK app.py
from aws_cdk import App
from stacks.network_stack import NetworkStack
from stacks.data_stack import DataStack
from stacks.observability_stack import ObservabilityStack
from stacks.compute_stack import ComputeStack
from stacks.api_stack import ApiStack

app = App()
env_config = {
    "region": app.node.try_get_context("region") or "ap-northeast-2",
    "account": app.account
}

network_stack = NetworkStack(app, "NetworkStack", env=env_config)
data_stack = DataStack(app, "DataStack", network_stack=network_stack, env=env_config)
observability_stack = ObservabilityStack(app, "ObservabilityStack", network_stack=network_stack, env=env_config)
compute_stack = ComputeStack(app, "ComputeStack", network_stack=network_stack, data_stack=data_stack, observability_stack=observability_stack, env=env_config)
api_stack = ApiStack(app, "ApiStack", network_stack=network_stack, compute_stack=compute_stack, env=env_config)

app.synth()
```

#### 1.6.2 CDK Snapshot Testing

**문제 해결**: 인프라 변경 시 의도치 않은 리소스 변경 감지

**솔루션 접근**:
- pytest + aws-cdk-lib.assertions 모듈 사용
- 각 스택별 snapshot 파일 생성 (`tests/snapshots/*.json`)
- 리소스 개수 및 주요 속성 검증 (세밀한 속성 검증은 생략)
- PR merge 전 snapshot 변경 리뷰 필수

**품질 속성**: Maintainability (변경 추적), Reliability (회귀 방지)

**Trade-offs**:
- 유지보수: Snapshot 변경 시 의도적 변경인지 확인 필요
- False positive: CDK 버전 업그레이드 시 snapshot 대량 변경
- 커버리지: Snapshot test는 구조 검증만, 실제 동작은 integration test 필요

**구현 노트**:
```python
# tests/test_network_stack.py
import pytest
from aws_cdk import App
from aws_cdk.assertions import Template, Match
from stacks.network_stack import NetworkStack

def test_network_stack_snapshot():
    app = App()
    stack = NetworkStack(app, "TestNetworkStack")
    template = Template.from_stack(stack)
    
    # 리소스 개수 검증
    template.resource_count_is("AWS::EC2::VPC", 1)
    template.resource_count_is("AWS::EC2::Subnet", 6)  # 2 AZ x 3 계층
    template.resource_count_is("AWS::EC2::SecurityGroup", 5)
    
    # 주요 속성 검증 (세밀한 속성은 생략)
    template.has_resource_properties("AWS::EC2::VPC", {
        "CidrBlock": "10.0.0.0/16",
        "EnableDnsHostnames": True,
        "EnableDnsSupport": True
    })
    
    template.has_resource_properties("AWS::EC2::SecurityGroup", {
        "GroupDescription": Match.string_like_regexp(".*alb-sg.*")
    })
```

#### 1.6.3 Cross-stack Export Strategy

**문제 해결**: 스택 간 리소스 참조 시 순환 의존성 방지

**솔루션 접근**:
- CDK의 자동 cross-stack 참조 활용 (CloudFormation Export)
- Export 명명 규칙: `{StackName}:{ResourceType}:{ResourceName}`
- SSM Parameter Store 미사용 (CDK Export로 충분)
- 스택 의존성: NetworkStack → DataStack/ObservabilityStack → ComputeStack → ApiStack

**품질 속성**: Maintainability (의존성 관리), Reliability (배포 순서 보장)

**Trade-offs**:
- 복잡성: Export 삭제 시 참조하는 스택 먼저 삭제 필요
- 제약: Export 값 변경 시 참조 스택 재배포 필요
- 디버깅: Export 이름 오류 시 CloudFormation 에러만 발생 (CDK 레벨에서 검증 어려움)

**구현 노트**:
```python
# CDK NetworkStack
self.vpc = ec2.Vpc(self, "Vpc", ...)
self.private_app_subnets = [...]
self.ecs_sg = ec2.SecurityGroup(self, "EcsSg", ...)

# CDK ComputeStack
def __init__(self, scope, id, network_stack: NetworkStack, **kwargs):
    super().__init__(scope, id, **kwargs)
    
    # Cross-stack 참조 (CDK 자동 Export 생성)
    vpc = network_stack.vpc
    subnets = network_stack.private_app_subnets
    security_group = network_stack.ecs_sg
```

---

### 1.7 Availability Patterns (가용성 패턴)

#### 1.7.1 Multi-AZ Deployment

**문제 해결**: 단일 AZ 장애 시 서비스 가용성 보장

**솔루션 접근**:
- 모든 레이어를 2개 AZ (ap-northeast-2a, 2c)에 배포
- ALB: 2 AZ의 public subnet에 배치
- ECS Service: 2 AZ의 private-app subnet에 Task 분산 (Unit 4)
- Aurora: 스토리지 레벨 3 AZ 복제 (자동)
- RDS Proxy: 2 AZ의 private-data subnet에 배치

**품질 속성**: Availability (99.95% 이상), Reliability (AZ 장애 복구)

**Trade-offs**:
- 비용: Multi-AZ 배포로 리소스 2배 (ALB, ECS Task, RDS Proxy)
- 복잡성: AZ별 서브넷 및 리소스 분산 관리
- 네트워크: Cross-AZ 트래픽 비용 ($0.01/GB)

**구현 노트**:
```python
# CDK NetworkStack - 2 AZ 서브넷
public_subnets = [
    ec2.Subnet(self, "PublicSubnet2a", availability_zone="ap-northeast-2a", ...),
    ec2.Subnet(self, "PublicSubnet2c", availability_zone="ap-northeast-2c", ...)
]

# CDK ApiStack - ALB Multi-AZ
alb = elbv2.ApplicationLoadBalancer(
    self, "Alb",
    vpc=network_stack.vpc,
    vpc_subnets=ec2.SubnetSelection(subnets=network_stack.public_subnets),
    internet_facing=True
)

# CDK ComputeStack - ECS Service Multi-AZ (Unit 4)
ecs_service = ecs.FargateService(
    self, "GatewayService",
    task_definition=task_definition,
    vpc_subnets=ec2.SubnetSelection(subnets=network_stack.private_app_subnets),
    desired_count=2  # staging/prod
)
```

#### 1.7.2 Maintenance Window Optimization

**문제 해결**: 유지보수 중 서비스 영향 최소화

**솔루션 접근**:
- Aurora 유지보수 창: 일요일 09:00-10:00 UTC (KST 일요일 18:00-19:00)
- 트래픽 최소 시간대 선택 (내부 개발자 사용 최소)
- Multi-AZ failover로 유지보수 중 단절 시간 최소화 (수십 초)

**품질 속성**: Availability (유지보수 영향 최소화), Maintainability (패치 자동 적용)

**Trade-offs**:
- 운영: 유지보수 창 변경 시 Aurora 설정 업데이트 필요
- 다운타임: Failover 시 수십 초 쓰기 불가 (읽기는 가능)
- 알람: 유지보수 이벤트 추적 및 완료 확인 필요

**구현 노트**:
```python
# CDK DataStack
aurora_cluster = rds.DatabaseCluster(
    self, "AuroraCluster",
    preferred_maintenance_window="Sun:09:00-Sun:10:00"  # UTC
)
```

#### 1.7.3 Deletion Protection for Production

**문제 해결**: 실수로 인한 프로덕션 리소스 삭제 방지

**솔루션 접근**:
- Aurora deletion protection: prod만 활성화
- ALB deletion protection: prod만 활성화
- dev/staging: 비활성화 (인프라 변경 테스트 용이성)

**품질 속성**: Availability (데이터 보호), Reliability (실수 방지)

**Trade-offs**:
- 운영: prod 리소스 삭제 시 deletion protection 수동 비활성화 필요
- 개발 속도: dev/staging은 deletion protection 없어 빠른 재생성 가능
- 복잡성: 환경별 코드 분기 관리

**구현 노트**:
```python
# CDK DataStack
env = self.node.try_get_context("environment") or "dev"
is_prod = (env == "prod")

aurora_cluster = rds.DatabaseCluster(
    self, "AuroraCluster",
    deletion_protection=is_prod
)

# CDK ApiStack
alb = elbv2.ApplicationLoadBalancer(
    self, "Alb",
    deletion_protection=is_prod
)
```

---

## 2. 논리 컴포넌트 설계

### 2.1 Network Layer 컴포넌트

#### 2.1.1 VPC with 3-tier Subnets

**책임**: 네트워크 격리 및 트래픽 라우팅

**Interfaces**:
- **Inputs**: Context (vpc_cidr, environment)
- **Outputs**: VPC ID, Subnet IDs, Route Table IDs
- **Dependencies**: 없음 (최상위 레이어)

**적용된 NFR 패턴**:
- Defense in Depth - Network Segmentation (1.4.1)
- Multi-AZ Deployment (1.7.1)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ec2.Vpc`, `aws_cdk.aws_ec2.Subnet`
- VPC CIDR: 10.0.0.0/16 (context 오버라이드 가능)
- 서브넷: 2 AZ × 3계층 (Public, Private-app, Private-data)

---

#### 2.1.2 Security Group Matrix

**책임**: 컴포넌트 간 네트워크 트래픽 제어

**Interfaces**:
- **Inputs**: VPC ID, 컴포넌트 역할 (ALB, ECS, Lambda, RDS, Endpoint)
- **Outputs**: Security Group IDs
- **Dependencies**: VPC

**적용된 NFR 패턴**:
- Defense in Depth - Network Segmentation (1.4.1)
- IAM Least Privilege (1.4.3)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ec2.SecurityGroup`
- 5개 보안 그룹: alb-sg, ecs-sg, lambda-sg, rds-sg, endpoint-sg
- 보안 그룹 규칙: Inbound/Outbound 명시적 정의 (Functional Design 10절 참조)

---

#### 2.1.3 VPC Endpoint Manager

**책임**: AWS 서비스 Private 접근 제공

**Interfaces**:
- **Inputs**: VPC ID, Private-app Subnets, Endpoint Security Group
- **Outputs**: Endpoint IDs, Private DNS 이름
- **Dependencies**: VPC, Security Group

**적용된 NFR 패턴**:
- VPC Endpoint 대역폭 최적화 (1.3.3)
- VPC Endpoint Policy Scoping (1.4.4)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ec2.InterfaceVpcEndpoint`, `aws_cdk.aws_ec2.GatewayVpcEndpoint`
- Interface Endpoint: Bedrock Runtime, ECR API/DKR, CloudWatch Logs, Secrets Manager, KMS, Identity Store, STS, AMP, ECS
- Gateway Endpoint: S3 (ECR 이미지 레이어 전용)

---

#### 2.1.4 Network Egress Defaults

**책임**: 네트워크 기본 경로를 private connectivity 중심으로 고정

**Interfaces**:
- **Inputs**: VPC ID, Route Table IDs, Endpoint IDs
- **Outputs**: Private subnet route policy, no-NAT topology
- **Dependencies**: VPC, VPC Endpoint Manager

**적용된 NFR 패턴**:
- VPC Endpoint Policy Scoping (1.4.4)
- Private Connectivity by Default (1.4.5)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ec2.Vpc`, `aws_cdk.aws_ec2.Subnet`, `aws_cdk.aws_ec2.GatewayVpcEndpoint`
- 기본 정책: private-app/private-data subnet은 인터넷 egress 경로를 만들지 않음
- 예외 처리: 새 외부 연동이 필요할 때만 별도 설계로 추가

---

### 2.2 Data Layer 컴포넌트

#### 2.2.1 Aurora Serverless v2 Cluster

**책임**: PostgreSQL 호환 관계형 데이터베이스

**Interfaces**:
- **Inputs**: Context (aurora_min_capacity, aurora_max_capacity, environment), VPC, Private-data Subnets, RDS Security Group
- **Outputs**: Cluster Endpoint, Cluster ARN
- **Dependencies**: VPC, Subnet, Security Group, Secrets Manager

**적용된 NFR 패턴**:
- Database Point-in-Time Recovery (1.1.1)
- Multi-AZ Storage Replication (1.1.2)
- Aurora Serverless v2 Auto-scaling (1.2.1)
- Encryption at Rest and in Transit (1.4.2)
- Maintenance Window Optimization (1.7.2)
- Deletion Protection for Production (1.7.3)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_rds.DatabaseCluster`
- Engine: aurora-postgresql, Serverless v2
- Min/Max Capacity: 0.5/1.0 ACU (context 오버라이드 가능)
- Backup: 7일 보존, PITR 활성화
- Encryption: AWS 관리형 RDS 키

---

#### 2.2.2 RDS Proxy

**책임**: DB 연결 풀 관리 및 멀티플렉싱

**Interfaces**:
- **Inputs**: Aurora Cluster, Secrets Manager, VPC, Private-data Subnets, RDS Security Group
- **Outputs**: RDS Proxy Endpoint
- **Dependencies**: Aurora Cluster, Secrets Manager

**적용된 NFR 패턴**:
- RDS Proxy Connection Multiplexing (1.2.2)
- RDS Proxy Connection Borrow Timeout (1.3.2)
- Encryption at Rest and in Transit (1.4.2)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_rds.DatabaseProxy`
- Max Connections Percent: 100%
- Borrow Timeout: 120초
- Idle Client Timeout: 1800초

---

#### 2.2.3 Secrets Manager for DB Credentials

**책임**: Aurora 자격증명 자동 생성 및 보관

**Interfaces**:
- **Inputs**: Aurora Cluster
- **Outputs**: Secret ARN, Secret Name
- **Dependencies**: Aurora Cluster

**적용된 NFR 패턴**:
- Encryption at Rest and in Transit (1.4.2)
- IAM Least Privilege (1.4.3)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_secretsmanager.Secret`
- Secret Name: `{app}/{env}/db-credentials`
- Encryption: AWS 관리형 키
- Access: Lambda, ECS Task 역할만 허용

---

### 2.3 Observability Layer 컴포넌트

#### 2.3.1 AMP Workspace

**책임**: Prometheus 호환 메트릭 저장소

**Interfaces**:
- **Inputs**: Context (app_name, environment)
- **Outputs**: AMP Remote Write URL, AMP Workspace ID
- **Dependencies**: 없음

**적용된 NFR 패턴**:
- Prometheus Metrics with AMP and ADOT (1.5.2)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_aps.CfnWorkspace`
- Alias: `{app}-{env}`
- Remote Write URL: `https://{workspace-id}.aps-workspaces.{region}.amazonaws.com/api/v1/remote_write`

---

### 2.4 Compute Layer 컴포넌트

#### 2.4.1 ECS Cluster

**책임**: Fargate Task 실행 환경

**Interfaces**:
- **Inputs**: Context (app_name, environment)
- **Outputs**: Cluster ARN, Cluster Name
- **Dependencies**: 없음

**적용된 NFR 패턴**:
- Infrastructure as Code with CDK (1.6.1)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ecs.Cluster`
- Capacity Providers: FARGATE, FARGATE_SPOT
- Container Insights: Enabled

---

#### 2.4.2 ECS Task Definition with ADOT Sidecar

**책임**: Gateway 애플리케이션 컨테이너 + ADOT Collector sidecar 정의

**Interfaces**:
- **Inputs**: ECR Repository URI (Unit 4), AMP Remote Write URL, RDS Proxy Endpoint, Secrets ARN, KMS Key ARN, VPC, Private-app Subnets, ECS Security Group
- **Outputs**: Task Definition ARN
- **Dependencies**: ECR Repository, AMP Workspace, RDS Proxy, Secrets Manager, KMS Key

**적용된 NFR 패턴**:
- ECS Task Health Check with Grace Period (1.1.3)
- ECS Task Rolling Update Strategy (1.2.3)
- Prometheus Metrics with AMP and ADOT (1.5.2)
- Centralized Logging with CloudWatch Logs (1.5.1)
- Multi-AZ Deployment (1.7.1)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ecs.FargateTaskDefinition`, `aws_cdk.aws_ecs.ContainerDefinition`
- Task CPU: 768 (0.75 vCPU), Memory: 1536 (1.5 GB)
- App Container: nginx:latest (placeholder, Unit 4에서 ECR URI로 교체)
- ADOT Container: public.ecr.aws/aws-observability/aws-otel-collector:latest
- ADOT Config: AOT_CONFIG_CONTENT 환경변수로 inline YAML 전달

---

#### 2.4.3 Lambda Token Service

**책임**: Virtual Key 발급 및 재조회

**Interfaces**:
- **Inputs**: RDS Proxy Endpoint, Secrets ARN, KMS Key ARN, VPC, Private-app Subnets, Lambda Security Group
- **Outputs**: Lambda Function ARN
- **Dependencies**: RDS Proxy, Secrets Manager, KMS Key

**적용된 NFR 패턴**:
- Encryption at Rest and in Transit (1.4.2)
- IAM Least Privilege (1.4.3)
- Centralized Logging with CloudWatch Logs (1.5.1)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_lambda.Function`
- Runtime: python3.13
- Code: Inline placeholder (Unit 3에서 실제 코드로 교체)
- Timeout: 30초, Memory: 512MB
- IAM: KMS Encrypt/Decrypt, Secrets Manager Read, VPC ENI 관리

---

#### 2.4.4 ECR Repository

**책임**: Gateway Docker 이미지 저장소

**Interfaces**:
- **Inputs**: Context (app_name, environment)
- **Outputs**: Repository URI
- **Dependencies**: 없음

**적용된 NFR 패턴**:
- Infrastructure as Code with CDK (1.6.1)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_ecr.Repository`
- Repository Name: `{app}-{env}-gateway`
- Scan on Push: Enabled
- Lifecycle Policy: Untagged 이미지 30일 후 삭제

---

#### 2.4.5 KMS Key for Virtual Key

**책임**: Virtual Key 암호화 키

**Interfaces**:
- **Inputs**: Context (app_name, environment)
- **Outputs**: KMS Key ARN, KMS Key Alias
- **Dependencies**: 없음

**적용된 NFR 패턴**:
- Encryption at Rest and in Transit (1.4.2)
- IAM Least Privilege (1.4.3)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_kms.Key`
- Alias: `alias/{app}-{env}-virtual-key`
- Automatic Rotation: Enabled (1년 주기)
- Key Policy: Lambda (Encrypt/Decrypt), ECS Task (Encrypt only)

---

### 2.5 API Layer 컴포넌트

#### 2.5.1 API Gateway for Token Service

**책임**: Lambda Token Service의 HTTPS endpoint 제공

**Interfaces**:
- **Inputs**: Lambda Function ARN
- **Outputs**: API Gateway Endpoint URL
- **Dependencies**: Lambda Function

**적용된 NFR 패턴**:
- IAM Least Privilege (1.4.3)
- Centralized Logging with CloudWatch Logs (1.5.1)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_apigateway.RestApi`
- Type: REST API, Regional
- Authorization: IAM (SigV4)
- Logging: ERROR

---

#### 2.5.2 ALB for Gateway

**책임**: ECS Task의 HTTPS ingress

**Interfaces**:
- **Inputs**: VPC, Public Subnets, ALB Security Group, ACM Certificate ARN (context)
- **Outputs**: ALB DNS Name, ALB ARN
- **Dependencies**: VPC, Public Subnets, ACM Certificate

**적용된 NFR 패턴**:
- ALB Idle Timeout for Long-polling (1.3.1)
- Encryption at Rest and in Transit (1.4.2)
- Multi-AZ Deployment (1.7.1)
- Deletion Protection for Production (1.7.3)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_elasticloadbalancingv2.ApplicationLoadBalancer`
- Scheme: internet-facing
- Idle Timeout: 300초
- SSL Policy: ELBSecurityPolicy-TLS13-1-2-2021-06

---

#### 2.5.3 ALB Target Group for ECS Service

**책임**: ECS Task 트래픽 라우팅

**Interfaces**:
- **Inputs**: VPC, ECS Task port (8000)
- **Outputs**: Target Group ARN
- **Dependencies**: VPC

**적용된 NFR 패턴**:
- ECS Task Health Check with Grace Period (1.1.3)
- ECS Task Rolling Update Strategy (1.2.3)

**기술 매핑**:
- AWS CDK: `aws_cdk.aws_elasticloadbalancingv2.ApplicationTargetGroup`
- Target Type: ip (Fargate awsvpc 모드)
- Health Check Path: /healthz
- Deregistration Delay: 30초

---

## 3. 환경별 NFR 차이

| NFR 항목 | dev | staging | prod | 구현 위치 |
|---------|-----|---------|------|----------|
| ECS desired count | 1 | 2 | 2 | ComputeStack (Unit 4) |
| Aurora deletion protection | false | false | true | DataStack |
| ALB deletion protection | false | false | true | ApiStack |
| CloudWatch Logs 보존 | 7일 | 7일 | 30일 | ComputeStack, ApiStack |
| Aurora 백업 보존 | 7일 | 7일 | 7일 | DataStack |
| Aurora Min/Max ACU | 0.5/1.0 | 0.5/1.0 | 0.5/1.0 | DataStack (context 오버라이드 가능) |

**환경별 코드 분기 예시**:
```python
# 모든 스택에서 공통 사용
env = self.node.try_get_context("environment") or "dev"
is_prod = (env == "prod")

# ECS desired count (ComputeStack - Unit 4)
desired_count = 1 if env == "dev" else 2

# Deletion protection (DataStack, ApiStack)
deletion_protection = is_prod

# Log retention (NetworkStack, ComputeStack, ApiStack)
retention_days = logs.RetentionDays.ONE_MONTH if is_prod else logs.RetentionDays.ONE_WEEK
```

---

## 4. 검증 및 모니터링 전략

### 4.1 NFR 검증 체크리스트

| NFR 카테고리 | 검증 항목 | 검증 방법 |
|------------|----------|----------|
| **Performance** | Aurora CPU < 80% | CloudWatch CPUUtilization 메트릭 |
| | ALB 504 에러 없음 | CloudWatch HTTPCode_Target_5XX_Count 메트릭 |
| | RDS Proxy borrow timeout 없음 | CloudWatch ConnectionBorrowTimeout 메트릭 |
| **Security** | NAT-less private routing 유지 | Route table 및 endpoint 구성 확인 |
| | TLS 1.2+ 적용 | ALB SSL Policy 확인 |
| | IAM 정책 최소 권한 | IAM Policy Simulator 검증 |
| **Reliability** | Aurora PITR 활성화 | RDS 콘솔에서 PITR 설정 확인 |
| | 백업 7일 보존 | RDS 콘솔에서 Backup Retention 확인 |
| | ECS Task health check 성공 | ECS Service health check status |
| **Scalability** | Aurora 자동 확장 | CloudWatch DatabaseConnections 메트릭 추적 |
| | RDS Proxy 연결 풀 효율 | CloudWatch DatabaseConnectionsCurrentlySessionPinned 메트릭 |
| **Maintainability** | CDK snapshot test 통과 | pytest 실행 (`pytest tests/`) |
| | 리소스 태그 적용 | AWS Cost Explorer 태그 기반 비용 확인 |
| **Observability** | CloudWatch Logs 정상 수집 | Log Group에서 로그 스트림 확인 |
| | AMP 메트릭 정상 수집 | Grafana에서 메트릭 쿼리 |
| **Availability** | Multi-AZ 배포 | ALB, ECS Task가 2 AZ에 분산 확인 |
| | Circuit breaker 활성화 | ECS Service 설정 확인 |

---

### 4.2 모니터링 대시보드 (Unit 4 이후 Grafana 구성)

| 대시보드 패널 | 메트릭 | 목적 |
|-------------|-------|------|
| **Aurora CPU Utilization** | `CPUUtilization` | Aurora 확장 트리거 감지 (80% 초과 10분) |
| **Aurora Connections** | `DatabaseConnections` | 연결 부족 감지 |
| **RDS Proxy Borrow Timeout** | `ConnectionBorrowTimeout` | 연결 대기 시간 모니터링 |
| **ALB 5xx Error Rate** | `HTTPCode_Target_5XX_Count / RequestCount` | 애플리케이션 에러율 추적 |
| **ALB Request Count** | `RequestCount` | 트래픽 패턴 분석 |
| **ECS Task Count** | `DesiredTaskCount`, `RunningTaskCount` | Task 스케일링 모니터링 |
| **Lambda Invocations** | `Invocations`, `Errors` | Token Service 호출 빈도 및 에러율 |
| **Bedrock Token Usage** | Gateway 애플리케이션 메트릭 (OTel) | 사용자별/팀별 토큰 사용량 추적 |
| **Bedrock Cost Usage** | Gateway 애플리케이션 메트릭 (OTel) | 사용자별/팀별 비용 추적 |

---

### 4.3 알람 설정 (v2 자동화 계획)

| 알람 이름 | 조건 | 조치 |
|---------|------|------|
| **Aurora CPU High** | CPUUtilization > 80% for 10분 | SNS → 운영자 알림, Aurora max capacity 상향 검토 |
| **RDS Proxy Borrow Timeout** | ConnectionBorrowTimeout > 5% for 5분 | SNS → 운영자 알림, Aurora max capacity 상향 |
| **ALB 5xx High** | HTTPCode_Target_5XX_Count > 5% for 5분 | SNS → 운영자 알림, ECS Task 로그 확인 |
| **ECS Task Stopped Unexpectedly** | Task stopped (reason: essential container exited) | SNS → 운영자 알림, CloudWatch Logs 확인 |
| **Lambda Errors** | Errors > 5% for 5분 | SNS → 운영자 알림, Lambda 로그 확인 |

---

## 5. 다음 단계: Infrastructure Design

본 NFR Design 문서가 승인되면, 다음 단계는 **Infrastructure Design (Unit 1)**이다.

Infrastructure Design에서 다룰 내용:
- CDK 코드 구조 및 디렉토리 레이아웃 (`infra/stacks/`, `infra/app.py`)
- 각 스택별 상세 CDK Construct 정의 (Functional Design의 CDK 코드 예시를 기반으로)
- Cross-stack 참조 구현 방법 (CDK export, props 전달)
- CDK context 파라미터 상세 정의 (`cdk.json`)
- CDK 배포 스크립트 및 명령어
- CDK snapshot test 코드 구조

본 NFR Design은 Infrastructure Design의 입력 문서로 사용된다.

---

## 문서 끝

본 문서는 Unit 1: Foundation Infrastructure의 **NFR Design**을 완료했다. 모든 NFR 요구사항에 대한 구체적 설계 패턴과 논리 컴포넌트가 정의되었으며, Infrastructure Design 단계로 진행할 준비가 되었다.

**주요 NFR 패턴 요약**:
- **Resilience**: PITR, Multi-AZ Storage Replication, Health Check, Circuit Breaker
- **Scalability**: Aurora Auto-scaling, RDS Proxy Multiplexing, Rolling Update
- **Performance**: ALB Idle Timeout, RDS Proxy Borrow Timeout, VPC Endpoint 최적화
- **Security**: Network Segmentation, Encryption, IAM Least Privilege, Endpoint Policy, Private Connectivity
- **Observability**: Centralized Logging, Prometheus Metrics with AMP/ADOT, Resource Tagging
- **Maintainability**: IaC with CDK, Snapshot Testing, Cross-stack Export
- **Availability**: Multi-AZ Deployment, Maintenance Window, Deletion Protection

**논리 컴포넌트 요약**:
- **Network Layer**: VPC 3-tier Subnets, Security Group Matrix, VPC Endpoint Manager, Network Egress Defaults
- **Data Layer**: Aurora Serverless v2, RDS Proxy, Secrets Manager
- **Observability Layer**: AMP Workspace
- **Compute Layer**: ECS Cluster, Task Definition with ADOT, Lambda Token Service, ECR, KMS Key
- **API Layer**: API Gateway, ALB, Target Group

**다음 단계: Infrastructure Design**
