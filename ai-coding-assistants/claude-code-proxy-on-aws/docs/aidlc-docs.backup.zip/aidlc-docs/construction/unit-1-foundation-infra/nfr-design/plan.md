# Unit 1: Foundation Infrastructure - NFR Design Plan

- **작성일**: 2026-04-01
- **단계**: CONSTRUCTION - NFR Design
- **상태**: Planning

---

## 목표

NFR Requirements에 정의된 비기능 요구사항을 구체적인 NFR 패턴과 논리 컴포넌트로 변환한다.

---

## NFR 패턴 후보 (Pattern Candidates)

### 1. Resilience Patterns (탄력성 패턴)

#### 1.1 Health Check Pattern
- **목적**: ECS Task 정상 상태 모니터링
- **적용 대상**: ECS Task Definition (ALB Target Group)
- **구현 방식**: `/healthz` 엔드포인트, DB connection pool 가용성만 확인
- **설정**: interval 30s, timeout 5s, unhealthy threshold 3
- **근거**: NFR Requirements 3.2절 (Health Check 설정)

#### 1.2 Circuit Breaker (ECS Deployment)
- **목적**: 배포 실패 시 자동 롤백
- **적용 대상**: ECS Service
- **구현 방식**: ECS circuit breaker 활성화
- **근거**: NFR Requirements 7.2절 (롤링 업데이트 전략)

#### 1.3 Multi-AZ High Availability
- **목적**: 가용 영역 장애 대응
- **적용 대상**: Aurora Serverless v2, ALB, ECS Task
- **구현 방식**: Aurora 스토리지 레벨 복제, ALB 2 AZ public subnet, ECS Task 2 AZ private subnet
- **근거**: Functional Design 5.2절 (서브넷 설계)

#### 1.4 Backup and Recovery
- **목적**: 데이터 손실 방지 및 복구
- **적용 대상**: Aurora Serverless v2
- **구현 방식**: PITR 활성화, 백업 보존 7일, RPO 5분, RTO 1시간
- **근거**: NFR Requirements 3.1절 (백업 및 복구 정책)

### 2. Scalability Patterns (확장성 패턴)

#### 2.1 Database Connection Pooling
- **목적**: DB 연결 재사용으로 성능 및 확장성 향상
- **적용 대상**: RDS Proxy
- **구현 방식**: RDS Proxy connection multiplexing, max connections 100%
- **근거**: NFR Requirements 1.3절 (RDS Proxy Connection Borrow Timeout)

#### 2.2 Serverless Auto-scaling
- **목적**: 트래픽에 따른 자동 용량 조정
- **적용 대상**: Aurora Serverless v2
- **구현 방식**: min 0.5 ACU, max 1.0 ACU, 단계적 확장 (1.0 → 2.0 → 4.0)
- **근거**: NFR Requirements 4.1절 (Aurora Serverless v2 최대 용량 확장)

#### 2.3 Horizontal Scaling (ECS)
- **목적**: 애플리케이션 계층 확장
- **적용 대상**: ECS Service (Unit 4 scope)
- **구현 방식**: desired count dev 1, staging/prod 2, 최대 10개 Task
- **근거**: NFR Requirements 4.3절 (ECS Task Auto-scaling 사전 고려)

#### 2.4 Reserved Concurrency (Lambda)
- **목적**: Lambda 동시성 관리
- **적용 대상**: Lambda Token Service
- **구현 방식**: 예약 동시성 미설정 (계정 기본 한도 사용)
- **근거**: NFR Requirements 4.2절 (Lambda Token Service 동시성 제한)

### 3. Performance Patterns (성능 패턴)

#### 3.1 Timeout Strategy
- **목적**: 장시간 스트리밍 지원 및 안정적 연결 관리
- **적용 대상**: ALB, RDS Proxy, boto3 Bedrock client, DB query
- **구현 방식**:
  - ALB idle timeout: 300초
  - RDS Proxy connection borrow timeout: 120초
  - RDS Proxy idle client timeout: 1800초
  - boto3 Bedrock connect timeout: 10초, read timeout: 290초
  - DB statement_timeout: 30초
- **근거**: NFR Requirements 1.2절, 1.3절, System NFR 10.2절

#### 3.2 VPC Endpoint Optimization
- **목적**: AWS 서비스 접근 지연 최소화 및 비용 절감
- **적용 대상**: VPC Interface/Gateway Endpoints
- **구현 방식**: 10개 Interface Endpoint + 1개 Gateway Endpoint (S3), NAT Gateway 완전 제거
- **근거**: NFR Requirements 1.4절 (VPC Endpoint 대역폭 고려)

#### 3.3 Resource Right-sizing
- **목적**: 초기 트래픽 규모에 맞는 리소스 할당
- **적용 대상**: Aurora, ECS Task, Lambda
- **구현 방식**:
  - Aurora: 0.5/1.0 ACU
  - ECS Task: 0.75 vCPU, 1.5GB RAM
  - Lambda: 512MB
- **근거**: NFR Requirements 1.1절 (Aurora Serverless v2 용량 설정)

### 4. Security Patterns (보안 패턴)

#### 4.1 Encryption at Rest
- **목적**: 저장된 데이터 보호
- **적용 대상**: Aurora, Secrets Manager, Virtual Key
- **구현 방식**:
  - Aurora: AWS managed RDS key
  - Secrets Manager: AWS managed key
  - Virtual Key: Customer managed KMS key (자동 rotation 1년)
- **근거**: NFR Requirements 2.2절, System NFR 4.1절

#### 4.2 Encryption in Transit
- **목적**: 전송 중 데이터 보호
- **적용 대상**: 모든 네트워크 통신
- **구현 방식**: TLS 1.2+ (ALB, RDS Proxy, VPC Endpoint, Bedrock)
- **근거**: System NFR 4.2절

#### 4.3 Network Isolation
- **목적**: Private subnet 기반 네트워크 격리
- **적용 대상**: VPC, Subnets, Security Groups
- **구현 방식**: 3계층 서브넷 (Public, Private-app, Private-data), VPC Endpoint 기반 AWS 서비스 접근, NAT Gateway 없음
- **근거**: System NFR 4.3절

#### 4.4 IAM Least Privilege
- **목적**: 최소 권한 원칙 준수
- **적용 대상**: IAM Roles (ECS, Lambda, API Gateway)
- **구현 방식**: 역할별 명시적 리소스 ARN, 와일드카드 최소화
- **근거**: NFR Requirements 2.4절, System NFR 4.4절

#### 4.5 Network Access Control
- **목적**: 네트워크 레벨 접근 제어
- **적용 대상**: Security Groups, VPC Endpoint Policies
- **구현 방식**: Security Group 최소 포트 허용, VPC Endpoint 정책 계정/리전 제한
- **근거**: NFR Requirements 2.2절, 2.3절

#### 4.6 Private Connectivity Defaults
- **목적**: 과도한 네트워크 구성 없이 기본 egress 경계를 명확히 유지
- **적용 대상**: Route Tables, VPC Endpoints, Public Subnets
- **구현 방식**: NAT Gateway 미사용, public subnet은 ingress 전용, AWS 서비스 접근은 VPC Endpoint로만 허용
- **근거**: System NFR 4.3절

### 5. Maintainability Patterns (유지보수성 패턴)

#### 5.1 Infrastructure as Code Testing
- **목적**: CDK 코드 품질 보장
- **적용 대상**: CDK Stacks
- **구현 방식**: `cdk synth` 검증, CDK snapshot test (pytest + aws-cdk.assertions)
- **근거**: NFR Requirements 5.1절

#### 5.2 Resource Tagging
- **목적**: 리소스 식별 및 비용 추적
- **적용 대상**: 모든 CDK 리소스
- **구현 방식**: CDK App 레벨 공통 태그 (Project, Environment, ManagedBy)
- **근거**: NFR Requirements 5.2절

#### 5.3 Direct Stack Modification
- **목적**: 단순한 인프라 업데이트 방식
- **적용 대상**: ComputeStack (Unit 3/4 업데이트)
- **구현 방식**: `compute_stack.py` 직접 수정, Overlay/patch 메커니즘 불필요
- **근거**: NFR Requirements 5.3절

### 6. Observability Patterns (관측성 패턴)

#### 6.1 Structured Logging
- **목적**: 로그 검색 및 분석 용이성
- **적용 대상**: CloudWatch Logs
- **구현 방식**: JSON 구조화 로그, 필수 필드 (timestamp, level, message, request_id)
- **근거**: System NFR 2.1절

#### 6.2 Metrics Collection
- **목적**: 시스템 메트릭 수집 및 시각화
- **적용 대상**: AMP + ADOT Collector sidecar
- **구현 방식**: OTel SDK → OTLP gRPC (localhost:4317) → ADOT → AMP
- **근거**: System NFR 2.2절

#### 6.3 Log Retention Policy
- **목적**: 비용 최적화 및 디버깅 지원
- **적용 대상**: CloudWatch Logs
- **구현 방식**: prod 30일, dev/staging 7일
- **근거**: NFR Requirements 6.1절

### 7. Availability Patterns (가용성 패턴)

#### 7.1 Rolling Deployment
- **목적**: 무중단 배포
- **적용 대상**: ECS Service (Unit 4)
- **구현 방식**: Min healthy 100%, Max 200%, circuit breaker 활성화
- **근거**: NFR Requirements 7.2절

#### 7.2 Maintenance Window
- **목적**: 유지보수 시간 최적화
- **적용 대상**: Aurora Serverless v2
- **구현 방식**: 일요일 09:00-10:00 UTC (KST 18:00-19:00)
- **근거**: NFR Requirements 7.1절

#### 7.3 Deletion Protection
- **목적**: 실수로 인한 리소스 삭제 방지
- **적용 대상**: Aurora, ALB
- **구현 방식**: prod만 활성화
- **근거**: NFR Requirements 3.3절

---

## 패턴 의존성 및 충돌 분석

### 의존성

1. **Network Isolation → IAM Least Privilege**
   - Private subnet 격리는 IAM 정책과 함께 방어 계층 구성
   - Security Group + IAM 조합으로 심층 방어 (Defense in Depth)

2. **VPC Endpoint Optimization → Network Isolation**
   - VPC Endpoint는 Private subnet에서 AWS 서비스 접근을 가능하게 함
   - NAT Gateway 없이도 AWS 서비스 사용 가능

3. **Database Connection Pooling → Serverless Auto-scaling**
   - RDS Proxy connection pooling은 Aurora Serverless 확장과 함께 동작
   - RDS Proxy가 연결을 멀티플렉싱하여 Aurora 부하 감소

4. **Health Check → Rolling Deployment**
   - Health check pass 확인 후 Task 교체
   - Circuit breaker는 health check 실패 시 롤백 트리거

5. **Backup and Recovery → Multi-AZ High Availability**
   - PITR + Multi-AZ 스토리지 복제로 RPO/RTO 보장

### 충돌 (없음)

모든 패턴은 상호 보완적이며 충돌 없음.

---

## 컴포넌트 매핑

| 논리 컴포넌트 | 적용 패턴 |
|------------|----------|
| **NetworkStack** | Network Isolation, VPC Endpoint Optimization, Network Access Control, Audit Logging |
| **DataStack** | Database Connection Pooling, Encryption at Rest, Backup and Recovery, Multi-AZ High Availability, Deletion Protection, Encryption in Transit |
| **ObservabilityStack** | Metrics Collection |
| **ComputeStack** | Health Check Pattern, Resource Right-sizing, Horizontal Scaling, Reserved Concurrency, IAM Least Privilege, Encryption at Rest (KMS), Infrastructure as Code Testing, Resource Tagging, Direct Stack Modification |
| **ApiStack** | Timeout Strategy, Encryption in Transit, Deletion Protection |

---

## 체크리스트

- [ ] 패턴 선택 완료
- [ ] 패턴 문서화 완료
- [ ] 논리 컴포넌트 설계 완료
- [ ] 검증 완료

---

## 질문

### 1. 패턴 선호도

**Q1-1**: v1 네트워크 보안에서 어느 수준까지를 기본 설계에 포함할지 결정해야 합니다.
- 옵션 A: Private subnet + VPC Endpoint + no-NAT 원칙까지만 포함
- 옵션 B: 옵션 A + 추가 보안 서비스 연동을 기본 포함
- 옵션 C: 옵션 A만 기본 포함하고 나머지는 운영 가이드로 분리

**Q1-2**: CDK snapshot test의 세밀도 수준을 결정해야 합니다.
- 옵션 A: 리소스 개수 및 주요 속성만 검증 (빠른 실행)
- 옵션 B: 모든 리소스 속성 검증 (상세한 검증)
- 옵션 C: Security Group, IAM 정책만 검증 (보안 중심)

### 2. Trade-off 우선순위

**Q2-1**: Aurora Serverless v2 최대 용량 확장 시 비용과 성능 간 균형
- 충돌: CPU 80% 초과 시 즉시 확장 vs. 10분 지속 확인 후 확장
- 현재 설정: 10분 지속 확인 (비용 최적화)
- 질문: 성능 최우선 시나리오에서는 5분으로 단축할 필요가 있나요?

**Q2-2**: CloudWatch Logs 보존 기간과 비용 간 균형
- 충돌: 긴 보존 기간 (디버깅 편의) vs. 짧은 보존 기간 (비용 절감)
- 현재 설정: prod 30일, dev 7일
- 질문: 현재 설정이 적절한가요, 아니면 dev를 3일로 줄여야 하나요?

### 3. 구현 제약사항

**Q3-1**: CDK snapshot test 도입 시 CI 파이프라인 영향
- 현재: Unit 1에서 CDK synth만 검증
- 변경: snapshot test 추가 (pytest 실행 시간 증가)
- 질문: CI 파이프라인이 아직 없는데, Build & Test 단계에서 구성하면 되나요?

**Q3-2**: Grafana 대시보드 수동 설정 시 재현성 보장
- 현재: Unit 4 완료 후 수동 설정 계획
- 문제: 수동 설정은 환경별 일관성 보장 어려움
- 질문: Grafana 대시보드 JSON을 Git에 커밋하여 재현 가능하도록 하면 충분한가요?

---

## 다음 단계

질문에 대한 답변 수집 후:
1. 패턴 선택 확정
2. NFR Design 문서 작성
3. 논리 컴포넌트 설계 문서 작성
