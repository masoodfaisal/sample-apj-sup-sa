# Unit 1: Foundation Infrastructure - Functional Design

- **문서 버전**: v1.0
- **작성일**: 2026-04-01
- **상태**: Final
- **단계**: CONSTRUCTION - Functional Design
- **근거 문서**:
  - [System NFR Decisions](../../../construction/system-nfr-decisions.md)
  - [Application Design](../../../inception/application-design/application-design.md)
  - [Unit of Work](../../../inception/application-design/unit-of-work.md)
  - [System Architecture](../../../../docs/SYSTEM_ARCHITECTURE.md)
  - [PRD](../../../../docs/PRD.md)
  - [ERD](../../../../docs/ERD.md)
  - [API Specification](../../../../docs/API_SPEC.md)
  - [Questions Round 1 (답변 완료)](./questions-round1.md)

---

## 문서 개요

본 문서는 Claude Code Proxy on AWS의 Unit 1 (Foundation Infrastructure)에 대한 상세 기능 설계를 정의한다. Unit 1은 AWS CDK Python을 사용하여 5개 스택(NetworkStack, DataStack, ObservabilityStack, ComputeStack, ApiStack)으로 구성되며, 전체 시스템의 인프라 기반을 프로비저닝한다.

본 문서의 "기능 설계"는 일반적인 애플리케이션 비즈니스 로직이 아닌, **인프라 구성의 비즈니스 로직**을 다룬다. 즉, WHAT infrastructure를 배포하고, WHY 그러한 구성이 필요하며, HOW 각 리소스가 상호작용하는지를 명확히 정의한다.

---

## 1. 설계 결정 요약표

본 표는 Questions Round 1에서 확정된 모든 설계 결정을 한눈에 볼 수 있도록 정리한 것이다.

| 카테고리 | 항목 | 결정 사항 |
|---------|------|----------|
| **Network** | VPC CIDR | 10.0.0.0/16 |
| | AZ | 2개 |
| | 서브넷 구조 | 3계층: Public /24 x2, Private-app /20 x2, Private-data /24 x2 |
| | Public Subnet | 10.0.0.0/24, 10.0.1.0/24 (ALB 전용) |
| | Private-app Subnet | 10.0.16.0/20, 10.0.32.0/20 (ECS, Lambda, VPC Endpoints) |
| | Private-data Subnet | 10.0.48.0/24, 10.0.49.0/24 (Aurora, RDS Proxy) |
| | VPC Endpoint 정책 | Endpoint별 개별 정책 |
| | Bedrock Endpoint 정책 | 전체 서비스 접근 허용 |
| | S3 Gateway Endpoint 정책 | ECR 이미지 레이어 버킷만 허용 |
| | 기타 Endpoint 정책 | aws:PrincipalAccount 조건으로 계정/리전 제한 |
| | NAT Gateway | 완전 제거 (코드에도 미포함) |
| **Data** | Aurora | Serverless v2, PostgreSQL 호환 |
| | Aurora 용량 | Min 0.5 ACU, Max 1.0 ACU (모든 환경 동일) |
| | Aurora 클러스터 | Writer 1개만, Reader 없음 |
| | Multi-AZ | Aurora Serverless v2 스토리지 복제로 보장 |
| | RDS Proxy | 최대 연결 기본값(100%), Secrets Manager 인증만 |
| | RDS Proxy 타임아웃 | connection borrow 120초, idle 1800초 |
| | 백업 보존 | 7일 |
| | 유지보수 창 | Sun 09:00-10:00 UTC (KST 일요일 18:00-19:00) |
| | PITR | 활성화 |
| | Deletion protection | prod만 활성화 |
| | Secrets Manager 이름 | {app}/{env}/db-credentials |
| **Compute** | ECS 이미지 | Skeleton placeholder (`nginx:latest`) |
| | ECS 리소스 | 0.5 vCPU, 1GB RAM |
| | ECS Health check | /healthz, interval 30s, timeout 5s |
| | ECS 환경변수 | 키 이름만 placeholder |
| | ECS 로깅 | awslogs 드라이버 + CloudWatch |
| | ECS Port | 8000 |
| | ADOT sidecar | AOT_CONFIG_CONTENT 환경변수 inline |
| | ADOT 리소스 | 0.25 vCPU, 512MB |
| | ADOT 이미지 | public.ecr.aws/aws-observability/aws-otel-collector:latest |
| | ADOT Port | 4317 (OTLP gRPC) |
| | ECS Service | Unit 4 scope (Unit 1 미생성) |
| | ECS desired count | dev 1, staging/prod 2 (Unit 4 적용) |
| | ECS 배포 전략 | Rolling update (Unit 4 적용) |
| | Auto-scaling | Unit 4 이후로 연기 |
| | Lambda runtime | python3.13 |
| | Lambda 코드 | inline placeholder |
| | Lambda 타임아웃 | 30초 |
| | Lambda 메모리 | 512MB |
| | Lambda 환경변수 | 키 이름만 placeholder |
| | Lambda VPC | private-app subnet |
| | Lambda IAM 역할 | KMS, Secrets, RDS Proxy, VPC ENI |
| | ECR Repository | {app}-{env}-gateway |
| **API** | API Gateway 유형 | Regional, REST API (IAM Auth) |
| | API Gateway throttling | 기본값 (10,000 req/s, burst 5,000) |
| | API Gateway 로깅 | ERROR |
| | ALB idle timeout | 300초 |
| | ALB deletion protection | prod만 활성화 |
| | ALB access logs | 비활성화 (v1) |
| | ALB deregistration delay | 30초 |
| | ACM 인증서 | 기존 ARN을 context로 전달 (자동 생성 안 함) |
| | HTTPS 필수 | 모든 환경 |
| **Observability** | AMP Workspace | 환경별 별도 생성 |
| | AMP Alias | {app}-{env} |
| | ADOT 설정 | Unit 1에서 전체 정의 (inline YAML) |
| | AMP URL | ObservabilityStack → ComputeStack cross-stack 참조 |
| **IAM & KMS** | IAM 역할 명명 | {app}-{env}-{service}-{role-type} |
| | IAM 정책 유형 | Inline Policy (CDK grant 메서드) |
| | KMS 자동 rotation | 활성화 (1년 주기) |
| | KMS alias | alias/{app}-{env}-virtual-key |
| | KMS 삭제 대기 | 30일 |
| **Cross-stack** | Export 전략 | CDK Export만 (SSM 미사용), 자동 참조 |
| | Export 명명 | {StackName}:{ResourceType}:{ResourceName} |
| **Context** | 총 개수 | 8개 |
| | environment | dev (기본값) |
| | region | ap-northeast-2 (기본값) |
| | vpc_cidr | 10.0.0.0/16 (기본값) |
| | aurora_min_capacity | 0.5 (기본값) |
| | aurora_max_capacity | 1.0 (기본값) |
| | acm_certificate_arn | 필수 (모든 환경) |
| | app_name | claude-proxy (기본값) |
| **환경별 차이** | ECS desired count | dev 1, else 2 (Unit 4 적용) |
| | Deletion protection | prod만 (Aurora, ALB) |
| | CloudWatch Logs 보존 | prod 30일, else 7일 |
| | 백업 보존 | 전 환경 7일 |
| | API GW 로깅 | 전 환경 ERROR |
| **Skeleton** | 업데이트 방식 | Unit 3/4에서 compute_stack.py 직접 수정 |
| | Construct 전략 | 각 스택에서 직접 리소스 정의 (커스텀 Construct 없음) |
| | infra/constructs/ | 미생성 |

---

## 2. CDK Context 파라미터 전체 정의

CDK 배포 시 사용할 수 있는 context 파라미터의 전체 목록이다. 이 파라미터들은 `cdk.json`에 기본값을 정의하고, 배포 시 `cdk deploy -c key=value` 형태로 오버라이드할 수 있다.

| 파라미터 | 타입 | 기본값 | 필수 여부 | 설명 |
|---------|------|--------|----------|------|
| `environment` | string | `dev` | 선택 | 배포 환경 (dev/staging/prod) |
| `region` | string | `ap-northeast-2` | 선택 | AWS 리전 |
| `vpc_cidr` | string | `10.0.0.0/16` | 선택 | VPC CIDR 블록 |
| `aurora_min_capacity` | float | `0.5` | 선택 | Aurora Serverless v2 최소 ACU |
| `aurora_max_capacity` | float | `1.0` | 선택 | Aurora Serverless v2 최대 ACU |
| `acm_certificate_arn` | string | (없음) | **필수** | ALB HTTPS 리스너용 ACM 인증서 ARN |
| `app_name` | string | `claude-proxy` | 선택 | 애플리케이션 이름 (리소스 명명에 사용) |

**배포 예시:**
```bash
cdk deploy --all \
  -c environment=prod \
  -c region=ap-northeast-2 \
  -c acm_certificate_arn=arn:aws:acm:ap-northeast-2:123456789012:certificate/abc123
```

---

## 3. 환경별 코드 분기 설정

Context로 전달하지 않고, 코드 내에서 `environment` context 값을 기준으로 분기 처리하는 항목들이다.

| 항목 | dev | staging | prod | 구현 위치 |
|------|-----|---------|------|----------|
| ECS desired count | 1 | 2 | 2 | ComputeStack (Unit 4 적용) |
| Aurora deletion protection | false | false | true | DataStack |
| ALB deletion protection | false | false | true | ApiStack |
| CloudWatch Logs 보존 | 7일 | 7일 | 30일 | ComputeStack, ApiStack |

**구현 예시 (ComputeStack):**
```python
env = self.node.try_get_context("environment") or "dev"
desired_count = 1 if env == "dev" else 2
```

---

## 4. 스택 의존성 및 배포 순서

### 4.1 스택 의존성 다이어그램

```
NetworkStack
    │
    ├─────────────┐
    │             │
    ▼             ▼
DataStack    ObservabilityStack
    │             │
    └──────┬──────┘
           │
           ▼
      ComputeStack
           │
           ▼
       ApiStack
```

### 4.2 배포 순서 및 이유

1. **NetworkStack** (최우선)
   - VPC, 서브넷, VPC Endpoints, 보안 그룹 생성
   - 모든 다른 스택이 네트워크 리소스를 참조해야 하므로 최우선

2. **DataStack** (NetworkStack 이후)
   - Aurora, RDS Proxy는 private-data subnet과 보안 그룹 필요

3. **ObservabilityStack** (NetworkStack 이후)
   - AMP Workspace 생성
   - ComputeStack의 ADOT sidecar가 AMP remote write URL을 참조해야 하므로 ComputeStack보다 먼저 생성

4. **ComputeStack** (DataStack + ObservabilityStack 이후)
   - ECS Task는 RDS Proxy endpoint, AMP remote write URL, VPC/Subnet/SG 모두 필요
   - Lambda는 RDS Proxy endpoint, VPC/Subnet/SG 필요

5. **ApiStack** (ComputeStack 이후)
   - API Gateway는 Lambda Function ARN 필요
   - ALB/Target Group은 Unit 1에서 생성하고, Unit 4의 ECS Service가 이후 연결

### 4.3 Cross-stack 참조 주요 항목

| From Stack | To Stack | 참조 항목 |
|-----------|---------|----------|
| NetworkStack | DataStack | VPC, private-data subnets, RDS 보안 그룹 |
| NetworkStack | ObservabilityStack | VPC Endpoint (aps-workspaces) |
| NetworkStack | ComputeStack | VPC, private-app subnets, ECS/Lambda 보안 그룹 |
| NetworkStack | ApiStack | VPC, public subnets, ALB 보안 그룹 |
| DataStack | ComputeStack | RDS Proxy endpoint, Secrets ARN |
| ObservabilityStack | ComputeStack | AMP Workspace remote write URL |
| ComputeStack | ApiStack | Lambda Function ARN |

---

## 5. NetworkStack 상세 설계

### 5.1 VPC 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| CIDR | 10.0.0.0/16 | 65,536개 IP 주소 |
| DNS Hostnames | Enabled | VPC Endpoint Private DNS 활성화 필요 |
| DNS Support | Enabled | Route 53 Resolver 사용 |
| NAT Gateway | 0개 | VPC Endpoint로 AWS 서비스 접근 |
| Internet Gateway | 1개 | ALB public ingress 전용 |

### 5.2 서브넷 설계

#### 5.2.1 서브넷 CIDR 할당

| 계층 | AZ-a | AZ-c | CIDR | 용도 |
|-----|------|------|------|------|
| Public | 10.0.0.0/24 | 10.0.1.0/24 | 256 IPs/subnet | ALB 전용 |
| Private-app | 10.0.16.0/20 | 10.0.32.0/20 | 4,096 IPs/subnet | ECS, Lambda, VPC Endpoints |
| Private-data | 10.0.48.0/24 | 10.0.49.0/24 | 256 IPs/subnet | Aurora, RDS Proxy |

#### 5.2.2 서브넷별 라우팅

| 서브넷 | Internet Gateway | NAT Gateway | VPC Endpoint | 설명 |
|--------|------------------|-------------|--------------|------|
| Public | ✓ | - | - | 0.0.0.0/0 → IGW |
| Private-app | - | - | ✓ | 로컬 VPC만, AWS 서비스는 Endpoint |
| Private-data | - | - | - | 로컬 VPC만 |

### 5.3 VPC Endpoint 설계

#### 5.3.1 Interface Endpoint 목록

| 서비스 | Endpoint ID | 서브넷 | 보안 그룹 | Private DNS | 필수 여부 |
|--------|------------|--------|----------|-------------|----------|
| Bedrock Runtime | com.amazonaws.ap-northeast-2.bedrock-runtime | private-app | endpoint-sg | ✓ | 필수 |
| ECR API | com.amazonaws.ap-northeast-2.ecr.api | private-app | endpoint-sg | ✓ | 필수 |
| ECR DKR | com.amazonaws.ap-northeast-2.ecr.dkr | private-app | endpoint-sg | ✓ | 필수 |
| CloudWatch Logs | com.amazonaws.ap-northeast-2.logs | private-app | endpoint-sg | ✓ | 필수 |
| Secrets Manager | com.amazonaws.ap-northeast-2.secretsmanager | private-app | endpoint-sg | ✓ | 필수 |
| KMS | com.amazonaws.ap-northeast-2.kms | private-app | endpoint-sg | ✓ | 필수 |
| Identity Store | com.amazonaws.ap-northeast-2.identitystore | private-app | endpoint-sg | ✓ | 필수 |
| STS | com.amazonaws.ap-northeast-2.sts | private-app | endpoint-sg | ✓ | 필수 |
| AMP Workspaces | com.amazonaws.ap-northeast-2.aps-workspaces | private-app | endpoint-sg | ✓ | 필수 |
| ECS | com.amazonaws.ap-northeast-2.ecs | private-app | endpoint-sg | ✓ | 필수 |

#### 5.3.2 Gateway Endpoint 목록

| 서비스 | Endpoint ID | 라우팅 테이블 | 정책 | 필수 여부 |
|--------|------------|--------------|------|----------|
| S3 | com.amazonaws.ap-northeast-2.s3 | private-app | ECR 이미지 레이어 버킷만 허용 | 필수 |

#### 5.3.3 Endpoint 정책 상세

**Bedrock Runtime Endpoint Policy:**
```json
{
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": "*",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": "*"
    }
  ]
}
```

**S3 Gateway Endpoint Policy (ECR 전용):**
```json
{
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": "*",
      "Action": [
        "s3:GetObject"
      ],
      "Resource": [
        "arn:aws:s3:::prod-ap-northeast-2-starport-layer-bucket/*"
      ]
    }
  ]
}
```

**기타 Interface Endpoint Policy (계정 제한):**
```json
{
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": "*",
      "Action": "*",
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "aws:PrincipalAccount": "<AWS_ACCOUNT_ID>"
        }
      }
    }
  ]
}
```

### 5.4 보안 그룹 설계

#### 5.4.1 보안 그룹 매트릭스

| 보안 그룹 | Inbound | From | 설명 |
|----------|---------|------|------|
| alb-sg | 443 | 0.0.0.0/0 | 인터넷에서 ALB HTTPS |
| ecs-sg | 8000 | alb-sg | ALB에서 ECS Task |
| | 443 | endpoint-sg | VPC Endpoint 접근 |
| lambda-sg | 443 | endpoint-sg | VPC Endpoint 접근 |
| rds-sg | 5432 | ecs-sg, lambda-sg | ECS/Lambda에서 RDS Proxy |
| endpoint-sg | 443 | ecs-sg, lambda-sg | ECS/Lambda에서 VPC Endpoint |

#### 5.4.2 보안 그룹별 상세 규칙

**alb-sg (ALB 전용):**
- Inbound: 443 from 0.0.0.0/0
- Outbound: 8000 to ecs-sg

**ecs-sg (ECS Task 전용):**
- Inbound: 8000 from alb-sg
- Outbound: 443 to endpoint-sg, 5432 to rds-sg

**lambda-sg (Lambda Function 전용):**
- Inbound: (none)
- Outbound: 443 to endpoint-sg, 5432 to rds-sg

**rds-sg (Aurora + RDS Proxy):**
- Inbound: 5432 from ecs-sg, 5432 from lambda-sg
- Outbound: (none)

**endpoint-sg (VPC Endpoint ENI 전용):**
- Inbound: 443 from ecs-sg, 443 from lambda-sg
- Outbound: (none)

## 6. DataStack 상세 설계

### 6.1 Aurora PostgreSQL Serverless v2 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Engine | aurora-postgresql | PostgreSQL 호환 |
| Engine Mode | serverless | Serverless v2 |
| Engine Version | 15.x (최신 안정 버전) | |
| 클러스터 구성 | Writer 1개만 | Reader 없음 |
| Multi-AZ | Storage replication | 스토리지 레벨 복제 |
| Min Capacity | 0.5 ACU | context 오버라이드 가능 |
| Max Capacity | 1.0 ACU | context 오버라이드 가능 |
| Database Name | `claudeproxy` | 초기 DB 이름 |
| Master Username | `dbadmin` | Secrets Manager에 저장 |
| Backup Retention | 7일 | 전 환경 동일 |
| Backup Window | 02:00-03:00 UTC | 트래픽 최소 시간대 |
| Maintenance Window | Sun 09:00-10:00 UTC | KST 일요일 18:00-19:00 |
| PITR | Enabled | 시점 복구 활성화 |
| Deletion Protection | prod만 활성화 | dev/staging false |
| Encryption | AWS managed RDS key | 자동 암호화 |
| Subnet Group | private-data subnets | DataStack에서 생성 |
| Security Group | rds-sg | NetworkStack에서 참조 |

### 6.2 RDS Proxy 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Name | {app}-{env}-rds-proxy | |
| Engine Family | POSTGRESQL | |
| Target | Aurora Writer 인스턴스 | |
| Auth | Secrets Manager only | IAM 인증 미사용 |
| Secret Name | {app}/{env}/db-credentials | Secrets Manager |
| Max Connections Percent | 100% | 기본값 |
| Max Idle Connections Percent | 50% | 기본값 |
| Connection Borrow Timeout | 120초 | 연결 대기 시간 |
| Idle Client Timeout | 1800초 (30분) | 유휴 연결 유지 시간 |
| Init Query | (none) | |
| Subnet Group | private-data subnets | DataStack에서 생성 |
| Security Group | rds-sg | NetworkStack에서 참조 |
| VPC | NetworkStack VPC | Cross-stack 참조 |

### 6.3 Secrets Manager 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Secret Name | {app}/{env}/db-credentials | 예: `claude-proxy/dev/db-credentials` |
| Secret Type | RDS database credentials | Aurora 자동 생성 |
| Rotation | Disabled (v1) | 수동 rotation |
| Encryption | AWS managed key | 기본 KMS 키 |
| Access Policy | Lambda, ECS Task 역할만 허용 | |
| Value Format | JSON | `{"username": "...", "password": "...", "engine": "postgres", ...}` |

### 6.4 DataStack Cross-stack Export

| Export Name | Resource Type | 참조 스택 |
|-------------|--------------|----------|
| {StackName}:RdsProxyEndpoint | RDS Proxy endpoint | ComputeStack |
| {StackName}:DbSecretArn | Secrets Manager ARN | ComputeStack |
| {StackName}:AuroraClusterArn | Aurora Cluster ARN | (운영 참조용) |

---

## 7. ObservabilityStack 상세 설계

### 7.1 AMP Workspace 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Alias | {app}-{env} | 예: `claude-proxy-dev` |
| Description | Claude Code Proxy metrics workspace for {env} | |
| Logging Config | Disabled (v1) | 운영 로그 미저장 |
| Retention | (unlimited) | AMP 기본 보존 |
| Remote Write URL | https://{workspace-id}.aps-workspaces.{region}.amazonaws.com/api/v1/remote_write | Cross-stack export |

### 7.2 ADOT Collector 설정 구조

ADOT Collector sidecar의 설정은 ECS Task Definition의 환경변수 `AOT_CONFIG_CONTENT`로 inline YAML 형태로 전달된다. 전체 설정은 Unit 1에서 정의하며, Unit 4에서 수정할 필요가 없다.

**ADOT 설정 YAML (inline):**

```yaml
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317

processors:
  batch:
    timeout: 60s
    send_batch_size: 50

exporters:
  prometheusremotewrite:
    endpoint: <AMP_REMOTE_WRITE_URL>
    auth:
      authenticator: sigv4auth
    resource_to_telemetry_conversion:
      enabled: true

extensions:
  sigv4auth:
    region: ap-northeast-2
    service: aps

service:
  extensions: [sigv4auth]
  pipelines:
    metrics:
      receivers: [otlp]
      processors: [batch]
      exporters: [prometheusremotewrite]
```

**주요 설정 포인트:**
- `<AMP_REMOTE_WRITE_URL>`: ObservabilityStack에서 AMP Workspace 생성 후 cross-stack 참조로 주입
- SigV4 인증: ECS Task 역할에 AMP remote write 권한 필요
- OTLP gRPC receiver: Gateway가 localhost:4317로 메트릭 push

### 7.3 ObservabilityStack Cross-stack Export

| Export Name | Resource Type | 참조 스택 |
|-------------|--------------|----------|
| {StackName}:AmpRemoteWriteUrl | AMP remote write URL | ComputeStack |
| {StackName}:AmpWorkspaceId | AMP workspace ID | (운영 참조용) |

---

## 8. ComputeStack 상세 설계

### 8.1 ECS Cluster 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Cluster Name | {app}-{env}-cluster | 예: `claude-proxy-dev-cluster` |
| Capacity Providers | FARGATE, FARGATE_SPOT | Fargate 전용 |
| Container Insights | Enabled | CloudWatch Container Insights 활성화 |

### 8.2 ECS Task Definition 설계 (Skeleton)

#### 8.2.1 Task 정의 기본 속성

| 속성 | 값 | 설명 |
|-----|-----|------|
| Family | {app}-{env}-gateway-task | |
| Launch Type | FARGATE | |
| Network Mode | awsvpc | VPC 네이티브 |
| CPU | 768 (0.75 vCPU) | App 0.5 + ADOT 0.25 |
| Memory | 1536 (1.5GB) | App 1GB + ADOT 512MB |
| Task Role | {app}-{env}-gateway-task-role | 애플리케이션 권한 |
| Execution Role | {app}-{env}-gateway-execution-role | ECR pull, Secrets 읽기 |

#### 8.2.2 App Container 정의 (Skeleton)

| 속성 | 값 | 설명 |
|-----|-----|------|
| Name | gateway-app | |
| Image | nginx:latest | **Placeholder metadata only** (Unit 1에서는 ECS Service 미생성) |
| CPU | 512 (0.5 vCPU) | |
| Memory | 1024 (1GB) | Hard limit |
| Port Mappings | 8000:8000 (TCP) | ALB target port |
| Essential | true | 이 컨테이너 종료 시 Task 종료 |
| Health Check | Command: `["CMD-SHELL", "curl -f http://localhost:8000/healthz || exit 1"]` | |
| | Interval: 30초 | |
| | Timeout: 5초 | |
| | Retries: 3 | |
| | Start Period: 60초 | |
| Logging | awslogs | CloudWatch Logs |
| Log Group | /ecs/{app}-{env}-gateway | |
| Log Stream Prefix | gateway-app | |
| Environment Variables | RDS_PROXY_ENDPOINT: placeholder | **Unit 4에서 실제 값으로 교체** |
| | DB_SECRET_ARN: placeholder | |
| | KMS_KEY_ARN: placeholder | |
| | AMP_WORKSPACE_ID: placeholder | |
| | IDENTITY_STORE_ID: placeholder | |
| | AWS_REGION: ap-northeast-2 | |

#### 8.2.3 ADOT Collector Sidecar 정의

| 속성 | 값 | 설명 |
|-----|-----|------|
| Name | adot-collector | |
| Image | public.ecr.aws/aws-observability/aws-otel-collector:latest | AWS 공식 이미지 (Task Definition metadata only) |
| CPU | 256 (0.25 vCPU) | |
| Memory | 512 (512MB) | Hard limit |
| Port Mappings | 4317:4317 (TCP) | OTLP gRPC |
| Essential | false | 이 컨테이너 종료해도 Task 유지 |
| Logging | awslogs | CloudWatch Logs |
| Log Group | /ecs/{app}-{env}-gateway | |
| Log Stream Prefix | adot-collector | |
| Environment Variables | AOT_CONFIG_CONTENT: <inline YAML> | 7.2절 ADOT 설정 YAML |
| | AWS_REGION: ap-northeast-2 | |

#### 8.2.4 Unit 4 업데이트 가이드

Unit 4 (Gateway 구현) 완료 후, `infra/stacks/compute_stack.py`를 직접 수정하여 다음 항목을 업데이트한다:

1. **App 컨테이너 이미지**: `nginx:latest` → ECR URI `{account}.dkr.ecr.{region}.amazonaws.com/{app}-{env}-gateway:latest`
2. **환경변수 값**: placeholder → 실제 cross-stack 참조 값
   - `RDS_PROXY_ENDPOINT`: DataStack export
   - `DB_SECRET_ARN`: DataStack export
   - `KMS_KEY_ARN`: KMS key ARN
   - `AMP_WORKSPACE_ID`: ObservabilityStack export
   - `IDENTITY_STORE_ID`: AWS Identity Center ID (context 또는 환경변수)
3. **ADOT AOT_CONFIG_CONTENT**: `<AMP_REMOTE_WRITE_URL>` placeholder를 ObservabilityStack export로 교체

**별도 스크립트/자동화 불필요. Code Generation 단계에서 인프라 코드 수정도 함께 포함.**

### 8.3 ECS Service 생성 범위

Unit 1에서는 **ECS Service를 생성하지 않는다**. ComputeStack은 다음 리소스까지만 책임진다.

- ECS Cluster
- Fargate Task Definition skeleton
- ECR Repository
- ECS 관련 IAM 역할

실제 ECS Service 생성 및 Task 기동은 **Unit 4**에서 Gateway Docker 이미지가 준비된 후 수행한다.

**Unit 4에서 적용할 ECS Service 값:**

| 속성 | 값 | 설명 |
|-----|-----|------|
| Service Name | {app}-{env}-gateway-service | |
| Task Definition | {app}-{env}-gateway-task | Unit 1에서 미리 등록 |
| Desired Count | dev: 1, staging/prod: 2 | 환경별 코드 분기 |
| Launch Type | FARGATE | |
| Platform Version | LATEST | |
| VPC | NetworkStack VPC | Cross-stack 참조 |
| Subnets | private-app subnets | NetworkStack export |
| Security Groups | ecs-sg | NetworkStack export |
| Assign Public IP | false | Private subnet |
| Health Check Grace Period | 60초 | ALB health check 유예 |
| Deployment Configuration | Min healthy: 100%, Max: 200% | Rolling update |
| Circuit Breaker | Enabled (rollback on failure) | |
| Auto-scaling | Disabled (v1) | 이후 단계 추가 예정 |

### 8.4 Lambda Function 설계 (Skeleton)

#### 8.4.1 Lambda 정의 기본 속성

| 속성 | 값 | 설명 |
|-----|-----|------|
| Function Name | {app}-{env}-token-service | |
| Runtime | python3.13 | |
| Handler | handler.lambda_handler | **Unit 3에서 실제 경로로 교체** |
| Code | Inline placeholder | **Unit 3에서 실제 코드로 교체** |
| Timeout | 30초 | |
| Memory | 512MB | |
| Execution Role | {app}-{env}-token-service-execution-role | |
| VPC | NetworkStack VPC | Cross-stack 참조 |
| Subnets | private-app subnets | NetworkStack export |
| Security Groups | lambda-sg | NetworkStack export |
| Environment Variables | RDS_PROXY_ENDPOINT: placeholder | **Unit 3에서 실제 값으로 교체** |
| | DB_SECRET_ARN: placeholder | |
| | KMS_KEY_ARN: placeholder | |
| | AWS_REGION: ap-northeast-2 | |
| Reserved Concurrency | (none) | v1에서는 기본 계정 한도 |

#### 8.4.2 Lambda Inline Placeholder 코드

```python
def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': '{"message": "Token Service skeleton - to be implemented in Unit 3"}'
    }
```

#### 8.4.3 Unit 3 업데이트 가이드

Unit 3 (Token Service 구현) 완료 후, `infra/stacks/compute_stack.py`를 직접 수정하여 다음 항목을 업데이트한다:

1. **Lambda 코드**: inline placeholder → `lambda.Code.from_asset("lambda")` (Lambda 코드 디렉토리)
2. **Handler**: `handler.lambda_handler` → `handler.lambda_handler` (실제 경로 확인)
3. **환경변수 값**: placeholder → 실제 cross-stack 참조 값
   - `RDS_PROXY_ENDPOINT`: DataStack export
   - `DB_SECRET_ARN`: DataStack export
   - `KMS_KEY_ARN`: KMS key ARN

**별도 스크립트/자동화 불필요. Code Generation 단계에서 인프라 코드 수정도 함께 포함.**

### 8.5 ECR Repository 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Repository Name | {app}-{env}-gateway | 예: `claude-proxy-dev-gateway` |
| Image Tag Mutability | MUTABLE | latest 태그 덮어쓰기 가능 |
| Scan on Push | Enabled | 취약점 스캔 자동 실행 |
| Encryption | AES256 (AWS managed) | |
| Lifecycle Policy | Untagged 이미지 30일 후 삭제 | |
| Image Retention | 최근 10개 tagged 이미지 보존 | |

**Unit 4에서 Docker 이미지 빌드 후 이 Repository에 push**

### 8.6 IAM 역할 설계

#### 8.6.1 ECS Task Execution Role

**역할 이름**: `{app}-{env}-gateway-execution-role`

**책임**: ECS Task 시작 시 필요한 권한 (ECR pull, Secrets 읽기, CloudWatch Logs 쓰기)

**Inline Policy (CDK grant 사용):**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage"
      ],
      "Resource": [
        "arn:aws:ecr:ap-northeast-2:<account>:repository/{app}-{env}-gateway"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": [
        "arn:aws:secretsmanager:ap-northeast-2:<account>:secret:{app}/{env}/db-credentials-*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:ap-northeast-2:<account>:log-group:/ecs/{app}-{env}-gateway:*"
      ]
    }
  ]
}
```

#### 8.6.2 ECS Task Role

**역할 이름**: `{app}-{env}-gateway-task-role`

**책임**: 애플리케이션 런타임 권한 (Bedrock, Secrets Manager, AMP, Identity Store, KMS)

**Inline Policy (CDK grant 사용):**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": [
        "arn:aws:bedrock:ap-northeast-2::foundation-model/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": [
        "arn:aws:secretsmanager:ap-northeast-2:<account>:secret:{app}/{env}/db-credentials-*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "aps:RemoteWrite"
      ],
      "Resource": [
        "arn:aws:aps:ap-northeast-2:<account>:workspace/<workspace-id>"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "identitystore:ListUsers",
        "identitystore:DescribeUser"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "kms:Encrypt"
      ],
      "Resource": [
        "arn:aws:kms:ap-northeast-2:<account>:key/<key-id>"
      ],
      "Condition": {
        "StringEquals": {
          "kms:ViaService": "secretsmanager.ap-northeast-2.amazonaws.com"
        }
      }
    },
    {
      "Effect": "Allow",
      "Action": [
        "ec2:CreateNetworkInterface",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DeleteNetworkInterface"
      ],
      "Resource": "*"
    }
  ]
}
```

#### 8.6.3 Lambda Execution Role

**역할 이름**: `{app}-{env}-token-service-execution-role`

**책임**: Lambda 실행 권한 (KMS Encrypt/Decrypt, Secrets 읽기, VPC ENI 관리)

**Inline Policy (CDK grant 사용):**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:GenerateDataKey"
      ],
      "Resource": [
        "arn:aws:kms:ap-northeast-2:<account>:key/<key-id>"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": [
        "arn:aws:secretsmanager:ap-northeast-2:<account>:secret:{app}/{env}/db-credentials-*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "ec2:CreateNetworkInterface",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DeleteNetworkInterface"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:ap-northeast-2:<account>:log-group:/aws/lambda/{app}-{env}-token-service:*"
      ]
    }
  ]
}
```

**주요 차이점 (ECS Task Role과 비교):**
- Lambda는 **KMS Decrypt** 권한 필요 (Virtual Key 복호화)
- Lambda는 **Bedrock, AMP, Identity Store** 권한 불필요 (Token Service는 Virtual Key만 발급)

### 8.7 KMS Key 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Key Name | {app}-{env}-virtual-key | |
| Alias | alias/{app}-{env}-virtual-key | |
| Key Spec | SYMMETRIC_DEFAULT | 256-bit AES-GCM |
| Key Usage | ENCRYPT_DECRYPT | |
| Automatic Rotation | Enabled (1년 주기) | |
| Deletion Pending Period | 30일 | 최대값 |
| Multi-Region | false | 단일 리전 |

**Key Policy:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "Enable IAM policies",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<account>:root"
      },
      "Action": "kms:*",
      "Resource": "*"
    },
    {
      "Sid": "Allow Lambda to encrypt and decrypt",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<account>:role/{app}-{env}-token-service-execution-role"
      },
      "Action": [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:GenerateDataKey"
      ],
      "Resource": "*"
    },
    {
      "Sid": "Allow ECS Task to encrypt only (Admin rotate)",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<account>:role/{app}-{env}-gateway-task-role"
      },
      "Action": [
        "kms:Encrypt"
      ],
      "Resource": "*"
    }
  ]
}
```

**주요 설계 포인트:**
- Lambda Token Service: Encrypt/Decrypt (Virtual Key 발급/재조회)
- ECS Gateway: Encrypt only (Admin API에서 Virtual Key rotate 시 신규 ciphertext 생성)
- **ECS Gateway는 저장된 key ciphertext 복호화 권한 불필요** (런타임에 fingerprint 비교만 수행)

---

## 9. ApiStack 상세 설계

### 9.1 API Gateway 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Name | {app}-{env}-token-api | |
| Type | REST API | |
| Endpoint Type | REGIONAL | |
| Authorization | IAM | SigV4 필수 |
| Throttling | Burst: 5,000 req/s, Rate: 10,000 req/s | 기본값 |
| Logging | ERROR | access log 미활성화 (v1) |
| Stage Name | prod | |
| Deploy | true | 자동 배포 |
| API Key Required | false | SigV4로 충분 |

**API Gateway 리소스 구조:**
```
/v1
  /auth
    /virtual-key
      POST (Lambda 통합)
```

**Lambda 통합 설정:**
- Integration Type: AWS_PROXY
- Lambda Function: ComputeStack Lambda Function ARN (cross-stack 참조)
- Credentials: API Gateway execution role

### 9.2 ALB 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Name | {app}-{env}-alb | |
| Scheme | internet-facing | Public subnet |
| IP Address Type | ipv4 | |
| VPC | NetworkStack VPC | Cross-stack 참조 |
| Subnets | public subnets (2 AZ) | NetworkStack export |
| Security Groups | alb-sg | NetworkStack export |
| Idle Timeout | 300초 | 장시간 스트리밍 지원 |
| Deletion Protection | prod만 활성화 | dev/staging false |
| Access Logs | Disabled (v1) | |
| Drop Invalid Header Fields | true | 보안 강화 |

### 9.3 Target Group 설계

| 속성 | 값 | 설명 |
|-----|-----|------|
| Name | {app}-{env}-gateway-tg | |
| Target Type | ip | Fargate awsvpc 모드 |
| Protocol | HTTP | ALB → ECS Task |
| Port | 8000 | ECS Task port |
| VPC | NetworkStack VPC | |
| Health Check Protocol | HTTP | |
| Health Check Path | /healthz | |
| Health Check Interval | 30초 | |
| Health Check Timeout | 5초 | |
| Healthy Threshold | 2 | |
| Unhealthy Threshold | 2 | |
| Deregistration Delay | 30초 | |
| Stickiness | Disabled | |

**Target Group 연결 방식:**
Unit 1에서는 Target Group을 비어 있는 상태로 생성한다. Unit 4에서 ComputeStack의 ECS Service가 이 Target Group을 참조하여 Task를 등록한다.

### 9.4 ALB Listener 설계

#### 9.4.1 HTTPS Listener (Port 443)

| 속성 | 값 | 설명 |
|-----|-----|------|
| Protocol | HTTPS | |
| Port | 443 | |
| SSL Certificate | ACM certificate ARN (context) | `acm_certificate_arn` |
| SSL Policy | ELBSecurityPolicy-TLS13-1-2-2021-06 | TLS 1.2+ |
| Default Action | Forward to target group | {app}-{env}-gateway-tg |

**Listener Rule:**
- Condition: Path pattern `/v1/*`
- Action: Forward to target group
- Priority: 1

#### 9.4.2 HTTP Listener (Port 80) - Redirect

| 속성 | 값 | 설명 |
|-----|-----|------|
| Protocol | HTTP | |
| Port | 80 | |
| Default Action | Redirect to HTTPS | Status code 301 (permanent) |

**모든 HTTP 요청은 HTTPS로 강제 리다이렉트**

### 9.5 ACM 인증서 처리

- **CDK에서 인증서 자동 생성하지 않음**
- **Context 파라미터로 기존 인증서 ARN 전달 필수**
- 도메인 이름 및 Route 53 관리는 CDK 범위 밖 (수동 설정)

**Context 예시:**
```bash
cdk deploy -c acm_certificate_arn=arn:aws:acm:ap-northeast-2:123456789012:certificate/abc123-def456
```

---

## 10. 보안 그룹 매트릭스 (전체)

아래 표는 모든 보안 그룹의 Inbound/Outbound 규칙을 한눈에 볼 수 있도록 정리한 것이다.

| 보안 그룹 | Inbound 포트 | Inbound Source | Outbound 포트 | Outbound Destination | 설명 |
|----------|-------------|----------------|--------------|---------------------|------|
| alb-sg | 443 | 0.0.0.0/0 | 8000 | ecs-sg | 인터넷 → ALB HTTPS |
| | 80 | 0.0.0.0/0 | | | HTTP (redirect only) |
| ecs-sg | 8000 | alb-sg | 443 | endpoint-sg | ALB → ECS Task |
| | | | 5432 | rds-sg | ECS → RDS Proxy |
| lambda-sg | (none) | - | 443 | endpoint-sg | Lambda → VPC Endpoint |
| | | | 5432 | rds-sg | Lambda → RDS Proxy |
| rds-sg | 5432 | ecs-sg | (none) | - | ECS → Aurora/RDS Proxy |
| | 5432 | lambda-sg | | | Lambda → Aurora/RDS Proxy |
| endpoint-sg | 443 | ecs-sg | (none) | - | ECS → VPC Endpoint |
| | 443 | lambda-sg | | | Lambda → VPC Endpoint |

---

## 11. IAM 역할 및 권한 매트릭스

| 역할 | 서비스 | 주요 권한 | Resource Scope | 설명 |
|-----|--------|----------|----------------|------|
| {app}-{env}-gateway-execution-role | ECS Task Execution | ECR: GetAuthorizationToken, BatchGetImage | 특정 ECR repo | ECS Task 시작 |
| | | Secrets Manager: GetSecretValue | 특정 secret | DB credentials 읽기 |
| | | Logs: CreateLogStream, PutLogEvents | 특정 log group | CloudWatch Logs |
| {app}-{env}-gateway-task-role | ECS Task | Bedrock: InvokeModel, InvokeModelWithResponseStream | foundation-model/* | Bedrock 호출 |
| | | Secrets Manager: GetSecretValue | 특정 secret | DB credentials 읽기 |
| | | APS: RemoteWrite | 특정 AMP workspace | AMP 메트릭 전송 |
| | | Identity Store: ListUsers, DescribeUser | * (read-only) | 사용자 sync |
| | | KMS: Encrypt | 특정 key | Admin rotate 경로 |
| | | EC2: CreateNetworkInterface, DescribeNetworkInterfaces, DeleteNetworkInterface | * | VPC ENI 관리 |
| {app}-{env}-token-service-execution-role | Lambda | KMS: Encrypt, Decrypt, GenerateDataKey | 특정 key | Virtual Key 암복호화 |
| | | Secrets Manager: GetSecretValue | 특정 secret | DB credentials 읽기 |
| | | EC2: CreateNetworkInterface, DescribeNetworkInterfaces, DeleteNetworkInterface | * | VPC ENI 관리 |
| | | Logs: CreateLogGroup, CreateLogStream, PutLogEvents | 특정 log group | CloudWatch Logs |

**최소 권한 원칙 준수:**
- 모든 리소스 ARN은 특정 리소스로 제한 (와일드카드 최소화)
- EC2 DescribeNetworkInterfaces는 읽기 전용이므로 와일드카드 허용
- Identity Store는 사용자 기본 정보 sync만 수행하므로 ListUsers/DescribeUser만 허용

---

## 12. Skeleton 정의 및 Unit 3/4 업데이트 가이드

### 12.1 Skeleton 범위 정의

**Skeleton**은 Unit 1에서 인프라를 프로비저닝할 때 애플리케이션 코드가 아직 없으므로, 최소한의 placeholder 값으로 리소스를 생성하는 것을 의미한다.

ECS의 경우 Unit 1에서는 **Task Definition만 등록**하고, ECS Service 및 실제 Task 기동은 Unit 4로 미룬다.

#### 12.1.1 ECS Task Definition Skeleton 범위

| 항목 | Skeleton 값 | Unit 4 업데이트 값 |
|------|------------|-------------------|
| 컨테이너 이미지 | nginx:latest | ECR URI ({account}.dkr.ecr.{region}.amazonaws.com/{app}-{env}-gateway:latest) |
| 환경변수 값 | placeholder 문자열 | 실제 cross-stack 참조 값 |
| 환경변수 키 | RDS_PROXY_ENDPOINT, DB_SECRET_ARN, KMS_KEY_ARN, AMP_WORKSPACE_ID, IDENTITY_STORE_ID | (유지) |
| ADOT AOT_CONFIG_CONTENT | `<AMP_REMOTE_WRITE_URL>` placeholder | ObservabilityStack export |

#### 12.1.2 Lambda Function Skeleton 범위

| 항목 | Skeleton 값 | Unit 3 업데이트 값 |
|------|------------|-------------------|
| Lambda 코드 | inline placeholder (Hello World) | lambda.Code.from_asset("lambda") |
| Handler | handler.lambda_handler | (확인 후 유지 또는 수정) |
| 환경변수 값 | placeholder 문자열 | 실제 cross-stack 참조 값 |
| 환경변수 키 | RDS_PROXY_ENDPOINT, DB_SECRET_ARN, KMS_KEY_ARN | (유지) |

### 12.2 Unit 3 업데이트 가이드 (Lambda Token Service)

**업데이트 시점:** Unit 3 (Token Service) Code Generation 완료 후

**업데이트 대상 파일:** `infra/stacks/compute_stack.py`

**업데이트 항목:**

1. **Lambda 코드 경로:**
   ```python
   # Before (Skeleton)
   code=lambda_.Code.from_inline('def lambda_handler(event, context): return {"statusCode": 200, "body": "..."}')
   
   # After (Unit 3)
   code=lambda_.Code.from_asset("lambda")
   ```

2. **환경변수 값:**
   ```python
   # Before (Skeleton)
   environment={
       "RDS_PROXY_ENDPOINT": "placeholder",
       "DB_SECRET_ARN": "placeholder",
       "KMS_KEY_ARN": "placeholder",
   }
   
   # After (Unit 3)
   environment={
       "RDS_PROXY_ENDPOINT": data_stack.rds_proxy_endpoint,
       "DB_SECRET_ARN": data_stack.db_secret_arn,
       "KMS_KEY_ARN": kms_key.key_arn,
   }
   ```

**배포 방법:**
```bash
cd infra
cdk diff  # 변경 사항 확인
cdk deploy ComputeStack ApiStack  # ComputeStack, ApiStack 재배포
```

### 12.3 Unit 4 업데이트 가이드 (Gateway)

**업데이트 시점:** Unit 4 (Gateway Runtime + Admin) Code Generation 완료 후

**업데이트 대상 파일:** `infra/stacks/compute_stack.py`

**업데이트 항목:**

1. **ECS 컨테이너 이미지:**
   ```python
   # Before (Skeleton)
   image=ecs.ContainerImage.from_registry("nginx:latest")
   
   # After (Unit 4)
   image=ecs.ContainerImage.from_ecr_repository(
       repository=ecr_repo,
       tag="latest"
   )
   ```

2. **ECS 환경변수 값:**
   ```python
   # Before (Skeleton)
   environment={
       "RDS_PROXY_ENDPOINT": "placeholder",
       "DB_SECRET_ARN": "placeholder",
       "KMS_KEY_ARN": "placeholder",
       "AMP_WORKSPACE_ID": "placeholder",
       "IDENTITY_STORE_ID": "placeholder",
   }
   
   # After (Unit 4)
   environment={
       "RDS_PROXY_ENDPOINT": data_stack.rds_proxy_endpoint,
       "DB_SECRET_ARN": data_stack.db_secret_arn,
       "KMS_KEY_ARN": kms_key.key_arn,
       "AMP_WORKSPACE_ID": observability_stack.amp_workspace_id,
       "IDENTITY_STORE_ID": self.node.try_get_context("identity_store_id"),
   }
   ```

3. **ADOT AOT_CONFIG_CONTENT:**
   ```python
   # Before (Skeleton)
   adot_config = f"""
   ...
   exporters:
     prometheusremotewrite:
       endpoint: <AMP_REMOTE_WRITE_URL>
   ...
   """
   
   # After (Unit 4)
   adot_config = f"""
   ...
   exporters:
     prometheusremotewrite:
       endpoint: {observability_stack.amp_remote_write_url}
   ...
   """
   ```

**배포 방법:**
```bash
# 1. Docker 이미지 빌드 및 ECR push
cd gateway
docker build -t {app}-{env}-gateway:latest .
aws ecr get-login-password --region ap-northeast-2 | docker login --username AWS --password-stdin {account}.dkr.ecr.ap-northeast-2.amazonaws.com
docker tag {app}-{env}-gateway:latest {account}.dkr.ecr.ap-northeast-2.amazonaws.com/{app}-{env}-gateway:latest
docker push {account}.dkr.ecr.ap-northeast-2.amazonaws.com/{app}-{env}-gateway:latest

# 2. CDK 재배포
cd infra
cdk diff  # 변경 사항 확인
cdk deploy ComputeStack ApiStack  # ComputeStack, ApiStack 재배포
```

---

## 13. 리소스 명명 규칙 정리

모든 AWS 리소스는 일관된 명명 규칙을 따른다. 이는 운영 시 리소스 식별 및 자동화를 용이하게 한다.

| 리소스 유형 | 명명 규칙 | 예시 (dev 환경) |
|-----------|---------|----------------|
| CDK Stack | {app}-{env}-{layer} | claude-proxy-dev-network |
| VPC | {app}-{env}-vpc | claude-proxy-dev-vpc |
| Subnet | {app}-{env}-{layer}-{az} | claude-proxy-dev-public-2a |
| Security Group | {app}-{env}-{service}-sg | claude-proxy-dev-alb-sg |
| VPC Endpoint | {app}-{env}-{service}-endpoint | claude-proxy-dev-bedrock-endpoint |
| Aurora Cluster | {app}-{env}-aurora | claude-proxy-dev-aurora |
| RDS Proxy | {app}-{env}-rds-proxy | claude-proxy-dev-rds-proxy |
| Secrets Manager | {app}/{env}/db-credentials | claude-proxy/dev/db-credentials |
| ECS Cluster | {app}-{env}-cluster | claude-proxy-dev-cluster |
| ECS Task Definition | {app}-{env}-gateway-task | claude-proxy-dev-gateway-task |
| ECS Service | {app}-{env}-gateway-service | claude-proxy-dev-gateway-service |
| ECR Repository | {app}-{env}-gateway | claude-proxy-dev-gateway |
| Lambda Function | {app}-{env}-token-service | claude-proxy-dev-token-service |
| API Gateway | {app}-{env}-token-api | claude-proxy-dev-token-api |
| ALB | {app}-{env}-alb | claude-proxy-dev-alb |
| Target Group | {app}-{env}-gateway-tg | claude-proxy-dev-gateway-tg |
| AMP Workspace | {app}-{env} (alias) | claude-proxy-dev |
| KMS Key | {app}-{env}-virtual-key | claude-proxy-dev-virtual-key |
| KMS Alias | alias/{app}-{env}-virtual-key | alias/claude-proxy-dev-virtual-key |
| IAM Role | {app}-{env}-{service}-{role-type} | claude-proxy-dev-gateway-task-role |
| CloudWatch Log Group | /aws/{service}/{app}-{env}-{component} | /aws/ecs/claude-proxy-dev-gateway |
| VPC Flow Log Group | /aws/vpc/{app}-{env}-flow-logs | /aws/vpc/claude-proxy-dev-flow-logs |

**주요 변수:**
- `{app}`: `app_name` context (기본값: `claude-proxy`)
- `{env}`: `environment` context (dev/staging/prod)
- `{layer}`: network, data, compute, api, observability
- `{az}`: 2a, 2c (ap-northeast-2 기준)
- `{service}`: alb, ecs, lambda, rds, endpoint 등
- `{role-type}`: task-role, execution-role, etc.

---

## 14. 배포 워크플로우

### 14.1 최초 배포 (Unit 1 완료 후)

**사전 준비:**
1. AWS CLI 설정: `aws configure`
2. CDK Bootstrap: `cdk bootstrap aws://<account>/<region>`
3. ACM 인증서 발급: AWS Console에서 수동 생성 후 ARN 확보

**배포 명령:**
```bash
cd infra

# 1. Synthesize (CloudFormation 템플릿 생성)
cdk synth --all

# 2. Diff (변경 사항 확인)
cdk diff --all

# 3. Deploy (전체 스택 배포)
cdk deploy --all \
  -c environment=dev \
  -c region=ap-northeast-2 \
  -c acm_certificate_arn=arn:aws:acm:ap-northeast-2:123456789012:certificate/abc123 \
  --require-approval broadening
```

**배포 순서 (CDK 자동 처리):**
1. NetworkStack
2. DataStack
3. ObservabilityStack
4. ComputeStack
5. ApiStack

**예상 배포 시간:** 약 15-20분 (Aurora, ALB 생성 시간 포함)

### 14.2 Unit 3/4 완료 후 재배포

**Unit 3 (Token Service) 완료 후:**
```bash
cd infra
cdk diff ComputeStack ApiStack  # 변경 사항 확인
cdk deploy ComputeStack ApiStack  # Lambda 코드 업데이트
```

**Unit 4 (Gateway) 완료 후:**
```bash
# 1. Docker 이미지 빌드 및 ECR push
cd gateway
docker build -t claude-proxy-dev-gateway:latest .
aws ecr get-login-password --region ap-northeast-2 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.ap-northeast-2.amazonaws.com
docker tag claude-proxy-dev-gateway:latest 123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/claude-proxy-dev-gateway:latest
docker push 123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/claude-proxy-dev-gateway:latest

# 2. CDK 재배포
cd infra
cdk diff ComputeStack ApiStack
cdk deploy ComputeStack ApiStack  # ECS Task Definition 업데이트
```

### 14.3 운영 환경 배포

**dev → staging → prod 순서 배포 권장**

```bash
# staging 배포
cdk deploy --all \
  -c environment=staging \
  -c acm_certificate_arn=arn:aws:acm:ap-northeast-2:123456789012:certificate/staging-cert

# prod 배포
cdk deploy --all \
  -c environment=prod \
  -c acm_certificate_arn=arn:aws:acm:ap-northeast-2:123456789012:certificate/prod-cert
```

**주의사항:**
- prod 환경은 deletion protection 활성화되므로 삭제 시 수동 비활성화 필요
- prod 배포는 staging 검증 후 진행 권장
- 모든 배포는 `--require-approval broadening` 옵션으로 IAM 권한 변경 승인 필요

---

## 15. 운영 고려사항

### 15.1 모니터링 포인트

| 항목 | 메트릭/로그 | 알람 기준 |
|------|-----------|----------|
| ALB 5xx 에러율 | ALB HTTPCode_Target_5XX_Count | > 5% for 5분 |
| ECS Task 비정상 종료 | ECS task stopped (reason) | 즉시 |
| Lambda 에러율 | Lambda Errors | > 5% for 5분 |
| Aurora CPU | Aurora CPUUtilization | > 80% for 10분 |
| Aurora 연결 수 | Aurora DatabaseConnections | > 80% of max |
| RDS Proxy 연결 실패 | RDS Proxy ConnectionErrors | > 5% for 5분 |

### 15.2 비용 최적화

- **Aurora Serverless v2**: 트래픽 패턴 관찰 후 min/max capacity 조정
- **ECS Fargate**: Auto-scaling 구성 (Unit 4 이후)
- **CloudWatch Logs**: 보존 기간 조정 (dev 7일 → 3일 검토)

### 15.3 보안 강화 옵션

- **VPC Endpoint Policy**: 더 세밀한 리소스 ARN 제한
- **ALB WAF**: AWS WAF 연동 (v2 고려)
- **Security Hub**: AWS Security Hub 통합 (v2 고려)

---

## 16. 참조 문서 요약

본 Functional Design은 다음 문서의 설계 결정을 구현한다:

1. **System NFR Decisions**: 전체 시스템 비기능 요구사항 (보안, 네트워크, 인증, 관측성)
2. **Application Design**: 5개 스택 구성 및 컴포넌트 책임
3. **System Architecture**: Private Subnet First, VPC Endpoint 전략, 인증 경계
4. **PRD**: 제품 요구사항 및 배포 토폴로지
5. **ERD**: PostgreSQL 데이터 모델 (DB migration은 Unit 2 책임)
6. **API Specification**: Token Service, Runtime Gateway, Admin API 명세

---

## 17. 다음 단계

본 Functional Design이 승인되면, 다음 단계는:

1. **Code Generation (Unit 1)**: CDK Python 코드 생성
   - 5개 스택 파일 생성 (`infra/stacks/*.py`)
   - CDK App 진입점 생성 (`infra/app.py`)
   - Context 파라미터 정의 (`cdk.json`)
   - CDK 의존성 정의 (`pyproject.toml`)

2. **Build & Test (Unit 1)**: CDK 배포 및 검증
   - `cdk synth` 성공
   - `cdk deploy` 전체 스택 배포
   - VPC, Aurora, ECR Repository, Lambda, API Gateway, ALB, Target Group, AMP 리소스 생성 확인
   - Cross-stack 참조 정상 동작 확인
   - ECS Task Definition 등록 확인 (Unit 1에서는 ECS Service/Task 미생성)
   - API Gateway → Lambda skeleton 연결 확인

3. **Unit 2**: Shared Models & DB Migration
   - SQLAlchemy ORM 모델 생성
   - Alembic 마이그레이션 실행
   - Unit 1의 Aurora에 테이블 생성

4. **Unit 3**: Token Service 구현
   - Lambda 코드 작성
   - `compute_stack.py` 업데이트
   - 재배포

5. **Unit 4**: Gateway 구현
   - FastAPI 앱 작성
   - Docker 이미지 빌드 및 ECR push
   - `compute_stack.py` 업데이트
   - 재배포

---

## 문서 끝

본 문서는 Unit 1: Foundation Infrastructure의 **Functional Design**을 완료했다. 모든 설계 결정은 Questions Round 1의 답변을 기반으로 하며, System NFR Decisions 및 Application Design 문서와 일관성을 유지한다.

**최종 검토 항목:**
- [x] 5개 스택 전체 상세 설계 완료
- [x] VPC, 서브넷, VPC Endpoint, 보안 그룹 정의
- [x] Aurora, RDS Proxy, Secrets Manager 정의
- [x] ECS Task Definition, Lambda Function skeleton 정의
- [x] ECS Service는 Unit 4 scope로 이관됨 문서화
- [x] API Gateway, ALB, Target Group 정의
- [x] AMP Workspace, ADOT 설정 정의
- [x] IAM 역할 및 KMS Key 정의
- [x] Cross-stack 참조 및 의존성 정의
- [x] CDK Context 및 환경별 분기 정의
- [x] Skeleton 범위 및 Unit 3/4 업데이트 가이드 정의
- [x] 리소스 명명 규칙 정리
- [x] 배포 워크플로우 정의

**다음 단계: Code Generation**
