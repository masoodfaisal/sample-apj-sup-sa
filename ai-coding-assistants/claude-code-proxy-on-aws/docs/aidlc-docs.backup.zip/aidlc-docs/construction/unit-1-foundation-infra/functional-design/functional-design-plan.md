# Unit 1: Foundation Infrastructure - Functional Design Plan

- 생성일: 2026-04-01
- 단계: CONSTRUCTION - Functional Design
- 상태: Completed

---

## 목적

Unit 1의 AWS CDK 기반 인프라 전체(5개 스택)에 대한 상세 기능 설계를 수행한다. "기능 설계"라는 용어는 일반적으로 애플리케이션 비즈니스 로직을 다루지만, Unit 1의 경우 인프라 프로비저닝 자체가 핵심 책임이므로, 본 문서에서는 **"인프라 구성의 비즈니스 로직"**을 다룬다.

즉, WHAT infrastructure가 필요하고 WHY 그러한 구성이 필요한지를 명확히 정의한다.

---

## 체크리스트

### 1. NetworkStack 기능 설계
- [x] VPC 설계 (CIDR, DNS 설정, 라우팅 기본값)
- [x] 서브넷 설계 (public, private-app, private-data)
- [x] VPC Endpoint 설계 (Interface/Gateway Endpoint 전체 목록 및 정책)
- [x] 보안 그룹 설계 (ALB, ECS, Lambda, RDS, Endpoint 별)
- [x] 라우팅 테이블 설계
- [x] NAT Gateway 비의존 전략 검증

### 2. DataStack 기능 설계
- [x] Aurora PostgreSQL Serverless v2 클러스터 설계
- [x] RDS Proxy 설계 (연결 풀, IAM 인증 설정)
- [x] Secrets Manager 시크릿 설계 (DB credentials)
- [x] 보안 그룹 및 서브넷 그룹 설계
- [x] 백업 및 유지보수 창 정책

### 3. ComputeStack 기능 설계
- [x] ECS Cluster 설계
- [x] Fargate Task Definition (skeleton) 설계
  - [x] App 컨테이너 skeleton (이미지 placeholder, 환경변수 구조)
  - [x] ADOT Collector sidecar 정의
  - [x] Task 역할 및 실행 역할
  - [x] 로깅 설정 (awslogs)
  - [x] Health check 정의
- [x] ECS Service는 Unit 4 scope로 이관됨 문서화
- [x] Lambda Function (skeleton) 설계
  - [x] 함수 구조 (코드 placeholder, 환경변수 구조)
  - [x] Lambda 실행 역할
  - [x] VPC 연결 설정
  - [x] 타임아웃 및 메모리

### 4. ApiStack 기능 설계
- [x] API Gateway 설계 (REST API, IAM 인증)
- [x] Lambda 통합 설정
- [x] ALB 설계 (internet-facing, HTTPS 전용)
- [x] Target Group 설계 (Unit 4 ECS Service 연결 대상)
- [x] ACM 인증서 처리 전략
- [x] Listener 규칙 설계

### 5. ObservabilityStack 기능 설계
- [x] AMP Workspace 설계
- [x] ADOT Collector 설정 구조
- [x] VPC Endpoint (aps-workspaces) 연동
- [x] IAM 역할 및 권한 (remote write)

### 6. IAM 역할 및 정책 설계
- [x] Lambda 실행 역할 (KMS, Secrets, RDS Proxy, VPC)
- [x] ECS Task 실행 역할 (ECR, Secrets, CloudWatch Logs)
- [x] ECS Task 역할 (Bedrock, RDS Proxy, AMP, Identity Store, KMS)
- [x] API Gateway 실행 역할
- [x] 최소 권한 원칙 준수 검증

### 7. KMS Key 설계
- [x] Virtual Key 암호화용 KMS Key
- [x] Key 정책 (Lambda, ECS Task 역할 사용 권한)

### 8. 교차 스택 참조 설계
- [x] NetworkStack → DataStack 참조 (VPC, Subnet, SG)
- [x] NetworkStack → ComputeStack 참조 (VPC, Subnet, SG)
- [x] DataStack → ComputeStack 참조 (RDS Proxy endpoint, Secrets ARN)
- [x] NetworkStack → ApiStack 참조 (VPC, Subnet, SG)
- [x] ComputeStack → ApiStack 참조 (Lambda Function ARN)
- [x] NetworkStack → ObservabilityStack 참조 (VPC Endpoint)
- [x] ObservabilityStack → ComputeStack 참조 (AMP remote write URL)

### 9. CDK Context 및 환경 설정 구조
- [x] Context 파라미터 정의 (environment, region, vpc_cidr, aurora_min_capacity, aurora_max_capacity)
- [x] 환경별 기본값 정의 (dev/staging/prod)
- [x] Stack 명명 규칙 정의

### 10. Skeleton 정의 명확화
- [x] ECS Task Definition의 skeleton 범위 명시
- [x] Lambda Function의 skeleton 범위 명시
- [x] Unit 3/4 완료 후 업데이트 필요 항목 문서화

---

## 다음 단계

1. Functional Design 승인
2. Unit 1 Code Generation 진행
3. CDK synth/diff 기반 검증 수행
