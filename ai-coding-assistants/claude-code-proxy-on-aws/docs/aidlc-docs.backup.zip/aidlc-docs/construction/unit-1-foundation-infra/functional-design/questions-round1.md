# Unit 1: Foundation Infrastructure - Functional Design Questions (Round 1)

- 생성일: 2026-04-01
- 상태: Answered

---

## 질문 분류

아래 질문들은 Unit 1의 상세 기능 설계를 위해 필요한 명확화 사항입니다. 각 질문에 `[Answer]:` 태그로 답변해 주세요.

---

## 1. 네트워크 구성 및 VPC 설계

### Q1.1: VPC CIDR 및 서브넷 구성
현재 PRD와 System NFR에서는 private subnet 우선 원칙과 3계층 서브넷(public, private-app, private-data)이 언급되어 있습니다.

**질문:**
- VPC의 기본 CIDR 블록은 무엇으로 설정할까요? (예: `10.0.0.0/16`)
- 각 서브넷 유형의 CIDR 할당 전략은 무엇으로 할까요? (예: public `/24`, private-app `/20`, private-data `/24`)
- 몇 개의 AZ에 배포할까요? (기본 2개 AZ를 가정하고 있지만 3개 AZ도 고려 대상인가요?)

[Answer]: VPC CIDR 10.0.0.0/16, 2개 AZ (ap-northeast-2a, 2c). 3계층 서브넷 유지: Public /24 x2 (10.0.0.0/24, 10.0.1.0/24 — ALB 전용), Private-app /20 x2 (10.0.16.0/20, 10.0.32.0/20 — ECS, Lambda, VPC Endpoints), Private-data /24 x2 (10.0.48.0/24, 10.0.49.0/24 — Aurora, RDS Proxy). 접근 제어는 보안 그룹으로 처리.

### Q1.2: VPC Endpoint Policy 상세 전략
System NFR에서는 VPC Endpoint policy를 통해 특정 리소스 ARN에 대한 접근만 허용하도록 명시되어 있습니다.

**질문:**
- VPC Endpoint policy는 모든 endpoint에 동일하게 적용할까요, 아니면 endpoint별로 다르게 구성할까요?
- Bedrock VPC Endpoint policy에서 허용할 모델 ID 범위를 미리 제한할까요, 아니면 일단 Bedrock service 전체에 대한 접근을 허용할까요?
- S3 Gateway Endpoint의 경우 ECR 이미지 레이어 접근만 허용하도록 제한할까요, 아니면 향후 확장을 고려해 더 넓은 범위를 허용할까요?

[Answer]: Endpoint별 개별 정책 적용. Bedrock: 전체 서비스 접근 허용 (모델 제어는 앱 레이어 정책 체인에서 처리). S3 Gateway: ECR 이미지 레이어 버킷만 허용 (ADOT 설정은 inline 환경변수이므로 S3 불필요). 나머지 endpoint: aws:PrincipalAccount 조건으로 해당 계정/리전 리소스로 제한.

### Q1.3: NAT Gateway 완전 제거 확인
System NFR에서는 NAT Gateway 없이 VPC Endpoint로 모든 AWS 서비스 접근을 처리하는 것을 기본 원칙으로 합니다.

**질문:**
- v1에서 NAT Gateway를 완전히 제거하고 배포할까요, 아니면 예외 상황을 위해 비활성화된 상태로 CDK 코드에만 포함시킬까요?
- 만약 NAT Gateway가 필요한 예외 상황이 발견되면 어떻게 처리할까요? (CDK context flag로 선택적 활성화?)

[Answer]: NAT Gateway 완전 제거. CDK 코드에 비활성 상태로도 남기지 않음. 모든 AWS 서비스 접근은 VPC Endpoint로 처리. 향후 필요 시 CDK context flag로 추가.

### Q1.4: VPC Flow Logs 설정
System NFR에서 VPC Flow Logs 활성화가 언급되어 있습니다.

**질문:**
- VPC Flow Logs의 destination은 CloudWatch Logs로 할까요, 아니면 S3로 할까요?
- Flow Logs의 로그 형식은 기본 형식으로 할까요, 아니면 커스텀 필드를 추가할까요?
- 로그 보존 기간은 며칠로 설정할까요? (예: 7일, 30일, 90일)

[Answer]: CloudWatch Logs로 전송, 기본 로그 형식, 보존 기간 prod 30일 / dev·staging 7일. CDK context flag (enable_vpc_flow_logs: true/false)로 활성화 여부 제어 가능하게 구성. 기본값은 true.

---

## 2. 데이터 계층 설계 (DataStack)

### Q2.1: Aurora Serverless v2 용량 설정
System NFR에서는 최소 0.5 ACU, 최대 1.0 ACU가 v1 기본값으로 명시되어 있습니다.

**질문:**
- 이 용량 설정은 모든 환경(dev/staging/prod)에 동일하게 적용할까요, 아니면 환경별로 다르게 설정할까요?
- CDK context로 용량을 override 가능하게 할까요?

[Answer]: 모든 환경(dev/staging/prod) 동일하게 Min 0.5 ACU, Max 1.0 ACU. CDK context (aurora_min_capacity, aurora_max_capacity)로 오버라이드 가능하게 구성.

### Q2.2: Aurora 클러스터 구성
**질문:**
- Aurora 클러스터는 단일 writer 인스턴스만 배포할까요, 아니면 reader 인스턴스도 함께 배포할까요?
- Multi-AZ 구성은 Aurora의 기본 복제 메커니즘에만 의존할까요, 아니면 명시적으로 여러 인스턴스를 프로비저닝할까요?

[Answer]: Writer 인스턴스 1개만. Reader 없음. Aurora Serverless v2 Multi-AZ 스토리지 복제로 데이터 내구성 보장. 필요 시 향후 reader 추가.

### Q2.3: RDS Proxy 설정
**질문:**
- RDS Proxy의 최대 연결 수는 몇 개로 설정할까요? (기본값 또는 특정 값)
- RDS Proxy의 IAM 인증 활성화는 필수일까요, 아니면 Secrets Manager 기반 인증만 사용할까요?
- RDS Proxy의 connection borrow timeout은 몇 초로 설정할까요?

[Answer]: 최대 연결 수 기본값(100%), 인증 방식 Secrets Manager만 (IAM 인증 미사용), connection borrow timeout 120초, idle client timeout 1800초(30분).

### Q2.4: Database 백업 및 유지보수
**질문:**
- Aurora 자동 백업 보존 기간은 며칠로 설정할까요? (1일 ~ 35일)
- 유지보수 창(maintenance window)은 특정 시간대로 고정할까요? (예: 일요일 03:00-04:00 UTC)
- Point-in-Time Recovery 활성화는 필수일까요?

[Answer]: 자동 백업 보존 7일, 유지보수 창 Sun 09:00-10:00 UTC (KST 일요일 18:00-19:00), PITR 활성화, Deletion protection prod만 활성화.

---

## 3. 컴퓨팅 계층 설계 (ComputeStack)

### Q3.1: ECS Fargate Task Definition - Skeleton 범위
Unit 1은 skeleton만 정의하고 Unit 4에서 최종 확정하는 것으로 이해하고 있습니다.

**질문:**
- Skeleton Task Definition에 포함할 항목은 무엇일까요?
  - Container 이미지: placeholder URI (예: `nginx:latest` 또는 빈 ECR 리포지토리 참조?)
  - 환경변수: 구조만 정의 (키 이름 나열, 값은 placeholder)
  - Health check: `/healthz` 경로는 확정, 타임아웃/간격은 skeleton에 포함?
  - 리소스: CPU/메모리는 skeleton에서 초기값 설정? (예: 0.5 vCPU, 1GB RAM)
- Unit 4에서 업데이트할 항목을 명시적으로 문서화할까요?

[Answer]: Skeleton에 포함: placeholder 이미지(nginx:latest), 0.5 vCPU/1GB, health check /healthz interval 30s timeout 5s, 환경변수 키 이름만 placeholder, awslogs 드라이버+CloudWatch 로그 그룹, ADOT sidecar 컨테이너 정의, port 8000. Unit 4에서 ECR 이미지 URI, 환경변수 값, 리소스 튜닝을 compute_stack.py 직접 수정으로 업데이트.

### Q3.2: ADOT Collector Sidecar 설정
**질문:**
- ADOT Collector의 설정 파일(config.yaml)은 어디에 위치시킬까요?
  - S3에 저장 후 컨테이너가 다운로드?
  - Secrets Manager에 저장?
  - Task Definition의 환경변수로 inline 전달?
- ADOT Collector의 리소스 할당은 얼마로 할까요? (예: 0.25 vCPU, 512MB RAM)

[Answer]: ADOT 설정은 AOT_CONFIG_CONTENT 환경변수로 inline 전달 (SSM/S3 불필요). 리소스 0.25 vCPU / 512MB. 이미지 public.ecr.aws/aws-observability/aws-otel-collector:latest. 포트 4317 (OTLP gRPC).

### Q3.3: ECS Service 설정
**질문:**
- ECS Service의 desired count는 몇 개로 시작할까요? (최소 2개 권장, 환경별로 다르게 설정?)
- 배포 전략은 어떤 것으로 할까요? (Rolling update, Blue/Green, 기본값 사용?)
- Auto-scaling은 Unit 1에서 설정할까요, 아니면 Unit 4 이후로 연기할까요?

[Answer]: ECS Service 생성은 Unit 4 scope로 이관. Unit 1에서는 ECS Cluster + Task Definition skeleton만 정의하고 ECS Service는 생성하지 않음. Unit 4에서 Service 생성 시 desired count는 dev 1, staging/prod 2, 배포 전략은 Rolling update (min healthy 100%, max 200%), auto-scaling은 이후 단계로 연기. 환경 지정은 CDK context 방식 (cdk deploy -c environment=dev). cdk.json에 기본값 설정, 배포 시 -c로 오버라이드.

### Q3.4: Lambda Function - Skeleton 범위
**질문:**
- Lambda Function의 skeleton에 포함할 항목은 무엇일까요?
  - 코드: placeholder 코드 (예: "Hello World" Python script)
  - 환경변수: 구조만 정의 (RDS_PROXY_ENDPOINT, KMS_KEY_ID 등 키 이름만)
  - 타임아웃: 몇 초로 설정? (예: 30초)
  - 메모리: 몇 MB로 설정? (예: 512MB)
- Unit 3에서 실제 Token Service 코드로 교체할 때 업데이트 필요 항목을 명시할까요?

[Answer]: Skeleton에 포함: runtime python3.13, inline placeholder 코드, 타임아웃 30초, 메모리 512MB, 환경변수 키 이름만 placeholder (RDS_PROXY_ENDPOINT, KMS_KEY_ID, DB_SECRET_ARN 등), VPC 설정 (private-app subnet, 보안 그룹), IAM 역할 (KMS, Secrets Manager, RDS Proxy, VPC ENI). Unit 3에서 실제 코드 경로, 환경변수 값을 compute_stack.py 직접 수정으로 업데이트.

---

## 4. API 계층 설계 (ApiStack)

### Q4.1: API Gateway 설정
**질문:**
- API Gateway는 Regional endpoint로 배포할까요, 아니면 Edge-optimized로 배포할까요?
- API Gateway의 throttling 설정은 기본값을 사용할까요, 아니면 특정 값을 지정할까요? (예: 초당 1000 요청)
- API Gateway의 로깅 수준은 어떻게 설정할까요? (INFO, ERROR, OFF?)

[Answer]: Regional endpoint, REST API (IAM Auth 지원). Throttling 기본값 (10,000 req/s, burst 5,000). 로깅 ERROR. API Gateway는 Token Service Lambda 전용.

### Q4.2: ALB 설정
**질문:**
- ALB의 idle timeout은 System NFR에 300초로 명시되어 있습니다. 다른 timeout 설정은 필요한가요?
- ALB의 deletion protection은 활성화할까요? (운영 환경에서만 활성화?)
- ALB의 access logs는 활성화할까요? (S3 버킷 필요)

[Answer]: Idle timeout 300초 (확정), deletion protection prod만 활성화, access logs 비활성화 (v1), deregistration delay 30초.

### Q4.3: ACM 인증서 처리
**질문:**
- ACM 인증서는 CDK에서 자동 생성할까요, 아니면 기존 인증서 ARN을 context로 받을까요?
- 도메인 이름은 어떻게 관리할까요? (Route 53 자동 설정? 수동 설정?)
- 개발 환경에서는 ACM 인증서 없이 ALB HTTPS를 생략할 수 있을까요, 아니면 모든 환경에서 HTTPS 필수인가요?

[Answer]: 기존 ACM 인증서 ARN을 CDK context (acm_certificate_arn)로 전달. CDK에서 자동 생성하지 않음. 도메인/Route 53 관리는 CDK 범위 밖. 모든 환경에서 HTTPS 필수 (System NFR).

---

## 5. 관측성 계층 설계 (ObservabilityStack)

### Q5.1: AMP Workspace 설정
**질문:**
- AMP Workspace는 환경별로 별도로 생성할까요? (dev/staging/prod 각각)
- AMP Workspace의 alias는 어떤 규칙으로 설정할까요? (예: `{app}-{env}-amp`)

[Answer]: 환경별 별도 AMP Workspace. Alias 규칙: {app}-{env} (예: claude-proxy-dev).

### Q5.2: ADOT Collector 설정 구조
**질문:**
- ADOT Collector의 설정 파일 구조는 Unit 1에서 전체를 정의할까요, 아니면 skeleton만 정의하고 Unit 4에서 완성할까요?
- Prometheus remote write endpoint URL은 어떻게 구성할까요? (AMP Workspace의 remote write URL 자동 참조?)

[Answer]: Unit 1에서 ADOT 설정 전체 정의 (inline YAML). AMP remote write URL은 ObservabilityStack에서 생성, ComputeStack이 ObservabilityStack에 의존하여 cross-stack 참조로 자동 주입. 스택 의존성 수정: Network → Data → ObservabilityStack → ComputeStack → ApiStack. Unit 4에서 수정 불필요.

---

## 6. IAM 역할 및 KMS 설계

### Q6.1: IAM 역할 명명 규칙
**질문:**
- IAM 역할 이름은 어떤 규칙으로 생성할까요? (예: `{app}-{env}-{service}-{role-type}`)
- Managed Policy와 Inline Policy 중 어느 것을 선호할까요?

[Answer]: 명명 규칙 {app}-{env}-{service}-{role-type} (예: claude-proxy-dev-gateway-task-role). Inline Policy 사용 (CDK grant 메서드 활용).

### Q6.2: KMS Key 설정
**질문:**
- KMS Key의 rotation은 활성화할까요? (자동 rotation 1년 주기)
- KMS Key alias는 어떤 규칙으로 설정할까요? (예: `alias/{app}-{env}-virtual-key`)
- KMS Key 삭제 대기 기간은 며칠로 설정할까요? (7일 ~ 30일)

[Answer]: 자동 rotation 활성화 (1년 주기). Alias: alias/{app}-{env}-virtual-key. 삭제 대기 30일 (최대).

---

## 7. 교차 스택 참조 및 의존성

### Q7.1: CDK Export 전략
**질문:**
- 모든 교차 스택 참조를 CDK Export로 처리할까요, 아니면 일부는 SSM Parameter Store를 사용할까요?
- Export 이름 규칙은 무엇으로 할까요? (예: `{StackName}-{ResourceType}-{ResourceName}`)

[Answer]: CDK Export만 사용 (SSM Parameter Store 미사용). CDK 자동 cross-stack 참조에 맡김. 명시적 export 필요 시 {StackName}:{ResourceType}:{ResourceName} 형식.

---

## 8. CDK Context 및 환경 설정

### Q8.1: Context 파라미터 상세
**질문:**
- Context 파라미터로 받을 항목의 전체 목록과 기본값을 확정할 수 있을까요?
  - `environment`: dev | staging | prod (필수)
  - `region`: ap-northeast-2 (기본값)
  - `vpc_cidr`: 10.0.0.0/16 (기본값)
  - `aurora_min_capacity`: 0.5 (기본값)
  - `aurora_max_capacity`: 1.0 (기본값)
  - 추가로 필요한 context 파라미터가 있을까요?

[Answer]: 총 8개 context 파라미터 확정. environment (기본 dev), region (기본 ap-northeast-2), vpc_cidr (기본 10.0.0.0/16), aurora_min_capacity (기본 0.5), aurora_max_capacity (기본 1.0), acm_certificate_arn (필수, 모든 환경), enable_vpc_flow_logs (기본 true), app_name (기본 claude-proxy). ecs_desired_count는 환경별 코드 분기로 처리.

### Q8.2: 환경별 차이
**질문:**
- dev/staging/prod 환경에서 달라지는 설정은 무엇일까요?
  - ECS desired count?
  - Aurora 용량?
  - 로깅 수준?
  - 백업 보존 기간?
  - 기타?

[Answer]: 환경별 차이는 코드 분기로 처리 (context 아님). ECS desired count: dev 1, else 2. Deletion protection (Aurora, ALB): prod만. Flow Logs 보존: prod 30일, else 7일. CloudWatch Logs 보존: prod 30일, else 7일. 백업 보존: 전 환경 7일. API GW 로깅: 전 환경 ERROR.

---

## 9. Skeleton 정의 및 Unit 3/4 연계

### Q9.1: Skeleton 업데이트 프로세스
**질문:**
- Unit 3 (Token Service Lambda) 완료 후 ComputeStack의 Lambda Function 정의를 업데이트하는 프로세스는 어떻게 할까요?
  - Unit 3에서 Lambda 코드 배포 스크립트 제공?
  - Unit 3에서 ComputeStack 코드 수정?
- Unit 4 (Gateway) 완료 후 ComputeStack의 ECS Task Definition을 업데이트하는 프로세스는 어떻게 할까요?
  - Unit 4에서 Docker 이미지 빌드 및 ECR push 스크립트 제공?
  - Unit 4에서 ComputeStack 코드 수정?

[Answer]: Unit 3/4에서 직접 infra/stacks/compute_stack.py 수정. 별도 스크립트/자동화 불필요. 각 Unit의 Code Generation 단계에서 인프라 코드 수정도 함께 포함.

---

## 10. 추가 고려사항

### Q10.1: CDK Construct 재사용 전략
**질문:**
- `infra/constructs/` 디렉토리에 재사용 가능한 CDK Construct를 만들 계획이 있을까요?
  - 예: VpcWithEndpoints, FargateServiceWithSidecar, SecureRdsProxy 등
- 아니면 각 Stack 파일 내에서 직접 리소스를 정의할까요?

[Answer]: 각 스택에서 직접 리소스 정의. 커스텀 Construct 분리 안 함. infra/constructs/ 디렉토리 미생성.

---

## 리뷰 후 추가 결정 사항

### R1: ECR Repository 생성
ComputeStack에서 ECR Repository 생성. 이름 규칙: {app}-{env}-gateway. Gateway Docker 이미지 저장용. Unit 4에서 이미지 빌드 후 push 대상.

### R2: Secrets Manager 시크릿 이름 규약
DataStack에서 Aurora 생성 시 Secrets Manager 시크릿 이름을 {app}/{env}/db-credentials 형식으로 명시적 지정 (예: claude-proxy/dev/db-credentials). System NFR 문서(4.5절)의 <env>/<app>/db-credentials도 {app}/{env}/db-credentials로 정정 필요.

### R3: 스택 의존성 순서 수정
기존: NetworkStack → DataStack → ComputeStack → (ApiStack + ObservabilityStack)
수정: NetworkStack → DataStack → ObservabilityStack → ComputeStack → ApiStack
이유: ComputeStack의 ADOT sidecar가 AMP remote write URL을 참조해야 하므로 ObservabilityStack이 먼저 생성되어야 함.

---

## 답변 방법

각 질문에 대해 아래와 같이 답변해 주세요.

```
### Q1.1: VPC CIDR 및 서브넷 구성
[Answer]: VPC CIDR은 10.0.0.0/16으로 설정합니다. 서브넷은 2개 AZ에 public /24, private-app /20, private-data /24로 할당합니다.
```

명확하지 않거나 결정이 필요한 항목은 선호도와 이유를 함께 제시해 주시면 더욱 좋습니다.
