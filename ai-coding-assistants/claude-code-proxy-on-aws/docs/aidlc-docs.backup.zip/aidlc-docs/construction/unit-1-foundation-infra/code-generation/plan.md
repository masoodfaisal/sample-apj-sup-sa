# Unit 1: Foundation Infrastructure - Code Generation Plan

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Completed
- 단계: CONSTRUCTION - Code Generation
- 근거 문서:
  - [Infrastructure Design](../infrastructure-design/infrastructure-design.md)
  - [Deployment Architecture](../infrastructure-design/deployment-architecture.md)
  - [System NFR Decisions](../../system-nfr-decisions.md)

---

## 1. 목표

Unit 1 설계 문서를 실제 실행 가능한 CDK Python scaffold로 전환한다. 이번 단계의 완료 기준은 다음과 같다.

- `infra/` CDK app과 5개 스택 코드 생성
- `uv` 기반 의존성 관리 설정 추가
- stack별 pytest snapshot 테스트 추가
- 최소 1회 synthesis 검증 성공

---

## 2. 생성 범위

- root `pyproject.toml`, `uv.lock`, `.gitignore`
- `infra/app.py`, `infra/cdk.json`, `infra/README.md`
- `infra/stacks/network_stack.py`
- `infra/stacks/data_stack.py`
- `infra/stacks/observability_stack.py`
- `infra/stacks/compute_stack.py`
- `infra/stacks/api_stack.py`
- `tests/test_*_stack.py`
- `tests/snapshots/*.json`

---

## 3. 구현 원칙

- 설계 문서의 5개 스택 분할을 그대로 유지한다.
- Lambda/ECS 애플리케이션은 placeholder로 남기되, 인프라 리소스와 wiring은 실제 값 기준으로 생성한다.
- CDK context 기본값은 `infra/cdk.json`에 두고, 필수 배포값은 context override로 받는다.
- snapshot 테스트는 CloudFormation 템플릿의 의도치 않은 변경을 감지하는 용도로 사용한다.

---

## 4. 검증 계획

1. `uv sync --group dev`
2. `uv export --format requirements-txt --output-file infra/requirements.txt`
3. `uv run python -m compileall infra tests`
4. context가 포함된 synthesis 실행
5. `uv run pytest`

---

## 5. 구현 결과

- root에 `pyproject.toml`, `uv.lock`, `.gitignore`를 추가해 Python/CDK 의존성 관리를 정리했다.
- `infra/`에 CDK app, context 설정, README, 5개 stack module을 생성했다.
- `tests/`에 stack별 snapshot 테스트와 기준 snapshot 파일 5개를 생성했다.
- `infra/requirements.txt`를 export해 배포 기준 의존성 고정 파일을 생성했다.

## 6. 검증 결과

1. `uv sync --group dev` 완료
2. `uv export --format requirements-txt --output-file infra/requirements.txt` 완료
3. `uv run python -m compileall infra tests` 성공
4. `cd infra && env PYTHONPATH=.. JSII_SILENCE_WARNING_UNTESTED_NODE_VERSION=1 npx aws-cdk@latest synth --all -c acm_certificate_arn=...` 성공
5. `uv run pytest` 성공 (`5 passed`)

## 7. 구현 메모

- `cdk.json`의 app 실행은 `infra/` 디렉토리 기준이므로 `PYTHONPATH=..`를 명시해 루트 패키지 import를 유지했다.
- `infra/cdk.context.json`은 synth 과정에서 생성되는 account-specific lookup cache이므로 `.gitignore`에 추가했다.
- ECS/Lambda 애플리케이션 로직과 일부 환경 변수는 설계 문서대로 placeholder 상태를 유지하며, 후속 Unit 3/4 Code Generation에서 실제 구현으로 대체된다.
- 최신 synth에서는 CDK upstream deprecated warning이 출력되지만, 현재 생성 코드의 blocking issue는 아니다.
