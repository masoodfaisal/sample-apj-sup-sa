# Unit 1: Foundation Infrastructure - Infrastructure Design Plan

- 문서 버전: v1.1
- 작성일: 2026-04-01
- 상태: Completed
- 단계: CONSTRUCTION - Infrastructure Design (Plan)
- 근거 문서:
  - [Functional Design](../functional-design/functional-design.md)
  - [NFR Requirements](../nfr-requirements/nfr-requirements.md)
  - [NFR Design](../nfr-design/nfr-design.md)
  - [System NFR Decisions](../../system-nfr-decisions.md)

---

## 1. 목적

Unit 1 (Foundation Infrastructure)의 논리 설계를 AWS CDK Python으로 구현 가능한 인프라 설계로 구체화하기 위한 계획 문서다. Functional Design과 NFR Design에서 정의한 WHAT/WHY를 바탕으로, Infrastructure Design 단계에서는 HOW를 확정한다.

본 문서는 Infrastructure Design 단계의 기준 plan이며, 기존 `aidlc-docs/construction/plans/` 하위의 중복 초안 2개를 정리하여 stage 로컬 경로로 통합했다.

---

## 2. 설계 범위

### 2.1 범위 내
- CDK 프로젝트 구조 및 디렉토리 레이아웃
- 5개 스택(Network/Data/Observability/Compute/Api) 구성 방식
- cross-stack 참조 방식
- context 파라미터와 환경별 분기 전략
- ECS/Lambda skeleton 인프라 구성
- Aurora/RDS Proxy/Secrets Manager/VPC Endpoint/KMS/IAM 설계
- 배포 순서 및 운영 관점 배포 아키텍처 정리

### 2.2 범위 외
- 실제 CDK Python 코드 생성
- Lambda/FastAPI 애플리케이션 구현
- DB 스키마 및 Alembic 마이그레이션
- CI/CD 파이프라인 자동화

---

## 3. 계획된 아티팩트

| 아티팩트 | 상태 | 설명 |
| --- | --- | --- |
| `questions-round1.md` | Completed | 구현 수준 세부 결정을 위한 질문/답변 정리 |
| `infrastructure-design.md` | Final | AWS 리소스 매핑, 스택 구조, context 전략, 구현 상세 |
| `deployment-architecture.md` | Final | 토폴로지/보안 경계/데이터 흐름/배포 의존성 시각화 |

선택 아티팩트였던 `shared-infrastructure.md`는 Unit 1 범위에서 커스텀 construct가 불필요하다고 판단되어 생성하지 않았다.

---

## 4. 핵심 결정 요약

- CDK 프로젝트는 `infra/` 루트에 수동 scaffold 방식으로 구성한다.
- AWS 계정/리전 전략은 단일 계정, 단일 리전 `ap-northeast-2`를 기본으로 한다.
- VPC는 NAT 없이 2 AZ, 3계층(public/private-app/private-data) 구조를 사용한다.
- cross-stack 참조는 props 직접 전달을 우선하고, output은 운영 확인용으로만 제한한다.
- ECS Task Definition과 Lambda는 Unit 1에서 skeleton만 정의하고 실제 서비스/코드는 후속 유닛에서 채운다.
- AMP는 L1 construct 기반으로 정의하고, ADOT는 inline 설정으로 remote write 한다.
- 보안 기본값은 private connectivity, least privilege IAM, encryption everywhere 원칙을 따른다.

---

## 5. 완료 상태

Infrastructure Design 단계에서 필요한 질문 수집과 답변 확정이 완료되었고, 그 결과가 최종 설계 문서에 반영되었다.

- 질문/답변 기준 문서: [questions-round1.md](./questions-round1.md)
- 최종 설계 명세: [infrastructure-design.md](./infrastructure-design.md)
- 배포 아키텍처 보조 문서: [deployment-architecture.md](./deployment-architecture.md)

현재 Unit 1의 Infrastructure Design은 완료 상태이며, 다음 공식 단계는 Code Generation이다.

---

## 6. 다음 단계

1. Unit 1 Code Generation plan 수립
2. `infra/` CDK 프로젝트 scaffold 생성
3. 5개 스택 코드와 공통 설정 코드 생성
4. `cdk synth` 및 기본 테스트 가능한 구조까지 마련
