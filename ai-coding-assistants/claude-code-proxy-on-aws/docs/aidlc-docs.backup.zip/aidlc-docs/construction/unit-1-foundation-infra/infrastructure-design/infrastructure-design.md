# Unit 1: Foundation Infrastructure - Infrastructure Design

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Final
- 단계: CONSTRUCTION - Infrastructure Design
- 근거 문서:
  - [Functional Design](../functional-design/functional-design.md)
  - [NFR Design](../nfr-design/nfr-design.md)
  - [System NFR Decisions](../../system-nfr-decisions.md)
  - [Infrastructure Design Plan](./plan.md)

---

## 문서 개요

본 문서는 Unit 1 (Foundation Infrastructure)의 논리적 컴포넌트를 실제 AWS 인프라 서비스로 매핑한다. CDK Python 코드로 구현 가능한 수준의 상세 명세를 제공하며, Code Generation 단계의 직접적인 입력 문서가 된다.

---

## 1. Infrastructure Overview

### 1.1 아키텍처 원칙

| 원칙 | 구현 전략 |
|-----|----------|
| **Private Connectivity by Default** | NAT Gateway 없음, VPC Endpoint 우선 |
| **Defense in Depth** | 3계층 서브넷 분리 (Public, Private-app, Private-data) |
| **Least Privilege** | IAM 역할별 최소 권한, 리소스 ARN 명시적 제한 |
| **Encryption Everywhere** | TLS 1.2+ (전송), KMS/Aurora 암호화 (저장) |
| **Infrastructure as Code** | AWS CDK Python, 5개 스택 모듈화 |
| **Multi-AZ by Default** | 모든 레이어 2 AZ 배포 |
| **Observability First** | CloudWatch Logs, AMP, ADOT 파이프라인 |

### 1.2 스택 구성 및 의존성

```
NetworkStack (최우선)
    │
    ├─────────────┐
    │             │
    ▼             ▼
DataStack    ObservabilityStack
    │             │
    └──────┬──────┘
           │
           ▼
      ComputeStack
           │
           ▼
       ApiStack
```

| 스택 | AWS 리소스 | 의존성 |
|-----|-----------|--------|
| NetworkStack | VPC, Subnet, Security Group, VPC Endpoint, IGW | 없음 |
| DataStack | Aurora Serverless v2, RDS Proxy, Secrets Manager | NetworkStack |
| ObservabilityStack | AMP Workspace | NetworkStack (VPC Endpoint 참조) |
| ComputeStack | ECS Cluster, Task Definition, Lambda, ECR, KMS | NetworkStack, DataStack, ObservabilityStack |
| ApiStack | API Gateway, ALB, Target Group | NetworkStack, ComputeStack |

---

## 2. Deployment Environment

### 2.1 AWS 리전 및 계정 전략

| 항목 | 결정 | 근거 |
|-----|------|------|
| Primary Region | ap-northeast-2 (Seoul) | Bedrock Claude 3.5 Sonnet v2 지원, 낮은 latency |
| Multi-Region | 없음 (v1) | 단일 리전으로 시작, v2에서 DR 고려 |
| AWS Account | 단일 계정 | 환경별 context 분리로 충분, 계정 분리는 post-v1 |
| CDK Bootstrap | 사전 작업 | `cdk bootstrap aws://<account>/ap-northeast-2` |

### 2.2 환경 전략

| 환경 | 목적 | 배포 트리거 | 데이터 보호 |
|-----|------|-----------|-----------|
| dev | 개발 및 테스트 | 수동 (개발자 로컬) | deletion protection 비활성화 |
| staging | 통합 테스트, Pre-prod 검증 | 수동 (배포 팀) | deletion protection 비활성화 |
| prod | 프로덕션 서비스 | 수동 (배포 팀) + 승인 | deletion protection 활성화 |

**환경별 차이**:
- ECS desired count: dev 1, staging/prod 2
- CloudWatch Logs 보존: dev/staging 7일, prod 30일
- Deletion protection: prod만 활성화 (Aurora, ALB)
- 백업 보존: 모든 환경 7일 (동일)

---

## 3. Network Architecture

### 3.1 VPC Topology

**CDK Construct**: `aws_cdk.aws_ec2.Vpc`

**VPC 속성**:
```python
{
    "cidr_block": "10.0.0.0/16",  # context: vpc_cidr (기본값)
    "enable_dns_hostnames": True,
    "enable_dns_support": True,
    "nat_gateways": 0,  # NAT Gateway 없음
    "max_azs": 2  # ap-northeast-2a, ap-northeast-2c
}
```

`vpc_cidr`는 context로 오버라이드 가능하며, 아래 IP 계산은 기본 예시 기준이다. 이 문서의 핵심 제약은 "2 AZ, 3계층(public/private-app/private-data), private subnet은 NAT 없이 isolated"이며, 세부 CIDR/mask 값은 환경별 규모에 맞게 조정할 수 있다.

**예시 IP 주소 용량 (기본 마스크 기준)**:
- 전체 VPC: 65,536개 IP (10.0.0.0/16)
- Public subnet: 512개 IP (2 AZ × 256)
- Private-app subnet: 8,192개 IP (2 AZ × 4,096)
- Private-data subnet: 512개 IP (2 AZ × 256)

### 3.2 Subnet Design

**CDK Construct**: `aws_cdk.aws_ec2.Vpc` + `subnet_configuration`

아래 배치는 초기 예시다. `/24`, `/20`, `/24` 마스크는 고정 정책이 아니라, 초기 환경에서 무난한 기본값으로 취급한다. 실제 Code Generation에서는 context 값으로 subnet mask를 조정할 수 있어야 한다.

| 계층 | AZ | 예시 CIDR | 주소 수 | 용도 | 라우팅 |
|-----|---|-----------|--------|------|--------|
| Public | ap-northeast-2a | 10.0.0.0/24 | 256 | ALB | 0.0.0.0/0 → IGW |
| Public | ap-northeast-2c | 10.0.1.0/24 | 256 | ALB | 0.0.0.0/0 → IGW |
| Private-app | ap-northeast-2a | 10.0.16.0/20 | 4,096 | ECS, Lambda, VPC Endpoints | Local only |
| Private-app | ap-northeast-2c | 10.0.32.0/20 | 4,096 | ECS, Lambda, VPC Endpoints | Local only |
| Private-data | ap-northeast-2a | 10.0.48.0/24 | 256 | Aurora, RDS Proxy | Local only |
| Private-data | ap-northeast-2c | 10.0.49.0/24 | 256 | Aurora, RDS Proxy | Local only |

**CDK 구현**:
```python
public_subnet_mask = self.node.try_get_context("public_subnet_mask") or 24
private_app_subnet_mask = self.node.try_get_context("private_app_subnet_mask") or 20
private_data_subnet_mask = self.node.try_get_context("private_data_subnet_mask") or 24

vpc = ec2.Vpc(
    self, "Vpc",
    cidr=vpc_cidr,
    max_azs=2,
    nat_gateways=0,
    subnet_configuration=[
        ec2.SubnetConfiguration(
            name="public",
            subnet_type=ec2.SubnetType.PUBLIC,
            cidr_mask=public_subnet_mask
        ),
        ec2.SubnetConfiguration(
            name="private-app",
            subnet_type=ec2.SubnetType.PRIVATE_ISOLATED,
            cidr_mask=private_app_subnet_mask
        ),
        ec2.SubnetConfiguration(
            name="private-data",
            subnet_type=ec2.SubnetType.PRIVATE_ISOLATED,
            cidr_mask=private_data_subnet_mask
        )
    ],
    enable_dns_hostnames=True,
    enable_dns_support=True
)
```

기본 경로는 `ec2.Vpc()`의 `subnet_configuration`과 자동 생성되는 route table을 사용하는 것이다. Subnet/route table을 개별 리소스로 수동 생성하는 방식은 특수 라우팅, 세밀한 네이밍, 명시적 네트워크 분리가 추가로 필요할 때만 사용한다.

### 3.3 Security Groups

**CDK Construct**: `aws_cdk.aws_ec2.SecurityGroup`

#### 3.3.1 alb-sg (ALB 전용)

**목적**: 인터넷에서 ALB HTTPS 접근 허용

**Inbound 규칙**:
```python
alb_sg.add_ingress_rule(
    peer=ec2.Peer.any_ipv4(),
    connection=ec2.Port.tcp(443),
    description="HTTPS from internet"
)
alb_sg.add_ingress_rule(
    peer=ec2.Peer.any_ipv4(),
    connection=ec2.Port.tcp(80),
    description="HTTP redirect from internet"
)
```

**Outbound 규칙**:
```python
alb_sg.add_egress_rule(
    peer=ec2.Peer.security_group_id(ecs_sg.security_group_id),
    connection=ec2.Port.tcp(8000),
    description="Forward to ECS Task"
)
```

#### 3.3.2 ecs-sg (ECS Task 전용)

**목적**: ALB에서 ECS Task 접근, VPC Endpoint/RDS Proxy 접근

**Inbound 규칙**:
```python
ecs_sg.add_ingress_rule(
    peer=ec2.Peer.security_group_id(alb_sg.security_group_id),
    connection=ec2.Port.tcp(8000),
    description="From ALB"
)
```

**Outbound 규칙**:
```python
ecs_sg.add_egress_rule(
    peer=ec2.Peer.security_group_id(endpoint_sg.security_group_id),
    connection=ec2.Port.tcp(443),
    description="To VPC Endpoints"
)
ecs_sg.add_egress_rule(
    peer=ec2.Peer.security_group_id(rds_sg.security_group_id),
    connection=ec2.Port.tcp(5432),
    description="To RDS Proxy"
)
```

#### 3.3.3 lambda-sg (Lambda Function 전용)

**목적**: VPC Endpoint/RDS Proxy 접근

**Inbound 규칙**: 없음

**Outbound 규칙**:
```python
lambda_sg.add_egress_rule(
    peer=ec2.Peer.security_group_id(endpoint_sg.security_group_id),
    connection=ec2.Port.tcp(443),
    description="To VPC Endpoints"
)
lambda_sg.add_egress_rule(
    peer=ec2.Peer.security_group_id(rds_sg.security_group_id),
    connection=ec2.Port.tcp(5432),
    description="To RDS Proxy"
)
```

#### 3.3.4 rds-sg (Aurora + RDS Proxy)

**목적**: ECS Task/Lambda에서 RDS Proxy 접근

**Inbound 규칙**:
```python
rds_sg.add_ingress_rule(
    peer=ec2.Peer.security_group_id(ecs_sg.security_group_id),
    connection=ec2.Port.tcp(5432),
    description="From ECS Task"
)
rds_sg.add_ingress_rule(
    peer=ec2.Peer.security_group_id(lambda_sg.security_group_id),
    connection=ec2.Port.tcp(5432),
    description="From Lambda"
)
```

**Outbound 규칙**: 없음

#### 3.3.5 endpoint-sg (VPC Endpoint ENI 전용)

**목적**: ECS Task/Lambda에서 VPC Endpoint 접근

**Inbound 규칙**:
```python
endpoint_sg.add_ingress_rule(
    peer=ec2.Peer.security_group_id(ecs_sg.security_group_id),
    connection=ec2.Port.tcp(443),
    description="From ECS Task"
)
endpoint_sg.add_ingress_rule(
    peer=ec2.Peer.security_group_id(lambda_sg.security_group_id),
    connection=ec2.Port.tcp(443),
    description="From Lambda"
)
```

**Outbound 규칙**: 없음

### 3.4 VPC Endpoints

#### 3.4.1 Interface Endpoints

**CDK Construct**: `aws_cdk.aws_ec2.InterfaceVpcEndpoint`

| 서비스 | Endpoint ID | Private DNS | 필요성 |
|--------|------------|-------------|--------|
| Bedrock Runtime | com.amazonaws.ap-northeast-2.bedrock-runtime | Enabled | ECS Task Bedrock API 호출 |
| ECR API | com.amazonaws.ap-northeast-2.ecr.api | Enabled | ECS Task ECR 인증 |
| ECR DKR | com.amazonaws.ap-northeast-2.ecr.dkr | Enabled | ECS Task 이미지 pull |
| CloudWatch Logs | com.amazonaws.ap-northeast-2.logs | Enabled | ECS/Lambda 로그 전송 |
| Secrets Manager | com.amazonaws.ap-northeast-2.secretsmanager | Enabled | ECS/Lambda DB credentials 조회 |
| KMS | com.amazonaws.ap-northeast-2.kms | Enabled | Lambda Virtual Key 암복호화 |
| Identity Store | com.amazonaws.ap-northeast-2.identitystore | Enabled | ECS Task Identity Center sync |
| STS | com.amazonaws.ap-northeast-2.sts | Enabled | IAM 역할 assume |
| AMP Workspaces | com.amazonaws.ap-northeast-2.aps-workspaces | Enabled | ADOT AMP remote write |
| ECS | com.amazonaws.ap-northeast-2.ecs | Enabled | ECS Task 메타데이터 |

**공통 속성**:
```python
endpoint = vpc.add_interface_endpoint(
    id=f"{service_name}Endpoint",
    service=ec2.InterfaceVpcEndpointAwsService.<SERVICE_CONSTANT>,
    subnets=ec2.SubnetSelection(
        subnets=private_app_subnets
    ),
    security_groups=[endpoint_sg],
    private_dns_enabled=True
)
```

**Endpoint Policy (Bedrock Runtime)**:
```python
bedrock_endpoint_policy = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.AnyPrincipal()],
            actions=[
                "bedrock:InvokeModel",
                "bedrock:InvokeModelWithResponseStream"
            ],
            resources=["*"]  # 모든 모델 허용 (애플리케이션 레벨 제어)
        )
    ]
)
```

**Endpoint Policy (기타 Interface Endpoints)**:
```python
default_endpoint_policy = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.AnyPrincipal()],
            actions=["*"],
            resources=["*"],
            conditions={
                "StringEquals": {
                    "aws:PrincipalAccount": Aws.ACCOUNT_ID
                }
            }
        )
    ]
)
```

#### 3.4.2 Gateway Endpoint (S3)

**CDK Construct**: `aws_cdk.aws_ec2.GatewayVpcEndpoint`

**목적**: ECR 이미지 레이어 다운로드 (S3 버킷 접근)

**속성**:
```python
s3_endpoint = vpc.add_gateway_endpoint(
    id="S3Endpoint",
    service=ec2.GatewayVpcEndpointAwsService.S3,
    subnets=[
        ec2.SubnetSelection(subnets=private_app_subnets)
    ]
)
```

**Endpoint Policy**:
```python
s3_endpoint_policy = iam.PolicyDocument(
    statements=[
        iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.AnyPrincipal()],
            actions=["s3:GetObject"],
            resources=[
                "arn:aws:s3:::prod-ap-northeast-2-starport-layer-bucket/*"
            ]
        )
    ]
)
```

---

## 4. Storage Architecture

### 4.1 Aurora PostgreSQL Serverless v2

**CDK Construct**: `aws_cdk.aws_rds.DatabaseCluster`

**속성**:
```python
aurora_cluster = rds.DatabaseCluster(
    self, "AuroraCluster",
    engine=rds.DatabaseClusterEngine.aurora_postgres(
        version=rds.AuroraPostgresEngineVersion.VER_15_5  # 최신 안정 버전
    ),
    cluster_identifier=f"{app_name}-{env}-aurora",
    default_database_name="claudeproxy",
    credentials=rds.Credentials.from_secret(db_secret),
    writer=rds.ClusterInstance.serverless_v2(
        "writer",
        scale_with_writer=True
    ),
    readers=[],  # Reader 없음
    serverless_v2_min_capacity=aurora_min_capacity,  # context/default
    serverless_v2_max_capacity=aurora_max_capacity,  # context/default
    vpc=network_stack.vpc,
    vpc_subnets=ec2.SubnetSelection(
        subnets=network_stack.private_data_subnets
    ),
    security_groups=[network_stack.rds_sg],
    storage_encrypted=True,  # AWS 관리형 RDS 키
    backup=rds.BackupProps(
        retention=Duration.days(aurora_backup_retention_days),
        preferred_window=aurora_backup_window  # optional context/default
    ),
    preferred_maintenance_window=aurora_maintenance_window,  # optional context/default
    deletion_protection=is_prod,  # prod만 활성화
    removal_policy=RemovalPolicy.SNAPSHOT if is_prod else RemovalPolicy.DESTROY
)
```

**Multi-AZ**: 스토리지 레벨 자동 복제 (3 AZ, 6 복제본)

Aurora min/max ACU, backup window, maintenance window는 설계 원칙이 아니라 운영 초기값이다. 초기값 예시(0.5/1.0 ACU, 특정 유지보수 창)는 `cdk.json` 또는 환경별 context에서 기본으로 둘 수 있지만, 실제 트래픽과 운영 캘린더가 쌓이면 값만 조정할 수 있어야 한다.

**초기 용량 예시 해석**:
- 0.5 ACU = 1GB RAM, 약 90 동시 연결
- 1.0 ACU = 2GB RAM, 약 180 동시 연결

### 4.2 RDS Proxy

**CDK Construct**: `aws_cdk.aws_rds.DatabaseProxy`

**속성**:
```python
rds_proxy = rds.DatabaseProxy(
    self, "RdsProxy",
    proxy_target=rds.ProxyTarget.from_cluster(aurora_cluster),
    secrets=[db_secret],
    db_proxy_name=f"{app_name}-{env}-rds-proxy",
    vpc=network_stack.vpc,
    vpc_subnets=ec2.SubnetSelection(
        subnets=network_stack.private_data_subnets
    ),
    security_groups=[network_stack.rds_sg],
    max_connections_percent=100,  # Aurora max_connections의 100% 사용
    max_idle_connections_percent=50,
    borrow_timeout=Duration.seconds(120),
    idle_client_timeout=Duration.seconds(1800),  # 30분
    require_tls=True
)
```

**연결 문자열**:
```python
connection_string = f"postgresql://{db_username}:{db_password}@{rds_proxy.endpoint}:5432/claudeproxy?sslmode=require"
```

### 4.3 Secrets Manager

**CDK Construct**: `aws_cdk.aws_secretsmanager.Secret`

**속성**:
```python
db_secret = secretsmanager.Secret(
    self, "DbSecret",
    secret_name=f"{app_name}/{env}/db-credentials",
    generate_secret_string=secretsmanager.SecretStringGenerator(
        secret_string_template='{"username": "dbadmin"}',
        generate_string_key="password",
        exclude_punctuation=True,
        password_length=32
    )
)

# Aurora 클러스터에 자동 attach
aurora_cluster = rds.DatabaseCluster(
    ...
    credentials=rds.Credentials.from_secret(db_secret)
)
```

**Secret 값 형식**:
```json
{
  "username": "dbadmin",
  "password": "<auto-generated>",
  "engine": "postgres",
  "host": "<rds-proxy-endpoint>",
  "port": 5432,
  "dbname": "claudeproxy"
}
```

---

## 5. Compute Architecture

### 5.1 ECS Cluster

**CDK Construct**: `aws_cdk.aws_ecs.Cluster`

**속성**:
```python
ecs_cluster = ecs.Cluster(
    self, "EcsCluster",
    cluster_name=f"{app_name}-{env}-cluster",
    vpc=network_stack.vpc,
    container_insights=True,
    enable_fargate_capacity_providers=True
)
```

### 5.2 ECS Task Definition (Skeleton)

**CDK Construct**: `aws_cdk.aws_ecs.FargateTaskDefinition`

#### 5.2.1 Task Definition 속성

```python
task_definition = ecs.FargateTaskDefinition(
    self, "GatewayTaskDefinition",
    family=f"{app_name}-{env}-gateway-task",
    cpu=768,  # 0.75 vCPU (app 0.5 + ADOT 0.25)
    memory_limit_mib=1536,  # 1.5 GB (app 1.0 + ADOT 0.5)
    task_role=gateway_task_role,
    execution_role=gateway_execution_role
)
```

#### 5.2.2 App Container (Skeleton)

```python
app_container = task_definition.add_container(
    "gateway-app",
    image=ecs.ContainerImage.from_registry("nginx:latest"),  # Placeholder
    cpu=512,  # 0.5 vCPU
    memory_limit_mib=1024,  # 1 GB
    essential=True,
    environment={
        "RDS_PROXY_ENDPOINT": "placeholder",  # Unit 4에서 실제 값으로 교체
        "DB_SECRET_ARN": "placeholder",
        "KMS_KEY_ARN": "placeholder",
        "AMP_WORKSPACE_ID": "placeholder",
        "IDENTITY_STORE_ID": "placeholder",
        "AWS_REGION": "ap-northeast-2"
    },
    logging=ecs.LogDrivers.aws_logs(
        stream_prefix="gateway-app",
        log_group=ecs_log_group
    ),
    health_check=ecs.HealthCheck(
        command=["CMD-SHELL", "curl -f http://localhost:8000/healthz || exit 1"],
        interval=Duration.seconds(30),
        timeout=Duration.seconds(5),
        retries=3,
        start_period=Duration.seconds(60)
    )
)

app_container.add_port_mappings(
    ecs.PortMapping(
        container_port=8000,
        protocol=ecs.Protocol.TCP
    )
)
```

#### 5.2.3 ADOT Collector Sidecar

```python
adot_config_yaml = f"""
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317

processors:
  batch:
    timeout: 60s
    send_batch_size: 50

exporters:
  prometheusremotewrite:
    endpoint: {observability_stack.amp_remote_write_url}
    auth:
      authenticator: sigv4auth
    resource_to_telemetry_conversion:
      enabled: true

extensions:
  sigv4auth:
    region: ap-northeast-2
    service: aps

service:
  extensions: [sigv4auth]
  pipelines:
    metrics:
      receivers: [otlp]
      processors: [batch]
      exporters: [prometheusremotewrite]
"""

adot_container = task_definition.add_container(
    "adot-collector",
    image=ecs.ContainerImage.from_registry(
        "public.ecr.aws/aws-observability/aws-otel-collector:latest"
    ),
    cpu=256,  # 0.25 vCPU
    memory_limit_mib=512,  # 512 MB
    essential=False,  # Sidecar 종료해도 Task 유지
    environment={
        "AOT_CONFIG_CONTENT": adot_config_yaml,
        "AWS_REGION": "ap-northeast-2"
    },
    logging=ecs.LogDrivers.aws_logs(
        stream_prefix="adot-collector",
        log_group=ecs_log_group
    )
)

adot_container.add_port_mappings(
    ecs.PortMapping(
        container_port=4317,
        protocol=ecs.Protocol.TCP
    )
)
```

#### 5.2.4 CloudWatch Logs

```python
env = self.node.try_get_context("environment") or "dev"
retention_days = logs.RetentionDays.ONE_MONTH if env == "prod" else logs.RetentionDays.ONE_WEEK

ecs_log_group = logs.LogGroup(
    self, "EcsLogGroup",
    log_group_name=f"/ecs/{app_name}-{env}-gateway",
    retention=retention_days,
    removal_policy=RemovalPolicy.DESTROY
)
```

### 5.3 Lambda Function (Skeleton)

**CDK Construct**: `aws_cdk.aws_lambda.Function`

**속성**:
```python
lambda_function = lambda_.Function(
    self, "TokenServiceFunction",
    function_name=f"{app_name}-{env}-token-service",
    runtime=lambda_.Runtime.PYTHON_3_13,
    handler="handler.lambda_handler",  # Unit 3에서 실제 경로 확인
    code=lambda_.Code.from_inline("""
def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': '{"message": "Token Service skeleton - to be implemented in Unit 3"}'
    }
    """),  # Placeholder
    timeout=Duration.seconds(30),
    memory_size=512,
    vpc=network_stack.vpc,
    vpc_subnets=ec2.SubnetSelection(
        subnets=network_stack.private_app_subnets
    ),
    security_groups=[network_stack.lambda_sg],
    environment={
        "RDS_PROXY_ENDPOINT": "placeholder",  # Unit 3에서 실제 값으로 교체
        "DB_SECRET_ARN": "placeholder",
        "KMS_KEY_ARN": "placeholder",
        "AWS_REGION": "ap-northeast-2"
    },
    role=lambda_execution_role
)
```

### 5.4 ECR Repository

**CDK Construct**: `aws_cdk.aws_ecr.Repository`

**속성**:
```python
ecr_repo = ecr.Repository(
    self, "GatewayEcrRepo",
    repository_name=f"{app_name}-{env}-gateway",
    image_tag_mutability=ecr.TagMutability.MUTABLE,
    image_scan_on_push=True,
    encryption=ecr.RepositoryEncryption.AES_256,
    lifecycle_rules=[
        ecr.LifecycleRule(
            description="Delete untagged images after default retention",
            rule_priority=1,
            tag_status=ecr.TagStatus.UNTAGGED,
            max_image_age=Duration.days(ecr_untagged_retention_days)
        ),
        ecr.LifecycleRule(
            description="Keep recent tagged images by default count",
            rule_priority=2,
            tag_status=ecr.TagStatus.TAGGED,
            max_image_count=ecr_tagged_image_count
        )
    ],
    removal_policy=RemovalPolicy.RETAIN  # ECR 이미지는 수동 삭제
)
```

ECR lifecycle 자체는 IaC로 관리하되, 보존 일수/개수는 운영 정책으로 고정하지 않는다. 예를 들어 untagged 30일, tagged 10개는 초기 기본값일 뿐이며, 배포 빈도와 이미지 churn을 본 뒤 context 값으로 조정한다.

### 5.5 KMS Key for Virtual Key

**CDK Construct**: `aws_cdk.aws_kms.Key`

**속성**:
```python
kms_key = kms.Key(
    self, "VirtualKeyKmsKey",
    alias=f"alias/{app_name}-{env}-virtual-key",
    description=f"KMS key for Virtual Key encryption - {env}",
    enable_key_rotation=True,  # 자동 rotation 1년
    pending_window=Duration.days(30),  # 삭제 대기 30일
    removal_policy=RemovalPolicy.RETAIN  # KMS 키는 수동 삭제
)

# Lambda Token Service: Encrypt/Decrypt
kms_key.grant_encrypt_decrypt(lambda_execution_role)

# ECS Gateway Task: Encrypt only (Admin rotate)
kms_key.grant_encrypt(gateway_task_role)
```

### 5.6 IAM Roles

#### 5.6.1 ECS Task Execution Role

**CDK Construct**: `aws_cdk.aws_iam.Role`

```python
gateway_execution_role = iam.Role(
    self, "GatewayExecutionRole",
    role_name=f"{app_name}-{env}-gateway-execution-role",
    assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name(
            "service-role/AmazonECSTaskExecutionRolePolicy"
        )
    ]
)

# ECR Repository 접근
ecr_repo.grant_pull(gateway_execution_role)

# Secrets Manager 접근
data_stack.db_secret.grant_read(gateway_execution_role)

# CloudWatch Logs 접근 (managed policy에 포함)
```

#### 5.6.2 ECS Task Role

```python
gateway_task_role = iam.Role(
    self, "GatewayTaskRole",
    role_name=f"{app_name}-{env}-gateway-task-role",
    assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com")
)

# Bedrock 접근
gateway_task_role.add_to_policy(
    iam.PolicyStatement(
        effect=iam.Effect.ALLOW,
        actions=[
            "bedrock:InvokeModel",
            "bedrock:InvokeModelWithResponseStream"
        ],
        resources=[
            f"arn:aws:bedrock:{Aws.REGION}::foundation-model/*"
        ]
    )
)

# Secrets Manager 접근
data_stack.db_secret.grant_read(gateway_task_role)

# AMP remote write 접근
gateway_task_role.add_to_policy(
    iam.PolicyStatement(
        effect=iam.Effect.ALLOW,
        actions=["aps:RemoteWrite"],
        resources=[observability_stack.amp_workspace_arn]
    )
)

# Identity Store 접근 (읽기 전용)
gateway_task_role.add_to_policy(
    iam.PolicyStatement(
        effect=iam.Effect.ALLOW,
        actions=[
            "identitystore:ListUsers",
            "identitystore:DescribeUser"
        ],
        resources=["*"]  # Identity Store는 리소스 ARN 미지원
    )
)

# KMS Encrypt (Admin rotate)
kms_key.grant_encrypt(gateway_task_role)
```

#### 5.6.3 Lambda Execution Role

```python
lambda_execution_role = iam.Role(
    self, "TokenServiceExecutionRole",
    role_name=f"{app_name}-{env}-token-service-execution-role",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name(
            "service-role/AWSLambdaVPCAccessExecutionRole"
        )
    ]
)

# KMS Encrypt/Decrypt
kms_key.grant_encrypt_decrypt(lambda_execution_role)

# Secrets Manager 접근
data_stack.db_secret.grant_read(lambda_execution_role)

# CloudWatch Logs 접근 (managed policy에 포함)
```

---

## 6. API Architecture

### 6.1 API Gateway for Token Service

**CDK Construct**: `aws_cdk.aws_apigateway.RestApi`

**속성**:
```python
token_api = apigateway.RestApi(
    self, "TokenApi",
    rest_api_name=f"{app_name}-{env}-token-api",
    description=f"Token Service API - {env}",
    endpoint_types=[apigateway.EndpointType.REGIONAL],
    deploy_options=apigateway.StageOptions(
        stage_name="prod",
        logging_level=apigateway.MethodLoggingLevel.ERROR,
        data_trace_enabled=False,
        metrics_enabled=True
    ),
    default_cors_preflight_options=None  # CORS는 애플리케이션 레벨에서 처리
)

# IAM Authorization 설정
v1 = token_api.root.add_resource("v1")
auth = v1.add_resource("auth")
virtual_key = auth.add_resource("virtual-key")

virtual_key.add_method(
    "POST",
    apigateway.LambdaIntegration(
        compute_stack.lambda_function,
        proxy=True
    ),
    authorization_type=apigateway.AuthorizationType.IAM
)
```

**API Gateway Execution Role**:
```python
api_gateway_role = iam.Role(
    self, "ApiGatewayRole",
    assumed_by=iam.ServicePrincipal("apigateway.amazonaws.com")
)

compute_stack.lambda_function.grant_invoke(api_gateway_role)
```

### 6.2 Application Load Balancer

**CDK Construct**: `aws_cdk.aws_elasticloadbalancingv2.ApplicationLoadBalancer`

**속성**:
```python
alb = elbv2.ApplicationLoadBalancer(
    self, "Alb",
    load_balancer_name=f"{app_name}-{env}-alb",
    vpc=network_stack.vpc,
    vpc_subnets=ec2.SubnetSelection(
        subnets=network_stack.public_subnets
    ),
    security_groups=[network_stack.alb_sg],
    internet_facing=True,
    idle_timeout=Duration.seconds(300),  # 5분 (장시간 스트리밍)
    deletion_protection=is_prod,
    drop_invalid_header_fields=True
)
```

### 6.3 ALB Target Group

**CDK Construct**: `aws_cdk.aws_elasticloadbalancingv2.ApplicationTargetGroup`

**속성**:
```python
target_group = elbv2.ApplicationTargetGroup(
    self, "GatewayTargetGroup",
    target_group_name=f"{app_name}-{env}-gateway-tg",
    vpc=network_stack.vpc,
    target_type=elbv2.TargetType.IP,  # Fargate awsvpc 모드
    protocol=elbv2.ApplicationProtocol.HTTP,
    port=8000,
    health_check=elbv2.HealthCheck(
        path="/healthz",
        protocol=elbv2.Protocol.HTTP,
        port="8000",
        interval=Duration.seconds(30),
        timeout=Duration.seconds(5),
        healthy_threshold_count=2,
        unhealthy_threshold_count=2
    ),
    deregistration_delay=Duration.seconds(30)
)
```

### 6.4 ALB Listeners

#### 6.4.1 HTTPS Listener (Port 443)

```python
acm_cert_arn = self.node.try_get_context("acm_certificate_arn")
if not acm_cert_arn:
    raise ValueError("Context 'acm_certificate_arn' is required")

https_listener = alb.add_listener(
    "HttpsListener",
    port=443,
    protocol=elbv2.ApplicationProtocol.HTTPS,
    certificates=[
        elbv2.ListenerCertificate.from_arn(acm_cert_arn)
    ],
    ssl_policy=elbv2.SslPolicy.TLS13_1_2_2021_06,
    default_action=elbv2.ListenerAction.forward([target_group])
)
```

#### 6.4.2 HTTP Listener (Port 80) - Redirect

```python
http_listener = alb.add_listener(
    "HttpListener",
    port=80,
    protocol=elbv2.ApplicationProtocol.HTTP,
    default_action=elbv2.ListenerAction.redirect(
        protocol="HTTPS",
        port="443",
        permanent=True  # 301 redirect
    )
)
```

---

## 7. Observability Architecture

### 7.1 Amazon Managed Prometheus (AMP)

**CDK Construct**: `aws_cdk.aws_aps.CfnWorkspace`

**속성**:
```python
amp_workspace = aps.CfnWorkspace(
    self, "AmpWorkspace",
    alias=f"{app_name}-{env}"
)

# Remote Write URL 계산
amp_remote_write_url = f"https://{amp_workspace.attr_workspace_id}.aps-workspaces.{Aws.REGION}.amazonaws.com/api/v1/remote_write"
```

### 7.2 CloudWatch Logs

**ECS Log Group**:
```python
ecs_log_group = logs.LogGroup(
    self, "EcsLogGroup",
    log_group_name=f"/ecs/{app_name}-{env}-gateway",
    retention=retention_days,  # prod 30일, else 7일
    removal_policy=RemovalPolicy.DESTROY
)
```

**Lambda Log Group** (자동 생성):
```
/aws/lambda/{app_name}-{env}-token-service
```

**API Gateway Log Group** (자동 생성):
```
/aws/api-gateway/{app_name}-{env}-token-api/prod
```

### 7.3 Resource Tagging

**CDK App 레벨 공통 태그**:
```python
# infra/app.py
from aws_cdk import App, Tags

app = App()
env = app.node.try_get_context("environment") or "dev"

Tags.of(app).add("Project", "claude-proxy")
Tags.of(app).add("Environment", env)
Tags.of(app).add("ManagedBy", "cdk")
```

---

## 8. CDK Implementation

### 8.1 CDK Project Structure

```
infra/
├── app.py                          # CDK App 진입점
├── cdk.json                        # CDK context 설정
├── requirements.txt                # CDK 의존성 (uv에서 생성)
├── stacks/
│   ├── __init__.py
│   ├── network_stack.py
│   ├── data_stack.py
│   ├── observability_stack.py
│   ├── compute_stack.py
│   └── api_stack.py
└── README.md                       # 배포 가이드
```

### 8.2 CDK Context Parameters

**cdk.json**:
```json
{
  "app": "python app.py",
  "context": {
    "environment": "dev",
    "region": "ap-northeast-2",
    "vpc_cidr": "10.0.0.0/16",
    "public_subnet_mask": 24,
    "private_app_subnet_mask": 20,
    "private_data_subnet_mask": 24,
    "aurora_min_capacity": 0.5,
    "aurora_max_capacity": 1.0,
    "aurora_backup_retention_days": 7,
    "aurora_backup_window": "02:00-03:00",
    "aurora_maintenance_window": "Sun:09:00-Sun:10:00",
    "ecr_untagged_retention_days": 30,
    "ecr_tagged_image_count": 10,
    "app_name": "claude-proxy"
  }
}
```

위 context 예시의 subnet mask, Aurora ACU, maintenance window, ECR lifecycle 숫자는 모두 초기 기본값이다. 설계 원칙으로 고정하지 않고 환경별 override를 허용한다.

**필수 context (CLI 전달)**:
- `acm_certificate_arn`: ALB HTTPS 리스너용 ACM 인증서 ARN

**배포 예시**:
```bash
cdk deploy --all \
  -c environment=prod \
  -c region=ap-northeast-2 \
  -c acm_certificate_arn=arn:aws:acm:ap-northeast-2:123456789012:certificate/abc123 \
  --require-approval broadening
```

### 8.3 Cross-stack References

**전략**: stack props/direct reference 우선, output은 운영 확인용 보조 수단

**NetworkStack → DataStack**:
```python
# NetworkStack
self.vpc = vpc
self.private_data_subnets = private_data_subnets
self.rds_sg = rds_sg

# DataStack
def __init__(self, scope, id, network_stack: NetworkStack, **kwargs):
    super().__init__(scope, id, **kwargs)
    vpc = network_stack.vpc
    subnets = network_stack.private_data_subnets
    security_group = network_stack.rds_sg
```

**DataStack → ComputeStack**:
```python
# DataStack
self.rds_proxy_endpoint = rds_proxy.endpoint
self.db_secret_arn = db_secret.secret_arn
self.aurora_cluster_arn = aurora_cluster.cluster_arn

# ComputeStack
def __init__(self, scope, id, data_stack: DataStack, **kwargs):
    super().__init__(scope, id, **kwargs)
    rds_proxy_endpoint = data_stack.rds_proxy_endpoint
    db_secret_arn = data_stack.db_secret_arn
```

**ObservabilityStack → ComputeStack**:
```python
# ObservabilityStack
self.amp_remote_write_url = amp_remote_write_url
self.amp_workspace_id = amp_workspace.attr_workspace_id
self.amp_workspace_arn = amp_workspace.attr_arn

# ComputeStack
def __init__(self, scope, id, observability_stack: ObservabilityStack, **kwargs):
    super().__init__(scope, id, **kwargs)
    amp_remote_write_url = observability_stack.amp_remote_write_url
```

스택 간 wiring은 생성자 props와 직접 속성 참조를 기본으로 한다. `CfnOutput`은 콘솔 확인, 운영 검증, 수동 확인 절차에 필요한 값만 노출하는 용도로 제한한다.

```python
CfnOutput(
    self,
    "RdsProxyEndpoint",
    value=self.rds_proxy_endpoint,
    description="운영 확인용 RDS Proxy endpoint"
)
```

### 8.4 Resource Naming Convention

**패턴**: `{app_name}-{env}-{resource_type}`

| 리소스 유형 | 명명 예시 (dev 환경) |
|-----------|-------------------|
| CDK Stack | `claude-proxy-dev-network` |
| VPC | `claude-proxy-dev-vpc` |
| Subnet | `claude-proxy-dev-public-2a` |
| Security Group | `claude-proxy-dev-alb-sg` |
| Aurora Cluster | `claude-proxy-dev-aurora` |
| RDS Proxy | `claude-proxy-dev-rds-proxy` |
| ECS Cluster | `claude-proxy-dev-cluster` |
| ECS Task Definition | `claude-proxy-dev-gateway-task` |
| Lambda Function | `claude-proxy-dev-token-service` |
| ECR Repository | `claude-proxy-dev-gateway` |
| ALB | `claude-proxy-dev-alb` |
| Target Group | `claude-proxy-dev-gateway-tg` |
| API Gateway | `claude-proxy-dev-token-api` |
| KMS Key Alias | `alias/claude-proxy-dev-virtual-key` |
| Secrets Manager | `claude-proxy/dev/db-credentials` |
| CloudWatch Log Group | `/ecs/claude-proxy-dev-gateway` |
| AMP Workspace Alias | `claude-proxy-dev` |

---

## 9. Cost Estimation

### 9.1 월별 예상 비용 (dev 환경, 사용량 가정)

이 절의 수치는 운영 정책이 아니라 초기 비용 추정용 가정이다. Aurora ACU, 로그 보존, endpoint 수 등은 실제 사용량 관찰 후 조정될 수 있다.

**가정**:
- ECS Task: 1개 (0.75 vCPU, 1.5 GB), 24시간 실행
- Lambda: 1,000 invocations/month, 512MB, 평균 5초 실행
- Aurora: 평균 0.5 ACU, 24시간 실행, 10GB 스토리지
- Bedrock API 호출: 10,000 requests/month, 평균 1K input + 1K output tokens
- CloudWatch Logs: 5GB ingestion/month
- AMP: 10M samples/month

| 리소스 | 단가 | 사용량 | 월 비용 (USD) |
|--------|-----|--------|--------------|
| **Compute** | | | |
| ECS Fargate (0.75 vCPU) | $0.04656/vCPU/hr | 720 hr | $33.5 |
| ECS Fargate (1.5 GB) | $0.00511/GB/hr | 1080 GB-hr | $5.5 |
| Lambda invocations | $0.20/1M req | 1K req | $0.0 |
| Lambda compute | $0.0000166667/GB-sec | 2.5K GB-sec | $0.04 |
| **Storage** | | | |
| Aurora Serverless v2 | $0.12/ACU/hr | 360 ACU-hr | $43.2 |
| Aurora Storage | $0.10/GB/month | 10 GB | $1.0 |
| Aurora Backup | $0.021/GB/month | 10 GB × 7 days | $0.2 |
| **Networking** | | | |
| VPC Endpoint (10개) | $0.01/hr/endpoint | 7200 endpoint-hr | $72.0 |
| ALB | $0.0225/hr | 720 hr | $16.2 |
| ALB LCU | $0.008/LCU/hr | 100 LCU-hr | $0.8 |
| **Observability** | | | |
| CloudWatch Logs Ingestion | $0.50/GB | 5 GB | $2.5 |
| CloudWatch Logs Storage | $0.03/GB/month | 5 GB × 7 days | $0.1 |
| AMP Sample Ingestion | $0.30/M samples | 10M samples | $3.0 |
| **Security** | | | |
| KMS Key | $1/month | 1 key | $1.0 |
| KMS Requests | $0.03/10K req | 10K req | $0.03 |
| Secrets Manager | $0.40/secret/month | 1 secret | $0.4 |
| **Bedrock (참고)** | | | |
| Claude 3.5 Sonnet v2 Input | $3/M tokens | 10M tokens | $30.0 |
| Claude 3.5 Sonnet v2 Output | $15/M tokens | 10M tokens | $150.0 |
| **총계** | | | **$359.4** |

**Bedrock 비용 제외 (인프라만)**: $179.4/월

### 9.2 staging/prod 환경 비용 차이

| 환경 | ECS desired count | CloudWatch Logs 보존 | 월 비용 (인프라만) |
|-----|------------------|---------------------|-------------------|
| dev | 1 | 7일 | $179.4 |
| staging | 2 | 7일 | $218.6 (+21%) |
| prod | 2 | 30일 | $220.8 (+23%) |

**주요 비용 증가 요인**:
- ECS Task 2배 → Compute 비용 2배 ($39 → $78)
- CloudWatch Logs 보존 30일 → Storage 비용 4배 ($0.1 → $0.4)

### 9.3 비용 최적화 전략

| 최적화 항목 | 현재 | 최적화 후 | 절감 예상 |
|-----------|-----|----------|----------|
| ECS Task vCPU/Memory | 0.75/1.5 | 0.5/1.0 (워크로드 분석 후) | -30% |
| Aurora min capacity | 0.5 ACU | 0.5 ACU 유지 (트래픽 패턴 확인 후) | - |
| VPC Endpoint 수 | 10개 | 필수만 유지 (8개) | -20% |
| CloudWatch Logs 보존 (dev) | 7일 | 3일 | -57% |

**예상 총 절감**: 약 $50/월 (28%)

---

## 10. Deployment Strategy

### 10.1 배포 순서

```
1. CDK Bootstrap
   cdk bootstrap aws://<account>/ap-northeast-2

2. 스택별 배포 (자동 의존성 처리)
   cdk deploy --all -c environment=dev -c acm_certificate_arn=<arn>

3. 배포 순서 (CDK 자동)
   NetworkStack → DataStack + ObservabilityStack → ComputeStack → ApiStack
```

### 10.2 Unit 3/4 완료 후 재배포

**Unit 3 (Token Service) 완료 후**:
```bash
# 1. Lambda 코드 경로 변경 (compute_stack.py)
#    code=lambda_.Code.from_inline(...) → code=lambda_.Code.from_asset("lambda")

# 2. 환경변수 값 변경 (compute_stack.py)
#    "placeholder" → 실제 cross-stack 참조 값

# 3. CDK 재배포
cd infra
cdk diff ComputeStack ApiStack
cdk deploy ComputeStack ApiStack
```

**Unit 4 (Gateway) 완료 후**:
```bash
# 1. Docker 이미지 빌드 및 ECR push
cd gateway
docker build -t claude-proxy-dev-gateway:latest .
aws ecr get-login-password --region ap-northeast-2 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.ap-northeast-2.amazonaws.com
docker tag claude-proxy-dev-gateway:latest 123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/claude-proxy-dev-gateway:latest
docker push 123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/claude-proxy-dev-gateway:latest

# 2. ECS Task Definition 변경 (compute_stack.py)
#    image=ecs.ContainerImage.from_registry("nginx:latest") → image=ecs.ContainerImage.from_ecr_repository(ecr_repo, "latest")
#    환경변수 값 변경: "placeholder" → 실제 cross-stack 참조 값
#    ADOT AOT_CONFIG_CONTENT: <AMP_REMOTE_WRITE_URL> → observability_stack.amp_remote_write_url

# 3. ECS Service 생성 (Unit 4에서 추가)

# 4. CDK 재배포
cd infra
cdk diff ComputeStack
cdk deploy ComputeStack
```

### 10.3 운영 환경 배포

```bash
# staging 배포
cdk deploy --all \
  -c environment=staging \
  -c acm_certificate_arn=<staging-cert-arn>

# prod 배포 (staging 검증 후)
cdk deploy --all \
  -c environment=prod \
  -c acm_certificate_arn=<prod-cert-arn> \
  --require-approval broadening
```

---

## 11. 다음 단계: Code Generation

본 Infrastructure Design이 승인되면, 다음 단계는 **Code Generation (Unit 1)**이다.

**Code Generation에서 생성할 산출물**:
1. `infra/app.py` — CDK App 진입점
2. `infra/cdk.json` — CDK context 설정
3. `infra/requirements.txt` — CDK 의존성
4. `infra/stacks/network_stack.py` — NetworkStack
5. `infra/stacks/data_stack.py` — DataStack
6. `infra/stacks/observability_stack.py` — ObservabilityStack
7. `infra/stacks/compute_stack.py` — ComputeStack
8. `infra/stacks/api_stack.py` — ApiStack
9. `infra/README.md` — 배포 가이드
10. `tests/test_network_stack.py` — NetworkStack snapshot test
11. `tests/test_data_stack.py` — DataStack snapshot test
12. 기타 스택 snapshot test

**Code Generation 완료 후 Build and Test**:
- `cdk synth` 성공 확인
- `cdk deploy --all` 전체 스택 배포
- 리소스 생성 확인 (VPC, Aurora, ECS Task Definition, Lambda, API Gateway, ALB, AMP)
- Cross-stack 참조 정상 동작 확인
- pytest 실행 (snapshot test)

---

## 문서 끝

본 문서는 Unit 1: Foundation Infrastructure의 **Infrastructure Design**을 완료했다. 모든 논리 컴포넌트가 실제 AWS 인프라 서비스로 매핑되었으며, CDK Python 코드 생성을 위한 상세 명세가 준비되었다.

**최종 검토 항목**:
- [x] 5개 스택별 AWS 서비스 매핑 완료
- [x] VPC, 서브넷, 보안 그룹, VPC Endpoint 상세 정의
- [x] Aurora, RDS Proxy, Secrets Manager 구성 완료
- [x] ECS Task Definition, Lambda Function skeleton 정의
- [x] API Gateway, ALB, Target Group 구성 완료
- [x] AMP Workspace, ADOT Collector 설정 완료
- [x] IAM 역할/정책, KMS Key 구성 완료
- [x] CDK context 파라미터 정의
- [x] Cross-stack 참조 전략 정의
- [x] 리소스 명명 규칙 정의
- [x] 비용 추정 완료
- [x] 배포 전략 정의

**다음 단계: Code Generation**
