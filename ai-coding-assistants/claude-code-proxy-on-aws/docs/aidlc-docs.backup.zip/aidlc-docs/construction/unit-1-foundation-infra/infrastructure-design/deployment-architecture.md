# Unit 1: Foundation Infrastructure - Deployment Architecture

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Final
- 단계: CONSTRUCTION - Infrastructure Design
- 근거 문서:
  - [Infrastructure Design](./infrastructure-design.md)
  - [Functional Design](../functional-design/functional-design.md)
  - [NFR Design](../nfr-design/nfr-design.md)

---

## 문서 개요

본 문서는 Unit 1 (Foundation Infrastructure)의 배포 아키텍처를 시각적으로 표현한다. 네트워크 토폴로지, 보안 경계, 데이터 흐름, 스택 의존성을 다이어그램으로 제시하여 Infrastructure Design 문서를 보완한다.

---

## 1. Deployment Topology Diagram

### 1.1 전체 시스템 토폴로지

```
┌────────────────────────────────────────────────────────────────────────────┐
│                           AWS Cloud (ap-northeast-2)                        │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │                 VPC (CIDR from context, e.g. 10.0.0.0/16)              ││
│  │                                                                          ││
│  │  ┌──────────────────────────────────────────────────────────────────┐  ││
│  │  │              Public Subnet (example CIDRs, context-driven)         │  ││
│  │  │                             2 AZ                                  │  ││
│  │  │  ┌────────────────────────────────────────────────────────────┐  │  ││
│  │  │  │              Application Load Balancer (ALB)               │  │  ││
│  │  │  │   - HTTPS (443) → ECS Task                                 │  │  ││
│  │  │  │   - HTTP (80) → Redirect to HTTPS                          │  │  ││
│  │  │  │   - TLS 1.2+ (ACM Certificate)                             │  │  ││
│  │  │  └────────────────────────────────────────────────────────────┘  │  ││
│  │  └──────────────────────────────────────────────────────────────────┘  ││
│  │                                │                                         ││
│  │                                │ (HTTPS)                                 ││
│  │                                ▼                                         ││
│  │  ┌──────────────────────────────────────────────────────────────────┐  ││
│  │  │         Private-app Subnet (example CIDRs, context-driven)       │  ││
│  │  │                             2 AZ                                  │  ││
│  │  │                                                                    │  ││
│  │  │  ┌──────────────────────────┐      ┌───────────────────────────┐ │  ││
│  │  │  │   ECS Fargate Task       │      │   Lambda Function         │ │  ││
│  │  │  │   ┌──────────────────┐   │      │   (Token Service)         │ │  ││
│  │  │  │   │  Gateway App     │   │      │                           │ │  ││
│  │  │  │   │  (0.5 vCPU,      │   │      │   - Virtual Key 발급      │ │  ││
│  │  │  │   │   1GB RAM)       │   │      │   - KMS Encrypt/Decrypt   │ │  ││
│  │  │  │   └──────────────────┘   │      │   - RDS Proxy 접근        │ │  ││
│  │  │  │   ┌──────────────────┐   │      └───────────────────────────┘ │  ││
│  │  │  │   │  ADOT Collector  │   │                │                    │  ││
│  │  │  │   │  (0.25 vCPU,     │   │                │                    │  ││
│  │  │  │   │   512MB RAM)     │   │                │                    │  ││
│  │  │  │   └──────────────────┘   │                │                    │  ││
│  │  │  └──────────────────────────┘                │                    │  ││
│  │  │              │                                │                    │  ││
│  │  │              │ (OTLP gRPC)                    │                    │  ││
│  │  │              ▼                                │                    │  ││
│  │  │  ┌──────────────────────────┐                │                    │  ││
│  │  │  │    VPC Endpoints (10개)  │◄───────────────┘                    │  ││
│  │  │  │  - Bedrock Runtime       │                                     │  ││
│  │  │  │  - ECR API/DKR           │                                     │  ││
│  │  │  │  - CloudWatch Logs       │                                     │  ││
│  │  │  │  - Secrets Manager       │                                     │  ││
│  │  │  │  - KMS                   │                                     │  ││
│  │  │  │  - Identity Store        │                                     │  ││
│  │  │  │  - STS                   │                                     │  ││
│  │  │  │  - AMP Workspaces        │                                     │  ││
│  │  │  │  - ECS                   │                                     │  ││
│  │  │  │  - S3 (Gateway Endpoint) │                                     │  ││
│  │  │  └──────────────────────────┘                                     │  ││
│  │  └──────────────────────────────────────────────────────────────────┘  ││
│  │                                │                                         ││
│  │                                │ (PostgreSQL)                            ││
│  │                                ▼                                         ││
│  │  ┌──────────────────────────────────────────────────────────────────┐  ││
│  │  │        Private-data Subnet (example CIDRs, context-driven)       │  ││
│  │  │                             2 AZ                                  │  ││
│  │  │                                                                    │  ││
│  │  │  ┌──────────────────────────┐      ┌───────────────────────────┐ │  ││
│  │  │  │     RDS Proxy            │      │  Aurora Serverless v2     │ │  ││
│  │  │  │   - Connection Pooling   │──────▶  (PostgreSQL)             │ │  ││
│  │  │  │   - TLS 1.2+             │      │  - Initial ACU defaults   │ │  ││
│  │  │  │   - Secrets Manager Auth │      │  - Multi-AZ Storage       │ │  ││
│  │  │  └──────────────────────────┘      │  - PITR enabled           │ │  ││
│  │  │                                     │  - Encrypted              │ │  ││
│  │  │                                     └───────────────────────────┘ │  ││
│  │  └──────────────────────────────────────────────────────────────────┘  ││
│  │                                                                          ││
│  └──────────────────────────────────────────────────────────────────────────┘│
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                        Outside VPC                                    │  │
│  │                                                                        │  │
│  │  ┌───────────────────────┐       ┌──────────────────────────────┐    │  │
│  │  │  API Gateway          │       │  Amazon Managed Prometheus   │    │  │
│  │  │  (Token Service)      │       │  (AMP Workspace)             │    │  │
│  │  │  - IAM Auth (SigV4)   │       │  - Prometheus 메트릭 저장    │    │  │
│  │  │  - Lambda 통합        │       │  - ADOT remote write         │    │  │
│  │  └───────────────────────┘       └──────────────────────────────┘    │  │
│  │                                                                        │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
└────────────────────────────────────────────────────────────────────────────┘

인터넷 ───────────────▶ ALB (Public Subnet)
                          │
                          ├─ HTTPS (443) ──▶ ECS Task (Private-app)
                          └─ HTTP (80) ────▶ 301 Redirect to HTTPS

AWS SSO (사용자) ─────▶ API Gateway (IAM Auth) ──▶ Lambda (Private-app)
```

### 1.2 계층별 배치 전략

| 계층 | 서브넷 | 리소스 | 인터넷 접근 | AWS 서비스 접근 |
|-----|--------|--------|-----------|--------------|
| **Ingress Layer** | Public | ALB | Inbound: 허용, Outbound: ECS만 | - |
| **Application Layer** | Private-app | ECS Task, Lambda | 차단 | VPC Endpoint |
| **Data Layer** | Private-data | Aurora, RDS Proxy | 차단 | - |

---

## 2. Network Flow Diagram

### 2.1 Runtime Gateway 요청 흐름 (Claude Code → Bedrock)

```
[Claude Code Client]
        │
        │ HTTPS POST /v1/messages
        │ x-api-key: vk-...
        ▼
[ALB - Public Subnet]
        │
        │ TLS termination (ACM 인증서)
        │ Listener rule: /v1/*
        ▼
[ECS Task - Private-app Subnet]
    │
    ├─▶ [Gateway App Container]
    │       │
    │       │ 1. Virtual Key 검증 (SHA-256 fingerprint)
    │       │ 2. PolicyChain 평가 (10단계)
    │       │ 3. Anthropic → Bedrock 요청 변환
    │       │ 4. Bedrock API 호출 (VPC Endpoint)
    │       │ 5. Bedrock → Anthropic 응답 변환
    │       │ 6. Usage 기록 (RDS Proxy → Aurora)
    │       │
    │       ├─▶ [VPC Endpoint - Bedrock Runtime]
    │       │       │
    │       │       └─▶ [Bedrock API]
    │       │
    │       ├─▶ [VPC Endpoint - Secrets Manager]
    │       │       │
    │       │       └─▶ [DB Credentials]
    │       │
    │       └─▶ [RDS Proxy - Private-data]
    │               │
    │               └─▶ [Aurora Serverless v2]
    │
    └─▶ [ADOT Collector Sidecar]
            │
            │ OTLP gRPC (localhost:4317)
            │
            ├─▶ [VPC Endpoint - AMP Workspaces]
            │       │
            │       └─▶ [AMP Remote Write]
            │
            └─▶ [VPC Endpoint - CloudWatch Logs]
                    │
                    └─▶ [CloudWatch Logs]
```

### 2.2 Token Service 요청 흐름 (AWS SSO → Virtual Key 발급)

```
[AWS SSO 사용자]
        │
        │ aws sts assume-role
        │ aws apigateway invoke
        ▼
[API Gateway - Regional]
        │
        │ IAM Authorization (SigV4 검증)
        │ POST /v1/auth/virtual-key
        ▼
[Lambda Function - Private-app Subnet]
        │
        │ 1. IAM Principal 추출
        │ 2. 사용자 조회 (RDS Proxy → Aurora)
        │ 3. Virtual Key 생성 (KMS Encrypt)
        │ 4. SHA-256 fingerprint 생성
        │ 5. DB 저장 (ciphertext + fingerprint)
        │ 6. Audit event 기록
        │
        ├─▶ [VPC Endpoint - KMS]
        │       │
        │       └─▶ [KMS Encrypt/Decrypt]
        │
        ├─▶ [VPC Endpoint - Secrets Manager]
        │       │
        │       └─▶ [DB Credentials]
        │
        └─▶ [RDS Proxy - Private-data]
                │
                └─▶ [Aurora Serverless v2]
```

### 2.3 네트워크 흐름 요약표

| 출발지 | 목적지 | 프로토콜 | 경로 | 보안 제어 |
|--------|--------|---------|------|----------|
| 인터넷 | ALB | HTTPS (443) | IGW → Public Subnet | alb-sg (0.0.0.0/0 허용) |
| ALB | ECS Task | HTTP (8000) | Public → Private-app | ecs-sg (alb-sg만 허용) |
| ECS Task | Bedrock | HTTPS (443) | Private-app → VPC Endpoint | endpoint-sg (ecs-sg 허용) |
| ECS Task | Aurora | PostgreSQL (5432) | Private-app → Private-data | rds-sg (ecs-sg 허용) |
| Lambda | KMS | HTTPS (443) | Private-app → VPC Endpoint | endpoint-sg (lambda-sg 허용) |
| Lambda | Aurora | PostgreSQL (5432) | Private-app → Private-data | rds-sg (lambda-sg 허용) |
| ADOT | AMP | HTTPS (443) | Private-app → VPC Endpoint | endpoint-sg (ecs-sg 허용) |

---

## 3. Security Boundary Diagram

### 3.1 보안 영역 분리

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Trust Boundary 1                                │
│                         Public Internet (Untrusted)                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ TLS 1.2+ (ACM)
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Trust Boundary 2                                │
│                           DMZ (Public Subnet)                                │
│                                                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  ALB (internet-facing)                                                 │ │
│  │  - TLS termination                                                     │ │
│  │  - WAF (v2 추가 예정)                                                  │ │
│  │  - Security Group: alb-sg                                              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ HTTP (8000) - Internal
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Trust Boundary 3                                │
│                       Application Layer (Private-app Subnet)                 │
│                                                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  ECS Task / Lambda                                                     │ │
│  │  - x-api-key 인증 (Virtual Key fingerprint)                           │ │
│  │  - IAM 역할 기반 권한 (Task Role / Execution Role)                   │ │
│  │  - Security Group: ecs-sg, lambda-sg                                   │ │
│  │  - Outbound: VPC Endpoint만 허용                                       │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ PostgreSQL (5432) + TLS
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Trust Boundary 4                                │
│                         Data Layer (Private-data Subnet)                     │
│                                                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  RDS Proxy + Aurora Serverless v2                                      │ │
│  │  - TLS 1.2+ 강제                                                       │ │
│  │  - Secrets Manager 인증                                                │ │
│  │  - Security Group: rds-sg                                               │ │
│  │  - Encryption at Rest (AWS 관리형 RDS 키)                              │ │
│  │  - Inbound: ecs-sg, lambda-sg만 허용                                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 보안 제어 매트릭스

| 보안 영역 | 접근 제어 | 암호화 | 인증 | 인가 | 감사 |
|----------|----------|--------|------|------|------|
| **Public Subnet** | alb-sg (0.0.0.0/0) | TLS 1.2+ (ACM) | - | - | ALB Access Logs (v2) |
| **Private-app Subnet** | ecs-sg, lambda-sg (ALB/VPC Endpoint만) | TLS 1.2+ (VPC Endpoint) | x-api-key, IAM | PolicyChain | CloudWatch Logs, audit_events |
| **Private-data Subnet** | rds-sg (ECS/Lambda만) | TLS 1.2+ (RDS Proxy), AWS 관리형 RDS 키 | Secrets Manager | IAM | Aurora Audit Logs (v2) |
| **KMS** | IAM 정책 (Lambda/ECS Task 역할) | 자동 rotation (1년) | IAM | Key Policy | CloudTrail |

### 3.3 암호화 경계

| 데이터 상태 | 암호화 방법 | 키 관리 | 적용 대상 |
|----------|-----------|--------|----------|
| **전송 중** | TLS 1.2+ | ACM (ALB), AWS 관리형 (VPC Endpoint) | ALB, VPC Endpoint, RDS Proxy |
| **저장 시** | KMS | 고객 관리형 (Virtual Key), AWS 관리형 (Aurora) | Virtual Key ciphertext, Aurora 스토리지 |
| **메모리** | 없음 | - | Virtual Key 평문 (Lambda 응답, 클라이언트 메모리만) |

---

## 4. Data Flow Diagram

### 4.1 Virtual Key 발급 흐름

```
┌─────────────┐
│  AWS SSO    │
│  사용자     │
└──────┬──────┘
       │
       │ 1. aws sts assume-role
       │    (IAM Principal 획득)
       ▼
┌─────────────────────┐
│  API Gateway        │
│  (IAM Auth)         │
└──────┬──────────────┘
       │
       │ 2. SigV4 검증
       │    IAM Principal 추출
       ▼
┌─────────────────────┐
│  Lambda Function    │
│  (Token Service)    │
└──────┬──────────────┘
       │
       │ 3. 사용자 조회 (DB)
       │    - UserLookupService.resolve_user()
       │    - 사용자 ID, 팀 ID 확인
       ▼
┌─────────────────────┐
│  RDS Proxy          │
│  → Aurora           │
└──────┬──────────────┘
       │
       │ 4. Virtual Key 생성 (KMS)
       │    - 신규 키 생성 또는 기존 키 조회
       │    - KMS Encrypt (평문 → ciphertext)
       ▼
┌─────────────────────┐
│  KMS                │
│  (Encrypt/Decrypt)  │
└──────┬──────────────┘
       │
       │ 5. SHA-256 fingerprint 생성
       │    - fingerprint = SHA-256(평문)
       │    - DB 저장: ciphertext + fingerprint
       ▼
┌─────────────────────┐
│  Aurora             │
│  (virtual_keys)     │
└──────┬──────────────┘
       │
       │ 6. 평문 Virtual Key 반환
       │    - API 응답으로 평문 반환 (1회만)
       │    - 이후 조회 불가
       ▼
┌─────────────┐
│  사용자     │
│  (평문 저장)│
└─────────────┘
```

### 4.2 Gateway 요청 처리 흐름

```
┌─────────────────┐
│  Claude Code    │
│  Client         │
└──────┬──────────┘
       │
       │ 1. POST /v1/messages
       │    x-api-key: vk-...
       │    Anthropic 요청 형식
       ▼
┌─────────────────────┐
│  ALB                │
└──────┬──────────────┘
       │
       │ 2. TLS termination
       │    Forward to ECS Task
       ▼
┌─────────────────────────────────────────────────────────────┐
│  ECS Task (Gateway App Container)                           │
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  3. Virtual Key 검증                                  │  │
│  │     - SHA-256 fingerprint 생성                        │  │
│  │     - DB 조회 (fingerprint 비교)                      │  │
│  │     - 상수 시간 비교                                  │  │
│  └───────────────────────────────────────────────────────┘  │
│                           │                                  │
│                           │ 4. PolicyChain 평가              │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  PolicyChain (10단계)                                 │  │
│  │  1. VirtualKey → 2. UserStatus → 3. TeamStatus →     │  │
│  │  4. ModelResolver → 5. UserModelPolicy →              │  │
│  │  6. TeamModelPolicy → 7. UserBudgetPreCheck →         │  │
│  │  8. TeamBudgetPreCheck → 9. ModelBudgetPreCheck →     │  │
│  │  10. CachePolicy                                      │  │
│  └───────────────────────────────────────────────────────┘  │
│                           │                                  │
│                           │ 5. 프로토콜 변환                 │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │  AnthropicToBedrockConverter                          │  │
│  │  - messages → Bedrock messages                        │  │
│  │  - system → Bedrock system                            │  │
│  │  - tools → Bedrock toolConfig                         │  │
│  │  - cache_control → cachePoint                         │  │
│  └───────────────────────────────────────────────────────┘  │
│                           │                                  │
└───────────────────────────┼──────────────────────────────────┘
                            │
                            │ 6. Bedrock API 호출
                            ▼
                ┌───────────────────────┐
                │  VPC Endpoint         │
                │  (Bedrock Runtime)    │
                └───────────┬───────────┘
                            │
                            ▼
                ┌───────────────────────┐
                │  Bedrock Converse API │
                │  (ConverseStream)     │
                └───────────┬───────────┘
                            │
                            │ 7. SSE 스트리밍 응답
                            ▼
┌───────────────────────────────────────────────────────────────┐
│  ECS Task (Gateway App Container)                             │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  8. BedrockToAnthropicConverter                         │  │
│  │     - contentBlockDelta → content_block_delta           │  │
│  │     - metadata → usage                                  │  │
│  └─────────────────────────────────────────────────────────┘  │
│                           │                                    │
│                           │ 9. Usage 기록                      │
│  ┌────────────────────────▼────────────────────────────────┐  │
│  │  UsageService.record_success()                          │  │
│  │  - apply_costs() (예산 사후 정산)                        │  │
│  │  - create_event() (usage_events 기록)                   │  │
│  └─────────────────────────────────────────────────────────┘  │
│                           │                                    │
└───────────────────────────┼────────────────────────────────────┘
                            │
                            ▼
                ┌───────────────────────┐
                │  RDS Proxy            │
                │  → Aurora             │
                └───────────┬───────────┘
                            │
                            │ 10. Metric emit
                            ▼
┌───────────────────────────────────────────────────────────────┐
│  ECS Task (ADOT Collector Sidecar)                            │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  MetricsService                                         │  │
│  │  - bedrock.token.usage (Counter)                        │  │
│  │  - bedrock.cost.usage (Counter)                         │  │
│  │  - bedrock.request.duration (Histogram)                 │  │
│  │  - OTLP gRPC push (localhost:4317)                      │  │
│  └─────────────────────────────────────────────────────────┘  │
│                           │                                    │
└───────────────────────────┼────────────────────────────────────┘
                            │
                            ▼
                ┌───────────────────────┐
                │  VPC Endpoint         │
                │  (AMP Workspaces)     │
                └───────────┬───────────┘
                            │
                            ▼
                ┌───────────────────────┐
                │  AMP Remote Write     │
                └───────────────────────┘
```

---

## 5. Stack Dependency Diagram

### 5.1 CDK 스택 배포 순서

```
┌───────────────────┐
│  NetworkStack     │
│  (최우선)         │
│  - VPC            │
│  - Subnet         │
│  - Security Group │
│  - VPC Endpoint   │
└─────────┬─────────┘
          │
          ├─────────────────────┐
          │                     │
          ▼                     ▼
┌───────────────────┐   ┌───────────────────────┐
│  DataStack        │   │  ObservabilityStack   │
│  (병렬 배포)      │   │  (병렬 배포)          │
│  - Aurora         │   │  - AMP Workspace      │
│  - RDS Proxy      │   │                       │
│  - Secrets Manager│   │                       │
└─────────┬─────────┘   └───────────┬───────────┘
          │                         │
          └──────────┬──────────────┘
                     │
                     ▼
          ┌───────────────────┐
          │  ComputeStack     │
          │  - ECS Cluster    │
          │  - Task Definition│
          │  - Lambda         │
          │  - ECR            │
          │  - KMS            │
          └─────────┬─────────┘
                    │
                    ▼
          ┌───────────────────┐
          │  ApiStack         │
          │  (최종)           │
          │  - API Gateway    │
          │  - ALB            │
          │  - Target Group   │
          └───────────────────┘
```

### 5.2 Cross-stack 참조 흐름

| From Stack | To Stack | 참조 항목 | 전달 방식 |
|-----------|---------|----------|----------|
| NetworkStack | DataStack | VPC, Private-data Subnets, rds-sg | Constructor props |
| NetworkStack | ObservabilityStack | VPC (VPC Endpoint 참조용) | Constructor props |
| NetworkStack | ComputeStack | VPC, Private-app Subnets, ecs-sg, lambda-sg | Constructor props |
| NetworkStack | ApiStack | VPC, Public Subnets, alb-sg | Constructor props |
| DataStack | ComputeStack | RDS Proxy Endpoint, DB Secret ARN, Aurora Cluster ARN | Constructor props |
| ObservabilityStack | ComputeStack | AMP Remote Write URL, AMP Workspace ID, AMP Workspace ARN | Constructor props |
| ComputeStack | ApiStack | Lambda Function ARN | Constructor props |

**참조 원칙**:
- 기본 전략은 constructor props/direct reference이다.
- `CfnOutput`은 운영 확인, 배포 검증, 콘솔 조회가 필요한 값만 노출한다.
- 명시적 export 이름을 cross-stack 패턴으로 관리하지 않는다.

---

## 6. Availability Zone Distribution

### 6.1 Multi-AZ 배포 전략

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           VPC (10.0.0.0/16)                                  │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                   Availability Zone A (ap-northeast-2a)               │   │
│  │                                                                        │   │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐   │   │
│  │  │  Public Subnet   │  │  Private-app     │  │  Private-data    │   │   │
│  │  │  (context)       │  │  (context)       │  │  (context)       │   │   │
│  │  │                  │  │                  │  │                  │   │   │
│  │  │  - ALB (AZ-a)    │  │  - ECS Task 1    │  │  - Aurora Writer │   │   │
│  │  │                  │  │  - Lambda (AZ-a) │  │  - RDS Proxy     │   │   │
│  │  │                  │  │  - VPC Endpoints │  │                  │   │   │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘   │   │
│  │                                                                        │   │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                   Availability Zone C (ap-northeast-2c)               │   │
│  │                                                                        │   │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐   │   │
│  │  │  Public Subnet   │  │  Private-app     │  │  Private-data    │   │   │
│  │  │  (context)       │  │  (context)       │  │  (context)       │   │   │
│  │  │                  │  │                  │  │                  │   │   │
│  │  │  - ALB (AZ-c)    │  │  - ECS Task 2    │  │  - RDS Proxy     │   │   │
│  │  │                  │  │  - Lambda (AZ-c) │  │  (Standby)       │   │   │
│  │  │                  │  │  - VPC Endpoints │  │                  │   │   │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘   │   │
│  │                                                                        │   │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │              Aurora Storage (3 AZ - 자동 복제)                         │   │
│  │  AZ-a: 복제본 2개 | AZ-c: 복제본 2개 | AZ-d: 복제본 2개             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 장애 복구 시나리오

| 장애 유형 | 영향 범위 | 복구 전략 | RTO | RPO |
|----------|----------|----------|-----|-----|
| **ECS Task 장애** | 단일 Task | ECS Service가 즉시 새 Task 기동 | < 2분 | 0 |
| **Lambda 장애** | 단일 Invocation | 즉시 재시도 (클라이언트 또는 API Gateway) | < 1분 | 0 |
| **ALB AZ 장애** | 단일 AZ | ALB가 자동으로 다른 AZ로 트래픽 전환 | < 1분 | 0 |
| **Aurora Writer 장애** | Writer 인스턴스 | Aurora 자동 failover (스토리지는 유지) | < 1분 | < 5분 |
| **RDS Proxy 장애** | 연결 풀 | 새 RDS Proxy 인스턴스 자동 기동 | < 2분 | 0 |
| **VPC Endpoint 장애** | 단일 Endpoint | AWS 자동 복구 (Multi-AZ ENI) | < 5분 | 0 |
| **AZ 전체 장애** | 단일 AZ | 다른 AZ의 리소스로 자동 전환 | < 5분 | < 5분 |

---

## 7. 배포 환경별 차이

### 7.1 dev 환경

```
┌─────────────────────────────────────────────────────────────────────────┐
│  dev 환경 (비용 최적화, 단순화)                                         │
│                                                                           │
│  ECS Task: 1개 (단일 AZ)                                                 │
│  Aurora: 초기 ACU 기본값 사용, 실제 부하 기반 조정                       │
│  CloudWatch Logs: 7일 보존                                               │
│  Deletion Protection: 비활성화                                           │
│                                                                           │
│  예상 월 비용: $179 (인프라만)                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

### 7.2 staging 환경

```
┌─────────────────────────────────────────────────────────────────────────┐
│  staging 환경 (prod 유사, 트래픽 낮음)                                  │
│                                                                           │
│  ECS Task: 2개 (Multi-AZ)                                                │
│  Aurora: 초기 ACU 기본값 사용, 실제 부하 기반 조정                       │
│  CloudWatch Logs: 7일 보존                                               │
│  Deletion Protection: 비활성화                                           │
│                                                                           │
│  예상 월 비용: $219 (인프라만)                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

### 7.3 prod 환경

```
┌─────────────────────────────────────────────────────────────────────────┐
│  prod 환경 (고가용성, 데이터 보호)                                      │
│                                                                           │
│  ECS Task: 2개 (Multi-AZ)                                                │
│  Aurora: 초기 ACU 기본값에서 시작, 운영 데이터 기반 조정                 │
│  CloudWatch Logs: 30일 보존                                              │
│  Deletion Protection: 활성화 (Aurora, ALB)                               │
│  Auto-scaling: Unit 4 이후 추가 예정                                     │
│                                                                           │
│  예상 월 비용: $221 (인프라만)                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 문서 끝

본 문서는 Unit 1: Foundation Infrastructure의 **Deployment Architecture**를 완료했다. 전체 시스템의 네트워크 토폴로지, 보안 경계, 데이터 흐름, 스택 의존성을 시각적으로 표현하여 Infrastructure Design 문서를 보완한다.

**주요 다이어그램 요약**:
- [x] Deployment Topology Diagram — 전체 시스템 토폴로지 (VPC, 서브넷, 리소스 배치)
- [x] Network Flow Diagram — Runtime Gateway 및 Token Service 요청 흐름
- [x] Security Boundary Diagram — 4계층 보안 영역 분리 및 보안 제어 매트릭스
- [x] Data Flow Diagram — Virtual Key 발급 및 Gateway 요청 처리 흐름
- [x] Stack Dependency Diagram — CDK 스택 배포 순서 및 Cross-stack 참조
- [x] Availability Zone Distribution — Multi-AZ 배포 전략 및 장애 복구 시나리오
- [x] 환경별 차이 — dev/staging/prod 환경별 리소스 구성 및 비용

**다음 단계: Code Generation**
