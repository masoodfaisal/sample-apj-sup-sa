# Unit 1: Foundation Infrastructure - Infrastructure Design 질문 (Round 1)

- **문서 버전**: v1.0
- **작성일**: 2026-04-01
- **상태**: Approved (답변 확정, 설계 반영 완료)
- **단계**: CONSTRUCTION - Infrastructure Design (Questions)

---

## 질문 개요

본 문서는 Unit 1 (Foundation Infrastructure)의 Infrastructure Design 단계에서 답변이 필요한 질문들을 정리한다.

모든 질문은 Functional Design, NFR Requirements, NFR Design을 기반으로 작성되었으며, CDK 코드 구현의 구체적인 방법론을 결정하기 위한 것이다.

---

## P0 (Critical) - 필수 답변 항목

### 범주 1: Deployment Environment (배포 환경)

#### Q1-1: CDK 프로젝트 초기화 방식
**질문**: CDK 프로젝트를 어떻게 초기화할 것인가?

**선택지**:
- [ ] A. `cdk init app --language python` 명령어 사용 (CDK 표준 템플릿)
- [x] B. 수동으로 `cdk.json`, `pyproject.toml`, `app.py` 작성 (uv 기반)

**제안**: B (uv 기반 최소 scaffold를 직접 생성)

**근거**:
- 예상 산출물 구조가 `pyproject.toml` + `uv.lock` 기반이므로 초기 bootstrap 방식도 동일하게 맞춘다.
- `cdk init` 템플릿을 생성한 뒤 다시 정리하는 이중 작업을 피할 수 있다.
- v1 범위에서는 필요한 파일이 적어 수동 scaffold 비용이 낮다.

**영향 범위**: Code Generation 단계의 프로젝트 구조 생성

---

#### Q1-2: CDK 프로젝트 루트 디렉토리
**질문**: CDK 프로젝트의 루트 디렉토리 위치는?

**선택지**:
- [x] A. 프로젝트 루트 하위 `infra/` (권장)
- [ ] B. 프로젝트 루트와 동일 레벨
- [ ] C. 다른 위치: _______

**제안**: A (`infra/`)

**근거**: 
- 프로젝트 루트에는 Gateway/Lambda 애플리케이션 코드 (Unit 3-4)가 위치
- `infra/` 디렉토리로 인프라 코드를 명확히 분리

**영향 범위**: 전체 프로젝트 디렉토리 구조, CI/CD 경로 설정

---

#### Q1-3: CDK 진입점 파일 이름
**질문**: CDK 진입점 파일 이름은?

**선택지**:
- [x] A. `app.py` (CDK 표준)
- [ ] B. `main.py`
- [ ] C. 다른 이름: _______

**제안**: A (`app.py`)

**근거**: CDK 표준 명명 규칙 준수, `cdk.json`의 `"app": "python app.py"` 설정과 일치

**영향 범위**: `cdk.json` 설정, CDK 배포 명령어

---

#### Q1-4: 환경별 AWS 계정/리전 분리 전략
**질문**: dev/staging/prod 환경별 AWS 계정 및 리전을 분리하는가?

**선택지**:
- [x] A. 단일 계정, 단일 리전 (ap-northeast-2)
- [ ] B. 단일 계정, 환경별 리전 분리
- [ ] C. 환경별 AWS 계정 분리, 단일 리전
- [ ] D. 환경별 AWS 계정 및 리전 모두 분리

**제안**: A (단일 계정, 단일 리전)

**근거**: 
- 내부 개발자 도구로 초기 복잡성 최소화
- 환경별 스택 이름 차별화(`{app}-{env}-{layer}`)로 리소스 분리
- 향후 필요 시 계정 분리 마이그레이션 가능

**영향 범위**: CDK bootstrap, 배포 명령어, IAM 권한 관리

---

#### Q1-5: CDK bootstrap 환경별 실행
**질문**: dev/staging/prod 환경별로 CDK bootstrap을 별도 실행하는가?

**선택지**:
- [x] A. 단일 계정이면 1회만 bootstrap (스택 이름으로 환경 구분)
- [ ] B. 환경별 계정이 다르면 각각 bootstrap
- [ ] C. 기타: _______

**제안**: A (단일 계정 1회 bootstrap)

**근거**: Q1-4에서 단일 계정 선택 시 bootstrap은 계정당 1회만 필요

**영향 범위**: 배포 초기 설정 절차

---

#### Q1-6: Context 기본값 정의 위치
**질문**: CDK context 파라미터의 기본값을 어디에 정의하는가?

**선택지**:
- [ ] A. `cdk.json`의 `context` 섹션에 모든 기본값 정의
- [ ] B. 코드에서 `try_get_context("key") or default` fallback만 사용
- [x] C. `cdk.json`에 일부 기본값, 코드에서 fallback

**제안**: C (`cdk.json`에 dev 기본값, 코드에서 fallback)

**근거**: 
- `cdk.json`에 개발 환경 기본값을 정의하여 로컬 개발 편의성 제공
- 코드에서 fallback으로 누락된 context 처리
- 예: `environment = self.node.try_get_context("environment") or "dev"`

**영향 범위**: 모든 스택의 context 읽기 로직

---

#### Q1-7: Context 오버라이드 방법
**질문**: Context 값을 오버라이드할 때 CLI 플래그만 사용하는가, 환경변수도 지원하는가?

**선택지**:
- [x] A. CLI 플래그만 (`-c key=value`)
- [ ] B. 환경변수도 지원 (예: `CDK_CONTEXT_environment=prod`)
- [ ] C. 둘 다 지원 (환경변수가 CLI보다 낮은 우선순위)

**제안**: A (CLI 플래그만)

**근거**: 
- CDK 표준은 CLI 플래그 (`-c key=value`)
- 환경변수 지원은 CDK 네이티브 기능 아님 (추가 구현 필요)
- 명시적 CLI 플래그가 배포 투명성 향상

**영향 범위**: 배포 스크립트, CI/CD 파이프라인

---

#### Q1-8: 민감한 context 값 관리
**질문**: ACM 인증서 ARN 등 민감한 context 값은 어떻게 관리하는가?

**선택지**:
- [x] A. CLI 플래그로 전달, `cdk.json`에 하드코딩하지 않음
- [ ] B. AWS Systems Manager Parameter Store에서 조회
- [ ] C. AWS Secrets Manager에서 조회
- [ ] D. 환경변수로 전달

**제안**: A (CLI 플래그로 전달)

**근거**: 
- ACM 인증서 ARN은 민감 정보가 아닌 리소스 식별자 (공개 가능)
- CLI 플래그로 전달하면 배포 명령어가 명확 (`cdk deploy -c acm_certificate_arn=arn:...`)
- CI/CD에서는 Parameter Store/Secrets Manager에서 조회 후 CLI 플래그로 전달 가능

**영향 범위**: 배포 절차, CI/CD 스크립트

---

#### Q1-9: CDK 테스트 코드 구조
**질문**: CDK snapshot 테스트 코드는 어떤 구조로 작성하는가?

**선택지**:
- [x] A. `tests/` 디렉토리에 스택별 테스트 파일 (`test_network_stack.py` 등)
- [ ] B. `tests/unit/` (unit test) + `tests/integration/` (배포 테스트) 분리
- [ ] C. 기타: _______

**제안**: A (`tests/` 하위에 스택별 테스트 파일)

**근거**: 
- v1에서는 snapshot 테스트만 수행 (CloudFormation 템플릿 검증)
- Integration 테스트는 Build & Test 단계에서 실제 배포로 검증
- 단순한 디렉토리 구조로 시작

**영향 범위**: 테스트 코드 작성, CI/CD 테스트 스크립트

---

### 범주 2: Networking (네트워킹)

#### Q2-1: VPC 생성 방식
**질문**: VPC를 L2 construct로 생성하는가, L1 construct로 생성하는가?

**선택지**:
- [x] A. L2 construct (`ec2.Vpc()`)
- [ ] B. L1 construct (`ec2.CfnVpc()`)

**제안**: A (L2 construct)

**근거**: 
- L2 construct는 더 높은 추상화 제공 (기본값 자동 설정)
- DNS Hostnames/Support, Internet Gateway 자동 생성
- L1은 모든 속성을 수동 설정해야 하여 복잡도 증가

**영향 범위**: NetworkStack VPC 생성 코드

---

#### Q2-2: Subnet 생성 방식
**질문**: Subnet은 어떤 생성 방식을 기본값으로 삼는가?

**선택지**:
- [ ] A. 수동 생성 (`ec2.Subnet()` 각각 정의)
- [x] B. `ec2.Vpc()` 자동 생성 (`subnet_configuration` 파라미터 사용)

**제안**: B (`ec2.Vpc()` 자동 생성 기본, subnet mask는 context로 조정)

**근거**: 
- Functional Design 5.2절의 3계층 서브넷 구조는 `subnet_configuration`만으로도 유지 가능
- CIDR/mask는 고정 정책이 아니라 context 기본값으로 두고 환경별로 조정할 수 있다.
- 개별 Subnet 수동 생성은 특수 라우팅이나 세밀한 네트워크 제어가 필요할 때만 예외적으로 선택한다.

**영향 범위**: NetworkStack Subnet 생성 코드

---

#### Q2-3: Route Table 수동 생성
**질문**: Route Table은 어떤 방식으로 관리하는가?

**선택지**:
- [ ] A. 예, 수동 생성 및 연결
- [x] B. 아니오, `ec2.Vpc()` 기본 route table 사용

**제안**: B (`ec2.Vpc()` 기본 route table 우선)

**근거**: 
- 현재 설계의 라우팅 요구는 public subnet의 인터넷 경로, isolated private subnet, VPC endpoint 연결만으로 표현 가능하다.
- 수동 Route Table 생성은 이후 특수 라우팅 요구가 생길 때 도입해도 늦지 않다.
- 기본 자동 생성 구성이 코드 복잡도를 줄이고 유지보수를 단순화한다.

**영향 범위**: NetworkStack Route Table 생성 코드

---

#### Q2-4: VPC Endpoint 생성 순서
**질문**: VPC Endpoint는 VPC 생성 직후 생성하는가, 스택 끝에서 생성하는가?

**선택지**:
- [x] A. VPC 생성 직후 생성
- [ ] B. 스택 끝에서 생성 (모든 리소스 생성 후)

**제안**: A (VPC 생성 직후)

**근거**: 
- 다른 리소스(ECS, Lambda, Aurora)가 VPC Endpoint를 참조할 수 있도록
- VPC Endpoint는 VPC 및 Subnet에만 의존하므로 조기 생성 가능

**영향 범위**: NetworkStack 리소스 생성 순서

---

#### Q2-5: Interface Endpoint와 Gateway Endpoint 메서드 분리
**질문**: Interface Endpoint와 Gateway Endpoint 생성을 별도 메서드로 분리하는가?

**선택지**:
- [x] A. 예, `_create_interface_endpoints()`, `_create_gateway_endpoints()` 분리
- [ ] B. 아니오, 단일 메서드에서 모두 생성

**제안**: A (메서드 분리)

**근거**: 
- Interface Endpoint (10개)와 Gateway Endpoint (S3 1개)는 생성 방식이 다름
- 코드 가독성 및 유지보수성 향상

**영향 범위**: NetworkStack 메서드 구조

---

#### Q2-6: Endpoint 정책 정의 방식
**질문**: VPC Endpoint 정책을 CDK에서 정의하는가, 별도 CloudFormation 리소스로 정의하는가?

**선택지**:
- [x] A. CDK에서 `iam.PolicyDocument()` 사용하여 정의
- [ ] B. 별도 CloudFormation 리소스로 정의

**제안**: A (CDK에서 `iam.PolicyDocument()` 사용)

**근거**: 
- CDK 코드 내에서 정책을 정의하여 단일 파일로 관리
- Functional Design 5.3.3절의 Endpoint 정책 상세를 코드로 직접 변환

**영향 범위**: NetworkStack VPC Endpoint 정책 코드

---

#### Q2-7: Security Group 순환 참조 처리
**질문**: Security Group 간 순환 참조 (예: ecs-sg ↔ endpoint-sg)는 어떻게 처리하는가?

**선택지**:
- [x] A. 모든 Security Group을 먼저 생성 후, Ingress/Egress 규칙을 별도로 추가 (`sg.add_ingress_rule()`)
- [ ] B. Security Group 생성 시 모든 규칙을 포함하여 한 번에 정의

**제안**: A (Security Group 생성 후 규칙 추가)

**근거**: 
- Security Group 간 순환 참조를 피하기 위해 SG 객체를 먼저 생성
- 이후 `add_ingress_rule()`, `add_egress_rule()` 메서드로 규칙 추가
- CDK가 CloudFormation에서 순환 의존성 자동 해결

**영향 범위**: NetworkStack Security Group 생성 코드

---

## P1 (High) - 중요 답변 항목

### 범주 3: Compute Infrastructure (컴퓨팅 인프라)

#### Q3-1: ECS skeleton 이미지 참조 방식
**질문**: ECS Task Definition의 skeleton 이미지 (nginx:latest)는 어떻게 참조하는가?

**선택지**:
- [x] A. `ecs.ContainerImage.from_registry("nginx:latest")`
- [ ] B. 다른 방법: _______

**제안**: A (`from_registry()` 사용, 단 Unit 1에서는 Task Definition만 등록)

**근거**:
- Unit 1에서는 ECS Service와 실제 Task 기동을 생성하지 않으므로 이미지 pull이 발생하지 않는다.
- 따라서 skeleton 단계에서는 placeholder metadata로 충분하다.
- Unit 4에서 ECS Service를 생성하기 전에 반드시 private ECR 이미지로 교체한다.

**영향 범위**: ComputeStack ECS Task Definition skeleton 코드, Unit 4 서비스 생성 전 ECR 전환 절차

---

#### Q3-2: Unit 4 ECR URI 교체 시 수정 방법
**질문**: Unit 4에서 ECS 이미지를 ECR URI로 교체 시 어떻게 수정하는가?

**선택지**:
- [x] A. `ecs.ContainerImage.from_ecr_repository(ecr_repo, tag="latest")`로 직접 수정
- [ ] B. 환경변수로 이미지 URI 전달
- [ ] C. 다른 방법: _______

**제안**: A (`from_ecr_repository()` 직접 수정)

**근거**: Functional Design 12.3절의 직접 수정 방식

**영향 범위**: Unit 4 ComputeStack 업데이트 절차

---

#### Q3-3: ADOT sidecar 이미지 버전
**질문**: ADOT Collector sidecar 이미지는 버전을 고정하는가, `latest`를 사용하는가?

**선택지**:
- [x] A. `latest` 사용 (AWS 공식 이미지로 자동 보안 패치)
- [ ] B. 특정 버전 고정 (예: `v0.34.0`)

**제안**: A (`latest` 사용)

**근거**: 
- AWS 공식 이미지로 보안 패치 자동 적용
- ADOT Collector는 안정적인 API 제공 (호환성 문제 낮음)

**영향 범위**: ComputeStack ADOT sidecar 이미지 정의

---

#### Q3-4: Lambda inline placeholder 코드 구현
**질문**: Lambda inline placeholder 코드는 `lambda_.Code.from_inline()` 사용하는가?

**선택지**:
- [x] A. 예, `from_inline("def lambda_handler...")`
- [ ] B. 다른 방법: _______

**제안**: A (`from_inline()` 사용)

**근거**: Functional Design 8.4.2절의 inline placeholder 코드

**영향 범위**: ComputeStack Lambda Function 코드

---

#### Q3-5: Unit 3 Lambda 코드 업데이트 경로
**질문**: Unit 3에서 Lambda 코드 업데이트 시 `lambda_.Code.from_asset()` 경로는?

**선택지**:
- [x] A. `../lambda` (`infra/` 기준 상대 경로, 프로젝트 루트의 `lambda/`)
- [ ] B. `src/lambda/`
- [ ] C. 다른 경로: _______

**제안**: A (`../lambda`)

**근거**:
- CDK 프로젝트 루트가 `infra/`이므로 `from_asset()` 경로도 그 기준으로 해석해야 한다.
- Lambda 함수 코드는 프로젝트 루트의 `lambda/` 디렉토리에 두고, CDK에서는 `../lambda`로 참조한다.

**영향 범위**: Unit 3 ComputeStack 업데이트, Lambda 코드 배치

---

#### Q3-6: Lambda Layer 필요성
**질문**: Lambda Function에 Lambda Layer가 필요한가?

**선택지**:
- [x] A. 불필요 (모든 의존성 Lambda 패키지에 포함)
- [ ] B. 필요 (공통 의존성 Layer로 분리)

**제안**: A (불필요)

**근거**: 
- v1에서 Lambda는 Token Service 하나뿐
- 공통 의존성이 여러 Lambda에서 공유될 필요 없음

**영향 범위**: Lambda 패키징 전략

---

#### Q3-7: ECR lifecycle policy CDK 정의
**질문**: ECR lifecycle policy는 CDK에서 정의하는가?

**선택지**:
- [x] A. 예, `repository.add_lifecycle_rule()` 사용
- [ ] B. 아니오, AWS Console에서 수동 설정

**제안**: A (CDK에서 정의)

**근거**: 
- Infrastructure as Code 원칙 준수
- Functional Design 8.5절의 lifecycle policy 명세

**영향 범위**: ComputeStack ECR Repository 생성 코드

---

#### Q3-8: Untagged/Tagged 이미지 정책 확인
**질문**: ECR lifecycle policy의 보존 기간/개수는 정책으로 고정하는가, 초기 기본값으로 두는가?

**선택지**:
- [x] A. 초기 기본값으로 둔다 (예: 30일 / 10개)
- [ ] B. 정책으로 고정한다
- [ ] C. 다른 기본값 사용: _______

**제안**: A (초기 기본값으로 정의하고 context로 조정 가능하게 유지)

**근거**:
- Lifecycle rule 자체는 IaC로 관리하되, 숫자는 운영 정책으로 못박지 않는다.
- 이미지 churn과 배포 빈도는 실제 운영 이후에 더 정확히 조정할 수 있다.

**영향 범위**: ECR lifecycle policy 설정

---

### 범주 4: Monitoring (모니터링)

#### Q4-1: AMP Workspace L2 construct 사용 가능 여부
**질문**: AMP Workspace에 CDK L2 construct가 있는가, L1 construct만 사용 가능한가?

**선택지**:
- [ ] A. L2 construct 사용 가능
- [x] B. L1 construct (`aps.CfnWorkspace()`) 사용 필요

**제안**: B (L1 construct)

**근거**: 
- CDK에 AMP L2 construct가 아직 없음 (2024년 기준)
- `aps.CfnWorkspace()` L1 construct 사용 필요

**영향 범위**: ObservabilityStack AMP Workspace 생성 코드

---

#### Q4-2: AMP remote write URL 추출 방법
**질문**: AMP remote write URL은 어떻게 구성하는가?

**선택지**:
- [x] A. `workspace.attr_workspace_id`를 사용하여 URL 구성: `https://{workspace_id}.aps-workspaces.{region}.amazonaws.com/api/v1/remote_write`
- [ ] B. CloudFormation Output에서 자동 제공
- [ ] C. 다른 방법: _______

**제안**: A (`attr_workspace_id` 사용)

**근거**: 
- L1 construct는 `attr_workspace_id` 속성 제공
- URL 형식은 AWS 문서에 명시된 표준 패턴

**영향 범위**: ObservabilityStack AMP remote write URL 구성 코드

---

#### Q4-3: AMP Workspace 참조 방식
**질문**: AMP Workspace ID와 remote write URL은 어떤 방식으로 `ComputeStack`에 전달하는가?

**선택지**:
- [ ] A. `CfnOutput()` 사용하여 수동 export
- [x] B. `ObservabilityStack` 속성을 props로 직접 전달

**제안**: B (stack props/direct reference 우선, `CfnOutput`은 운영 확인용만 사용)

**근거**: 
- ComputeStack의 ADOT sidecar 환경변수에서 참조
- Stack 인스턴스의 속성을 직접 참조하면 코드가 단순해지고 export 패턴 관리가 필요 없다.
- `CfnOutput()`은 콘솔 확인이나 운영 검증용 값 노출에만 제한하면 충분하다.

**영향 범위**: ObservabilityStack → ComputeStack 생성자 시그니처 및 속성 참조 방식

---

#### Q4-4: CloudWatch Log Group 개별 생성 확인
**질문**: CloudWatch Log Group은 각 스택에서 개별 생성하는가?

**선택지**:
- [x] A. 예, ECS/Lambda/API Gateway 로그를 각 해당 스택에서 생성
- [ ] B. 아니오, 공통 스택에서 통합 생성

**제안**: A (각 스택에서 개별 생성)

**근거**: 
- ECS/Lambda 로그는 `ComputeStack`, API Gateway 로그는 `ApiStack`에서 관리
- 스택 삭제 시 로그 그룹도 함께 삭제

**영향 범위**: ComputeStack, ApiStack Log Group 생성 코드

---

#### Q4-5: 보존 기간 환경별 분기 구현
**질문**: CloudWatch Logs 보존 기간은 환경별 코드 분기로 설정하는가?

**선택지**:
- [x] A. 예, `logs.RetentionDays.ONE_MONTH if env == "prod" else logs.RetentionDays.ONE_WEEK`
- [ ] B. 아니오, context 파라미터로 전달

**제안**: A (코드 분기)

**근거**: 
- Functional Design 3절의 환경별 차이 정의
- 보존 기간은 환경 특성에 따라 자동 결정되는 것이 자연스러움

**영향 범위**: ComputeStack, ApiStack Log Group 생성 코드

---

## P2 (Medium) - 추가 확인 항목

### 범주 5: Storage Infrastructure (스토리지 인프라)

#### Q5-1: Aurora Subnet Group 생성 위치
**질문**: Aurora Subnet Group은 DataStack에서 생성하는가?

**선택지**:
- [x] A. 예, DataStack에서 생성
- [ ] B. 아니오, NetworkStack에서 생성

**제안**: A (DataStack에서 생성)

**근거**: 
- Subnet Group은 Aurora와 밀접한 관계
- NetworkStack은 VPC/Subnet 정의만, 서비스별 Subnet Group은 각 스택에서 생성

**영향 범위**: DataStack Aurora 생성 코드

---

#### Q5-2: RDS Proxy private-data subnet 공유 여부
**질문**: RDS Proxy는 Aurora와 동일한 private-data subnet 집합을 사용하는가?

**선택지**:
- [x] A. 예, Aurora와 동일한 private-data subnets를 선택
- [ ] B. 아니오, 다른 subnet 집합을 선택

**제안**: A (동일 private-data subnets 선택)

**근거**: 
- Functional Design 6.2절에서 RDS Proxy는 private-data subnet 사용
- Aurora와 동일한 서브넷 계층에 배치하여 네트워크 latency 최소화
- Aurora의 DB Subnet Group과 RDS Proxy의 subnet selection은 같은 개념으로 취급하지 않는다.

**영향 범위**: DataStack RDS Proxy subnet selection 코드

---

## P3 (Low) - 선택 사항

### 범주 6: Shared Infrastructure (공통 인프라)

#### Q6-1: Custom Construct 필요성
**질문**: v1에서 여러 스택에서 공통 사용하는 Custom Construct가 필요한가?

**선택지**:
- [x] A. 불필요 (각 스택에서 직접 리소스 정의)
- [ ] B. 필요 (공통 패턴 추상화)

**제안**: A (불필요)

**근거**: 
- Functional Design 표 1에서 "Construct 전략: 각 스택에서 직접 리소스 정의"
- v1에서는 복잡성 최소화

**영향 범위**: `infra/constructs/` 디렉토리 생성 여부

---

#### Q6-2: `infra/constructs/` 디렉토리 생성 여부
**질문**: `infra/constructs/` 디렉토리를 생성하는가?

**선택지**:
- [x] A. 생성하지 않음 (v1에서 커스텀 Construct 없음)
- [ ] B. 생성 (향후 확장 대비)

**제안**: A (생성하지 않음)

**근거**: Q6-1에서 Custom Construct 불필요 결정 시

**영향 범위**: 프로젝트 디렉토리 구조

---

#### Q6-3: CDK Aspect 활용 범위
**질문**: 리소스 태깅, Deletion Protection 등을 CDK Aspect로 적용하는가?

**선택지**:
- [x] A. 태깅만 CDK App 레벨 Aspect (`Tags.of(app).add()`)
- [ ] B. 태깅 + Deletion Protection 모두 Aspect
- [ ] C. Aspect 미사용 (각 리소스에서 개별 설정)

**제안**: A (태깅만 Aspect, Deletion Protection은 개별 설정)

**근거**: 
- 태깅은 모든 리소스에 공통 적용 (Aspect 적합)
- Deletion Protection은 환경별 분기 필요 (개별 설정 적합)

**영향 범위**: `app.py` 태깅 로직, 각 스택의 Deletion Protection 설정

---

## 답변 요약표

| 질문 번호 | 카테고리 | 질문 | 제안 답변 | 우선순위 |
|---------|---------|------|----------|---------|
| Q1-1 | Deployment | CDK 프로젝트 초기화 방식 | B. uv 기반 수동 scaffold | P0 |
| Q1-2 | Deployment | CDK 루트 디렉토리 | A. `infra/` | P0 |
| Q1-3 | Deployment | CDK 진입점 파일 이름 | A. `app.py` | P0 |
| Q1-4 | Deployment | 환경별 계정/리전 분리 | A. 단일 계정, 단일 리전 | P0 |
| Q1-5 | Deployment | CDK bootstrap 환경별 실행 | A. 단일 계정 1회 | P0 |
| Q1-6 | Deployment | Context 기본값 위치 | C. `cdk.json` + 코드 fallback | P0 |
| Q1-7 | Deployment | Context 오버라이드 방법 | A. CLI 플래그만 | P0 |
| Q1-8 | Deployment | 민감한 context 값 관리 | A. CLI 플래그 전달 | P0 |
| Q1-9 | Deployment | CDK 테스트 코드 구조 | A. `tests/` 스택별 파일 | P0 |
| Q2-1 | Networking | VPC 생성 방식 | A. L2 construct | P0 |
| Q2-2 | Networking | Subnet 생성 방식 | B. `ec2.Vpc()` 자동 생성 기본 | P0 |
| Q2-3 | Networking | Route Table 수동 생성 | B. `ec2.Vpc()` 기본 route table 우선 | P0 |
| Q2-4 | Networking | VPC Endpoint 생성 순서 | A. VPC 생성 직후 | P0 |
| Q2-5 | Networking | Endpoint 메서드 분리 | A. 분리 | P0 |
| Q2-6 | Networking | Endpoint 정책 정의 | A. CDK `PolicyDocument()` | P0 |
| Q2-7 | Networking | SG 순환 참조 처리 | A. SG 생성 후 규칙 추가 | P0 |
| Q3-1 | Compute | ECS skeleton 이미지 | A. `from_registry()` (Task Definition only) | P1 |
| Q3-2 | Compute | Unit 4 ECR URI 교체 | A. `from_ecr_repository()` | P1 |
| Q3-3 | Compute | ADOT 이미지 버전 | A. `latest` | P1 |
| Q3-4 | Compute | Lambda inline placeholder | A. `from_inline()` | P1 |
| Q3-5 | Compute | Unit 3 Lambda 경로 | A. `../lambda` | P1 |
| Q3-6 | Compute | Lambda Layer 필요성 | A. 불필요 | P1 |
| Q3-7 | Compute | ECR lifecycle policy | A. CDK 정의 | P1 |
| Q3-8 | Compute | ECR 정책 값 확인 | A. 초기 기본값으로 정의 | P1 |
| Q4-1 | Monitoring | AMP L2 construct | B. L1 사용 | P1 |
| Q4-2 | Monitoring | AMP URL 추출 | A. `attr_workspace_id` | P1 |
| Q4-3 | Monitoring | AMP 참조 방식 | B. props 직접 전달 + output은 운영 확인용 | P1 |
| Q4-4 | Monitoring | Log Group 개별 생성 | A. 각 스택 개별 | P1 |
| Q4-5 | Monitoring | 보존 기간 분기 | A. 코드 분기 | P1 |
| Q5-1 | Storage | Subnet Group 위치 | A. DataStack | P2 |
| Q5-2 | Storage | RDS Proxy private-data subnet 공유 | A. 동일 private-data subnets | P2 |
| Q6-1 | Shared | Custom Construct | A. 불필요 | P3 |
| Q6-2 | Shared | `constructs/` 디렉토리 | A. 생성 안 함 | P3 |
| Q6-3 | Shared | CDK Aspect 범위 | A. 태깅만 Aspect | P3 |

---

## 처리 결과

- 질문 답변은 Infrastructure Design 최종 문서에 반영되었다.
- 생성 산출물:
  - `infrastructure-design.md`
  - `deployment-architecture.md`
- Unit 1 Infrastructure Design은 완료 상태로 정리되었다.

---

## 다음 단계

1. Unit 1 Code Generation 단계 진행
2. `infra/` CDK scaffold 및 스택 코드 생성
3. 생성 코드 기준 `cdk synth` 가능 구조 확보

---

**문서 끝**
