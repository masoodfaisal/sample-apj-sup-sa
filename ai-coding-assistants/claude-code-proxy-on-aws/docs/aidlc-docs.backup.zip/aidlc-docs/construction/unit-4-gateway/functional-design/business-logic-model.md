# Business Logic Model — Unit 4: Gateway

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 근거: [Component Methods](../../inception/application-design/component-methods.md), [Services](../../inception/application-design/services.md), [Design Questions](./design-questions.md)

---

## 1. 기술 결정 요약

| 항목 | 결정 |
|------|------|
| Admin 인증 | API Gateway가 주입한 Admin origin/principal 헤더 신뢰, 내부 RBAC 없음 |
| 세션 관리 | Request-scoped AsyncSession (FastAPI Depends), 명시적 commit/rollback |
| Bedrock async | run_in_executor (동기 boto3) |
| 페이지네이션 | Offset-based (page + page_size) |
| 스트리밍 에러 | Abort (즉시 연결 종료) |

---

## 2. GatewayService 오케스트레이션

### 2.1 비스트리밍 흐름 (`process_message`)

```
1. PolicyChain.evaluate(context)
   → 실패 시 UsageService.record_blocked_request() 후 예외 전파
2. session.commit()  # 읽기 트랜잭션 종료
3. AnthropicToBedrockConverter.convert_request(request, resolved_model, cache_policy)
4. loop.run_in_executor(None, bedrock_client.converse, bedrock_request)
5. BedrockToAnthropicConverter.convert_response(bedrock_resp, selected_model)
6. UsageService.record_success(context, usage_info)
7. session.commit()  # 쓰기 트랜잭션 종료
8. return AnthropicResponse
```

### 2.2 스트리밍 흐름 (`process_message_stream`)

```
1. PolicyChain.evaluate(context)
   → 실패 시 UsageService.record_blocked_request() 후 예외 전파
2. session.commit()
3. AnthropicToBedrockConverter.convert_request(request, resolved_model, cache_policy)
4. loop.run_in_executor(None, bedrock_client.converse_stream, bedrock_request)
5. StreamProcessor.stream_response(bedrock_stream, context)
   → 각 이벤트를 SSE로 변환하여 yield
   → final metadata 수신 시 UsageService.record_success()
   → upstream stream 에러 시 즉시 연결 종료 (abort)
   → metadata 이후 DB write 실패는 로그만 남기고 정상 종료
6. yield SSEEvent sequence
```

### 2.3 에러 기록 원칙

| 시점 | 동작 |
|------|------|
| Policy 차단 | zero-token usage_event 기록, 예외 전파 |
| Bedrock 호출 전 에러 | zero-token 기록 |
| Bedrock 호출 후 에러 (비스트리밍) | partial-usage 기록 (가능한 경우) |
| 스트리밍 중 에러 | 연결 abort, 에러 로그 + 메트릭, 누락 usage는 사후 보정 배치 |
| DB write 실패 | 비스트리밍은 요청 실패, 스트리밍 metadata 이후 실패는 정상 종료 + 로그/사후 보정 |

---

## 3. PolicyChain 상세 로직

### 3.1 핸들러 인터페이스

```python
class PolicyHandler(ABC):
    @abstractmethod
    async def handle(self, context: PolicyContext) -> None:
        """검증/enrichment 수행. 실패 시 도메인 예외 raise."""
        ...
```

### 3.2 PolicyContext 구조

```python
@dataclass
class PolicyContext:
    api_key: str                          # x-api-key 원문
    request: AnthropicRequest             # 원본 요청
    # enrichment 필드 (핸들러가 채움)
    virtual_key: VirtualKey | None = None
    user: User | None = None
    team: Team | None = None
    resolved_model: ModelCatalog | None = None
    cache_policy: str = "none"
    applicable_budgets: list[BudgetPolicy] = field(default_factory=list)
    warnings: list[BudgetWarning] = field(default_factory=list)
```

### 3.3 핸들러별 로직

| # | 핸들러 | 로직 | 예외 |
|---|--------|------|------|
| 1 | VirtualKeyHandler | SHA-256(api_key) → fingerprint → DB 조회. ACTIVE만 허용 | InvalidKeyError / KeyRevokedError |
| 2 | UserStatusHandler | virtual_key.user_id → User 조회. ACTIVE만 허용 | UserInactiveError |
| 3 | TeamStatusHandler | user.default_team_id → Team 조회. team-less면 no-op. ACTIVE만 허용 | TeamInactiveError |
| 4 | ModelResolverHandler | selected_model → ModelAliasMapping 우선순위 조회 → fallback. context에 resolved_model enrichment | ModelNotFoundError |
| 5 | UserModelPolicyHandler | (user_id, model_id) → UserModelPolicy 조회. allow=False면 차단 | ModelNotAllowedError |
| 6 | TeamModelPolicyHandler | (team_id, model_id) → TeamModelPolicy 조회. user override 없을 때만 적용 | ModelNotAllowedError |
| 7 | UserBudgetPreCheckHandler | scope_type=USER, scope_user_id → BudgetPolicy SELECT. hard 초과→차단, soft 초과→warning | BudgetExceededError |
| 8 | TeamBudgetPreCheckHandler | scope_type=TEAM, scope_team_id → BudgetPolicy SELECT. team-less면 no-op | BudgetExceededError |
| 9 | ModelBudgetPreCheckHandler | model_id 기반 budget SELECT | BudgetExceededError |
| 10 | CachePolicyHandler | user/team cache_policy 해석. supports_prompt_cache=False면 none downgrade. block-level cache_control 보존 | — |

---

## 4. Converter 상세 로직

### 4.1 AnthropicToBedrockConverter

| 메서드 | 핵심 변환 |
|--------|-----------|
| `convert_request` | model→modelId, system→system[], messages→messages[], tools→toolConfig, thinking→additionalModelRequestFields |
| `convert_system` | str→[{text:str}], list→그대로 |
| `convert_messages` | role 유지, content block 변환: text→text, tool_use→toolUse, tool_result→toolResult, image→image(base64), thinking→reasoning content |
| `convert_tools` | tools→toolConfig.tools[], tool_choice→toolConfig.toolChoice |
| `convert_thinking` | thinking.budget_tokens→thinking block, prior reasoning signature 재전달 |
| `apply_cache_points` | cache_policy에 따라 tools→system→messages 순서로 마지막 cacheable block에 cachePoint 삽입 |

### 4.2 BedrockToAnthropicConverter

| 메서드 | 핵심 변환 |
|--------|-----------|
| `convert_response` | output.message→content[], stopReason→stop_reason 매핑, usage→usage block |
| `convert_stream_event` | stream 시작 시 `message_start` 1회 생성, contentBlockStart/Delta/Stop→SSE content_block events, metadata→`message_delta`(usage), `messageStop`→`message_stop` |
| `extract_usage` | inputTokens/outputTokens + cache metadata 추출 |

### 4.3 stop_reason 매핑

| Bedrock stopReason | Anthropic stop_reason |
|---|---|
| end_turn | end_turn |
| tool_use | tool_use |
| max_tokens | max_tokens |
| stop_sequence | stop_sequence |
| content_filtered | end_turn (+ warning log) |

---

## 5. StreamProcessor 로직

```python
async def stream_response(bedrock_stream, context) -> AsyncGenerator[SSEEvent]:
    state = StreamState()
    iterator = bedrock_stream["stream"]
    try:
        while True:
            event = await loop.run_in_executor(None, next_event, iterator)
            if event is END_OF_STREAM:
                break
            sse_events = converter.convert_stream_event(event, state)
            for sse in sse_events:
                yield sse
            if "metadata" in event:
                usage = converter.extract_usage(event["metadata"])
                try:
                    await usage_service.record_success(context, usage)
                except Exception:
                    logger.error("Usage persistence failed after stream metadata", exc_info=True)
    except Exception:
        # abort — 연결 종료, 에러 로그
        logger.error("Stream error", exc_info=True)
        raise

# next_event()는 sync iterator에서 next()를 호출하고 종료 시 END_OF_STREAM sentinel 반환
```

---

## 6. UsageService 로직

### 6.1 record_success

```
1. ModelPricingRepository.get_active_pricing(model_id) → pricing
2. cost = calculate_cost(usage_info, pricing, cache_policy)
3. BudgetPolicyRepository.apply_costs(applicable_budgets, cost)  # atomic UPDATE...RETURNING
4. UsageEventRepository.create_event(context, usage_info, cost, status=SUCCESS)
5. session.commit()
6. MetricsService.emit_token_usage / emit_cost_usage / emit_request_duration
```

### 6.2 비용 계산 공식

```
input_cost  = input_tokens * input_price_per_1k / 1000
output_cost = output_tokens * output_price_per_1k / 1000
cache_read_cost  = cached_read_tokens * cache_read_price_per_1k / 1000
cache_write_cost = cached_write_tokens * cache_write_{policy}_price_per_1k / 1000
total_cost = input_cost + output_cost + cache_read_cost + cache_write_cost
```

---

## 7. MetricsService 로직

```python
# 앱 시작 시 초기화
meter = MeterProvider(resource=resource, metric_readers=[...]).get_meter("gateway")
token_counter = meter.create_counter("bedrock.token.usage")
cost_counter  = meter.create_counter("bedrock.cost.usage")
duration_hist = meter.create_histogram("bedrock.request.duration")

# emit 규칙: BLOCKED_* 또는 upstream usage 미확정 ERROR에는 emit하지 않음
```

Attributes: `user_id`, `team_id`, `model_id`, `is_stream`
