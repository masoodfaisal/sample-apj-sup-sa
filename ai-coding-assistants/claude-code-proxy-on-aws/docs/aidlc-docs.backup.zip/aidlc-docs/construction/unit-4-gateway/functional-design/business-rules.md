# Business Rules — Unit 4: Gateway

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 근거: [Services](../../inception/application-design/services.md), [system-nfr-decisions](../system-nfr-decisions.md)

---

## 1. 정책 평가 규칙

### 1.1 평가 순서 (불변)

핸들러 1~10 순서는 고정. 재배치 불가.

### 1.2 Fail-Closed 원칙

- 정책 데이터 조회 실패 → 요청 차단 (InternalError)
- 알 수 없는 상태값 → 요청 차단

### 1.3 Team-less 사용자 처리

- `user.default_team_id = NULL` → TeamStatusHandler no-op, TeamModelPolicyHandler/TeamBudgetPreCheckHandler no-op
- 시스템 기본 정책으로 fallback

### 1.4 Budget Window 리셋

- 런타임 경로에서 lazy 리셋: `window_started_at`이 현재 기간 이전이면 `current_used_usd=0` 리셋 후 평가
- DAILY: UTC 일 경계, MONTHLY: UTC 월 경계

### 1.5 Budget Soft/Hard Limit

- hard_limit 초과 → BudgetExceededError (즉시 차단)
- soft_limit 초과 → PolicyContext.warnings에 BudgetWarning 추가 (요청 계속)

---

## 2. 에러 매핑 규칙

| 예외 | HTTP | Anthropic error type |
|------|------|---------------------|
| InvalidKeyError | 401 | authentication_error |
| KeyRevokedError | 401 | authentication_error |
| UserInactiveError | 403 | permission_error |
| TeamInactiveError | 403 | permission_error |
| ModelNotAllowedError | 403 | permission_error |
| BudgetExceededError | 403 | permission_error |
| BedrockThrottlingError | 429 | rate_limit_error |
| BedrockError | 502 | api_error |
| ValidationError | 400 | invalid_request_error |
| InternalError | 500 | api_error |

### 2.1 에러 응답 형식 (Runtime)

```json
{"type":"error","error":{"type":"<anthropic_type>","message":"<msg>"},"request_id":"<req_id>"}
```

### 2.2 에러 응답 형식 (Admin)

```json
{"error":{"code":"<snake_case>","message":"<msg>","request_id":"<req_id>","retryable":false}}
```

---

## 3. 트랜잭션 경계 규칙

### 3.1 Runtime 요청 (services.md Q7 준수)

```
[읽기 TX] PolicyChain.evaluate() → session.commit()
[Bedrock 호출] run_in_executor (DB 커넥션 미점유)
[쓰기 TX] apply_costs() + create_event() → session.commit()
[TX 외부] MetricsService.emit_*()
```

- 단일 AsyncSession, 명시적 commit으로 트랜잭션 분리
- 쓰기 TX 실패 → 요청 실패 (부분 성공 없음)

### 3.2 Admin 요청

- 단일 트랜잭션: 서비스 로직 완료 후 commit
- 실패 시 자동 rollback
- `/v1/admin/*`는 FastAPI middleware에서 `x-admin-origin` 헤더를 필수 검증
- API Gateway는 IAM principal 식별값을 `x-admin-principal` 헤더로 전달, Admin 서비스는 이 값을 actor 식별에 사용

---

## 4. 로깅 규칙 (SECURITY-03 준수)

### 4.1 필수 로그 필드

모든 요청: `timestamp`, `level`, `message`, `request_id`
Runtime 요청 추가: `user_id`, `team_id`, `resolved_model_id`, `status`, `latency_ms`, `estimated_cost_usd`

### 4.2 로깅 금지 항목

- 프롬프트/응답 본문
- Virtual Key 평문
- KMS ciphertext
- 사용자 PII (email 등)

### 4.3 민감 필드 마스킹

- key_fingerprint: 앞 8자만 노출 (`abcd1234...`)

---

## 5. Admin API 비즈니스 규칙

### 5.1 페이지네이션

- Offset-based: `page` (default=1), `page_size` (default=100, max=1000)
- 응답: `{"items": [...], "next_page": 2 | null}`

### 5.2 Admin 서비스 공통 패턴

- 존재하지 않는 리소스 → 404
- 중복 생성 → 409
- 상태 전이 위반 → 422
- 모든 변경 → audit_events 기록
- ALB 직통 호출 등 `x-admin-origin` 검증 실패 → 403
- `x-admin-principal` 누락/파싱 실패 → 401

### 5.3 IdentitySyncService

- Identity Store API → 사용자 목록 조회 (run_in_executor)
- 신규 → INACTIVE 생성
- 기존 → 기본 정보 업데이트
- source 삭제 → INACTIVE + source_deleted_at
- sync_run 이력 기록
