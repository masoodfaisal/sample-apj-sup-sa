# Unit 4 Functional Design — 질문

기존 설계 문서(component-methods.md, services.md, API_SPEC.md, system-nfr-decisions.md)에서
Unit 4의 비즈니스 로직이 상세하게 정의되어 있습니다.
아래는 구현 수준에서 추가 확인이 필요한 항목입니다.

---

## Question 1
Admin API의 인증/인가를 어떻게 구현할까요? (API Gateway SigV4 이후 ECS에 도달한 요청)

A) API Gateway context 신뢰 — API Gateway가 SigV4 검증 완료 후 전달하는 `requestContext`의 IAM principal 정보를 신뢰하고, Gateway 내부에서는 추가 인증 없이 Admin 라우트 접근 허용
B) 내부 RBAC 추가 — API Gateway SigV4 + Gateway 내부에서 IAM principal을 admin 허용 목록과 대조하여 이중 검증
C) Other (please describe after [Answer]: tag below)

[Answer]: A

## Question 2
Repository 레이어의 세션 관리 패턴을 어떻게 할까요?

A) Request-scoped session — FastAPI Depends로 요청당 단일 AsyncSession 주입, 요청 종료 시 자동 close. 명시적 commit/rollback으로 트랜잭션 분리 (services.md Q7 결정 준수)
B) Unit of Work 패턴 — 별도 UoW 클래스가 세션과 트랜잭션을 관리
C) Other (please describe after [Answer]: tag below)

[Answer]: A

## Question 3
Bedrock Converse API 호출 시 async 처리를 어떻게 할까요?

A) aiobotocore/aioboto3 — 네이티브 async boto3 클라이언트 사용
B) run_in_executor — 동기 boto3를 asyncio executor에서 실행
C) Other (please describe after [Answer]: tag below)

[Answer]: B

## Question 4
Admin API의 페이지네이션 방식을 어떻게 할까요?

A) Cursor-based — `next_cursor` 토큰 기반 (대규모 데이터셋에 적합)
B) Offset-based — `page` + `page_size` 파라미터 (단순, 소규모 데이터)
C) Other (please describe after [Answer]: tag below)

[Answer]: B

## Question 5
스트리밍 응답에서 Bedrock ConverseStream 이벤트를 Anthropic SSE로 변환할 때, 에러 처리를 어떻게 할까요?

A) Graceful close — 스트림 중 에러 발생 시 Anthropic error event를 SSE로 전송 후 스트림 종료. 이미 전송된 partial response는 유지
B) Abort — 스트림 중 에러 발생 시 즉시 연결 종료 (클라이언트가 재시도)
C) Other (please describe after [Answer]: tag below)

[Answer]: B
