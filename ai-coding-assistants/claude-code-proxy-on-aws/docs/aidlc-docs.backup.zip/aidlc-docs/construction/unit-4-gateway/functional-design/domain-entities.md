# Domain Entities — Unit 4: Gateway

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 근거: [Component Methods](../../inception/application-design/component-methods.md), [Design Questions](./design-questions.md)

---

## 1. Repository 레이어

### 1.1 공통 패턴

```python
class BaseRepository:
    def __init__(self, session: AsyncSession):
        self.session = session
```

- 모든 Repository는 AsyncSession을 생성자 주입
- FastAPI Depends 체인으로 request-scoped session 공유
- SELECT 쿼리: `await session.execute(select(...))`
- INSERT/UPDATE: `session.add()` / 직접 `execute(update(...))`
- commit은 서비스 레이어에서 명시적 호출

### 1.2 Repository 목록 (14개)

| Repository | 주요 쿼리 패턴 |
|------------|---------------|
| UserRepository | `get_by_id`, `get_by_identity_store_id`, `update_status`, `list(page, page_size)` |
| TeamRepository | `get_by_id`, `get_by_name`, `create`, `update`, `list(page, page_size)` |
| TeamMembershipRepository | `add_member`, `remove_member`, `get_by_user_and_team`, `get_default_team(user_id)`, `list_by_team(page, page_size)` |
| VirtualKeyRepository | `get_active_by_user(user_id)`, `get_by_fingerprint(fp)`, `create`, `update_status` |
| ModelCatalogRepository | `get_by_id`, `get_active_list`, `create`, `update_status` |
| ModelAliasMappingRepository | `resolve_model(selected_model)` — priority ASC 순회, `get_fallback`, `create`, `update` |
| ModelPricingRepository | `get_active_pricing(model_id)` — effective_from DESC, active=True LIMIT 1 |
| UserModelPolicyRepository | `get_policy(user_id, model_id)`, `set_policy` (upsert) |
| TeamModelPolicyRepository | `get_policy(team_id, model_id)`, `set_policy` (upsert) |
| BudgetPolicyRepository | `get_applicable(scope_type, scope_id, model_id, period)`, `create`, `update`, `apply_costs(policies, cost)` — atomic UPDATE...RETURNING |
| UsageEventRepository | `create_event`, `list_by_user(page, page_size)`, `list_by_team(page, page_size)` |
| UsageAggRepository | `get_daily(filters, page)`, `get_monthly(filters, page)`, `upsert_daily`, `upsert_monthly` |
| AuditEventRepository | `create_event`, `list_events(filters, page)` |
| IdentitySyncRunRepository | `create_run`, `update_run`, `get_latest` |

### 1.3 BudgetPolicyRepository.apply_costs 상세

```sql
UPDATE budget_policies
SET current_used_usd = current_used_usd + :cost,
    updated_at = now()
WHERE id = :policy_id AND active = true
RETURNING current_used_usd
```

- applicable budget 목록 각각에 대해 실행
- 단일 쓰기 트랜잭션 내에서 UsageEvent INSERT와 함께 수행

---

## 2. DI 구조 (FastAPI Depends)

```
get_db_session()
  ├── get_user_repository(session)
  ├── get_team_repository(session)
  ├── get_team_membership_repository(session)
  ├── get_virtual_key_repository(session)
  ├── get_model_catalog_repository(session)
  ├── get_model_alias_mapping_repository(session)
  ├── get_model_pricing_repository(session)
  ├── get_user_model_policy_repository(session)
  ├── get_team_model_policy_repository(session)
  ├── get_budget_policy_repository(session)
  ├── get_usage_event_repository(session)
  ├── get_usage_agg_repository(session)
  ├── get_audit_event_repository(session)
  ├── get_identity_sync_run_repository(session)
  ├── get_admin_request_context()        # x-admin-origin / x-admin-principal 검증
  │
  ├── get_policy_chain(repos...) → PolicyChain([10 handlers])
  ├── get_usage_service(pricing_repo, budget_repo, event_repo, metrics)
  ├── get_gateway_service(policy_chain, converters, bedrock_client, stream_processor, usage_service)
  │
  ├── get_admin_user_service(user_repo, audit_repo, admin_ctx)
  ├── get_admin_team_service(team_repo, membership_repo, audit_repo, admin_ctx)
  ├── get_admin_model_service(catalog_repo, mapping_repo, pricing_repo, audit_repo, admin_ctx)
  ├── get_admin_budget_service(budget_repo, agg_repo, audit_repo, admin_ctx)
  ├── get_admin_virtual_key_service(key_repo, audit_repo, admin_ctx)
  ├── get_admin_usage_service(event_repo, agg_repo)
  └── get_identity_sync_service(user_repo, sync_repo, audit_repo, admin_ctx)
```

---

## 3. 파일 구조

```
gateway/
├── main.py                           # FastAPI app, lifespan, exception handlers
├── core/
│   ├── config.py                     # Settings (env vars)
│   ├── database.py                   # async engine, session factory
│   ├── dependencies.py               # FastAPI Depends 정의
│   ├── middleware.py                 # Admin origin header 검증
│   └── exceptions.py                 # AppError 계층
├── domains/
│   ├── runtime/
│   │   ├── router.py                 # POST /v1/messages, GET /v1/models, GET /healthz
│   │   ├── services.py               # GatewayService
│   │   ├── converter/
│   │   │   ├── __init__.py
│   │   │   ├── request_converter.py  # AnthropicToBedrockConverter
│   │   │   └── response_converter.py # BedrockToAnthropicConverter
│   │   ├── streaming.py              # StreamProcessor
│   │   └── bedrock_client.py         # BedrockClient (run_in_executor)
│   ├── policy/
│   │   ├── engine.py                 # PolicyChain
│   │   ├── context.py                # PolicyContext, BudgetWarning
│   │   └── handlers/
│   │       ├── __init__.py
│   │       ├── virtual_key.py
│   │       ├── user_status.py
│   │       ├── team_status.py
│   │       ├── model_resolver.py
│   │       ├── user_model_policy.py
│   │       ├── team_model_policy.py
│   │       ├── user_budget.py
│   │       ├── team_budget.py
│   │       ├── model_budget.py
│   │       └── cache_policy.py
│   ├── admin/
│   │   ├── router.py                 # /v1/admin/* 라우트
│   │   ├── auth.py                   # AdminRequestContext (principal 파싱)
│   │   ├── users.py
│   │   ├── teams.py
│   │   ├── models.py
│   │   ├── budgets.py
│   │   ├── virtual_keys.py
│   │   └── usage.py
│   ├── sync/
│   │   ├── router.py
│   │   └── services.py
│   └── usage/
│       ├── services.py               # UsageService
│       ├── metrics.py                # MetricsService
│       └── rollup.py                 # UsageRollupService
├── repositories/
│   ├── __init__.py
│   ├── base.py                       # BaseRepository
│   ├── user.py
│   ├── team.py
│   ├── team_membership.py
│   ├── virtual_key.py
│   ├── model_catalog.py
│   ├── model_alias_mapping.py
│   ├── model_pricing.py
│   ├── user_model_policy.py
│   ├── team_model_policy.py
│   ├── budget_policy.py
│   ├── usage_event.py
│   ├── usage_agg.py
│   ├── audit_event.py
│   └── identity_sync_run.py
└── Dockerfile
```
