# Code Summary — Unit 2: Shared Models & DB Migration

- 작성일: 2026-04-01
- 상태: Completed
- 근거: [Code Generation Plan](./code-generation-plan.md), [Functional Design](../functional-design/)

---

## 생성 결과

- `shared/` 패키지 생성
  - `shared/utils/constants.py` — 11개 `StrEnum`, `ZERO_UUID`
  - `shared/utils/hashing.py`, `shared/utils/kms.py`
  - `shared/models/*.py` — 15개 엔터티, relationship, PostgreSQL partial/expression index 정의
  - `shared/schemas/*.py` — Minimal create/update/response DTO
- `migrations/` 생성
  - `alembic.ini`, `env.py`, `script.py.mako`
  - `versions/001_initial_schema.py` — 15개 테이블 + partial unique + expression unique index
- root `docker-compose.yml` 추가
- `tests/unit/shared/` 추가
  - constants, models, hashing, kms, schemas, migration constraint 테스트
- `pyproject.toml`, `uv.lock` 업데이트
  - SQLAlchemy, Alembic, asyncpg, Pydantic, boto3, Hypothesis 의존성 추가

## 설계 반영 메모

- default team의 source of truth는 `users.default_team_id`로 구현하고 `team_memberships.is_default`는 생성하지 않았다.
- `usage_daily_agg`, `usage_monthly_agg`는 surrogate PK + `coalesce(team_id, ZERO_UUID)` unique index로 구현했다.
- `budget_policies`는 scope/period/model 기준 active uniqueness를 PostgreSQL partial unique index로 구현했다.
- enum-backed DTO 필드는 raw `str` 대신 대응 `StrEnum` 타입을 사용한다.

## 검증 결과

1. `uv lock` 성공
2. `uv run ruff check --fix shared tests/unit/shared migrations` 성공
3. `uv run python -m compileall shared migrations tests/unit/shared` 성공
4. `uv run pytest tests/unit/shared -q` 성공 (`16 passed`)
