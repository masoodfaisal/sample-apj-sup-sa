# Code Generation Plan — Unit 2: Shared Models & DB Migration

- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Functional Design](../functional-design/), [ERD v0.3](../../../../docs/ERD.md)

---

## Unit Context

| 항목 | 내용 |
|------|------|
| 컴포넌트 | C5 (Shared Models & Migration) |
| 직접 매핑 스토리 | 없음 (기반 유닛, Unit 3/4 간접 의존) |
| 의존성 | Unit 1 (Aurora, KMS Key) — 런타임 의존만, 코드 의존 없음 |
| 산출물 위치 | `shared/`, `migrations/`, `docker-compose.yml`, `pyproject.toml`, `tests/` |

---

## Generation Steps

### Step 1: Project Structure Setup
- [ ] `shared/__init__.py` 생성
- [ ] `shared/models/__init__.py` 생성
- [ ] `shared/schemas/__init__.py` 생성
- [ ] `shared/utils/__init__.py` 생성
- [ ] `pyproject.toml` 업데이트 — sqlalchemy[asyncio], asyncpg, alembic, pydantic, boto3 의존성 추가

### Step 2: Constants & Enums
- [ ] `shared/utils/constants.py` — 11개 StrEnum 정의 (UserStatus, TeamStatus, VirtualKeyStatus, ModelStatus, ScopeType, BudgetPeriod, RequestStatus, SyncRunStatus, CachePolicy, MembershipSource, MembershipRole)

### Step 3: Base Classes
- [ ] `shared/models/base.py` — DeclarativeBase, TimestampMixin, UUIDPrimaryKeyMixin, MetaData naming convention

### Step 4: ORM Models
- [ ] `shared/models/user.py` — User, TeamMembership (`users.default_team_id` source of truth, membership 존재성 검증, relationship 포함)
- [ ] `shared/models/team.py` — Team
- [ ] `shared/models/virtual_key.py` — VirtualKey (partial unique index 포함)
- [ ] `shared/models/model_catalog.py` — ModelCatalog, ModelAliasMapping, ModelPricing
- [ ] `shared/models/policy.py` — UserModelPolicy, TeamModelPolicy, BudgetPolicy (CHECK 제약 + active 정책 유일성 index 포함)
- [ ] `shared/models/usage.py` — UsageEvent, UsageDailyAgg, UsageMonthlyAgg (surrogate PK + `coalesce(team_id, ZERO_UUID)` unique index)
- [ ] `shared/models/audit.py` — AuditEvent, IdentitySyncRun
- [ ] `shared/models/__init__.py` 업데이트 — 모든 모델 re-export

### Step 5: Utility Functions
- [ ] `shared/utils/kms.py` — KmsHelper (encrypt_key, decrypt_key, generate_fingerprint)
- [ ] `shared/utils/hashing.py` — sha256_hex, generate_api_key (sk- prefix)

### Step 6: Pydantic Schemas (Minimal DB DTOs)
- [ ] `shared/schemas/user.py` — UserCreate, UserUpdate, UserResponse, TeamMembershipResponse (`status` 등 enum-backed 필드는 대응 `StrEnum` 사용)
- [ ] `shared/schemas/team.py` — TeamCreate, TeamUpdate, TeamResponse
- [ ] `shared/schemas/virtual_key.py` — VirtualKeyResponse
- [ ] `shared/schemas/model_catalog.py` — ModelCreate, ModelUpdate, ModelResponse, AliasMappingCreate, AliasMappingResponse, PricingCreate, PricingResponse
- [ ] `shared/schemas/policy.py` — UserModelPolicyCreate, UserModelPolicyResponse, TeamModelPolicyCreate, TeamModelPolicyResponse, BudgetPolicyCreate, BudgetPolicyUpdate, BudgetPolicyResponse
- [ ] `shared/schemas/usage.py` — UsageEventResponse, DailyAggResponse, MonthlyAggResponse
- [ ] `shared/schemas/audit.py` — AuditEventResponse, SyncRunResponse
- [ ] `shared/schemas/__init__.py` 업데이트

### Step 7: Alembic Setup
- [ ] `migrations/alembic.ini` — DATABASE_URL 환경변수 기반
- [ ] `migrations/env.py` — shared.models.Base.metadata target, naming convention
- [ ] `migrations/script.py.mako` — 템플릿

### Step 8: Initial Migration Script
- [ ] `migrations/versions/001_initial_schema.py` — 15개 테이블 생성 + 인덱스 + partial unique index + expression unique index + CHECK 제약
- [ ] 수동 추가 항목 반영: `budget_policies` active uniqueness index 2개, `usage_*_agg` expression unique index 2개

### Step 9: Docker Compose
- [ ] `docker-compose.yml` — PostgreSQL 16, claude_proxy DB, dev/dev 인증

### Step 10: Unit Tests
- [ ] `tests/unit/__init__.py` 생성
- [ ] `tests/unit/shared/__init__.py` 생성
- [ ] `tests/unit/shared/test_constants.py` — StrEnum 값 검증
- [ ] `tests/unit/shared/test_models.py` — 모델 인스턴스 생성, 제약조건 검증, relationship 검증, `default_team_id` 일관성 검증
- [ ] `tests/unit/shared/test_hashing.py` — sha256_hex 결정성, generate_api_key 형식/유일성
- [ ] `tests/unit/shared/test_kms.py` — KmsHelper mock 기반 encrypt/decrypt round-trip
- [ ] `tests/unit/shared/test_schemas.py` — Pydantic 스키마 직렬화/역직렬화, enum validation, `from_attributes` 검증
- [ ] PBT: encrypt→decrypt round-trip (PBT-02), sha256 결정성 invariant (PBT-03), DTO enum serialization round-trip

### Step 10.1: Migration Verification Tests
- [ ] `tests/unit/shared/test_migration_constraints.py` — `budget_policies` active uniqueness, `usage_*_agg` expression unique index, aggregate NULL team bucket 검증

### Step 11: Documentation Summary
- [ ] `aidlc-docs/construction/unit-2-shared-models/code-generation/code-summary.md` — 생성된 파일 목록, 스토리 커버리지, 확장 compliance

---

## Extension Compliance Plan

### Security Baseline
| Rule | Applicability | 조치 |
|------|--------------|------|
| SECURITY-01 | N/A | 인프라 레벨 (Unit 1) |
| SECURITY-02 | N/A | 네트워크 레벨 (Unit 1) |
| SECURITY-03 | Applicable | KMS 헬퍼에서 민감 데이터 로깅 금지 확인 |
| SECURITY-04~15 | N/A | 웹/API/인프라 레벨 |

### Property-Based Testing
| Rule | Applicability | 조치 |
|------|--------------|------|
| PBT-02 | Applicable | KMS encrypt/decrypt round-trip, Pydantic serialize/deserialize round-trip |
| PBT-03 | Applicable | sha256 결정성 invariant, StrEnum 값 일관성 |
| PBT-07+ | N/A | 상태/통합 테스트 범위 |
