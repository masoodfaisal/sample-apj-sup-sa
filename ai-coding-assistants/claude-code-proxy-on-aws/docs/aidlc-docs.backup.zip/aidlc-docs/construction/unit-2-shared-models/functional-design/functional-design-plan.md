# Functional Design Plan — Unit 2: Shared Models & DB Migration

- 작성일: 2026-04-01
- 상태: In Progress

---

## Plan

- [x] Step 1: 질문 수집 및 답변 분석
- [x] Step 2: Domain Entities 생성 — SQLAlchemy ORM 모델 상세 설계
- [x] Step 3: Business Rules 생성 — 상태 전이, 제약조건, 유효성 검증 규칙
- [x] Step 4: Business Logic Model 생성 — KMS 헬퍼, 해시 유틸, 공통 스키마, Alembic 설정

---

## Scope

| 항목 | 내용 |
|------|------|
| SQLAlchemy ORM 모델 | 14개 테이블 (ERD v0.3 기준) |
| Alembic 마이그레이션 | 환경 설정 + 초기 마이그레이션 |
| 공통 유틸리티 | KMS 헬퍼, 해시, 상수 |
| Pydantic 스키마 | 공통 DTO (shared 레벨) |
| 로컬 개발 환경 | Docker Compose (PostgreSQL) |
| 프로젝트 설정 | pyproject.toml, uv |

## NFR 스킵 근거

Unit 2는 런타임 서비스가 아닌 공유 라이브러리/모델 패키지이며, 시스템 레벨 NFR은 `system-nfr-decisions.md`에 이미 반영됨. Per-unit NFR Requirements/NFR Design 스킵.
