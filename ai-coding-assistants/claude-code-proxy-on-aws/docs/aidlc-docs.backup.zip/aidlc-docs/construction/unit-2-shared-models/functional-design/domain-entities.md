# Domain Entities — Unit 2: Shared Models & DB Migration

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [ERD v0.3](../../../../docs/ERD.md), [Design Questions](./design-questions.md)

---

## 1. 기술 결정 요약

| 항목 | 결정 |
|------|------|
| SQLAlchemy 스타일 | 2.0 — `DeclarativeBase`, `Mapped[T]`, `mapped_column` |
| 패키지 구조 | 모노레포 단일 `pyproject.toml`, `shared/`는 서브패키지 |
| Pydantic 스키마 | Minimal — DB 모델 기준 create/update/response DTO만 |
| Alembic | Autogenerate + 수동 검토 |
| Enum 관리 | DB text 컬럼 + Python `StrEnum` |

---

## 2. Base 클래스 설계

### 2.1 DeclarativeBase

```python
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import text
from datetime import datetime
from uuid import UUID, uuid4

class Base(DeclarativeBase):
    pass
```

### 2.2 TimestampMixin

모든 테이블에 공통 적용되는 `created_at`, `updated_at` 컬럼.

```python
class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        server_default=text("now()"), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        server_default=text("now()"), onupdate=text("now()"), nullable=False
    )
```

### 2.3 UUIDPrimaryKeyMixin

대부분의 테이블에 적용되는 UUID PK.

```python
class UUIDPrimaryKeyMixin:
    id: Mapped[UUID] = mapped_column(
        primary_key=True, default=uuid4
    )
```

---

## 3. 엔터티 정의

### 3.1 User

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | UUIDPrimaryKeyMixin | |
| identity_store_user_id | text | UNIQUE, NOT NULL | 외부 sync 키 |
| user_name | text | NOT NULL | |
| display_name | text | | |
| email | text | | |
| status | text | NOT NULL, default='INACTIVE' | StrEnum: ACTIVE, INACTIVE |
| source_deleted_at | timestamptz | nullable | 외부 삭제 판정 시각 |
| last_synced_at | timestamptz | nullable | |
| default_team_id | UUID FK → teams.id | nullable | 기본 팀 source of truth |
| last_login_at | timestamptz | nullable | |
| created_at, updated_at | TimestampMixin | | |

인덱스: `unique(identity_store_user_id)`, `index(status)`, `index(last_synced_at DESC)`, `index(last_login_at DESC)`

### 3.2 Team

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| name | text | UNIQUE, NOT NULL | |
| description | text | nullable | |
| status | text | NOT NULL, default='ACTIVE' | StrEnum: ACTIVE, INACTIVE |
| created_at, updated_at | TimestampMixin | | |

인덱스: `unique(name)`, `index(status)`

### 3.3 TeamMembership

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| user_id | UUID FK → users.id | NOT NULL | |
| team_id | UUID FK → teams.id | NOT NULL | |
| source | text | NOT NULL, default='ADMIN' | |
| role | text | NOT NULL, default='MEMBER' | |
| created_at, updated_at | TimestampMixin | | |

제약: `unique(user_id, team_id)`

기본 팀은 `users.default_team_id`가 유일한 source of truth다. `default_team_id`는 반드시 같은 사용자의 `team_memberships` row 중 하나를 참조해야 하며, team-less user는 `NULL`이다. Admin API의 `is_default` 입력은 저장 컬럼이 아니라 `users.default_team_id`를 갱신하는 command field로 해석한다.

### 3.4 VirtualKey

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| user_id | UUID FK → users.id | NOT NULL | |
| key_fingerprint | text | UNIQUE, NOT NULL | SHA-256 |
| key_last4 | text | NOT NULL | |
| kms_ciphertext | LargeBinary | NOT NULL | |
| status | text | NOT NULL, default='ACTIVE' | StrEnum: ACTIVE, REVOKED, ROTATED, EXPIRED |
| issued_at | timestamptz | NOT NULL | |
| expires_at | timestamptz | nullable | |
| last_used_at | timestamptz | nullable | |
| revoked_at | timestamptz | nullable | |
| created_at, updated_at | TimestampMixin | | |

제약: `unique(key_fingerprint)`, partial unique `unique(user_id) WHERE status = 'ACTIVE'`

### 3.5 ModelCatalog

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| canonical_name | text | UNIQUE, NOT NULL | 예: claude-sonnet-4-6 |
| bedrock_model_id | text | UNIQUE, NOT NULL | |
| provider | text | NOT NULL | |
| family | text | | |
| status | text | NOT NULL, default='ACTIVE' | StrEnum: ACTIVE, INACTIVE |
| supports_streaming | bool | NOT NULL, default=True | |
| supports_tools | bool | NOT NULL, default=True | |
| supports_prompt_cache | bool | NOT NULL, default=False | |
| default_max_tokens | int | | |
| created_at, updated_at | TimestampMixin | | |

### 3.6 ModelAliasMapping

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| selected_model_pattern | text | NOT NULL | exact/prefix/regex |
| target_model_id | UUID FK → model_catalog.id | NOT NULL | |
| priority | int | NOT NULL | 낮을수록 먼저 평가 |
| is_fallback | bool | NOT NULL, default=False | |
| active | bool | NOT NULL, default=True | |
| created_at, updated_at | TimestampMixin | | |

제약: `unique(selected_model_pattern, priority)`, partial unique `unique(is_fallback) WHERE is_fallback = true`

### 3.7 ModelPricing

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| model_id | UUID FK → model_catalog.id | NOT NULL | |
| input_price_per_1k | Numeric | NOT NULL | |
| output_price_per_1k | Numeric | NOT NULL | |
| cache_read_price_per_1k | Numeric | NOT NULL | |
| cache_write_5m_price_per_1k | Numeric | NOT NULL | 5분 TTL |
| cache_write_1h_price_per_1k | Numeric | NOT NULL | 1시간 TTL |
| currency | text | NOT NULL, default='USD' | |
| effective_from | timestamptz | NOT NULL | |
| active | bool | NOT NULL, default=True | |
| created_at, updated_at | TimestampMixin | | |

제약: `unique(model_id, effective_from)`

### 3.8 UserModelPolicy

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| user_id | UUID FK → users.id | NOT NULL | |
| model_id | UUID FK → model_catalog.id | NOT NULL | |
| allow | bool | NOT NULL | |
| cache_policy | text | nullable | none/5m/1h |
| max_tokens_override | int | nullable | |
| created_at, updated_at | TimestampMixin | | |

제약: `unique(user_id, model_id)`

### 3.9 TeamModelPolicy

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| team_id | UUID FK → teams.id | NOT NULL | |
| model_id | UUID FK → model_catalog.id | NOT NULL | |
| allow | bool | NOT NULL | |
| cache_policy | text | nullable | none/5m/1h |
| max_tokens_override | int | nullable | |
| created_at, updated_at | TimestampMixin | | |

제약: `unique(team_id, model_id)`

### 3.10 BudgetPolicy

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| scope_type | text | NOT NULL | StrEnum: USER, TEAM |
| scope_user_id | UUID FK → users.id | nullable | |
| scope_team_id | UUID FK → teams.id | nullable | |
| model_id | UUID FK → model_catalog.id | nullable | null=전체 예산 |
| period | text | NOT NULL | StrEnum: DAILY, MONTHLY |
| soft_limit_usd | Numeric | NOT NULL | |
| hard_limit_usd | Numeric | NOT NULL | |
| current_used_usd | Numeric | NOT NULL, default=0 | |
| window_started_at | timestamptz | NOT NULL | |
| currency | text | NOT NULL, default='USD' | |
| active | bool | NOT NULL, default=True | |
| created_at, updated_at | TimestampMixin | | |

제약: CHECK `exactly one of scope_user_id / scope_team_id is NOT NULL`, CHECK `soft_limit_usd <= hard_limit_usd`
인덱스: `index(scope_type, scope_user_id, scope_team_id, period, active)`, `index(window_started_at)`
유일성:
- user scope active 정책: `unique(scope_user_id, period, coalesce(model_id, ZERO_UUID)) WHERE scope_type = 'USER' AND active = true`
- team scope active 정책: `unique(scope_team_id, period, coalesce(model_id, ZERO_UUID)) WHERE scope_type = 'TEAM' AND active = true`

같은 scope + period + model 조합에는 active policy가 최대 1개만 존재해야 한다. `model_id = NULL`은 해당 scope/period의 전체 예산 정책을 의미한다.

### 3.11 UsageEvent

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| request_id | text | UNIQUE, NOT NULL | |
| user_id | UUID FK → users.id | NOT NULL | |
| team_id | UUID FK → teams.id | nullable | team-less 허용 |
| virtual_key_id | UUID FK → virtual_keys.id | NOT NULL | |
| resolved_model_id | UUID FK → model_catalog.id | NOT NULL | |
| budget_policy_id | UUID FK → budget_policies.id | nullable | |
| selected_model | text | NOT NULL | client input |
| request_status | text | NOT NULL | StrEnum: SUCCESS, BLOCKED_BUDGET, BLOCKED_MODEL_POLICY, BLOCKED_USER_INACTIVE, BLOCKED_TEAM_INACTIVE, ERROR_UPSTREAM, ERROR_INTERNAL |
| stop_reason | text | nullable | |
| is_stream | bool | NOT NULL | |
| input_tokens | BigInteger | NOT NULL, default=0 | |
| output_tokens | BigInteger | NOT NULL, default=0 | |
| total_tokens | BigInteger | NOT NULL, default=0 | |
| cached_read_tokens | BigInteger | NOT NULL, default=0 | |
| cached_write_tokens | BigInteger | NOT NULL, default=0 | |
| cache_details_json | JSON | nullable | |
| estimated_cost_usd | Numeric | NOT NULL, default=0 | |
| latency_ms | int | nullable | |
| bedrock_invocation_id | text | nullable | |
| trace_id | text | nullable | |
| occurred_at | timestamptz | NOT NULL | |

인덱스: `unique(request_id)`, `index(user_id, occurred_at DESC)`, `index(team_id, occurred_at DESC)`, `index(resolved_model_id, occurred_at DESC)`, `index(request_status, occurred_at DESC)`

### 3.12 UsageDailyAgg

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | UUIDPrimaryKeyMixin | surrogate PK |
| agg_date | Date | NOT NULL | UTC 기준 |
| user_id | UUID FK | NOT NULL | |
| team_id | UUID FK | nullable | NULL = team-less bucket |
| model_id | UUID FK | NOT NULL | |
| request_count | BigInteger | NOT NULL, default=0 | |
| success_count | BigInteger | NOT NULL, default=0 | |
| blocked_count | BigInteger | NOT NULL, default=0 | |
| error_count | BigInteger | NOT NULL, default=0 | |
| input_tokens | BigInteger | NOT NULL, default=0 | |
| output_tokens | BigInteger | NOT NULL, default=0 | |
| total_tokens | BigInteger | NOT NULL, default=0 | |
| cached_read_tokens | BigInteger | NOT NULL, default=0 | |
| cached_write_tokens | BigInteger | NOT NULL, default=0 | |
| estimated_cost_usd | Numeric | NOT NULL, default=0 | |
| updated_at | timestamptz | NOT NULL | |

유일성: `unique(agg_date, user_id, model_id, coalesce(team_id, ZERO_UUID))`

### 3.13 UsageMonthlyAgg

UsageDailyAgg와 동일 구조이며 집계 시점 컬럼만 `month_start`를 사용한다.

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | UUIDPrimaryKeyMixin | surrogate PK |
| month_start | Date | NOT NULL | UTC 월 시작일 |
| user_id | UUID FK | NOT NULL | |
| team_id | UUID FK | nullable | NULL = team-less bucket |
| model_id | UUID FK | NOT NULL | |
| request_count | BigInteger | NOT NULL, default=0 | |
| success_count | BigInteger | NOT NULL, default=0 | |
| blocked_count | BigInteger | NOT NULL, default=0 | |
| error_count | BigInteger | NOT NULL, default=0 | |
| input_tokens | BigInteger | NOT NULL, default=0 | |
| output_tokens | BigInteger | NOT NULL, default=0 | |
| total_tokens | BigInteger | NOT NULL, default=0 | |
| cached_read_tokens | BigInteger | NOT NULL, default=0 | |
| cached_write_tokens | BigInteger | NOT NULL, default=0 | |
| estimated_cost_usd | Numeric | NOT NULL, default=0 | |
| updated_at | timestamptz | NOT NULL | |

유일성: `unique(month_start, user_id, model_id, coalesce(team_id, ZERO_UUID))`

### 3.14 IdentitySyncRun

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| started_at | timestamptz | NOT NULL | |
| finished_at | timestamptz | nullable | |
| status | text | NOT NULL | StrEnum: STARTED, SUCCEEDED, FAILED |
| users_scanned | int | default=0 | |
| users_created | int | default=0 | |
| users_updated | int | default=0 | |
| users_inactivated | int | default=0 | |
| error_summary | text | nullable | |
| created_at | timestamptz | NOT NULL | |

### 3.15 AuditEvent

| 컬럼 | 타입 | 제약 | 비고 |
|------|------|------|------|
| id | UUID PK | | |
| actor_type | text | NOT NULL | |
| actor_id | text | NOT NULL | |
| event_type | text | NOT NULL | |
| object_type | text | NOT NULL | |
| object_id | text | NOT NULL | |
| request_id | text | nullable | |
| sync_run_id | UUID FK → identity_sync_runs.id | nullable | |
| payload_json | JSON | nullable | 변경 메타데이터만 |
| created_at | timestamptz | NOT NULL | |

---

## 4. Relationship 정의

```
User.teams            → TeamMembership (back_populates="user")
User.virtual_keys     → VirtualKey (back_populates="user")
User.model_policies   → UserModelPolicy (back_populates="user")
User.budget_policies  → BudgetPolicy (foreign_keys=[scope_user_id])
User.usage_events     → UsageEvent (back_populates="user")
User.default_team     → Team (foreign_keys=[default_team_id])

Team.memberships      → TeamMembership (back_populates="team")
Team.model_policies   → TeamModelPolicy (back_populates="team")
Team.budget_policies  → BudgetPolicy (foreign_keys=[scope_team_id])

ModelCatalog.alias_mappings → ModelAliasMapping (back_populates="target_model")
ModelCatalog.pricing        → ModelPricing (back_populates="model")
```

> Relationship은 lazy="select" 기본값. 필요 시 Unit 3/4에서 `selectinload`/`joinedload` 전략을 쿼리별로 지정.

---

## 5. 파일 구조

```
shared/
├── __init__.py
├── models/
│   ├── __init__.py          # Base, 모든 모델 re-export
│   ├── base.py              # DeclarativeBase, TimestampMixin, UUIDPrimaryKeyMixin
│   ├── user.py              # User, TeamMembership
│   ├── team.py              # Team
│   ├── virtual_key.py       # VirtualKey
│   ├── model_catalog.py     # ModelCatalog, ModelAliasMapping, ModelPricing
│   ├── policy.py            # UserModelPolicy, TeamModelPolicy, BudgetPolicy
│   ├── usage.py             # UsageEvent, UsageDailyAgg, UsageMonthlyAgg
│   └── audit.py             # AuditEvent, IdentitySyncRun
├── schemas/
│   ├── __init__.py
│   ├── user.py              # UserCreate, UserUpdate, UserResponse
│   ├── team.py              # TeamCreate, TeamUpdate, TeamResponse
│   ├── virtual_key.py       # VirtualKeyResponse
│   ├── model_catalog.py     # ModelCreate, ModelUpdate, ModelResponse, ...
│   ├── policy.py            # PolicyCreate, PolicyUpdate, PolicyResponse, ...
│   ├── budget.py            # BudgetCreate, BudgetUpdate, BudgetResponse
│   ├── usage.py             # UsageEventResponse, AggResponse
│   └── audit.py             # AuditEventResponse
└── utils/
    ├── __init__.py
    ├── kms.py               # KmsHelper
    ├── hashing.py           # hash utilities
    └── constants.py         # StrEnum 정의, 상수
```
