# Business Logic Model — Unit 2: Shared Models & DB Migration

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [Component Methods](../../../inception/application-design/component-methods.md), [Design Questions](./design-questions.md)

---

## 1. StrEnum 정의 (shared/utils/constants.py)

```python
from enum import StrEnum

class UserStatus(StrEnum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"

class TeamStatus(StrEnum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"

class VirtualKeyStatus(StrEnum):
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    ROTATED = "ROTATED"
    EXPIRED = "EXPIRED"

class ModelStatus(StrEnum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"

class ScopeType(StrEnum):
    USER = "USER"
    TEAM = "TEAM"

class BudgetPeriod(StrEnum):
    DAILY = "DAILY"
    MONTHLY = "MONTHLY"

class RequestStatus(StrEnum):
    SUCCESS = "SUCCESS"
    BLOCKED_BUDGET = "BLOCKED_BUDGET"
    BLOCKED_MODEL_POLICY = "BLOCKED_MODEL_POLICY"
    BLOCKED_USER_INACTIVE = "BLOCKED_USER_INACTIVE"
    BLOCKED_TEAM_INACTIVE = "BLOCKED_TEAM_INACTIVE"
    ERROR_UPSTREAM = "ERROR_UPSTREAM"
    ERROR_INTERNAL = "ERROR_INTERNAL"

class SyncRunStatus(StrEnum):
    STARTED = "STARTED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"

class CachePolicy(StrEnum):
    NONE = "none"
    FIVE_MIN = "5m"
    ONE_HOUR = "1h"

class MembershipSource(StrEnum):
    ADMIN = "ADMIN"

class MembershipRole(StrEnum):
    MEMBER = "MEMBER"
    ADMIN = "ADMIN"
```

---

## 2. KMS 헬퍼 (shared/utils/kms.py)

### 2.1 인터페이스

| 메서드 | 입력 | 출력 | 목적 |
|--------|------|------|------|
| `encrypt_key(plaintext_key)` | str | bytes | KMS Encrypt API로 키 암호화 |
| `decrypt_key(ciphertext)` | bytes | str | KMS Decrypt API로 키 복호화 |
| `generate_fingerprint(plaintext_key)` | str | str | SHA-256 hex digest |

### 2.2 설계 규칙

- KMS Key ID는 환경변수 `KMS_KEY_ID`에서 로드
- boto3 KMS client는 모듈 레벨 싱글턴
- `encrypt_key`: `kms.encrypt(KeyId=key_id, Plaintext=plaintext_key.encode())` → `CiphertextBlob` 반환
- `decrypt_key`: `kms.decrypt(CiphertextBlob=ciphertext)` → `Plaintext.decode()` 반환
- `generate_fingerprint`: `hashlib.sha256(plaintext_key.encode()).hexdigest()`
- KMS 호출 실패 시 예외를 그대로 전파 (caller가 처리)

---

## 3. 해시 유틸리티 (shared/utils/hashing.py)

| 함수 | 입력 | 출력 | 목적 |
|------|------|------|------|
| `sha256_hex(data)` | str | str | SHA-256 hex digest |
| `generate_api_key()` | — | str | 암호학적으로 안전한 랜덤 API key 생성 |

- `generate_api_key`: `secrets.token_urlsafe(32)` — 43자 URL-safe base64
- key 형식: `sk-` prefix + token (예: `sk-abc123...`)

---

## 4. Pydantic 스키마 설계 원칙 (shared/schemas/)

### 4.1 범위

- DB 모델 기준 create/update/response DTO만 정의
- API request/response envelope, 에러 스키마, 페이지네이션은 Unit 3/4에서 정의

### 4.2 패턴

```python
from pydantic import BaseModel, ConfigDict
from uuid import UUID
from datetime import datetime
from shared.utils.constants import UserStatus

class UserCreate(BaseModel):
    identity_store_user_id: str
    user_name: str
    display_name: str | None = None
    email: str | None = None

class UserUpdate(BaseModel):
    display_name: str | None = None
    email: str | None = None
    status: UserStatus | None = None
    default_team_id: UUID | None = None

class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    identity_store_user_id: str
    user_name: str
    display_name: str | None
    email: str | None
    status: UserStatus
    last_login_at: datetime | None
    created_at: datetime
    updated_at: datetime
```

- enum-backed 필드는 DTO에서도 raw `str` 대신 대응 `StrEnum` 타입을 사용한다. 잘못된 값은 request validation 단계에서 즉시 거부한다.
- 모든 Response 스키마: `ConfigDict(from_attributes=True)` — SQLAlchemy 모델에서 직접 변환
- Update 스키마: 모든 필드 optional (partial update)
- Create 스키마: 필수 필드만 required

---

## 5. Alembic 설정

### 5.1 디렉토리 구조

```
migrations/
├── alembic.ini
├── env.py
├── script.py.mako
└── versions/
    └── 001_initial_schema.py
```

### 5.2 설정 규칙

- `alembic.ini`: `sqlalchemy.url`은 환경변수 `DATABASE_URL`에서 로드 (env.py에서 override)
- `env.py`: `shared.models.Base.metadata`를 target_metadata로 설정
- naming convention 적용:

```python
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}
```

- autogenerate 사용, 생성 후 수동 검토 필수
- partial unique index는 autogenerate가 감지하지 못하므로 수동 추가

---

## 6. Docker Compose (로컬 개발)

```yaml
services:
  postgres:
    image: postgres:16
    environment:
      POSTGRES_DB: claude_proxy
      POSTGRES_USER: dev
      POSTGRES_PASSWORD: dev
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
```

- PostgreSQL 16 (Aurora PostgreSQL 16 호환)
- 로컬 개발/테스트 전용

---

## 7. 프로젝트 설정 (pyproject.toml)

### 7.1 의존성 추가

기존 `pyproject.toml`에 Unit 2 의존성 추가:

| 패키지 | 용도 |
|--------|------|
| `sqlalchemy[asyncio]` | ORM + async 지원 |
| `asyncpg` | PostgreSQL async driver |
| `alembic` | DB 마이그레이션 |
| `pydantic` | 스키마/DTO |
| `boto3` | KMS 호출 |

### 7.2 모노레포 구조

```
claude-code-proxy-on-aws/
├── pyproject.toml          # 단일 프로젝트 설정
├── shared/                 # 서브패키지 (직접 import)
├── lambda/                 # Unit 3
├── gateway/                # Unit 4
├── migrations/             # Alembic
├── infra/                  # Unit 1 (CDK)
├── tests/
└── docker-compose.yml
```

- `shared/`는 별도 패키지가 아닌 프로젝트 루트의 서브패키지
- Lambda/Gateway에서 `from shared.models import User` 형태로 직접 import
