# Unit 2 Functional Design — 질문

- 생성일: 2026-04-01
- 상태: Answered

ERD v0.3과 Application Design 문서에서 대부분의 스키마가 정의되어 있습니다.
아래는 구현 수준의 설계 결정이 필요한 항목입니다.

---

## Question 1
SQLAlchemy 모델 스타일을 어떻게 구성할까요?

A) SQLAlchemy 2.0 Mapped Column 스타일 (`mapped_column`, `Mapped[T]`, `DeclarativeBase`) — 타입 힌트 기반, mypy 호환
B) SQLAlchemy 1.x Classic 스타일 (`Column`, `declarative_base()`) — 레거시 호환
C) Other (please describe after [Answer]: tag below)

[Answer]: A. SQLAlchemy 2.0 스타일로 통일합니다. `DeclarativeBase`, `Mapped[T]`, `mapped_column` 기준으로 작성하고, 신규 프로젝트이므로 1.x 호환성은 고려하지 않습니다.

## Question 2
shared/ 패키지를 Lambda와 Gateway에서 어떻게 import할까요?

A) Python namespace package — `shared/` 를 독립 패키지로 두고 각 런타임에서 `pip install -e ./shared` (editable install)
B) 모노레포 단일 pyproject.toml — 프로젝트 루트에 하나의 pyproject.toml, shared/는 서브패키지로 직접 import
C) Lambda Layer — shared/를 Lambda Layer로 패키징, Gateway는 COPY로 포함
D) Other (please describe after [Answer]: tag below)

[Answer]: B. 루트 단일 `pyproject.toml` 구조를 유지하고 `shared/`는 서브패키지로 직접 import합니다. 별도 editable install이나 Lambda Layer는 추가하지 않습니다.

## Question 3
shared/ 레벨의 Pydantic 스키마 범위를 어떻게 정할까요?

A) Minimal — DB 모델의 create/update/response DTO만 (Unit 3/4에서 도메인별 스키마는 각자 정의)
B) Comprehensive — DB DTO + 공통 request/response envelope + 에러 스키마 + 페이지네이션 스키마까지 shared에 포함
C) Other (please describe after [Answer]: tag below)

[Answer]: A. Minimal 범위로 갑니다. `shared/schemas/`에는 DB 모델 기준의 create/update/response DTO만 두고, API request/response 스키마는 Unit 3/4에서 각 도메인에 맞게 정의합니다.

## Question 4
Alembic 마이그레이션 전략을 어떻게 할까요?

A) Autogenerate 기반 — `alembic revision --autogenerate`로 모델 변경 감지, 수동 검토 후 적용
B) 수동 작성 — 모든 마이그레이션을 수동으로 작성
C) Other (please describe after [Answer]: tag below)

[Answer]: A. Alembic autogenerate 기반으로 진행합니다. `revision --autogenerate`로 초안을 만들고, 생성된 migration은 항상 수동 검토 후 반영합니다.

## Question 5
enum/상태값을 DB와 애플리케이션에서 어떻게 관리할까요? (ERD 구현 메모: "PostgreSQL enum보다 text + application validation이 배포 유연성 면에서 유리")

A) Text + Python Enum — DB는 text 컬럼, Python 코드에서 `StrEnum`으로 검증 (ERD 권장)
B) PostgreSQL ENUM type — DB 레벨에서 강제
C) Other (please describe after [Answer]: tag below)

[Answer]: A. DB는 text 컬럼으로 두고, 애플리케이션에서 Python `StrEnum`으로 검증합니다. PostgreSQL ENUM type은 사용하지 않습니다.
