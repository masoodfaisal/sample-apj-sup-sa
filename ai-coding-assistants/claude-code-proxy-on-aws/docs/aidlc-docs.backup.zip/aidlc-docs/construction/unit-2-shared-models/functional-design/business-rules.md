# Business Rules — Unit 2: Shared Models & DB Migration

- 문서 버전: v1.0
- 작성일: 2026-04-01
- 상태: Draft
- 근거: [ERD v0.3](../../../../docs/ERD.md), [Domain Entities](./domain-entities.md)

---

## 1. 상태 전이 규칙

### 1.1 User Status

```
[생성] → INACTIVE
INACTIVE → ACTIVE    (Admin 명시적 활성화)
ACTIVE → INACTIVE    (Admin 비활성화 또는 source 삭제 판정)
```

- 신규 sync 사용자는 항상 `INACTIVE`로 생성
- `ACTIVE` 전환은 Admin API를 통해서만 가능
- source 삭제 판정 시 `INACTIVE` 전환 + `source_deleted_at` 기록
- `INACTIVE` 사용자는 Virtual Key 발급 및 runtime 사용 불가

### 1.2 Team Status

```
[생성] → ACTIVE
ACTIVE → INACTIVE    (Admin 비활성화)
INACTIVE → ACTIVE    (Admin 재활성화)
```

- `INACTIVE` 팀 소속 사용자의 요청은 TeamStatusHandler에서 차단

### 1.3 VirtualKey Status

```
[생성] → ACTIVE
ACTIVE → REVOKED     (Admin 폐기)
ACTIVE → ROTATED     (Admin 회전 — 기존 키)
ACTIVE → EXPIRED     (만료 시각 도달)
```

- 사용자당 `ACTIVE` 키는 최대 1개 (partial unique index)
- `ROTATED` 시 기존 키는 `ROTATED`로 전환, 신규 키 `ACTIVE` 생성
- terminal 상태(`REVOKED`, `ROTATED`, `EXPIRED`)에서 다른 상태로 전이 불가

### 1.4 ModelCatalog Status

```
[생성] → ACTIVE
ACTIVE → INACTIVE    (Admin 비활성화)
INACTIVE → ACTIVE    (Admin 재활성화)
```

### 1.5 IdentitySyncRun Status

```
[생성] → STARTED
STARTED → SUCCEEDED  (정상 완료)
STARTED → FAILED     (오류 발생)
```

- terminal 상태에서 전이 불가

---

## 2. 유일성 제약 규칙

| 테이블 | 제약 | 유형 |
|--------|------|------|
| users | `identity_store_user_id` | UNIQUE |
| teams | `name` | UNIQUE |
| team_memberships | `(user_id, team_id)` | UNIQUE |
| virtual_keys | `key_fingerprint` | UNIQUE |
| virtual_keys | `user_id WHERE status = 'ACTIVE'` | Partial UNIQUE |
| model_catalog | `canonical_name` | UNIQUE |
| model_catalog | `bedrock_model_id` | UNIQUE |
| model_alias_mappings | `(selected_model_pattern, priority)` | UNIQUE |
| model_alias_mappings | `is_fallback WHERE is_fallback = true` | Partial UNIQUE |
| model_pricing | `(model_id, effective_from)` | UNIQUE |
| user_model_policies | `(user_id, model_id)` | UNIQUE |
| team_model_policies | `(team_id, model_id)` | UNIQUE |
| budget_policies | `(scope_user_id, period, coalesce(model_id, ZERO_UUID)) WHERE scope_type = 'USER' AND active = true` | Partial UNIQUE |
| budget_policies | `(scope_team_id, period, coalesce(model_id, ZERO_UUID)) WHERE scope_type = 'TEAM' AND active = true` | Partial UNIQUE |
| usage_events | `request_id` | UNIQUE |
| usage_daily_agg | `(agg_date, user_id, model_id, coalesce(team_id, ZERO_UUID))` | UNIQUE |
| usage_monthly_agg | `(month_start, user_id, model_id, coalesce(team_id, ZERO_UUID))` | UNIQUE |

---

## 3. CHECK 제약 규칙

### 3.1 BudgetPolicy scope 배타성

```sql
CHECK (
  (scope_type = 'USER' AND scope_user_id IS NOT NULL AND scope_team_id IS NULL)
  OR
  (scope_type = 'TEAM' AND scope_team_id IS NOT NULL AND scope_user_id IS NULL)
)
```

### 3.2 BudgetPolicy limit 순서

```sql
CHECK (soft_limit_usd <= hard_limit_usd)
```

### 3.3 ModelPricing 양수 제약

```sql
CHECK (input_price_per_1k >= 0)
CHECK (output_price_per_1k >= 0)
CHECK (cache_read_price_per_1k >= 0)
CHECK (cache_write_5m_price_per_1k >= 0)
CHECK (cache_write_1h_price_per_1k >= 0)
```

### 3.4 Default team membership 존재성

`users.default_team_id IS NOT NULL`이면, 동일 `user_id`와 `default_team_id`를 갖는 `team_memberships` row가 반드시 존재해야 한다.

---

## 4. 비즈니스 검증 규칙 (Application Level)

### 4.1 TeamMembership / User — default team 일관성

- `users.default_team_id`가 기본 팀의 유일한 source of truth다.
- 멤버 추가 요청에서 `is_default = true`가 들어오면 같은 트랜잭션에서 `users.default_team_id = team_id`로 갱신한다.
- default team membership 삭제 시 `users.default_team_id`를 `NULL`로 변경하거나, 대체 default team 지정 없이 삭제를 거부한다.
- `users.default_team_id`는 반드시 해당 사용자의 membership 중 하나여야 한다.

### 4.2 VirtualKey — 활성 키 유일성

- 신규 키 생성 시, 동일 `user_id`의 기존 `ACTIVE` 키가 있으면 생성 거부 (또는 rotate 흐름으로 유도)
- DB partial unique index가 최종 안전장치

### 4.3 ModelAliasMapping — fallback 유일성

- `is_fallback = True` 설정 시, 기존 fallback row가 있으면 교체
- DB partial unique index가 최종 안전장치

### 4.4 BudgetPolicy — active 정책 유일성

- 같은 scope + period + model 조합에는 active policy가 최대 1개만 존재한다.
- `model_id = NULL`은 해당 scope/period의 전체 예산 정책이다.
- duplicate active row 생성/활성화 요청은 application level에서 거부하고, DB partial unique index가 최종 안전장치다.

### 4.5 BudgetPolicy — window 리셋

- `DAILY`: `window_started_at`이 현재 UTC 일 경계 이전이면 `current_used_usd = 0`, `window_started_at = 오늘 UTC 00:00` 리셋
- `MONTHLY`: `window_started_at`이 현재 UTC 월 경계 이전이면 리셋
- 리셋은 runtime 경로에서 lazy하게 수행 (조회 시점에 판단)

### 4.6 UsageEvent — token 일관성

- `total_tokens = input_tokens + output_tokens`
- 차단된 요청: 모든 token 필드 = 0, `estimated_cost_usd = 0`

---

## 5. Cascade 규칙

| 부모 | 자식 | ON DELETE |
|------|------|-----------|
| users | team_memberships | CASCADE |
| users | virtual_keys | CASCADE |
| users | user_model_policies | CASCADE |
| teams | team_memberships | CASCADE |
| teams | team_model_policies | CASCADE |
| model_catalog | model_alias_mappings | CASCADE |
| model_catalog | model_pricing | CASCADE |
| model_catalog | user_model_policies | CASCADE |
| model_catalog | team_model_policies | CASCADE |
| users/teams → usage_events | — | RESTRICT (삭제 불가) |
| users/teams → budget_policies | — | RESTRICT (삭제 불가) |

> 사용 이력이 있는 사용자/팀은 물리 삭제 불가. 논리 삭제(status=INACTIVE)만 허용.
